from pathlib import Path
import ctypes as C,json,os,sys,time
runtime,media,out=map(Path,sys.argv[1:]);out.mkdir()
directory=os.add_dll_directory(str(runtime));vlc=C.CDLL(str(runtime/'libvlc.dll'))
def bind(name,result,*args):
    fn=getattr(vlc,name);fn.restype=result;fn.argtypes=args;return fn
ptr=C.c_void_p
new=bind('libvlc_new',ptr,C.c_int,C.POINTER(C.c_char_p))
release=bind('libvlc_release',None,ptr)
new_media=bind('libvlc_media_new_path',ptr,C.c_char_p)
release_media=bind('libvlc_media_release',None,ptr)
new_player=bind('libvlc_media_player_new',ptr,ptr,ptr,ptr)
release_player=bind('libvlc_media_player_release',None,ptr)
set_media=bind('libvlc_media_player_set_media',None,ptr,ptr)
play=bind('libvlc_media_player_play',C.c_int,ptr)
state=bind('libvlc_media_player_get_state',C.c_int,ptr)
pause=bind('libvlc_media_player_set_pause',None,ptr,C.c_int)
stop=bind('libvlc_media_player_stop_async',C.c_int,ptr)
get_time=bind('libvlc_media_player_get_time',C.c_int64,ptr)
get_count=bind('libvlc_media_player_get_chapter_count',C.c_int,ptr)
get_chapter=bind('libvlc_media_player_get_chapter',C.c_int,ptr)
set_chapter=bind('libvlc_media_player_set_chapter',None,ptr,C.c_int)
class Chapter(C.Structure):
    _fields_=[('offset',C.c_int64),('duration',C.c_int64),('name',C.c_char_p)]
ChapterList=C.POINTER(C.POINTER(Chapter))
get_descriptions=bind('libvlc_media_player_get_full_chapter_descriptions',C.c_int,ptr,C.c_int,C.POINTER(ChapterList))
release_descriptions=bind('libvlc_chapter_descriptions_release',None,ChapterList,C.c_uint)
options=['--no-ignore-config','--config='+str(out/'vlcrc'),'--no-media-library','--no-metadata-network-access',
 '--extraintf=','--control=','--vout=vdummy','--aout=dummy','--no-hw-dec','--avcodec-threads=1',
 '--sub-fps=0','--no-sub-autodetect-file','--file-logging','--verbose=2','--log-verbose=2','--logfile='+str(out/'vlc.log')]
(out/'vlcrc').write_text('metadata-network-access=0\n',encoding='utf-8')
arguments=[s.encode('utf-8') for s in options]
instance=new(len(arguments),(C.c_char_p*len(arguments))(*arguments));assert instance
player=None;report=dict(fullBetaAccepted=False,timeUnit='microseconds',selections=[])
def wait(predicate,seconds,message):
    end=time.monotonic()+seconds
    while not predicate():
        assert state(player)!=6,'native media error'
        assert time.monotonic()<end,message
        time.sleep(.01)
try:
    player=new_player(instance,None,None);assert player
    item=new_media(str(media).encode('utf-8'));assert item
    set_media(player,item);release_media(item);assert play(player)==0
    wait(lambda:state(player)==2 and get_count(player)==3,12,'three native chapters deadline')
    pause(player,1);wait(lambda:state(player)==3,5,'pause deadline')
    descriptions=ChapterList();count=get_descriptions(player,0,C.byref(descriptions));assert count==3
    try:
        report['chapters']=[dict(offset=descriptions[i].contents.offset,duration=descriptions[i].contents.duration,
            name=descriptions[i].contents.name.decode('utf-8')) for i in range(count)]
    finally:release_descriptions(descriptions,count)
    assert [c['name'] for c in report['chapters']]==['Opening','Middle <b>äö</b>','Ending']
    assert [c['offset'] for c in report['chapters']]==[0,20_000_000,40_000_000]
    for chapter in [2,1,0]:
        set_chapter(player,chapter)
        target=chapter*20_000_000
        wait(lambda:get_chapter(player)==chapter and abs(get_time(player)-target)<100_000,8,'chapter seek deadline')
        time.sleep(.15)
        report['selections'].append(dict(chapter=get_chapter(player),time=get_time(player),state=state(player)))
        assert state(player)==3
finally:
    if player:
        stop(player);end=time.monotonic()+5
        while state(player)!=4 and time.monotonic()<end:time.sleep(.01)
        report['stopState']=state(player);release_player(player)
    release(instance)
assert report['stopState']==4
(out/'probe.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(report),flush=True)
