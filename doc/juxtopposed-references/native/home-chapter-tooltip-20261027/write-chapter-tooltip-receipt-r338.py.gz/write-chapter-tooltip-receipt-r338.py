from pathlib import Path
from hashlib import sha256
import gzip,json
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
before=read(work/'component-tooltip-before-r336/verification.json')
fixed=read(work/'component-tooltip-fixed-r337/verification.json')
assert before['negativeBaselineReproduced'] and not before['messages']
assert sum(not c['passed'] for c in before['cases'])==3
assert fixed['passed'] and len(fixed['cases'])==5 and not fixed['messages']
assert before['helperSha256']==fixed['helperSha256']==digest(repo/'modules/gui/qt/tests/test_pointing_tooltip_text.py')
runs=['ui-chapters-r334','ui-tooltip-fixed-r337']
records={name:read(work/name/'verification.json') for name in runs}
for record in records.values():
    assert record['normalExit'] and record['moduleCounts']==['602'] and not record['diagnostics']
    assert all(v for k,v in record.items() if k.endswith('Unchanged'))
native=read(work/'native-chapters-r333/verification.json')
assert all(v for k,v in native.items() if k.endswith('Unchanged'))
assert native['cases']['chapters']['normalExit']
probe=native['cases']['chapters']['probe']
assert [c['offset'] for c in probe['chapters']]==[0,20_000_000,40_000_000]
assert all(s['state']==3 and abs(s['time']-s['chapter']*20_000_000)<100_000 for s in probe['selections'])
assert probe['stopState']==4
setup=read(work/'ui-chapters-r333/verification.json')
assert setup['normalExit'] and 'chapterFixturesUnchanged' not in setup
out=repo/'doc/juxtopposed-references/native/home-chapter-tooltip-20261027'
assert not out.exists();out.mkdir();artifacts=[]
def retain(p):
    name=p.relative_to(work).as_posix()+'.gz';target=out/name;target.parent.mkdir(parents=True,exist_ok=True)
    raw=p.read_bytes();target.write_bytes(gzip.compress(raw,mtime=0))
    artifacts.append(dict(path=name,sha256=digest(target),rawSha256=sha256(raw).hexdigest()))
for name in runs+['ui-chapters-r333','native-chapters-r333']:
    root=work/name
    for filename in ['verification.json','producer.py','launch.json','staging.json','layout-fixture.json']:
        if (root/filename).is_file():retain(root/filename)
    for p in sorted((root/'observations').glob('*')):
        if p.suffix in ['.json','.png']:retain(p)
    for p in sorted(root.glob('*/probe.json')):retain(p)
for name in ['component-tooltip-before-r335','component-tooltip-before-r336','component-tooltip-fixed-r337']:
    retain(work/name/'verification.json')
for filename in ['chapter-media-r332/chapters.ffmeta','chapter-media-r332/manifest.json',
    'prepare-chapter-fixture-r332.py','chapter-worker-r333.py','run-native-chapters-r333.py',
    'run-ui-chapters-r333.py','run-ui-chapters-r334.py','run-ui-tooltip-r337.py',
    'freeze-tooltip-r337.py','build-tooltip-r337.sh','build-customizer-r337-exit.txt',
    'inputs-r333.json','inputs-r334.json','inputs-r337.json','write-chapter-tooltip-receipt-r338.py']:
    retain(work/filename)
result=dict(status='passed-scoped-chapter-workflows-and-literal-pointing-tooltip-repair',fullBetaAccepted=False,
    runtimeSha256=records['ui-tooltip-fixed-r337']['runtimeSha256'],sourceSha256=fixed['sourceSha256'],
    observations=[
        'The generated60-second MP4 adds three native chapters at0/20/40seconds to the owned video/audio/subtitle fixture. Native C API descriptions retain the literal Unicode name; selected chapters2/1/0 report40/20/0seconds plus the established1microsecond clock origin while remaining paused. Release reaches stopped4; all guards pass.',
        'Ordinary GUI329: Chapters tile opens the genuine list; offsets0/20/40and literal Middle <b>äö</b> display correctly. Double-click seeks the blue20-second frame, mouse-select/Return seeks green40, and mouse-select/Space seeks red0 while paused. Playing selection retains playback and the clock advances.',
        'The playing run reaches EOF before the later Pause action and automatically advances to plain Show.S01E02. Its chapter rows clear and the tile disables. Pause settles on the plain source; Previous starts chaptered playback and restores all three rows. No manual Next click, bounded seek latency or preserved pause across Previous is claimed.',
        'A timeline click exposes the old tooltip formatting defect: its accessibility string contains literal tags, but the screenshot renders Middle äö with bold formatting. ToolTipExt now exposes its text-format alias; PointingTooltip selects PlainText. Other ToolTipExt defaults are retained.',
        'Actual production tooltip Qt text layout compared with independent literal Text: two pass/three expected failures before, five pass after, no messages. This checks tags, br-looking text, entities, ordinary text and empty text; supplied style/MainCtx dependencies do not establish ordinary popup placement.',
        'Ordinary GUI337 renders the complete literal chapter name in its timeline tooltip. Zero/ending tooltips appear inside the window near timeline edges; paused seeking produces the expected red/blue frames and selected captions. An immediate near-end capture still has the preceding red frame; the later settled capture shows the blue ending frame and last cue. No latency bound or initial-frame pass is inferred from the stale capture.',
        'Both completed ordinary journeys exit0/602modules/zero error diagnostics/all guards, including the new chapter fixture. The early r333 launcher exits1 for a missing final chapter-fixture result key after a normal app exit; the corrected r334 run includes and passes that check. The first tooltip component attempt retains its font-directory setup warning; the same semantic failures are reproduced cleanly after selecting the existing Inter font.'
    ],limits=[
        'Chapter behavior on earlier GUI329 and the targeted tooltip replay on GUI337 have distinct scopes. The native C API probe does not render a window. Broad format/AT/DPI/theme/touch and final-package acceptance remain open.',
        'The expected fixture video cycles red/green/blue every10seconds; a57-second frame is blue. Chapter starts at0/20/40 deliberately map to red/blue/green. Raw generated media, binaries, logs/configs and databases remain ignored locally.',
        'All tests use generated owned media and isolated profiles. No dependencies were installed, no security/privacy settings changed, and no forced cleanup was used.'
    ],artifacts=artifacts)
(out/'checkpoint.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Chapters and literal timeline help - 27 October 2026

Current-tuple native/ordinary chapter checks cover genuine0/20/40-second metadata,
literal names, paused pointer/Return/Space seeking, playing continuation and
chaptered/plain-source clearing/restoration. EOF/Previous behavior is retained
with its actual playback semantics and no latency claim.

The journey exposed formatting of literal chapter tags in pointing tooltips.
PointingTooltip now uses plain text through a ToolTipExt text-format alias. The
production layout regression fails three cases before and passes all five after.
Ordinary GUI337 displays the literal name and bounded edge tooltips correctly.

Both completed apps exit0/602modules/zero errors/all guards. Initial launcher/font
setup failures and stale immediate captures remain distinct from later results.
See the [checkpoint](checkpoint.json) for exact identities and limitations.
Continue from [STATUS](../../../juxtopposed/STATUS.md); full beta acceptance is
still open.
''',encoding='utf-8',newline='\n')
for artifact in artifacts:
    p=out/artifact['path'];assert digest(p)==artifact['sha256']
    assert sha256(gzip.decompress(p.read_bytes())).hexdigest()==artifact['rawSha256']
print(out,len(artifacts),'verified artifacts',flush=True)
