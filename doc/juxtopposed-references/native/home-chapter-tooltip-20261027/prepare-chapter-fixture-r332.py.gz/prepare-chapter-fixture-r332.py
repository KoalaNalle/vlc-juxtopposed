from pathlib import Path
from hashlib import sha256
import json,subprocess
work=Path(__file__).resolve().parent
source=work/'attachment-media-r85/Show.S01E01.mp4'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
before=digest(source)
out=work/'chapter-media-r332';assert not out.exists();out.mkdir()
metadata=out/'chapters.ffmeta'
metadata.write_text(''';FFMETADATA1
[CHAPTER]
TIMEBASE=1/1000
START=0
END=20000
title=Opening
[CHAPTER]
TIMEBASE=1/1000
START=20000
END=40000
title=Middle <b>äö</b>
[CHAPTER]
TIMEBASE=1/1000
START=40000
END=60000
title=Ending
''',encoding='utf-8',newline='\n')
linux=lambda p:'/mnt/c/'+p.as_posix().split(':/',1)[1]
target=out/'Owned chapters.mp4'
command=['wsl.exe','-d','VLC-Juxtopposed-Home-20261018','--exec','/usr/bin/ffmpeg',
 '-hide_banner','-v','error','-nostdin','-i',linux(source),'-i',linux(metadata),
 '-map','0','-map_metadata','0','-map_chapters','1','-c','copy','-movflags','+faststart',linux(target)]
result=subprocess.run(command,capture_output=True,text=True,timeout=30)
assert result.returncode==0,result.stderr
probe_command=['wsl.exe','-d','VLC-Juxtopposed-Home-20261018','--exec','/usr/bin/ffprobe','-v','error','-show_chapters','-of','json',linux(target)]
probe=subprocess.run(probe_command,capture_output=True,text=True,encoding='utf-8',timeout=15)
assert probe.returncode==0,probe.stderr
chapters=json.loads(probe.stdout)['chapters'];assert len(chapters)==3
assert [c['tags']['title'] for c in chapters]==['Opening','Middle <b>äö</b>','Ending']
assert before==digest(source)
(out/'manifest.json').write_text(json.dumps(dict(synthetic=True,sourceUnchanged=True,sourceSha256=before,
 files={p.name:digest(p) for p in [metadata,target]},command=command,probeCommand=probe_command,chapters=chapters),indent=2)+'\n',encoding='utf-8',newline='\n')
print(out,flush=True)
