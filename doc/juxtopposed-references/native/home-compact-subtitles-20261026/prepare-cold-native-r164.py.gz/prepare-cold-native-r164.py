from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'build-r162.sh').read_text(encoding='utf-8').replace('r162','r164')
target=work/'build-r164.sh';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared fresh native build after materializing QByteArray prefix',flush=True)
