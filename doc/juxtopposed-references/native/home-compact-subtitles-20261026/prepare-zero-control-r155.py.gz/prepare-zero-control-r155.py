from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'run-ui-notice-r153.py').read_text(encoding='utf-8')
old="shutil.copyfile(work/'subtitle-r130-bin/libsubtitle_plugin.dll',subtitle)"
assert old in text
text=text.replace(old,"shutil.copyfile(base/subtitle_name,subtitle)")
target=work/'run-ui-zero-legacy-r155.py';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared legacy subtitle demux comparison; same ordinary Core/GUI',flush=True)
