from pathlib import Path
from hashlib import sha256
import re
work=Path(__file__).resolve().parent
text=(work/'build-core-r172.sh').read_text(encoding='utf-8').replace('r172','r173')
expected=sha256((work/'core-r172-bin/libvlccore.dll').read_bytes()).hexdigest()
text=re.sub(r'(= )[a-f0-9]{64}(\n)',r'\g<1>'+expected+r'\2',text,count=1)
assert expected in text
target=work/'build-core-r173.sh';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared diagnostic-only current input/timer eligibility trace',flush=True)
