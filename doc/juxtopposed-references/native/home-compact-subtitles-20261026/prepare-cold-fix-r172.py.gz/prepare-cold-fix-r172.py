from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'build-core-r171.sh').read_text(encoding='utf-8').replace('r171','r172')
text=text.replace('08606660e6d4059081a483d5bc3ea7bec2cc5c0a6a01972a84fb18bc7de885a7','a58fc29497e21973fd2eef941ed2e1d08af5a8280d7831807f0f0d620b2844bb')
target=work/'build-core-r172.sh';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared current paused input-time fallback when both output timer points are unavailable',flush=True)
