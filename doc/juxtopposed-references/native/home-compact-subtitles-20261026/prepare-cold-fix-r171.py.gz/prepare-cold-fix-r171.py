from pathlib import Path
from hashlib import sha256
import json
work=Path(__file__).resolve().parent;repo=work.parents[1]
manifest=json.loads((work/'inputs-r167.json').read_text())
for name in ['src/video_output/video_output.c','src/video_output/vout_subpictures.c']:
    assert sha256((repo/name).read_bytes()).hexdigest()==manifest['files'][name],name
assert 'origin refresh trace' not in (repo/'src/player/input.c').read_text(encoding='utf-8')
text=(work/'build-core-r170.sh').read_text(encoding='utf-8').replace('r170','r171')
text=text.replace('f0b13ed1ed4e2631b902e7e7b021e7f6c5dc1c56c5c51c27d8d71984ef8d1534','08606660e6d4059081a483d5bc3ea7bec2cc5c0a6a01972a84fb18bc7de885a7')
target=work/'build-core-r171.sh';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
print('Restored renderer source identities; prepared clean paused-origin fallback Core',flush=True)
