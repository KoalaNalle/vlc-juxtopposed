#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
native="$base/owned-single-frame-native-20261026-r158"
ordinary="$base/owned-single-frame-ordinary-20261026-r158"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-r158.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-r158-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = ad8f4c62a6ab8565388a46d7ad9cb40c817d24d7ac139ba936720e8075f09c6a
test ! -e "$ordinary"
test ! -e "$work/ordinary-r158-bin"
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/build-windows/beta-subtitle-sync-20261025/ordinary.mk" -j2 QA_OUT="$ordinary" owned-ordinary-subtitle-sync
mkdir "$work/ordinary-r158-bin"
cp "$ordinary/.libs/libqt_plugin.dll" "$work/ordinary-r158-bin/"
sha256sum "$work/ordinary-r158-bin/libqt_plugin.dll"
