from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'build-core-r169.sh').read_text(encoding='utf-8').replace('r169','r170')
text=text.replace('ad8f4c62a6ab8565388a46d7ad9cb40c817d24d7ac139ba936720e8075f09c6a','f0b13ed1ed4e2631b902e7e7b021e7f6c5dc1c56c5c51c27d8d71984ef8d1534')
target=work/'build-core-r170.sh';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared diagnostic-only paused-source target trace',flush=True)
