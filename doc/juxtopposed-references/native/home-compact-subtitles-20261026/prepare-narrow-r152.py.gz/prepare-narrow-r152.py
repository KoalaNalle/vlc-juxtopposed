from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'run-ui-cue-r150.py').read_text(encoding='utf-8')
old=" '--fullscreen','--rate='+rate"
assert old in text
text=text.replace(old," '--rate='+rate")
text=text.replace("scope='Ordinary attachment file/folder/playlist, default selection and cold persistence. Generated fixtures only; actual Computer Use observations required.'", "scope='Ordinary narrow subtitle failure notice, complete detailed error and replacement recovery on the current cue-clock candidate. Generated fixtures only; actual Computer Use observations required.'")
assert "'--fullscreen'" not in text
target=work/'run-ui-notice-r152.py';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared current-tuple ordinary window runner',flush=True)
