from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'build-core-r136.sh').read_text(encoding='utf-8').replace('r136','r169')
text=text.replace('f33bec1fcc121d3654177d0962847e57abb8f5e67a0da957cd4c5d3139e38126','ad8f4c62a6ab8565388a46d7ad9cb40c817d24d7ac139ba936720e8075f09c6a')
target=work/'build-core-r169.sh';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared private origin-clock trace; this Core is diagnostic only',flush=True)
