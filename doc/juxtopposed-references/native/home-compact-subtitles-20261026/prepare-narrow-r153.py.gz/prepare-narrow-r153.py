from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'run-ui-notice-r152.py').read_text(encoding='utf-8')
text=text.replace(" '--rate='+rate", " '--no-qt-video-autoresize','--rate='+rate")
assert "'--no-qt-video-autoresize'" in text
target=work/'run-ui-notice-r153.py';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
print('Disabled media-driven resizing only in the isolated notice test',flush=True)
