from pathlib import Path
from hashlib import sha256
import json,re
work=Path(__file__).resolve().parent;repo=work.parents[1]
manifest=json.loads((work/'inputs-r167.json').read_text())
name='src/player/input.c';target=repo/name
current=target.read_text(encoding='utf-8')
assert 'origin fallback trace' in current and 'const vlc_tick_t paused_time' in current
raw=Path(manifest['sourceCopies'][name]).read_bytes()
assert sha256(raw).hexdigest()==manifest['files'][name]
target.write_bytes(raw)
for name in ['src/player/input.c','src/video_output/video_output.c','src/video_output/vout_subpictures.c']:
    assert sha256((repo/name).read_bytes()).hexdigest()==manifest['files'][name],name
text=(work/'build-core-r173.sh').read_text(encoding='utf-8').replace('r173','r174')
expected=sha256((work/'core-r173-bin/libvlccore.dll').read_bytes()).hexdigest()
text=re.sub(r'(= )[a-f0-9]{64}(\n)',r'\g<1>'+expected+r'\2',text,count=1)
assert expected in text
target=work/'build-core-r174.sh';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
(work/'candidate-restored-r174.json').write_text(json.dumps(dict(
    sourceInputRevision='r167',restored=['src/player/input.c','src/video_output/video_output.c','src/video_output/vout_subpictures.c'],
    selectedTestedCore='core-r136-bin/libvlccore.dll',failedAttemptsNotSelected=['r169','r170','r171','r172','r173'],
    note='All temporary diagnostics and unsuccessful cold-start fallback edits removed; strict failing regression retained.'),indent=2)+'\n',encoding='utf-8')
print('Restored exact tested production source; native cold-start regression remains open',flush=True)
