#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-core-r172.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-core-r172-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = a58fc29497e21973fd2eef941ed2e1d08af5a8280d7831807f0f0d620b2844bb
test ! -e "$work/core-r172-bin"
make -C "$base/win64/src" -j2 libvlccore.la
mkdir "$work/core-r172-bin"
cp "$base/win64/src/.libs/libvlccore.dll" "$work/core-r172-bin/"
cp "$base/win64/src/player/.deps/libvlccore_la-input.Plo" "$work/core-r172-bin/player-input.Plo"
sha256sum "$work/core-r172-bin/libvlccore.dll"
