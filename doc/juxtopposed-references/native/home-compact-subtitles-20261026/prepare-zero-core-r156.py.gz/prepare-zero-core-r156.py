from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'run-ui-zero-legacy-r155.py').read_text(encoding='utf-8')
old="work/'core-r136-bin/libvlccore.dll'"
assert old in text
text=text.replace(old,"work/'core-r117-bin/libvlccore.dll'")
target=work/'run-ui-zero-core-r156.py';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared pre-picture-clock Core with legacy demux comparison',flush=True)
