#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-core-r170.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-core-r170-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = f0b13ed1ed4e2631b902e7e7b021e7f6c5dc1c56c5c51c27d8d71984ef8d1534
test ! -e "$work/core-r170-bin"
make -C "$base/win64/src" -j2 libvlccore.la
mkdir "$work/core-r170-bin"
cp "$base/win64/src/.libs/libvlccore.dll" "$work/core-r170-bin/"
cp "$base/win64/src/player/.deps/libvlccore_la-input.Plo" "$work/core-r170-bin/player-input.Plo"
sha256sum "$work/core-r170-bin/libvlccore.dll"
