#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-core-r169.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-core-r169-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = ad8f4c62a6ab8565388a46d7ad9cb40c817d24d7ac139ba936720e8075f09c6a
test ! -e "$work/core-r169-bin"
make -C "$base/win64/src" -j2 libvlccore.la
mkdir "$work/core-r169-bin"
cp "$base/win64/src/.libs/libvlccore.dll" "$work/core-r169-bin/"
cp "$base/win64/src/player/.deps/libvlccore_la-input.Plo" "$work/core-r169-bin/player-input.Plo"
sha256sum "$work/core-r169-bin/libvlccore.dll"
