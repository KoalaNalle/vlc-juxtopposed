#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-core-r171.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-core-r171-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 08606660e6d4059081a483d5bc3ea7bec2cc5c0a6a01972a84fb18bc7de885a7
test ! -e "$work/core-r171-bin"
make -C "$base/win64/src" -j2 libvlccore.la
mkdir "$work/core-r171-bin"
cp "$base/win64/src/.libs/libvlccore.dll" "$work/core-r171-bin/"
cp "$base/win64/src/player/.deps/libvlccore_la-input.Plo" "$work/core-r171-bin/player-input.Plo"
sha256sum "$work/core-r171-bin/libvlccore.dll"
