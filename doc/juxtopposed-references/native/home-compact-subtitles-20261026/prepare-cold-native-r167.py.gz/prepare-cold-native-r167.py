from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'build-r164.sh').read_text(encoding='utf-8').replace('r164','r167')
target=work/'build-r167.sh';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared second-capture diagnostic without changing the first-frame assertion',flush=True)
