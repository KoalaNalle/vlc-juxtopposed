from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'run-ui-layout-r158.py').read_text(encoding='utf-8')
old='revision,label,previous,rate,association=sys.argv[1:];'
assert old in text
text=text.replace(old,"revision,label,previous,rate,association,policy,style=sys.argv[1:]; assert policy in ['0','1','2'] and style in ['redesigned','classic'];")
old=" '--no-qt-video-autoresize','--rate='+rate"
assert old in text
text=text.replace(old," '--no-qt-video-autoresize','--qt-controls-auto-hide='+policy,'--qt-controls-hide-timeout=1000',('--qt-juxtopposed-controls' if style=='redesigned' else '--no-qt-juxtopposed-controls'),'--rate='+rate")
target=work/'run-ui-layout-policy-r159.py';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared explicit fixed/fullscreen-only/auto-hide and traditional-control comparisons',flush=True)
