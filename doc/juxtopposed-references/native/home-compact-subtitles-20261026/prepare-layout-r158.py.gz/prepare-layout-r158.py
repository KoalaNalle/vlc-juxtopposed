from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'build-gui-r150.sh').read_text(encoding='utf-8').replace('r150','r158')
target=work/'build-gui-r158.sh';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
text=(work/'run-ui-notice-r153.py').read_text(encoding='utf-8').replace('ordinary-r150-bin','ordinary-r158-bin')
target=work/'run-ui-layout-r158.py';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared ordinary GUI layout repair and isolated runner',flush=True)
