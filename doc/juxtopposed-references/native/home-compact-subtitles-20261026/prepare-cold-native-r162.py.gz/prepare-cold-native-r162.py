from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'build-r135.sh').read_text(encoding='utf-8').replace('r135','r162')
text=text.replace('f33bec1fcc121d3654177d0962847e57abb8f5e67a0da957cd4c5d3139e38126','ad8f4c62a6ab8565388a46d7ad9cb40c817d24d7ac139ba936720e8075f09c6a')
target=work/'build-r162.sh';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
text=(work/'run-native-subtitle-r130.py').read_text(encoding='utf-8')
old="elif mode=='late-fps':command+=['fpsResetBeforeFirstCue']"
assert old in text
text=text.replace(old,old+"\nelif mode=='cold-origin':command+=['attachmentColdCaptionAtOrigin']")
target=work/'run-native-cold-r162.py';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared native origin-caption regression without a user seek or resume',flush=True)
