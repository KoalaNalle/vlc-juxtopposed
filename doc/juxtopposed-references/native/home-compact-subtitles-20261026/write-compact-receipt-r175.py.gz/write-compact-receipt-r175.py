from pathlib import Path
from hashlib import sha256
import gzip,json
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
out=repo/'doc/juxtopposed-references/native/home-compact-subtitles-20261026'
assert not out.exists()
uis=['ui-narrow-r152','ui-narrow-r153','ui-narrow-cold-r154','ui-zero-legacy-r155',
     'ui-zero-core-r156','ui-layout-before-r157','ui-layout-after-r158',
     'ui-layout-fs-only-r159','ui-layout-auto-r160','ui-layout-classic-r161','ui-notice-final-r163']
for name in uis:
    v=read(work/name/'verification.json')
    assert v['normalExit'] and all(v[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','pluginCacheUnchanged']),name
for name in ['cold-origin-software-r164','cue-final-r174','native-final-software-r174']:
    v=read(work/name/'verification.json');assert v['status']=='terminal' and v['exitCode']==0,name
    assert all(i['type']=='pass' for f in v['functions'] for i in f['incidents']),name
    assert all(v[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged']),name
failed=['cold-origin-d3d11-r165','cold-origin-old-core-r166','cold-origin-second-r168',
        'cold-origin-trace-r169','cold-origin-target-r170','cold-origin-fixed-r171',
        'cold-origin-input-r172','cold-origin-eligibility-r173']
for name in failed:
    v=read(work/name/'verification.json');assert v['status']=='terminal' and v['exitCode']==2,name
hardware=read(work/'native-final-d3d11-r174/verification.json')
assert hardware['status']=='terminal'
assert all(hardware[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged'])
final=read(work/'ui-notice-final-r163/verification.json')
restored=read(work/'candidate-restored-r174.json')
out.mkdir();artifacts=[]
def retain(p,name=None):
    raw=p.read_bytes();relative=name or p.relative_to(work).as_posix();target=out/(relative+'.gz')
    assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(raw,mtime=0))
    artifacts.append(dict(path=target.relative_to(out).as_posix(),sha256=digest(target),rawSha256=sha256(raw).hexdigest()))
runs=uis+['cold-origin-software-r164']+failed+['cue-final-r174','native-final-software-r174','native-final-d3d11-r174']
for name in runs:
    for p in sorted((work/name).rglob('*')):
        parts=p.relative_to(work/name).parts
        if not p.is_file() or any(x in parts for x in ['runtime','temp','userdata']):continue
        if p.name in ['config-before.txt','config-after.txt']:continue
        if p.suffix in ['.json','.xml','.log','.txt','.png','.jpg']:retain(p)
sources=['modules/gui/qt/player/qml/Player.qml','modules/gui/qt/tests/test_player_subtitle_delay.cpp',
         'src/player/input.c','src/video_output/video_output.c','src/video_output/vout_subpictures.c']
for revision in ['r156','r158','r162','r164','r167','r169','r170','r171','r172','r173','r174']:
    m=read(work/f'inputs-{revision}.json');retain(work/f'inputs-{revision}.json')
    for name in sources:
        p=Path(m['sourceCopies'][name]);assert digest(p)==m['files'][name]
        retain(p,f'sources/{revision}/{name}')
for pattern in ['prepare-narrow-r15*.py','prepare-zero-*-r15*.py','prepare-layout-*.py',
                'prepare-cold-*.py','build-gui-r158.sh','build-r162*','build-r164*','build-r167*',
                'build-core-r169*','build-core-r170*','build-core-r171*','build-core-r172*',
                'build-core-r173*','build-core-r174*','restore-cold-candidate-r174.py',
                'candidate-restored-r174.json','run-ui-notice-r15*.py','run-ui-zero-*.py',
                'run-ui-layout-*.py','run-native-cold-r162.py','write-compact-receipt-r175.py']:
    for p in sorted(work.glob(pattern)):
        if p.is_file() and not any(a['path']==p.relative_to(work).as_posix()+'.gz' for a in artifacts):retain(p)
failures=[dict(function=f['name'],incidents=[i for i in f['incidents'] if i['type']!='pass'])
          for f in hardware['functions'] if any(i['type']!='pass' for i in f['incidents'])]
record=dict(status='scoped-checkpoint-beta-incomplete',fullBetaAccepted=False,artifacts=artifacts,
 selectedOrdinaryRuntime=final['runtimeSha256'],restored=restored,
 ordinary=['Actual602x421 transient notice wraps its complete text; the full alert name is captured through UIA.',
 'Actual602x421 detailed error wraps and leaves Save/Cancel usable; a valid replacement renders while the primary player remains paused.',
 'A native saved frame contains the caption while the old compact GUI covers it. Fullscreen reveals the same caption, including on an older Core/legacy subtitle-demux control.',
 'GUI r158 reserves video space above redesigned fixed windowed controls. Cold caption, paused seek, playback and fullscreen/return pass on the recorded ordinary tuple.',
 'Fullscreen-only policy keeps windowed fixed space and hides controls in fullscreen. Auto-hide mode2 still overlays/reveals/hides in a window; traditional controls remain reachable and their step action works.'],
 remaining=['A later cold-start case has no first paused caption until a user seek. Native software passes six cycles; actual D3D11 fails both service-registration orders, including an older Core. The strict assertion remains failing.',
 'The selection-time trace shows no video timer source and invalid master point; the input has not supplied a current time. Invalid timer timestamps may still contain previous-media values. A deferred, source-bound refresh needs further work.',
 'Two fallback attempts failed and were removed. Diagnostic Cores169/170/173 and unsuccessful Cores171/172 are not selected. Production player/renderer source bytes were restored to r167 before the clean r174 rebuild.',
 'The wider D3D11 suite also fails paused-time preservation assertions in attachmentNativePausedAndFreshInputRestore and attachmentDecodeFailureAndReplacement. Their software cases pass. Actual hardware clock/frame deltas still need isolation; do not dismiss them as fixture timing without evidence.',
 'The saved hardware snapshot in ui-layout-before-r157 includes the caption but emits two blend/preview diagnostics. Normal journeys without that snapshot have separate clean logs; snapshot-preview qualification remains open.',
 'The earlier longer warm caption loss in ui-cue-r118 remains separate; these observations do not establish its cause.',
 'OS DPI, complete design review, final matched package and all other beta gates remain open.'],
 native=dict(softwareFunctions=len(read(work/'native-final-software-r174/verification.json')['functions']),
             cueFunctions=len(read(work/'cue-final-r174/verification.json')['functions']),
             hardwareExitCode=hardware['exitCode'],hardwareFailures=failures),
 setup=['The first native test build r162 failed because a lazy QByteArray expression needed a concrete QByteArray. Build164 corrects the test type; production code was unaffected.',
 'The first notice setup retained media-driven resize and reopened at962px. The later isolated runner disables that option; ordinary narrow captures are602x421.',
 'The final malformed-input journey retains eighteen expected DVD probe diagnostics. Do not call its negative-control log clean.'])
(out/'checkpoint.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Compact subtitles and cold-start regression - 26 October 2026

The actual602x421 player now shows the full wrapped failure notice and accessible
error details, and supports paused replacement recovery. Fixed redesigned
windowed controls reserve video space so the compact two-row bar no longer
covers captions. Paused seek, playback, fullscreen/return, explicit auto-hide
policies and a traditional-controls route have separately scoped observations.

The new native cold-origin test is deliberately still failing with D3D11.
Software passes six startup cycles. Hardware fails both registration orders,
including an older Core; a second capture without seeking also has no caption.
Selection can precede a valid current clock. The failed fallback attempts were
removed, exact production source restored, and diagnostic runtimes excluded.
The wider hardware suite also fails two paused-time preservation assertions
in attachment and replacement journeys. Their software cases pass; precise
hardware clock/frame deltas remain to isolate.

[checkpoint.json](checkpoint.json) binds all before/after captures, runtime hashes,
native results, setup corrections and remaining issues. The first hardware
snapshot includes a caption but retains blend/preview diagnostics. Older scoped
passes do not establish final-package, OS-DPI or full beta acceptance.
Continue from [STATUS](../../../juxtopposed/STATUS.md).
''',encoding='utf-8',newline='\n')
print(str(out),len(artifacts),flush=True)
