from pathlib import Path
from hashlib import sha256
import gzip,json,re
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
runs=['ui-sort-categories-r342','ui-collection-sort-fixed-r344','ui-collection-sort-cold-r345']
records={name:read(work/name/'verification.json') for name in runs}
for record in records.values():
    assert record['normalExit'] and record['moduleCounts']==['602'] and not record['diagnostics']
    assert all(v for k,v in record.items() if k.endswith('Unchanged'))
for name,count in [('ml-query-races-r342',9),('native-collection-sort-r344',14)]:
    record=read(work/name/'verification.json')
    assert record['normalExit'] and record['cases']==count and not record['failures']
    assert all(v for k,v in record.items() if k.endswith('Unchanged'))
    log=(work/name/'stderr.txt').read_text(encoding='utf-8',errors='replace')
    assert not re.search(r'\berror:|QWARN|Assertion failed|FAIL!',log)
before=read(work/'component-collection-sort-before-r343/verification.json')
fixed=read(work/'component-collection-sort-fixed-r344/verification.json')
assert not before['passed'] and 'Declared collection default' in before['failure'] and not before['messages']
assert fixed['passed'] and len(fixed['completed'])==16 and not fixed['messages']
assert before['helperSha256']==fixed['helperSha256']==digest(repo/'modules/gui/qt/tests/test_page_loader_routes.py')
from PySide6.QtCore import QSettings
def settings(name,file):
    s=QSettings(str(work/name/file),QSettings.IniFormat);s.setFallbacksEnabled(False)
    return {key:s.value(key) for key in s.allKeys()}
saved=settings(runs[1],'settings-after.ini');cold=settings(runs[2],'settings-before.ini')
keys=['sortCriteria/music/albums','sortOrder/music/albums','sortCriteria/music/artists/all',
      'sortOrder/music/artists/all','sortCriteria/music/genres/all','sortOrder/music/genres/all']
assert all(saved[key]==cold[key] for key in keys)
assert saved['sortCriteria/music/artists/all']=='nb_tracks'
out=repo/'doc/juxtopposed-references/native/home-library-defaults-queries-20261027'
assert not out.exists();out.mkdir();artifacts=[]
def retain(p):
    name=p.relative_to(work).as_posix()+'.gz';dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True)
    raw=p.read_bytes();dest.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(dest.read_bytes())==raw
    artifacts.append(dict(path=name,sha256=digest(dest),rawSha256=sha256(raw).hexdigest()))
for name in runs:
    for file in ['verification.json','producer.py','launch.json','staging.json']:
        retain(work/name/file)
    for p in sorted((work/name/'observations').glob('*')):
        if p.suffix in ['.json','.png']:retain(p)
for name in ['ml-query-races-r342','native-collection-sort-r344']:
    for file in ['verification.json','producer.py','results.xml']:retain(work/name/file)
for name in ['component-collection-sort-before-r343','component-collection-sort-fixed-r344']:
    retain(work/name/'verification.json')
for file in ['inputs-r342.json','inputs-r344.json','collection-native-policy-r344.json',
 'prepare-query-races-r342.py','build-query-races-r342.sh','build-query-races-r342-exit.txt',
 'run-ml-query-races-r342.py','prepare-collection-sort-r344.py','build-collection-sort-r344.sh',
 'build-collection-sort-r344-exit.txt','freeze-collection-sort-r344.py',
 'run-ui-collection-sort-r344.py','run-native-collection-sort-r344.py','write-collection-sort-receipt-r346.py']:
    retain(work/file)
result=dict(status='passed-scoped-native-query-races-and-collection-sort-feedback',fullBetaAccepted=False,
 runtimeSha256=records[runs[1]]['runtimeSha256'],sourceSha256=fixed['sourceSha256'],
 restoredSortValues={key:saved[key] for key in keys},observations=[
  'Production MLBaseModel/MediaLib cache tests force two prior row loads to remain in flight while a third current result completes. Search, parent and sort-order A-B-A resets each retain the current three row IDs after both old tasks finish, with no stale count/data signals. Nine native cases pass including the existing selected-Play, read-cancel, offset/order/origin and shutdown cases.',
  'The race fixture supplies bounded row operations backed by real generated media identities and uses the actual production cache/service/thread machinery. It is not a native SQL timing test, an ordinary desktop rapid-input claim or a guarantee about arbitrary platform scheduling.',
  'Ordinary GUI337 reproduces the unmarked Albums sort menu when the saved criterion is empty; the visible native result is descending alphabetical. Native bundled Album/Artist/Genre source treats DEFAULT as ALPHA. The exact local source hashes/excerpts are retained as policy analysis, separate from runtime provenance.',
  'Actual native DEFAULT and ALPHA return identical ordered entity IDs for Albums, Artists and Genres in ascending and descending directions. Fourteen native query cases pass. The artist comparison uses the all-artists API flag; the ordinary three-artist model exercises its album-artist route separately.',
  'PageExt now accepts an explicit child-declared native default solely for sort feedback. Albums declares title, Artists/Genres name. Saved explicit criteria and model-provided criteria take precedence; no default is guessed for other categories or detail types. The component test fails the new semantic check before, then passes16 groups after with no unexpected messages.',
  'Ordinary GUI344 marks Alphabetic for all three empty-criterion collections. Selecting the active criterion reverses Albums and Genres; choosing Tracks Count overrides Artists alphabetical feedback and reorders the1/2/2-song fixture. The main chaptered input stays paused at zero.',
  'Normal restart copies the saved three collection criteria/orders unchanged; ordinary GUI344 restores Artists Tracks Count and the matching1/2/2 order. The exact saved values are included without publishing raw configs.',
  'All three ordinary runs exit0/602modules/zero checked errors/all source/runtime/fixture/producer/cache guards. Both native suites exit0 with complete reports and all guards. The native report format emits its existing xunitxml deprecation notice; no checked native error/QWARN is present. Cross-host libtool warnings remain in ignored build logs; builds exit0 and the actual Windows executables run.'
 ],limits=[
  'Only the three verified music collection defaults are declared. Artist-track/detail, video/group/playlist and other category default policies remain separate. Older GUI337 baseline and GUI344 ordinary evidence have distinct scopes.',
  'The first cold Artists capture still shows the outgoing category page; the settled capture confirms the destination and saved order. No bounded navigation latency is claimed. Component dependency adapters and owned/generated media do not establish full design, accessibility, Windows DPI, physical audio or clean-package acceptance.',
  'Raw logs/configs/databases, media and binaries remain ignored locally. No dependencies or security/privacy settings changed; no forced cleanup was used.'
 ],artifacts=artifacts)
(out/'checkpoint.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Library query races and collection sort feedback - 27 October 2026

Nine production model/service cases pass, including three forced overlapping
search/parent/sort-order A-B-A queries. Abandoned results cannot replace current
rows or emit stale updates. The supplied row loader is separate from native SQL.

Albums, Artists and Genres now show their verified native alphabetical default
when no explicit criterion is saved. Fourteen native query cases, sixteen
component groups and ordinary GUI344 before/after/restart journeys qualify the
repair. Explicit choices retain precedence and survive restart. Other categories
and final beta gates remain open.

See the [checkpoint](checkpoint.json) for identities, preserved baseline failure,
capture/build/report limitations and exact evidence. Continue from
[STATUS](../../../juxtopposed/STATUS.md).
''',encoding='utf-8',newline='\n')
print(out,len(artifacts),'verified artifacts')
