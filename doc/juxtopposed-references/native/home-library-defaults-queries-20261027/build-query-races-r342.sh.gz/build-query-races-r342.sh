#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
native="$base/owned-ml-query-races-20261027-r342"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-query-races-r342.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-query-races-r342-exit.txt"; exit "$code"' EXIT
test ! -e "$native"
test ! -e "$work/native-query-r342-bin"
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = fdfcfcd599588512bb7f3a51e46305b7b0d947b47387dd205851feb45f032b46
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/modules/gui/qt/tests/native_library/ml-play-request.mk" -j2 ML_REQUEST_OUT="$native" ml-play-request-native
mkdir "$work/native-query-r342-bin"
cp "$native/.libs/test_qt_ml_play_request.exe" "$work/native-query-r342-bin/"
sha256sum "$work/native-query-r342-bin/"*
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = fdfcfcd599588512bb7f3a51e46305b7b0d947b47387dd205851feb45f032b46
