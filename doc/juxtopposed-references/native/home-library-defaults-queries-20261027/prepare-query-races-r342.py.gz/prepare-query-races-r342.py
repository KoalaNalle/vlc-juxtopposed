from pathlib import Path
work=Path(__file__).resolve().parent
source=(work/'run-ml-play-request-r286.py').read_text(encoding='utf-8')
source=source.replace("base=work/'ui-music-r279/runtime'", "base=work/'ui-tooltip-fixed-r337/runtime'")
start=source.index("for name in ['plugins/gui/libqt_plugin.dll'")
end=source.index("program=runtime/",start)
source=source[:start]+source[end:]
source=source.replace("work/'ordinary-r286-bin'/program.name", "work/'native-query-r342-bin'/program.name")
source=source.replace("assert len(cases)==6", "assert len(cases)==9")
source=source.replace('No ordinary desktop or physical audio claim.', 'Three forced overlapping A-B-A view cache cases cover search, parent and sort-order resets with late abandoned results. The supplied row operation is not a native SQL query. No ordinary desktop or physical audio claim.')
(work/'run-ml-query-races-r342.py').write_text(source,encoding='utf-8',newline='\n')
