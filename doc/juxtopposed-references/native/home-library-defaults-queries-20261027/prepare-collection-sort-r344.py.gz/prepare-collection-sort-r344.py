from pathlib import Path
import subprocess
work=Path(__file__).resolve().parent
ui=(work/'run-ui-tooltip-r337.py').read_text(encoding='utf-8').replace('ordinary-r337-bin','ordinary-r344-bin').replace('GUI337','GUI344')
(work/'run-ui-collection-sort-r344.py').write_text(ui,encoding='utf-8',newline='\n')
native=(work/'run-music-queries-r283.py').read_text(encoding='utf-8')
native=native.replace("base=work/'ui-music-r279/runtime'", "base=work/'ui-tooltip-fixed-r337/runtime'")
start=native.index("for name in ['plugins/gui/libqt_plugin.dll'")
end=native.index('program=runtime/',start)
native=native[:start]+native[end:]
native=native.replace('native-music-real-r283-bin','native-collections-r344-bin').replace('assert len(cases)==6','assert len(cases)==14')
native=native.replace('No ordinary desktop, Qt model or hardware playback claim.', 'Collection DEFAULT and ALPHA must return identical ordered IDs for Albums, Artists and Genres in both directions. No ordinary desktop, Qt model or hardware playback claim.')
(work/'run-native-collection-sort-r344.py').write_text(native,encoding='utf-8',newline='\n')
freeze=(work/'freeze-global-shortcuts-r340.py').read_text(encoding='utf-8')
anchor="names.add('modules/control/globalhotkeys/win32.c')"
assert freeze.count(anchor)==1
freeze=freeze.replace(anchor,anchor+"\nnames.add('build-windows/beta-single-frame-20261025-night/collection-native-policy-r344.json')")
(work/'freeze-collection-sort-r344.py').write_text(freeze,encoding='utf-8',newline='\n')
code='''from pathlib import Path
from hashlib import sha256
import json
root=Path('/root/vlc-juxtopposed-build/contrib/contrib-win64/medialibrary/src')
result={}
for name,start,end in [('Album.cpp',287,350),('Artist.cpp',853,888),('Genre.cpp',530,550)]:
 p=root/name;raw=p.read_bytes();lines=raw.decode().splitlines()
 result[name]=dict(path=str(p),sha256=sha256(raw).hexdigest(),startLine=start,endLine=end,excerpt='\\n'.join(lines[start-1:end]))
print(json.dumps(dict(scope='Read-only local bundled-library policy evidence; runtime query acceptance is separate.',files=result),indent=2))
'''
data=subprocess.check_output(['wsl.exe','-d','VLC-Juxtopposed-Home-20261018','--','python3','-c',code])
(work/'collection-native-policy-r344.json').write_bytes(data)
