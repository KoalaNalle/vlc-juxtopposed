#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-cache-before-r262.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-cache-before-r262-exit.txt"; exit "$code"' EXIT
native="$base/owned-player-timer-cache-before-r262"
test ! -e "$native"
test ! -e "$work/cache-before-r262-bin"
make -C "$base/win64/test" -f Makefile -f "$repo/test/player-timer-cache-native.mk" -j2 TIMER_CACHE_OUT="$native" owned-player-timer-cache
mkdir "$work/cache-before-r262-bin"
cp "$native/.libs/test_player_timer_cache.exe" "$work/cache-before-r262-bin/"
sha256sum "$work/cache-before-r262-bin/test_player_timer_cache.exe"
