from pathlib import Path
from hashlib import sha256
import gzip,json
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
out=repo/'doc/juxtopposed-references/native/home-subtitle-selection-clock-20261027';assert not out.exists()
batch=read(work/'cache-regressions-r267/summary.json');assert batch['status']=='terminal' and batch['allPassed'] and len(batch['cases'])==6
selection=read(work/'selection-analysis-r266.json');assert selection['passed'] and selection['dualBeforeAndResetPixelIdentical']
roles=read(work/'role-analysis-r259.json');assert roles['beforeAssertionFailure'] and roles['afterPass']
ui=read(work/'ui-selection-fixed-r265/verification.json');assert ui['normalExit'] and not ui['diagnostics']
unit_before=read(work/'timer-cache-before-r264/verification.json');unit_after=read(work/'timer-cache-after-r265/verification.json')
assert unit_before['exitCode']==1 and unit_after['exitCode']==0
assert len(unit_before['rows'])==len(unit_after['rows'])==16
assert not any(r['passed'] for r in unit_before['rows']) and all(r['passed'] for r in unit_after['rows'])
assert unit_before['runtimeSha256']==unit_after['runtimeSha256']
manifests={r:read(work/f'inputs-{r}.json') for r in ['r256','r257','r258','r260','r262','r263','r264','r265','r267']}
assert all(digest(repo/p)==h for p,h in manifests['r267']['files'].items())
assert manifests['r264']['files']['test/src/player/timer_cache.c']==manifests['r265']['files']['test/src/player/timer_cache.c']
assert manifests['r256']['files']['modules/gui/qt/tests/test_player_subtitle_delay.cpp']==manifests['r267']['files']['modules/gui/qt/tests/test_player_subtitle_delay.cpp']
names=['native-role-hooks-before-r257','native-role-hooks-after-r258','native-role-software-r256','native-role-hardware-r258',
       'ui-role-r258','ui-selection-trace-r260','ui-selection-fixed-r265','timer-cache-before-r262','timer-cache-before-r263',
       'timer-cache-before-r264','timer-cache-after-r265','cache-regressions-r267']+[r['label'] for r in batch['cases']]
matrix=read(work/'fragment-matrix-r265/summary.json');names += [r['label'] for r in matrix['cases']]
out.mkdir();artifacts=[];streams=[]
def retain(p,relative=None):
    target=out/((relative or p.relative_to(work).as_posix())+'.gz');assert not target.exists()
    raw=p.read_bytes();target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(raw,mtime=0))
    artifacts.append(dict(path=target.relative_to(out).as_posix(),sha256=digest(target),rawSha256=sha256(raw).hexdigest()))
for name in names:
    for p in sorted((work/name).rglob('*')):
        if not p.is_file() or any(x in p.relative_to(work/name).parts for x in ['runtime','userdata','appdata','localappdata','temp']):continue
        if p.suffix in ['.log','.txt']:streams.append(dict(path=p.relative_to(work).as_posix(),sha256=digest(p),packaged=False))
        elif p.suffix in ['.json','.xml','.png','.py','.qml']:retain(p)
sources=['src/player/timer.c','src/player/input.c','src/player/player.h','test/src/player/timer_cache.c','test/player-timer-cache-native.mk',
    'modules/gui/qt/player/player_controller.cpp','modules/gui/qt/player/player_controller.hpp','modules/gui/qt/player/qml/TracksPageSubtitle.qml',
    'modules/gui/qt/player/qml/PlaybackSettingsMenu.qml','modules/gui/qt/widgets/qml/TrackDelayButton.qml','modules/gui/qt/tests/test_player_subtitle_delay.cpp']
for revision,m in manifests.items():
    retain(work/f'inputs-{revision}.json')
    for name in sources:
        if name not in m['files']:continue
        p=Path(m['sourceCopies'][name]);assert digest(p)==m['files'][name]
        retain(p,f'sources/{revision}/{name}')
for name in ['role-analysis-r259.json','selection-analysis-r266.json','selection-measurements-r266.json','selection-analysis-fixture-note-r267.json']:retain(work/name)
for p in sorted(work.iterdir()):
    if p.is_file() and p.suffix in ['.py','.sh','.mk'] and any(f'r{n}' in p.stem for n in range(256,269)):retain(p)
record=dict(status='tested-nightly-selection-clock-beta-incomplete',fullBetaAccepted=False,
    selectedRuntime='build-windows/beta-single-frame-20261025-night/ui-selection-fixed-r265/runtime',runtimeSha256=ui['runtimeSha256'],
    artifacts=artifacts,localStreams=streams,batch=batch,selection=selection,roleBeforeAfter=roles,
    accepted=[
      'The ordinary app disables unavailable secondary timing in both editors; Tab skips the disabled setting. After a role exists, independent+333ms, cross-editor feedback, Reset0 and disabling after removal pass.',
      'Frozen previous synchronization hooks fail the isolated native secondary-unselect row. Current hooks pass with the identical executable/controller/Core and no seek. Both same-object marks and native selection changes are checked without altering category or own delays.',
      'The video timestamp cache no longer waits for frame-rate metadata. Frame-number notifications remain gated until that metadata exists. Sixteen direct-production-translation-unit cases fail the previous source and pass the fixed source across four rates, paused/playing dates and listener presence; known-rate callback controls pass on both.',
      'The ordinary first-frame negative selects Finnish but has no secondary output before a seek. A temporary trace records a selected video source with an empty timestamp. The production fix activates both cues and timing at80ms without a user seek/resume. Native exports keep marker0, suppress only Finnish at+333ms, and restore a pixel-identical dual-caption image atReset0. Playback reaches both LAST cues and repauses normally.',
      'The timing-button animation now targets the background Rectangle color property. The diagnostic GUI exercises Voice Heard without the previous Cannot animate warnings; no animation trace/hook is shipped in the production candidate.',
      'The final six regression groups pass on Core265: both31-function software/hardware suites, real-WASAPI own/inherited delay rows,13 startup controls,12 MP4 cases and official A-B/timer programs. Each scope retains its own binary, source, fixture and process identity.'
    ],unresolved=[
      'Earlier setup runs r262/r263 do not execute the component because libssp-0.dll is absent. Their loader exits are retained separately. The explicit static support-library linkage is used by the valid before r264 and after r265 cases; protections remain enabled.',
      'The first image analysis searched the upper quarter for Finnish. Native exports arrange both captions in the lower quarter. The failed helper, measurements and corrected analysis are retained. Export/display placement and OSD intersections remain separate from video identity.',
      'Full suites retain scoped late-picture warning counts in batch and earlier role results. Zero avcodec-late errors are required. A passing suite is not described as warning-free.',
      'Core260 is diagnostic-only; its trace is removed before Core265. The source-cache unit uses a local opaque source token and real timer code; it is not decoder, native ES or desktop integration evidence.',
      'The older ordinary late-cue preset/default/A-B-A/cold replay is still pending on this tuple. Sparse-cue cost, other MP4 index/live layouts, secondary-screen idle capture, physical DPI/design/accessibility and final-package gates remain open. Windows10 and physical endpoint/receiver deferrals remain visible.',
      'The earlier role receipt analysis preserves its then-open activation failure. This later Core265 evidence resolves that specific generated first-frame journey; it does not retroactively qualify the older binary.'
    ])
(out/'checkpoint.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Subtitle selection and first-frame clock - 27 October 2026

Core `fdfcfcd5`, ordinary GUI `8e92470c` and MP4 `df15e8ed` activate a second
subtitle while paused at the opening80ms frame. Previously, the video source
existed but its timestamp cache waited for frame-rate metadata. The repair keeps
the video timestamp available and still withholds frame-number notifications
until that metadata is known. Sixteen source-level before/after cases qualify
that contract; the ordinary app separately qualifies real track activation.

Both ordinary timing editors reflect actual secondary availability. Disabled
controls are skipped by Tab. Native same-object marks cancel on subtitle
selection changes without a seek; the previous hooks fail the isolated control.
The timing-button animation uses the existing background color property.

Three opening-frame native exports keep marker0: both captions, Finnish delayed
333ms, and both after Reset. The first and last images are pixel-identical.
Playback then reaches both LAST cues and repauses, with normal app exit and no
error diagnostics. Native export and ordinary display caption placement differ;
the first analysis used the wrong image band and its correction is retained.

Both31-function software/hardware suites, real-WASAPI delay rows,13 startup
controls,12 MP4 cases and official A-B/timer programs pass. Warning counts remain
explicit in [checkpoint.json](checkpoint.json), alongside early test-loader
failures, the diagnostic trace and exact source/runtime identities. Temporary
trace code is absent from Core265. Raw streams, binaries, profiles and personal
media are excluded from these compressed generated artifacts.

The older ordinary late-cue preset replay and broader beta/display/DPI/package
gates remain open. This is a source nightly checkpoint, not beta readiness.
Continue from [STATUS](../../../juxtopposed/STATUS.md).
''',encoding='utf-8',newline='\n')
for item in artifacts:
    p=out/item['path'];assert digest(p)==item['sha256'] and sha256(gzip.decompress(p.read_bytes())).hexdigest()==item['rawSha256']
print(out,len(artifacts),'verified artifacts',flush=True)
