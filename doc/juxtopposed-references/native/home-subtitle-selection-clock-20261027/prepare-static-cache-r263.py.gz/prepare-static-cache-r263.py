from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'build-cache-before-r262.sh').read_text(encoding='utf-8').replace('r262','r263')
target=work/'build-cache-before-r263.sh';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared a fresh static compiler-runtime test build')
