#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
native="$base/owned-single-frame-native-20261027-r256"
ordinary="$base/owned-single-frame-ordinary-20261027-r256"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-r256.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-r256-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 0ab943f0161b7a5fc4c7476f2e6d593f3da80a4a56f0e763e97c6a90825dd988
test ! -e "$native"
test ! -e "$ordinary"
test ! -e "$work/native-r256-bin"
test ! -e "$work/ordinary-r256-bin"
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/build-windows/beta-subtitle-fps-20261023/native-r1.mk" -j2 FPS_NATIVE_OUT="$native" owned-subtitle-fps-native
mkdir "$work/native-r256-bin"
cp "$native/.libs/test_qt_player_subtitle_delay.exe" "$work/native-r256-bin/"
sha256sum "$work/native-r256-bin/test_qt_player_subtitle_delay.exe"
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/build-windows/beta-subtitle-sync-20261025/ordinary.mk" -j2 QA_OUT="$ordinary" owned-ordinary-subtitle-sync
mkdir "$work/ordinary-r256-bin"
cp "$ordinary/.libs/libqt_plugin.dll" "$work/ordinary-r256-bin/"
sha256sum "$work/ordinary-r256-bin/libqt_plugin.dll"
