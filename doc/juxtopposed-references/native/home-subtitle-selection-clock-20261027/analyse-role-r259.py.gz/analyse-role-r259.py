from pathlib import Path
from hashlib import sha256
import json,re
from PySide6.QtGui import QImage
work=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
before=read(work/'native-role-hooks-before-r257/verification.json')
after=read(work/'native-role-hooks-after-r258/verification.json')
assert before['exitCode']==1 and after['exitCode']==0
assert before['testExecutableSha256']==after['testExecutableSha256']
assert before['runtimeSha256']==after['runtimeSha256']
assert before['functions'][1]['incidents']==[dict(type='fail',description="'!marked()' returned FALSE. ()")]
assert all(i['type']=='pass' for f in after['functions'] for i in f['incidents'])
native={}
for name in ['native-role-software-r256','native-role-hardware-r258']:
    v=read(work/name/'verification.json');assert v['normalExit']
    assert len(v['functions'])==31
    assert all(i['type']=='pass' for f in v['functions'] for i in f['incidents'])
    assert len(next(f for f in v['functions'] if f['name']=='timingContextCancellation')['incidents'])==14
    native[name]=dict(functions=31,contextRows=14,latePictureWarnings=v['latePictureWarnings'],avcodecLateErrors=v['avcodecLateErrors'])
ui=work/'ui-role-r258';v=read(ui/'verification.json')
assert v['normalExit'] and not v['diagnostics'] and v['moduleCounts']==['602']
assert all(v[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','producerUnchanged','pluginCacheUnchanged'])
obs=ui/'observations'
tree=lambda name:read(obs/(name+'.json'))['accessibility']['tree']
for name in ['02-settings-no-secondary-disabled','04-sync-no-secondary-disabled','07-two-selected-secondary-still-unavailable-before-seek','16-secondary-disabled-after-removal']:
    assert re.search(r'(?:edit|spinner) \(disabled,.*?Secondary subtitle delay Value: 0',tree(name))
assert 'spinner (settable, float) Secondary subtitle delay Value: 333' in tree('13-sync-secondary333-enabled-settled')
assert 'spinner (settable, float) Secondary subtitle delay Value: 0' in tree('14-secondary-reset0-primary0')
assert 'edit (settable, string) Secondary subtitle delay Value: 0.333 s' in tree('11-secondary333-primary0-clock-held')
images=list((ui/'app-snapshots').glob('*.png'));assert len(images)==1
im=QImage(str(images[0])).convertToFormat(QImage.Format_RGBA8888);assert not im.isNull()
raw=bytes(im.bits());stride=im.bytesPerLine()
bright=lambda lo,hi:sum(raw[y*stride+x*4]>160 and raw[y*stride+x*4+1]>160 and raw[y*stride+x*4+2]>160 for y in range(lo,hi) for x in range(im.width()))
pixels=dict(marker=sum(1<<b for b in range(11) if im.pixelColor(32+64*b,20).red()>128),topCaptionPixels=bright(0,im.height()//4),bottomCaptionPixels=bright(3*im.height()//4,im.height()),sha256=sha256(images[0].read_bytes()).hexdigest())
assert pixels['marker']==0 and pixels['topCaptionPixels']==0 and pixels['bottomCaptionPixels']==1488
record=dict(fullBetaAccepted=False,scope='Native cancellation and ordinary truthful control availability; initial paused second-track activation remains failed.',native=native,
    runtimeSha256=v['runtimeSha256'],beforeAssertionFailure=True,afterPass=True,ordinaryNormalExit=True,ordinaryErrorDiagnostics=0,beforeSeekNativeExport=pixels,
    accepted=['Native same-object marks cancel after secondary/all unselection without a seek. The previous production QML hooks fail the isolated row; current hooks pass on the identical executable/Core/runtime.',
      'No-secondary controls are disabled in both ordinary editors; Tab skips the disabled setting to FPS. After a normal seek activates both captions, secondary+333ms remains independent of primary0; the synchronization tools show333ms, Reset returns0 and removing Finnish disables its controls again. The clock remains32.04s during those edits.'],
    unresolved=['At the initial paused80ms frame, adding Finnish selects it but does not create a secondary output/role. Its timing controls remain unavailable and the native export contains only the English caption. A user seek to32.04s activates both captions. This path is not accepted.',
      'Clicking Voice Heard exposes two existing ColorAnimation warnings: TrackDelayButton targets nonexistent backgroundColor instead of the Rectangle color property. No code repair for that warning is included in this run.',
      'Full software/hardware suites pass but retain one/two late-picture warnings (89ms software;58/55ms hardware), zero avcodec-late errors. They are preserved, not described as warning-free.',
      'Observation12 has a misleading filename from a transition and actually records the track list. It does not prove enabled synchronization controls; settled observation13 supplies that evidence.',
      'Ordinary page switching does not establish same-object estimator cancellation. The native context tests provide that distinct proof. Broader beta/DPI/package gates remain open.'])
(work/'role-analysis-r259.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(native=native,beforeSeekNativeExport=pixels,activationAccepted=False,ordinaryNormalExit=True)))
