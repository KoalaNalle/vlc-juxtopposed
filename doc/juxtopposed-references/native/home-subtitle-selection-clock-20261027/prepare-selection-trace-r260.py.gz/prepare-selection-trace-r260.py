from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'build-core-r252.sh').read_text(encoding='utf-8').replace('r252','r260')
text=text.replace('a42c50a021801494e0955ac60b3728a2e4d358c882b1e606d2cce8af6cafaecc',
                  '0ab943f0161b7a5fc4c7476f2e6d593f3da80a4a56f0e763e97c6a90825dd988')
text+='''ordinary="$base/owned-single-frame-ordinary-20261027-r260"
test ! -e "$ordinary"
test ! -e "$work/ordinary-r260-bin"
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/build-windows/beta-subtitle-sync-20261025/ordinary.mk" -j2 QA_OUT="$ordinary" owned-ordinary-subtitle-sync
mkdir "$work/ordinary-r260-bin"
cp "$ordinary/.libs/libqt_plugin.dll" "$work/ordinary-r260-bin/"
sha256sum "$work/ordinary-r260-bin/libqt_plugin.dll"
'''
target=work/'build-r260.sh';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
text=(work/'run-ui-role-r256.py').read_text(encoding='utf-8')
text=text.replace('core-r252-bin','core-r260-bin').replace('ordinary-r256-bin','ordinary-r260-bin')
text=text.replace('privateCore=False','privateCore=True')
target=work/'run-ui-selection-trace-r260.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
text=(work/'run-ui-late-r256.py').read_text(encoding='utf-8').replace('ordinary-r256-bin','ordinary-r260-bin')
target=work/'run-ui-late-r260.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared diagnostic Core trace and production animation repair GUI')
