from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'build-core-r252.sh').read_text(encoding='utf-8').replace('r252','r265')
text=text.replace('a42c50a021801494e0955ac60b3728a2e4d358c882b1e606d2cce8af6cafaecc',
                  '9dedca7d1c2bd98104a471cb8d04bcb591df62b1462dc24bfb7d937ace346ede')
text+='''native="$base/owned-player-timer-cache-after-r265"
test ! -e "$native"
test ! -e "$work/cache-after-r265-bin"
make -C "$base/win64/test" -f Makefile -f "$repo/test/player-timer-cache-native.mk" -j2 TIMER_CACHE_OUT="$native" owned-player-timer-cache
mkdir "$work/cache-after-r265-bin"
cp "$native/.libs/test_player_timer_cache.exe" "$work/cache-after-r265-bin/"
sha256sum "$work/cache-after-r265-bin/test_player_timer_cache.exe"
'''
target=work/'build-r265.sh';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
text=(work/'run-ui-selection-trace-r260.py').read_text(encoding='utf-8').replace('core-r260-bin','core-r265-bin').replace('privateCore=True','privateCore=False')
target=work/'run-ui-selection-r265.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
text=(work/'run-ui-late-r260.py').read_text(encoding='utf-8').replace('core-r252-bin','core-r265-bin')
target=work/'run-ui-late-r265.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
text=(work/'run-fragment-r253.py').read_text(encoding='utf-8').replace('core-r252-bin','core-r265-bin')
target=work/'run-fragment-r265.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
text=(work/'run-fragment-all-r253.py').read_text(encoding='utf-8').replace('r253','r265')
target=work/'run-fragment-all-r265.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared production video-cache Core, direct contract and affected integration runners')
