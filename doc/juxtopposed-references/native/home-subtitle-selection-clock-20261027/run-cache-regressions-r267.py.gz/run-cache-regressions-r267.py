from pathlib import Path
import json,subprocess,sys
work=Path(__file__).resolve().parent;revision=sys.argv[1]
out=work/'cache-regressions-r267';assert not out.exists();out.mkdir()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
record=dict(status='running',fullBetaAccepted=False,forcedCleanupUsed=False,cases=[])
save=lambda:(out/'summary.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
native=lambda label,video,audio,mode:['run-native-mp4-r235.py',revision,label,'core-r265-bin/libvlccore.dll',mode,'r256',video,audio,'r240']
specs=[('native-cache-software-r267',native('native-cache-software-r267','software','dummy','all'),'native',240),
       ('native-cache-hardware-r267',native('native-cache-hardware-r267','d3d11','dummy','all'),'native',240),
       ('native-cache-wasapi-r267',native('native-cache-wasapi-r267','d3d11','wasapi','large-delays'),'native',240),
       ('startup-cache-r267',['run-cold-start-r251.py',revision,'startup-cache-r267','r265','all'],'startup',360),
       ('fragment-matrix-r265',['run-fragment-all-r265.py',revision],'matrix',1200),
       ('official-cache-r267',['run-player-r267.py',revision,'official-cache-r267','all'],'official',660)]
save()
for label,args,kind,timeout in specs:
    command=[sys.executable,str(work/args[0]),*args[1:]]
    with (out/(label+'.txt')).open('wb') as stream:
        child=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        record.update(activeLabel=label,activeObserverPid=child.pid);save();print(label,'observer',child.pid,flush=True)
        try:code=child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            record['status']='observer-timeout-inspect-owned-process';save();raise SystemExit('Inspect observer and its child; no automatic cleanup/restart')
    if code!=0:
        record.update(status='observer-failed-inspect-result',exitCode=code);save();raise SystemExit(code)
    result=read(work/label/('summary.json' if kind=='matrix' else 'verification.json'))
    if kind=='matrix':assert result['status']=='terminal' and result['allPassed'] and len(result['cases'])==12
    else:
        assert result['sourceInputsUnchanged'] and result['runtimeUnchanged']
        if kind=='native':
            assert result['normalExit'] and all(i['type']=='pass' for f in result['functions'] for i in f['incidents'])
            assert result['avcodecLateErrors']==0
            if 'wasapi' in label:assert result['actualWasapiSelected']
        elif kind=='startup':assert result['passed'] and len(result['records'])==13
        else:assert result['normalExit'] and len(result['processes'])==2
    row=dict(label=label,kind=kind,observerExitCode=code,passed=True)
    if kind=='native':row.update(functions=len(result['functions']),latePictureWarnings=result['latePictureWarnings'],avcodecLateErrors=result['avcodecLateErrors'])
    record['cases'].append(row);save();print(json.dumps(row),flush=True)
record.update(status='terminal',allPassed=True)
record.pop('activeLabel',None);record.pop('activeObserverPid',None);save();print('All six affected regression groups passed',flush=True)
