#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-core-r265.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-core-r265-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 9dedca7d1c2bd98104a471cb8d04bcb591df62b1462dc24bfb7d937ace346ede
test ! -e "$work/core-r265-bin"
make -C "$base/win64/src" -j2 libvlccore.la
mkdir "$work/core-r265-bin"
cp "$base/win64/src/.libs/libvlccore.dll" "$work/core-r265-bin/"
cp "$base/win64/src/player/.deps/libvlccore_la-input.Plo" "$work/core-r265-bin/player-input.Plo"
sha256sum "$work/core-r265-bin/libvlccore.dll"
native="$base/owned-player-timer-cache-after-r265"
test ! -e "$native"
test ! -e "$work/cache-after-r265-bin"
make -C "$base/win64/test" -f Makefile -f "$repo/test/player-timer-cache-native.mk" -j2 TIMER_CACHE_OUT="$native" owned-player-timer-cache
mkdir "$work/cache-after-r265-bin"
cp "$native/.libs/test_player_timer_cache.exe" "$work/cache-after-r265-bin/"
sha256sum "$work/cache-after-r265-bin/test_player_timer_cache.exe"
