from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'run-native-role-before-r257.py').read_text(encoding='utf-8')
needle="old=read(work/'inputs-r253.json')\n    original=Path(old['sourceCopies'][key]);assert digest(original)==old['files'][key]"
assert text.count(needle)==1
text=text.replace(needle,"original=Path(inputs['sourceCopies'][key]);assert digest(original)==inputs['files'][key]")
text=text.replace('frozen old production QML synchronization hooks. Expected assertion failure after secondary unselection without seeking.',
                  'current production QML synchronization hooks. Cancellation after secondary unselection without seeking must pass.')
target=work/'run-native-role-after-r258.py';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared matching one-row current-QML control')
