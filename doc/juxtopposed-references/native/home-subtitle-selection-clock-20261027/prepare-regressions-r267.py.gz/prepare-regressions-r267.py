from pathlib import Path
import json,shutil
work=Path(__file__).resolve().parent
source=work/'analyse-selection-r266.py';backup=work/'analyse-selection-band-before-r266.py'
assert not backup.exists();shutil.copyfile(source,backup)
text=source.read_text(encoding='utf-8')
text=text.replace("assert all(r['marker']==0 and r['bottomCaptionPixels']==1488 for r in rows)",
    "assert all(r['marker']==0 and r['topCaptionPixels']==0 for r in rows)\nassert rows[1]['bottomCaptionPixels']==1488\nassert rows[0]['bottomCaptionPixels']==rows[2]['bottomCaptionPixels']>rows[1]['bottomCaptionPixels']+500")
text=text.replace("assert rows[0]['topCaptionPixels']>1000 and rows[1]['topCaptionPixels']==0 and rows[2]['topCaptionPixels']>1000\n",'')
text=text.replace("'App captures can reposition Finnish while the delay/snapshot OSD is visible. Native exports exclude that OSD; this scoped equality does not close other display/capture or DPI behavior.'",
    "'The first analysis searched for Finnish in the upper quarter, but the native export arranges both cues in the lower quarter. That fixture assertion failed and is retained. Actual UI inspection and native image inspection confirm both captions. The corrected analysis uses the lower-band difference and exact before/Reset pixel equality. Export/display placement and DPI remain separate scopes.'")
target=work/'analyse-selection-r267.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
(work/'selection-analysis-fixture-note-r267.json').write_text(json.dumps(dict(initialBandAssertionFailed=True,
    correctedScope='Native export has both captions near the bottom; ordinary app placement differs. The candidate did not advance the encoded video marker.',
    preservedFailedHelper=backup.name,measurements='selection-measurements-r266.json'),indent=2)+'\n',encoding='utf-8',newline='\n')
text=(work/'run-player-r226.py').read_text(encoding='utf-8').replace('core-r224-bin','core-r265-bin')
needle="expected=read(work/'ui-r77/verification.json')['runtimeSha256']"
assert text.count(needle)==1
text=text.replace(needle,needle+"\nexpected['plugins/demux/libmp4_plugin.dll']=digest(base/'plugins/demux/libmp4_plugin.dll')")
target=work/'run-player-r267.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
text=(work/'freeze-timer-r262.py').read_text(encoding='utf-8')
needle="names.update(['src/player/timer.c','src/player/player.h','test/src/player/timer_cache.c','test/player-timer-cache-native.mk'])"
assert text.count(needle)==1
text=text.replace(needle,needle+"\nnames.update(['test/src/player/timers.c','test/src/player/timers.h','test/src/player/common.h'])")
target=work/'freeze-regressions-r267.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared corrected image-band analysis and official timer regression')
