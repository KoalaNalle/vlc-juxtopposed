from pathlib import Path
from hashlib import sha256
import json
from PySide6.QtGui import QImage
work=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
run=work/'ui-selection-fixed-r265';paths=sorted((run/'app-snapshots').glob('*.png'));assert len(paths)==3
rows=[];pixels=[]
for p in paths:
    im=QImage(str(p)).convertToFormat(QImage.Format_RGBA8888);assert not im.isNull()
    raw=bytes(im.bits());pixels.append(raw);stride=im.bytesPerLine()
    bright=lambda lo,hi:sum(raw[y*stride+x*4]>160 and raw[y*stride+x*4+1]>160 and raw[y*stride+x*4+2]>160 for y in range(lo,hi) for x in range(im.width()))
    rows.append(dict(path=p.name,sha256=sha256(p.read_bytes()).hexdigest(),marker=sum(1<<b for b in range(11) if im.pixelColor(32+64*b,20).red()>128),topCaptionPixels=bright(0,im.height()//4),bottomCaptionPixels=bright(3*im.height()//4,im.height())))
(work/'selection-measurements-r266.json').write_text(json.dumps(dict(frames=rows,dualPixelsEqual=pixels[0]==pixels[2]),indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(rows),flush=True)
assert all(r['marker']==0 and r['bottomCaptionPixels']==1488 for r in rows)
assert rows[0]['topCaptionPixels']>1000 and rows[1]['topCaptionPixels']==0 and rows[2]['topCaptionPixels']>1000
assert pixels[0]==pixels[2]
v=read(run/'verification.json');assert v['normalExit'] and not v['diagnostics'] and v['moduleCounts']==['602']
assert all(v[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','producerUnchanged','pluginCacheUnchanged'])
trace=read(work/'ui-selection-trace-r260/verification.json');assert trace['normalExit']
text=(work/'ui-selection-trace-r260/vlc.log').read_text(encoding='utf-8',errors='replace')
assert 'target=0 video=1 seeking=0 system=0 ts=0 seek=0 pos=-1.000000' in text
assert 'Cannot animate' not in text
record=dict(passed=True,scope='Ordinary initial paused selection, independent secondary333ms/Reset, native export; software unit and broader regressions have separate scopes.',fullBetaAccepted=False,frames=rows,dualBeforeAndResetPixelIdentical=True,
    ordinaryRuntimeSha256=v['runtimeSha256'],traceRuntimeSha256=trace['runtimeSha256'],diagnosticTraceRemovedFromProduction=True,
    notes=['No user seek or resume precedes these three exports. Both subtitle roles activate at80ms; the secondary delay suppresses only Finnish, and Reset restores the pixel-identical initial dual-caption image. Encoded video marker remains0.',
      'App captures can reposition Finnish while the delay/snapshot OSD is visible. Native exports exclude that OSD; this scoped equality does not close other display/capture or DPI behavior.',
      'The previous trace has a selected video source but no cached timestamp. The source-cache contract is separately tested against unknown frame-rate metadata. The trace GUI also exercises the repaired animation without the earlier Cannot animate warning.'])
(work/'selection-analysis-r266.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(passed=True,frames=rows,pixelIdenticalDualBeforeReset=True)))
