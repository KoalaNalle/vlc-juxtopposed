from pathlib import Path
work=Path(__file__).resolve().parent
core='0ab943f0161b7a5fc4c7476f2e6d593f3da80a4a56f0e763e97c6a90825dd988'
text=(work/'build-r235.sh').read_text(encoding='utf-8')
text=text.replace('r235','r256').replace('20261026-r256','20261027-r256')
text=text.replace('ccf72399765f11541dbcb434a3b088a84127f1595af51755037fa03620dadaeb',core)
text+='''make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/build-windows/beta-subtitle-sync-20261025/ordinary.mk" -j2 QA_OUT="$ordinary" owned-ordinary-subtitle-sync
mkdir "$work/ordinary-r256-bin"
cp "$ordinary/.libs/libqt_plugin.dll" "$work/ordinary-r256-bin/"
sha256sum "$work/ordinary-r256-bin/libqt_plugin.dll"
'''
target=work/'build-r256.sh';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
text=(work/'run-ui-cold-r252.py').read_text(encoding='utf-8')
text=text.replace('ordinary-r230-bin','ordinary-r256-bin')
target=work/'run-ui-role-r256.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
assert text.count("media=work/'fragment-ui-media-r242'")==1
text=text.replace("media=work/'fragment-ui-media-r242'","media=work/'attachment-media-r85'")
target=work/'run-ui-late-r256.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared native and ordinary builds, role and saved-late-cue runners')
