from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'freeze-mp4-r245.py').read_text(encoding='utf-8')
needle="names.add('test/libvlc/native_mp4_subtitle_seek.py')"
assert text.count(needle)==1
text=text.replace(needle,needle+"\nnames.update(['src/player/timer.c','src/player/player.h','test/src/player/timer_cache.c','test/player-timer-cache-native.mk'])")
target=work/'freeze-timer-r262.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
text=(work/'build-cache-before-r261.sh').read_text(encoding='utf-8').replace('r261','r262')
target=work/'build-cache-before-r262.sh';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared source inventory and fresh frozen cache-contract build')
