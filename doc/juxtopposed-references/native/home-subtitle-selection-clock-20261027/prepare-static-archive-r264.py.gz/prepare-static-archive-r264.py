from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'build-cache-before-r263.sh').read_text(encoding='utf-8').replace('r263','r264')
target=work/'build-cache-before-r264.sh';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared explicit static support-library linkage')
