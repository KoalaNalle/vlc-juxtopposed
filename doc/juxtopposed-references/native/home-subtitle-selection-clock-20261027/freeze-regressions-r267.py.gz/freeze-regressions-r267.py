from pathlib import Path
from hashlib import sha256
import json,shutil,sys
work=Path(__file__).resolve().parent
repo=work.parents[1]
prior,revision=sys.argv[1:]
old=json.loads(Path(prior).read_text(encoding='utf-8'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
names={p for p in old['files'] if (repo/p).is_file()
       and not p.startswith('build-windows/beta-subtitle-sync-20261025/')}
names.update(p.relative_to(repo).as_posix() for p in work.iterdir()
             if p.suffix in ('.py','.sh','.mk','.cpp','.h','.c'))
names.update(['AGENTS.md','README.md','.gitattributes',
              'test/src/interface/controls.c','test/controls-native.mk',
              'test/libvlc/native_controls.py','test/libvlc/native_paused_video_startup.py'])
names.update(['test/src/clock/clock.c','src/clock/clock.c','src/clock/clock.h'])
names.add('build-windows/beta-subtitle-sync-20261025/ordinary.mk')
names.add('test/libvlc/native_mp4_subtitle_seek.py')
names.update(['src/player/timer.c','src/player/player.h','test/src/player/timer_cache.c','test/player-timer-cache-native.mk'])
names.update(['test/src/player/timers.c','test/src/player/timers.h','test/src/player/common.h'])
if (repo/'test/libvlc/native_timeshift.py').exists():
    names.add('test/libvlc/native_timeshift.py')
forbidden={'test/libvlc/native_soxr_reference.py',
 'test/modules/audio_filter/soxr_lifecycle_trace.c',
 'test/modules/audio_filter/soxr_native_reference.c',
 'test/modules/audio_filter/soxr_pcm_trace.c'}
assert not names.intersection(forbidden)
root=work/f'source-{revision}';assert not root.exists();root.mkdir()
files={p:digest(repo/p) for p in sorted(names)}
copies={};fresh=0
for name,h in files.items():
    if old['files'].get(name)==h:
        target=Path(old['sourceCopies'][name])
    else:
        target=root/name;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(repo/name,target);fresh+=1
    assert digest(target)==h
    copies[name]=str(target)
(work/f'inputs-{revision}.json').write_text(json.dumps(dict(files=files,sourceCopies=copies,
 sourceCount=len(files),newCopies=fresh,fullBetaAccepted=False),indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(revision=revision,inputs=len(files),newCopies=fresh)),flush=True)
