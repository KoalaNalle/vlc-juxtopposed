from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'run-native-mp4-r235.py').read_text(encoding='utf-8')
needle="elif mode=='context-one':command+=['timingContextCancellation:audio-native-resume']"
assert text.count(needle)==1
text=text.replace(needle,needle+"\nelif mode=='role-unselect':command+=['timingContextCancellation:subtitle-native-secondary-unselect']")
needle="original=Path(inputs['sourceCopies'][key]);assert digest(original)==inputs['files'][key]"
assert text.count(needle)==1
text=text.replace(needle,"old=read(work/'inputs-r253.json')\n    original=Path(old['sourceCopies'][key]);assert digest(original)==old['files'][key]")
needle="record=dict(subtitlePluginSha256=subtitle_hash,"
assert text.count(needle)==1
text=text.replace(needle,"record=dict(comparisonScope='Same new native executable/controller/Core; frozen old production QML synchronization hooks. Expected assertion failure after secondary unselection without seeking.',subtitlePluginSha256=subtitle_hash,")
target=work/'run-native-role-before-r257.py';assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared one-row old-QML cancellation control')
