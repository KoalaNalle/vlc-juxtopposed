#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-core-r260.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-core-r260-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 0ab943f0161b7a5fc4c7476f2e6d593f3da80a4a56f0e763e97c6a90825dd988
test ! -e "$work/core-r260-bin"
make -C "$base/win64/src" -j2 libvlccore.la
mkdir "$work/core-r260-bin"
cp "$base/win64/src/.libs/libvlccore.dll" "$work/core-r260-bin/"
cp "$base/win64/src/player/.deps/libvlccore_la-input.Plo" "$work/core-r260-bin/player-input.Plo"
sha256sum "$work/core-r260-bin/libvlccore.dll"
ordinary="$base/owned-single-frame-ordinary-20261027-r260"
test ! -e "$ordinary"
test ! -e "$work/ordinary-r260-bin"
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/build-windows/beta-subtitle-sync-20261025/ordinary.mk" -j2 QA_OUT="$ordinary" owned-ordinary-subtitle-sync
mkdir "$work/ordinary-r260-bin"
cp "$ordinary/.libs/libqt_plugin.dll" "$work/ordinary-r260-bin/"
sha256sum "$work/ordinary-r260-bin/libqt_plugin.dll"
