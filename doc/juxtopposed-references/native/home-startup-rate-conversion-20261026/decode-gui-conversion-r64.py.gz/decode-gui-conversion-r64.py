from pathlib import Path
from hashlib import sha256
import json,os,sys,wave,array
work=Path(__file__).resolve().parent;repo=work.parents[1]
sys.path.insert(0,str(repo/'test/libvlc'))
from native_http_runtime import environment
from native_flac_drain import Runtime,streaminfo
root=work/'ui-r64/gui-conversion';out=root/'native-decode';out.mkdir()
runtime=work/'ui-r64/runtime'
os.environ.update(environment(runtime,out));os.environ.pop('VLC_PLUGIN_PATH',None)
os.environ['VLC_LIB_PATH']=str(runtime/'plugins')
source=root/'source ä 100%.wav';result=root/'converted ä 100%.flac'
before=json.loads((root/'fixture-before.json').read_text(encoding='utf-8'))
assert all(sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before['beforeSha256'].items())
engine=Runtime(runtime,out);events,pcm=engine.stage(result,'gui-output-decode')
values=array.array('h');values.frombytes(pcm)
with wave.open(str(source),'rb') as w: frames=w.getnframes();rate=w.getframerate();original=w.readframes(frames)
report=dict(scope='Fully decode actual ordinary GUI-produced FLAC; not mocked output',passed=events['eos'] and len(values)==frames and any(values[-64:]),events=events,decodedFrames=len(values),expectedFrames=frames,rate=rate,tailSamples=values[-16:].tolist(),pcmEqualsMonoSource=pcm==original,outputSha256=sha256(result.read_bytes()).hexdigest(),coreSha256=sha256((runtime/'libvlccore.dll').read_bytes()).hexdigest(),originalsUnchanged=all(sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before['beforeSha256'].items()),fullBetaAccepted=False)
(out/'verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(report));assert report['passed'] and report['originalsUnchanged']
