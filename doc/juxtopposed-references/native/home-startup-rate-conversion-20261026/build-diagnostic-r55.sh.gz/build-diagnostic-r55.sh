#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
out="$base/owned-diagnostic-core-20261026-r55"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-diagnostic-r55.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-diagnostic-r55-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = e1767d37d607766f50d6e86c62ecf02ae53a01fe6c19bc57b02e681d139ad720
test ! -e "$out"
test ! -e "$work/diagnostic-r55-bin"
make -C "$base/win64/src" -f Makefile -f "$work/diagnostic-core-r55.mk" -j2 DIAGNOSTIC_CORE_OUT="$out" owned-diagnostic-core
mkdir "$work/diagnostic-r55-bin"
cp "$out/.libs/libvlccore.dll" "$work/diagnostic-r55-bin/"
sha256sum "$work/diagnostic-r55-bin/libvlccore.dll" "$base/win64/src/.libs/libvlccore.dll"
