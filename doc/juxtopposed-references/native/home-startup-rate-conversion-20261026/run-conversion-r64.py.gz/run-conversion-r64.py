from pathlib import Path
from hashlib import sha256
import ctypes,json,platform,shutil,subprocess,sys
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
revision,label=sys.argv[1:]
manifest=work/f'inputs-{revision}.json';inputs=read(manifest)
assert all(digest(repo/p)==h and digest(Path(inputs['sourceCopies'][p]))==h for p,h in inputs['files'].items())
base=work/'ui-r59/runtime';base_record=read(base.parent/'verification.json')
assert base_record['normalExit'] and all(digest(base/p)==h for p,h in base_record['runtimeSha256'].items())
assert (work/'build-conversion-r16-exit.txt').read_text().strip()=='0'
root=work/label;assert not root.exists();root.mkdir()
shutil.copyfile(Path(__file__),root/'producer.py')
sys.path.insert(0,str(repo/'test/libvlc'))
from native_http_runtime import stage_runtime,environment
runtime=root/'runtime';stage_runtime(base,runtime)
shutil.copyfile(base/'plugins/plugins.dat',runtime/'plugins/plugins.dat')
program='test_qt_conversion_controller.exe'
shutil.copyfile(work/'conversion-r16-bin'/program,runtime/program)
identities={p.relative_to(runtime).as_posix():digest(p) for p in runtime.rglob('*')
            if p.is_file() and p.suffix.lower() in ('.dll','.exe')}
records=[]
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.SetErrorMode.argtypes=[ctypes.c_uint];kernel.SetErrorMode.restype=ctypes.c_uint
previous=kernel.SetErrorMode(0x8003)
try:
    for name,worker,arguments in [
        ('strict-flac','native_flac_drain.py',['--package',str(runtime),'--output-dir',str(root/'strict-flac/probe')]),
        ('controller','native_conversion_controller.py',['--package',str(runtime),'--test-exe',str(runtime/program),
            '--output-dir',str(root/'controller/probe')])]:
        out=root/name;out.mkdir()
        command=[sys.executable,str(repo/'test/libvlc'/worker),*arguments]
        record=dict(status='starting',case=name,sourceManifestSha256=digest(manifest),
            producerSha256=digest(Path(__file__)),workerSha256=digest(repo/'test/libvlc'/worker),
            runtimeSha256=identities,platform=platform.platform(),privateNativeExecutable=True,
            ordinaryGuiAccepted=False,fullBetaAccepted=False,forcedCleanupUsed=False)
        with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
            child=subprocess.Popen(command,cwd=runtime,env=environment(runtime,out),stdout=stdout,stderr=stderr,
                creationflags=subprocess.CREATE_NO_WINDOW)
            record.update(status='running',pid=child.pid);write(out/'process.json',record)
            print(name,'PID',child.pid,flush=True)
            try:code=child.wait(timeout=180)
            except subprocess.TimeoutExpired:
                record.update(status='observation-timeout-process-left-running');write(out/'process.json',record)
                raise SystemExit('Inspect recorded PID; no automatic cleanup/restart')
        report=read(out/'probe/verification.json') if (out/'probe/verification.json').exists() else None
        record.update(status='terminal',exitCode=code,normalExit=code==0,
            passed=bool(code==0 and report and report.get('passed')),result=report,
            sourceInputsUnchanged=all(digest(repo/p)==h for p,h in inputs['files'].items()),
            runtimeUnchanged=all(digest(runtime/p)==h for p,h in identities.items()),
            producerUnchanged=digest(Path(__file__))==record['producerSha256'])
        write(out/'process.json',record);records.append(record)
        print(json.dumps({k:record[k] for k in ['case','exitCode','normalExit','passed','sourceInputsUnchanged','runtimeUnchanged']}),flush=True)
        if not all(record[k] for k in ['passed','sourceInputsUnchanged','runtimeUnchanged','producerUnchanged']):
            write(root/'verification.json',dict(status='stopped-on-failure',passed=False,records=records,fullBetaAccepted=False))
            raise SystemExit('Inspect conversion result before proceeding')
finally:kernel.SetErrorMode(previous)
write(root/'verification.json',dict(status='terminal',passed=True,records=records,fullBetaAccepted=False))
