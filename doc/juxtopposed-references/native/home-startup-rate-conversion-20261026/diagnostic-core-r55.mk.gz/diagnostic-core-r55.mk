ifndef DIAGNOSTIC_CORE_OUT
$(error Set DIAGNOSTIC_CORE_OUT)
endif
DIAGNOSTIC_CORE_OBJECTS = $(patsubst clock/libvlccore_la-clock.lo,$(DIAGNOSTIC_CORE_OUT)/clock.lo,$(patsubst video_output/libvlccore_la-vout_subpictures.lo,$(DIAGNOSTIC_CORE_OUT)/spu.lo,$(libvlccore_la_OBJECTS)))
.PHONY: owned-diagnostic-core
owned-diagnostic-core: $(DIAGNOSTIC_CORE_OUT)/libvlccore.la
$(DIAGNOSTIC_CORE_OUT):
	mkdir -p "$@"
$(DIAGNOSTIC_CORE_OUT)/spu.lo: /mnt/c/Modding/vlc-juxtopposed/build-windows/beta-single-frame-20261025-night/spu_trace_r50.c | $(DIAGNOSTIC_CORE_OUT)
	$(LIBTOOL) --tag=CC --mode=compile $(CC) $(DEFS) $(DEFAULT_INCLUDES) $(INCLUDES) $(AM_CPPFLAGS) $(CPPFLAGS) $(libvlccore_la_CPPFLAGS) -I$(srcdir)/video_output $(AM_CFLAGS) $(CFLAGS) -c "$<" -o "$@"
$(DIAGNOSTIC_CORE_OUT)/clock.lo: /mnt/c/Modding/vlc-juxtopposed/build-windows/beta-single-frame-20261025-night/clock_trace_r55.c | $(DIAGNOSTIC_CORE_OUT)
	$(LIBTOOL) --tag=CC --mode=compile $(CC) $(DEFS) $(DEFAULT_INCLUDES) $(INCLUDES) $(AM_CPPFLAGS) $(CPPFLAGS) $(libvlccore_la_CPPFLAGS) -I$(srcdir)/clock $(AM_CFLAGS) $(CFLAGS) -c "$<" -o "$@"
$(DIAGNOSTIC_CORE_OUT)/libvlccore.la: $(DIAGNOSTIC_CORE_OBJECTS) $(libvlccore_la_DEPENDENCIES)
	$(libvlccore_la_LINK) -rpath $(libdir) $(DIAGNOSTIC_CORE_OBJECTS) $(libvlccore_la_LIBADD) $(LIBS)
