from pathlib import Path
import ctypes as C, json, os, sys, time
runtime, media, out = map(Path, sys.argv[1:4]); mode = sys.argv[4]
assert mode in ['clean', 'seek', 'seek-no-sub']
out.mkdir(); records = out/'recordings'; records.mkdir()
config = out/'vlcrc'; config.write_text('metadata-network-access=0\ninput-record-path='+str(records)+'\n',encoding='utf-8')
dll_directory = os.add_dll_directory(str(runtime))
vlc = C.CDLL(str(runtime/'libvlc.dll'))
def bind(name, result, *args):
    fn = getattr(vlc,name); fn.restype=result; fn.argtypes=args; return fn
ptr=C.c_void_p
new=bind('libvlc_new',ptr,C.c_int,C.POINTER(C.c_char_p))
release=bind('libvlc_release',None,ptr)
media_new=bind('libvlc_media_new_path',ptr,C.c_char_p)
media_release=bind('libvlc_media_release',None,ptr)
player_new=bind('libvlc_media_player_new',ptr,ptr,ptr,ptr)
player_release=bind('libvlc_media_player_release',None,ptr)
set_media=bind('libvlc_media_player_set_media',None,ptr,ptr)
play=bind('libvlc_media_player_play',C.c_int,ptr)
state=bind('libvlc_media_player_get_state',C.c_int,ptr)
get_time=bind('libvlc_media_player_get_time',C.c_int64,ptr)
set_time=bind('libvlc_media_player_set_time',C.c_int,ptr,C.c_int64,C.c_bool)
pause=bind('libvlc_media_player_set_pause',None,ptr,C.c_int)
stop=bind('libvlc_media_player_stop_async',C.c_int,ptr)
record=bind('libvlc_media_player_record',None,ptr,C.c_bool,C.c_char_p)
options=['--no-ignore-config','--config='+str(config),'--no-media-library','--no-metadata-network-access',
 '--no-ml-network-discovery','--no-sub-autodetect-file','--sub-language=eng','--sub-fps=0',
 '--extraintf=','--control=','--vout=vdummy','--aout=dummy','--no-hw-dec','--avcodec-threads=1',
 '--start-paused','--file-logging','--verbose=2','--log-verbose=2','--logfile='+str(out/'vlc.log')]
if mode == 'seek-no-sub': options += ['--no-spu']
args=[s.encode('utf-8') for s in options]
instance=new(len(args),(C.c_char_p*len(args))(*args)); assert instance
player=None; report=dict(mode=mode, timeUnit='microseconds', seeks=[], fullBetaAccepted=False)
def wait(predicate, seconds, message):
    deadline=time.monotonic()+seconds
    while not predicate():
        assert state(player)!=6, 'native media error'
        assert time.monotonic()<deadline, message
        time.sleep(.01)
try:
    player=player_new(instance,None,None); assert player
    item=media_new(str(media).encode('utf-8')); assert item
    set_media(player,item); media_release(item); assert play(player)==0
    wait(lambda:state(player)==2,10,'initial playing deadline')
    pause(player,1); wait(lambda:state(player)==3,5,'explicit initial pause deadline')
    assert set_time(player,0,False)==0
    wait(lambda:abs(get_time(player))<50_000,5,'initial zero seek deadline')
    time.sleep(.2)
    if mode != 'clean':
        for seconds in [10,25,10,0,10,20,10,0]:
            assert set_time(player,seconds*1_000_000,False)==0
            wait(lambda:abs(get_time(player)-seconds*1_000_000)<50_000,5,'precise seek deadline')
            time.sleep(.2)
            report['seeks'].append(dict(requested=seconds*1_000_000, observed=get_time(player),state=state(player)))
    report['recordStartTime']=get_time(player)
    record(player,True,str(records).encode('utf-8')); time.sleep(.15)
    pause(player,0); wait(lambda:state(player)==2,5,'playing deadline')
    time.sleep(16)
    report['recordStopTime']=get_time(player)
    record(player,False,str(records).encode('utf-8')); time.sleep(.3)
    pause(player,1); wait(lambda:state(player)==3,5,'pause deadline')
finally:
    if player:
        stop(player)
        deadline=time.monotonic()+5
        while state(player)!=4 and time.monotonic()<deadline: time.sleep(.01)
        report['stopState']=state(player)
        player_release(player)
    release(instance)
report['files']=[dict(name=p.name,size=p.stat().st_size) for p in records.iterdir() if p.is_file()]
(out/'probe.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(report),flush=True)
