from pathlib import Path
from hashlib import sha256
import json, subprocess
work=Path(__file__).resolve().parent
roots=[work/'ui-customizer-transport-r305/recordings',work/'ui-customizer-record-clean-r305/recordings']
roots += [work/'native-short-record-before-r308'/mode/'recordings' for mode in ['clean','seek','seek-no-sub']]
roots += [work/'ui-customizer-record-short-r311/recordings']
roots += [work/'native-fast-record-before-r313'/mode/'recordings' for mode in ['seek','seek-no-sub']]
results=[]
for root in roots:
    for p in root.iterdir():
        if not p.is_file():continue
        path='/mnt/c/'+p.as_posix().split(':/',1)[1]
        prefix=['wsl.exe','-d','VLC-Juxtopposed-Home-20261018','--exec']
        probe_command=prefix+['/usr/bin/ffprobe','-v','error','-count_frames','-show_entries',
            'stream=index,codec_type,codec_name,nb_read_frames,start_time,duration:format=duration','-of','json',path]
        probe=subprocess.run(probe_command,capture_output=True,text=True,timeout=25)
        decode_command=prefix+['/usr/bin/ffmpeg','-hide_banner','-v','error','-xerror','-i',path,
            '-map','0:v:0','-map','0:a:0','-progress','pipe:1','-f','null','-']
        decode=subprocess.run(decode_command,capture_output=True,text=True,timeout=30)
        result=dict(path=p.relative_to(work).as_posix(),sha256=sha256(p.read_bytes()).hexdigest(),size=p.stat().st_size,
            probeCommand=probe_command,probeExit=probe.returncode,probeStderr=probe.stderr,
            probe=json.loads(probe.stdout) if probe.returncode==0 else None,
            decodeCommand=decode_command,decodeExit=decode.returncode,decodeStderr=decode.stderr,decodeProgress=decode.stdout)
        streams=(result['probe'] or {}).get('streams',[])
        result['decodedAV']=decode.returncode==0 and all(any(s['codec_type']==kind and int(s.get('nb_read_frames','0'))>0 for s in streams) for kind in ['video','audio'])
        results.append(result)
        print(result['path'],'decodedAV',result['decodedAV'],flush=True)
out=work/'recording-comparison-r314.json'
out.write_text(json.dumps(dict(fullBetaAccepted=False,results=results),indent=2)+'\n',encoding='utf-8',newline='\n')
print(out,flush=True)
