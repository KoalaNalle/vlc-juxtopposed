from pathlib import Path
from hashlib import sha256
import gzip, json

work = Path(__file__).resolve().parent
repo = work.parents[1]
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda p: sha256(p.read_bytes()).hexdigest()
runs = ['ui-customizer-draft-r304', 'ui-customizer-transport-r305',
        'ui-customizer-library-r305', 'ui-customizer-record-clean-r305',
        'ui-customizer-library-fixed-r311', 'ui-customizer-record-short-r311']
records = {name: read(work/name/'verification.json') for name in runs}
for name, record in records.items():
    assert record['normalExit'] and record['exitCode'] == 0
    assert record['moduleCounts'] == ['602']
    assert all(value for key, value in record.items() if key.endswith('Unchanged'))
    if name == 'ui-customizer-library-r305':
        assert len(record['diagnostics']) == 1
        assert "Property 'close'" in record['diagnostics'][0]
    else:
        assert not record['diagnostics']
before = read(work/'component-customizer-r310-before/verification.json')
fixed = read(work/'component-customizer-r311-fixed/verification.json')
routes = read(work/'component-page-routes-r311-fixed/verification.json')
assert before['negativeBaselineReproduced'] and not before['passed']
assert sum(not case['passed'] for case in before['cases']) == 5
assert fixed['passed'] and len(fixed['cases']) == 10 and not fixed['messages']
assert routes['passed'] and len(routes['completed']) == 15 and not routes['messages']
assert all(digest(repo/p) == h for p,h in fixed['sourceSha256'].items())
assert digest(repo/'modules/gui/qt/tests/test_customizer_routes.py') == fixed['helperSha256']
comparison = read(work/'recording-comparison-r314.json')
assert len(comparison['results']) == 8
assert not comparison['results'][0]['decodedAV']
assert all(result['decodedAV'] for result in comparison['results'][1:])
short = comparison['results'][5]
video = next(s for s in short['probe']['streams'] if s['codec_type'] == 'video')
assert video['nb_read_frames'] == '25' and video['duration'] == '1.000000'

def tree(run, name):
    return read(work/run/'observations'/(name+'.json'))['accessibility']['tree']

assert 'No playlists found' in tree('ui-customizer-library-fixed-r311', '02-fixed-first-playlists-tile-immediate')
out = repo/'doc/juxtopposed-references/native/home-customizer-routes-20261027'
assert not out.exists(); out.mkdir()
artifacts = []

def retain(p):
    name = p.relative_to(work).as_posix()+'.gz'
    target = out/name; target.parent.mkdir(parents=True, exist_ok=True)
    raw = p.read_bytes(); target.write_bytes(gzip.compress(raw, mtime=0))
    artifacts.append(dict(path=name,sha256=digest(target),rawSha256=sha256(raw).hexdigest()))

for name in runs:
    root = work/name
    for filename in ['verification.json','producer.py','launch.json','staging.json','layout-fixture.json']:
        p = root/filename
        if p.is_file(): retain(p)
    for p in sorted((root/'observations').glob('*')):
        if p.suffix in ['.json','.png']: retain(p)
for name in ['component-customizer-r310-before','component-customizer-r311-fixed','component-page-routes-r311-fixed']:
    retain(work/name/'verification.json')
for name in ['native-short-record-before-r308','native-fast-record-before-r313']:
    record = read(work/name/'verification.json')
    assert all(v for k,v in record.items() if k.endswith('Unchanged'))
    assert all(case['normalExit'] for case in record['cases'].values())
    retain(work/name/'verification.json')
    for p in sorted((work/name).glob('*/probe.json')): retain(p)
for filename in ['inputs-r310.json','inputs-r311.json','inputs-r312.json','inputs-r313.json',
    'freeze-navigation-r310.py','build-customizer-r311.sh','build-customizer-r311-exit.txt',
    'run-ui-customizer-r304.py','run-ui-customizer-tiles-r305.py','run-ui-customizer-fixed-r311.py',
    'record-short-worker-r308.py','record-fast-worker-r313.py','run-record-fast-r313.py',
    'inspect-recordings-r314.py','recording-comparison-r314.json','write-customizer-receipt-r315.py']:
    retain(work/filename)
result = dict(status='passed-scoped-navigation-and-quit-repair-recording-open',fullBetaAccepted=False,
    runtimeSha256=records['ui-customizer-library-fixed-r311']['runtimeSha256'],
    sourceSha256=fixed['sourceSha256'],componentFixedCases=10,pageLoaderCaseGroups=15,
    observations=[
        'GUI301 first Playlists tile was overwritten by the initial Home route: previousEmpty is also true with one valid entry. MainDisplay now defaults Home only for an empty viewPath. First playlist/detail/artist property maps survive in the extracted-production callback regression.',
        'GUI301 Quit tile invoked nonexistent MainCtx.close and emitted a real TypeError. It now invokes DialogsProvider.quit, also used by existing native quit routes. Disabled/busy tile guards remain effective.',
        'The new callback test reproduces five expected failures before the two changes and passes all ten cases after. Fifteen existing PageLoader case groups pass with their intentional unknown-property negative control retained in allMessages.',
        'Ordinary GUI311 opens Playlists on its first tile activation, returns to the paused player, opens Home from Playlists history and closes through the Quit tile. App exits0 with602modules, no error diagnostics and every source/runtime/base/media/cache/producer guard intact.',
        'GUI301 ordinary customizer Add/Save installs a Snapshot tile and produces a real generated-media PNG. Additional preseeded toolbar fixtures exercise bookmark add/reopen, favorite pointer/Space, sidebar, native media information/settings, paused jumps/Replay, speed/zoom, PiP and Stop. Preseeding does not prove gesture installation of each tile.',
        'Recording remains unaccepted: one ordinary output contains no decoded video, while another29.7-second desktop recording has only25video frames/1second with about10.9seconds audio. A longer desktop recording and five public-API native recordings decode both streams. A decode-exit pass alone does not establish complete duration or AV alignment.',
    ],limits=[
        'The before-library app exits normally but its strict runner fails for the real TypeError. Its original verification is preserved. The original transport app has zero diagnostics but its generated recording fails independent AV decoding; it is not an accepted recording journey.',
        'Native recording probes use dummy/software outputs and explicit public-API pause/seek, without the ordinary GUI. They do not resolve the desktop recording defect. Exact cause remains open; there is no production recording change in this checkpoint.',
        'Immediate and settled accessibility captures can differ. Observation names are not acceptance assertions; captures with stale clocks or animation must be read with their later settled observations.',
        'Full tile/action coverage, HDR native consumer, metadata variants, visual/accessibility/DPI and final-package replay remain open. Only generated owned media was used. Raw profiles, personal logs, databases, media and binaries are excluded.'
    ],artifacts=artifacts)
(out/'checkpoint.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# First toolbar route and Quit repair - 27 October 2026

The first Playlists tile opened Home because startup mistook a one-entry history
for empty history. Startup now preserves a valid first route and its properties.
The Quit tile called an unavailable method; it now uses the native quit provider.

The callback regression fails five expected cases before and passes all ten
after; fifteen PageLoader groups also pass. Ordinary GUI311 verifies first
Playlists, Home, retained paused input and normal Quit with zero error diagnostics
and all guards intact. Earlier tile and customizer journeys have separate scope.

Recording is still open. One ordinary recording contains no decoded video;
another has only one second of video alongside longer audio. Longer desktop and
native comparison recordings decode AV, which does not establish full duration
or synchronization. No recording fix is claimed here.

The [checkpoint](checkpoint.json) retains exact identities, original failures,
owned captures, probe results and limitations. Continue from
[STATUS](../../../juxtopposed/STATUS.md); all beta gates remain open.
''',encoding='utf-8',newline='\n')
for artifact in artifacts:
    p=out/artifact['path']
    assert digest(p)==artifact['sha256']
    assert sha256(gzip.decompress(p.read_bytes())).hexdigest()==artifact['rawSha256']
print(out,len(artifacts),'verified artifacts',flush=True)
