from pathlib import Path
from hashlib import sha256
import gzip,json
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
out=repo/'doc/juxtopposed-references/native/home-subtitle-load-restore-20261026'
assert not (out/'checkpoint.json').exists()
native=read(work/'native-all-r105/verification.json')
assert native['normalExit'] and native['sourceInputsUnchanged'] and len(native['functions'])==24
assert all(i['type']=='pass' for f in native['functions'] for i in f['incidents'])
uis={n:read(work/n/'verification.json') for n in ['ui-decode-r100','ui-decode-cold-r101','ui-late-r104','ui-late-cold-r105']}
for v in uis.values():
    assert v['normalExit'] and all(v[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','pluginCacheUnchanged'])
assert all(not v['diagnostics'] for n,v in uis.items() if n!='ui-decode-r100')
out.mkdir(exist_ok=True);artifacts=[]
def retain(path,name=None):
    raw=path.read_bytes();target=out/((name or path.relative_to(work).as_posix())+'.gz')
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(raw,mtime=0))
    artifacts.append(dict(path=target.relative_to(out).as_posix(),sha256=digest(target),rawSha256=sha256(raw).hexdigest()))
for folder in ['decode-before-r98','native-all-r100','integration-isolated-r100','native-trace-all-r101','native-trace-with-gui-r101','preset-before-cue-before-r102','native-all-r104','native-all-r105']:
    for name in ['verification.json','results.xml','stdout.txt','stderr.txt']:retain(work/folder/name)
for folder in uis:
    for name in ['verification.json','launch.json','vlc.log','settings-before.ini','settings-after.ini']:retain(work/folder/name)
    for pattern in ['*.jpg','*tree.txt']:
        for p in sorted((work/folder).glob(pattern)):retain(p)
for folder in ['attachment-accessibility-before-r101','attachment-accessibility-after-r102']:
    retain(work/folder/'verification.json')
    for pattern in ['*.stdout.txt','*.stderr.txt','*-stdout.txt','*-stderr.txt']:
        for p in sorted((work/folder).glob(pattern)):
            if not any(a['path']==p.relative_to(work).as_posix()+'.gz' for a in artifacts):retain(p)
for folder in ['decode-media-r100','late-media-r104']:
    for p in sorted((work/folder).iterdir()):
        if p.is_file():retain(p)
for revision in ['r98','r99','r101','r102','r103','r105']:
    manifest=read(work/f'inputs-{revision}.json');retain(work/f'inputs-{revision}.json')
    for key in ['maininterface/subtitle_attachment_model.hpp','maininterface/subtitle_attachment_model.cpp','maininterface/subtitle_preset_model.cpp','util/ui_notifier.hpp','util/ui_notifier.cpp','dialogs/dialogs/qml/JuxtopposedSubtitleAttachments.qml','tests/test_player_subtitle_delay.cpp','tests/test_juxtopposed_subtitle_attachments.py']:
        name='modules/gui/qt/'+key
        source=Path(manifest['sourceCopies'][name]);assert digest(source)==manifest['files'][name]
        retain(source,f'sources/{revision}/{name}')
for name in ['build-r99.sh','build-r99-exit.txt','build-r101.sh','build-r101-exit.txt','build-r102.sh','build-r102-exit.txt','build-r103.sh','build-r103-exit.txt','build-r105.sh','build-r105-exit.txt','run-native-decode-r98.py','run-native-trace-r101.py','run-ui-decode-r100.py','run-ui-late-r104.py','write-load-restore-receipt-r106.py']:retain(work/name)
record=dict(status='scoped-checkpoint-session-continues',fullBetaAccepted=False,nativeFunctions=24,nativeTestSha256=native['testExecutableSha256'],ordinaryRuntimeSha256={n:v['runtimeSha256'] for n,v in uis.items()},artifacts=artifacts,
    loadFailure='Readable invalid SRT produces one deferred notification and retained actionable error after 8 seconds. Existing mappings are preserved; a different valid file recovers without moving the paused clock. Superseded checks cannot publish stale failures. A reentrant native lock observer passes.',
    beforeFirstCue='Known selected native ES order is sufficient before a caption output exists. Capture/apply no longer wait for a nonexistent SPU vout while paused before the first cue. Actual output events continue refining role identity.',
    testCorrections='r104 late-cue rows reach Save but collide with immediate-row preset names in persistent test settings. r105 only makes names unique across cue variants and prints save errors. Production GUI/model source is unchanged. r105 all 24 functions pass with the ordinary GUI simultaneously active and optional trace disabled.',
    ordinary='Four ordinary processes exit normally with unchanged source/runtime/fixture/cache guards and 602 modules. Malformed-load toast/error, valid replacement and cold caption return pass. New saved preset at paused 0.08 seconds, cold 30fps restore, Default/reapply before first cue and paused seek to the actual late cue pass.',
    diagnostics='ui-decode-r100 retains nine expected DVD probe diagnostics for the deliberately invalid SRT. The other three ordinary runs have no diagnostics. Failed before controls and mixed-suite failures are retained.',
    limits=['Error Accessible.name has supplied-state before/after evidence; ordinary r100 predates that fix.','Narrow-window toast layout, online search/download, remaining W1/W2 paths and final-package/design gates are unfinished.','Private native fixture and ordinary GUI are separate binaries; no full beta acceptance.'])
(out/'checkpoint.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Subtitle load recovery and before-cue presets - 26 October 2026

The selected ordinary runtime is Core `883f7e51` / GUI `03a963ad`. Twenty-four
native functions pass with the ordinary application simultaneously running and
optional diagnostic tracing disabled. This includes four attachment/preset
construction-order and delayed-cue rows, eight timing-context rows and malformed
attachment recovery. Native and ordinary binaries have separate identities.

A readable invalid subtitle now produces one delayed notice and a retained
actionable error. Choosing a valid replacement recovers the actual caption at
the unchanged paused clock; that replacement returns after restart. Superseded
load checks do not publish stale errors. The native reentrant-lock observer passes.
The negative ordinary run retains expected DVD probe diagnostics for its invalid
SRT; the other three ordinary runs have none.

Preset capture and restore use the selected track's known native order before
the first subtitle output exists. Previously a player paused before the first
cue could wait indefinitely. Ordinary save, cold 30 fps restore, Default and
named reapply all complete before the first cue; seeking while paused then shows
the actual late caption. Native output events still refine renderer role identity.

The r104 fixture reached Save but reused names across immediate/late rows. The
r105 test-only unique-name correction is preserved separately; production source
is unchanged. Earlier mixed-run and deterministic before-cue failures remain.
All four ordinary processes close normally with 602 modules and unchanged guards.

The error's accessible name has a separate supplied-state failing-before/passing-
after control. Ordinary error run r100 predates that accessibility change.
Narrow-window notices, online search/download and remaining beta gates are open.
[checkpoint.json](checkpoint.json) binds exact identities and immutable gzip
artifacts. Continue from [STATUS](../../../juxtopposed/STATUS.md).
''',encoding='utf-8',newline='\n')
print(str(out),len(artifacts),flush=True)
