#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
native="$base/owned-single-frame-native-20261026-r105"
ordinary="$base/owned-single-frame-ordinary-20261026-r105"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-r105.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-r105-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 883f7e51c57be0de40e8c6a47db6ca3f60ac4cdb98920a9846b9a5e8ce8adb22
test ! -e "$native"
test ! -e "$ordinary"
test ! -e "$work/native-r105-bin"
test ! -e "$work/ordinary-r105-bin"
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/build-windows/beta-subtitle-fps-20261023/native-r1.mk" -j2 FPS_NATIVE_OUT="$native" owned-subtitle-fps-native
mkdir "$work/native-r105-bin"
cp "$native/.libs/test_qt_player_subtitle_delay.exe" "$work/native-r105-bin/"
sha256sum "$work/native-r105-bin/test_qt_player_subtitle_delay.exe"
