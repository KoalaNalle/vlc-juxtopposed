from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
from PySide6.QtGui import QImage,QColor
work=Path(__file__).resolve().parent;out=work/'music-media-r273';assert not out.exists();out.mkdir()
prefix=['wsl.exe','-d','VLC-Juxtopposed-Home-20261018','--']
posix=lambda p:'/mnt/c/'+str(p.resolve()).replace('\\','/')[3:]
rows=[]
for directory,title,artist,album,genre,index in [
 ('My Songs','First light','Fixture Artist','Morning Album','Ambient',1),
 ('My Songs','Second light','Fixture Artist','Morning Album','Ambient',2),
 ('My Songs','A long title for checking truncation and focus in the redesigned music library','Another Artist','Evening Album','Electronic',1),
 ('My Songs/Nested collection','Nested song','Another Artist','Evening Album','Electronic',2),
 ('N\u00e4ive Songs','Unicode song \u00e4\u00f6','\u00c4rtist','\u00c4lbum','Ambient',1)]:
    folder=out/directory;folder.mkdir(parents=True,exist_ok=True)
    cover=out/('cover-'+str(len(rows))+'.png');image=QImage(128,128,QImage.Format_RGB32)
    image.fill(QColor('#2A6F99' if index==1 else '#9E442A'));assert image.save(str(cover))
    target=folder/(str(index)+'-'+title[:18]+'.flac')
    cmd=prefix+['/usr/bin/ffmpeg','-nostdin','-v','error','-n','-f','lavfi','-i','anullsrc=r=44100:cl=stereo',
        '-i',posix(cover),'-map','0:a','-map','1:v','-t','60','-c:a','flac','-c:v','copy','-disposition:v','attached_pic',
        '-metadata','title='+title,'-metadata','artist='+artist,'-metadata','album_artist='+artist,
        '-metadata','album='+album,'-metadata','genre='+genre,'-metadata','track='+str(index),posix(target)]
    p=subprocess.run(cmd,capture_output=True,timeout=40,creationflags=subprocess.CREATE_NO_WINDOW)
    assert p.returncode==0,p.stderr.decode(errors='replace')
    probe=subprocess.run(prefix+['/usr/bin/ffprobe','-v','error','-show_format','-show_streams','-of','json',posix(target)],capture_output=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
    assert probe.returncode==0
    rows.append(dict(path=target.relative_to(out).as_posix(),metadata=json.loads(probe.stdout),command=cmd))
video=work/'attachment-media-r85/Show.S01E01.mp4'
assert sha256(video.read_bytes()).hexdigest()=='fd82d189533aa73d9715596d9856d27960cf76c76df1baaa0632672660c9b42d'
shutil.copyfile(video,out/'My Songs/Video mixed into music folder.mp4')
files={p.relative_to(out).as_posix():sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file()}
(out/'manifest.json').write_text(json.dumps(dict(scope='Generated silent tagged FLAC with embedded owned solid-color covers, nested/Unicode folders and one video mixed into the music folder.',files=files,cases=rows,producerSha256=sha256(Path(__file__).read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8',newline='\n')
text=(work/'run-ui-late-r265.py').read_text(encoding='utf-8')
text=text.replace("media=work/'attachment-media-r85'","media=work/'attachment-media-r85'\nmusic=work/'music-media-r273'\nmusic_fixtures={p.relative_to(music).as_posix():digest(p) for p in music.rglob('*') if p.is_file()}")
text=text.replace("media.as_uri()","music.as_uri()")
text=text.replace("lateFixtureSha256=late_fixtures,","musicFixtureSha256=music_fixtures,lateFixtureSha256=late_fixtures,")
text=text.replace("lateFixturesUnchanged=all(","musicFixturesUnchanged=all(digest(music/p)==h for p,h in music_fixtures.items()),lateFixturesUnchanged=all(")
text=text.replace('Ordinary secondary/per-track timing and estimator journey; generated ten-minute clip, encoded markers repeat once per source minute; strict native outcomes remain separately recorded. Generated fixtures only; actual Computer Use observations required.',
 'Ordinary music category/folder/detail journey with generated silent tagged files; one60.011s encoded video holds primary playback. Actual Computer Use observations and native library indexing are required.')
target=work/'run-ui-music-r273.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared',len(files),'owned generated files and ordinary music runner',flush=True)
