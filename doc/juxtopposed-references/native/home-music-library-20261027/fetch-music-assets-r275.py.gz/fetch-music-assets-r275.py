from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess,xml.etree.ElementTree as ET
work=Path(__file__).resolve().parent;repo=work.parents[1];out=work/'music-assets-r275';assert not out.exists();out.mkdir()
assets=repo/'modules/gui/qt/pixmaps/juxtopposed'
prefix='https://www.figma.com/api/mcp/asset/b2c92c35-191f-47a4-8950-6864844feeb0/'
rows=[]
for name,file in [('songs','018cc.svg'),('albums','beb21.svg'),('artists','7bb62.svg'),('genres','66b4e.svg'),('add','97a9d.svg'),('folder','cf6e1.svg')]:
    url=prefix+file
    if name=='folder':url='https://www.figma.com/api/mcp/asset/42b0842b-8752-4ac5-a518-c1e9923e0d87/'+file
    target=out/(name+'.svg')
    p=subprocess.run(['curl.exe','-f','-L','--silent','--show-error','--max-time','30','--output',str(target),url],capture_output=True,timeout=40,creationflags=subprocess.CREATE_NO_WINDOW)
    assert p.returncode==0,p.stderr.decode(errors='replace')
    attrs=ET.parse(target).getroot().attrib;assert attrs.get('width')=='24' and attrs.get('height')=='24',attrs
    h=sha256(target.read_bytes()).hexdigest()
    matches=[p for p in assets.glob('*.svg') if sha256(p.read_bytes()).hexdigest()==h]
    selected=matches[0] if matches else assets/('music-'+name+'-'+file)
    if not matches:assert not selected.exists();shutil.copyfile(target,selected)
    rows.append(dict(slot=name,node='858:5001' if name!='folder' else '4767:23606',url=url,sha256=h,width=24,height=24,selected=selected.relative_to(repo).as_posix(),existingMatch=bool(matches)))
(out/'manifest.json').write_text(json.dumps(dict(fileKey='zdNUYRVOH9lEtIxMYvh8DV',sessionId='0ece9d99-62f1-4c65-98d2-e283d693a6ed',date='2026-10-27',assets=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(rows,indent=2),flush=True)
