from pathlib import Path
import json
work=Path(__file__).resolve().parent
for name in ['build-music-r285.sh','run-ui-music-r285.py','run-ml-play-request-r285.py']:
    target=work/name.replace('r285','r286');assert not target.exists()
    text=(work/name).read_text().replace('r285','r286')
    if name.endswith('.sh'):
        line=next(line for line in text.splitlines() if 'ML_REQUEST_OUT=' in line)
        text=text.replace(line+'\n','')
        after='cp "$base/win64/modules/.libs/libmedialibrary_plugin.dll" "$work/ordinary-r286-bin/"\n'
        text=text.replace(after,after+line+'\n')
    target.write_text(text,encoding='utf-8',newline='\n')
print(json.dumps(dict(prepared=True)))
