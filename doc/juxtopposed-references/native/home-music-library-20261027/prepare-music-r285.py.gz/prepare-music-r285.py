from pathlib import Path
import json
work=Path(__file__).resolve().parent
for name in ['build-music-r284.sh','run-ui-music-r284.py','run-ml-play-request-r284.py']:
    target=work/name.replace('r284','r285');assert not target.exists()
    text=(work/name).read_text().replace('r284','r285')
    if name.startswith('run-ml-'):
        text=text.replace('assert len(cases)==5','assert len(cases)==6')
    target.write_text(text,encoding='utf-8',newline='\n')
print(json.dumps(dict(prepared=True)))
