#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
ordinary="$base/owned-music-ordinary-20261027-r285"
native="$base/owned-ml-play-request-20261027-r285"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-music-r285.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-music-r285-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = fdfcfcd599588512bb7f3a51e46305b7b0d947b47387dd205851feb45f032b46
test ! -e "$ordinary"
test ! -e "$native"
test ! -e "$work/ordinary-r285-bin"
make -C "$base/win64/modules" -j2 libmedialibrary_plugin.la
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/build-windows/beta-subtitle-sync-20261025/ordinary.mk" -j2 QA_OUT="$ordinary" owned-ordinary-subtitle-sync
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/modules/gui/qt/tests/native_library/ml-play-request.mk" -j2 ML_REQUEST_OUT="$native" ml-play-request-native
mkdir "$work/ordinary-r285-bin"
cp "$ordinary/.libs/libqt_plugin.dll" "$work/ordinary-r285-bin/"
cp "$base/win64/modules/.libs/libmedialibrary_plugin.dll" "$work/ordinary-r285-bin/"
cp "$native/.libs/test_qt_ml_play_request.exe" "$work/ordinary-r285-bin/"
cp "$(x86_64-w64-mingw32-gcc -print-file-name=libssp-0.dll)" "$work/ordinary-r285-bin/"
sha256sum "$work/ordinary-r285-bin/"*
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = fdfcfcd599588512bb7f3a51e46305b7b0d947b47387dd205851feb45f032b46
