from pathlib import Path
import json
work=Path(__file__).resolve().parent
repo=work.parents[1]
def write(name,text):
    target=work/name;assert not target.exists()
    target.write_text(text,encoding='utf-8',newline='\n')
freeze=(work/'freeze-music-r282.py').read_text()
freeze=freeze.replace("forbidden={", "names.update(['modules/gui/qt/tests/test_ml_play_request.cpp','modules/gui/qt/tests/native_library/ml-play-request.mk'])\nforbidden={")
write('freeze-music-r284.py',freeze)
runner=(work/'run-ui-music-r282.py').read_text()
runner=runner.replace("assert all(digest(base/p)==h for p,h in expected.items())", "assert all(digest(base/p)==h for p,h in expected.items())\nbase_identities=dict(expected)\nml_name='plugins/misc/libmedialibrary_plugin.dll'\nbase_identities[ml_name]=digest(base/ml_name)")
runner=runner.replace("work/'ordinary-r282-bin/libqt_plugin.dll'", "work/'ordinary-r284-bin/libqt_plugin.dll'")
runner=runner.replace("runtimeUnchanged=all(digest(base/p)==h and digest(runtime/p)==identities[p] for p,h in expected.items()),", "runtimeUnchanged=all(digest(runtime/p)==h for p,h in identities.items()),\n baseRuntimeUnchanged=all(digest(base/p)==h for p,h in base_identities.items()),")
runner+='\nassert record["normalExit"] and not record["diagnostics"]\nassert all(record[k] for k in ["sourceInputsUnchanged","runtimeUnchanged","baseRuntimeUnchanged","musicFixturesUnchanged","fixturesUnchanged","lateFixturesUnchanged","decodeFixturesUnchanged","extraFixturesUnchanged","producerUnchanged","pluginCacheUnchanged"])\n'
write('run-ui-music-r284.py',runner)
build=(work/'build-music-r282.sh').read_text().replace('r282','r284')
build=build.replace('owned-music-queries-20261027-r284','owned-ml-play-request-20261027-r284')
build=build.replace('tests/native_library/music-queries.mk','tests/native_library/ml-play-request.mk').replace('MUSIC_QUERIES_OUT=', 'ML_REQUEST_OUT=').replace(' music-queries-native',' ml-play-request-native')
build=build.replace('cp "$native/test_qt_music_library_queries.exe"', 'cp "$native/.libs/test_qt_ml_play_request.exe"')
write('build-music-r284.sh',build)
native=(work/'run-music-queries-r283.py').read_text()
native=native.replace("revision,label,mode=sys.argv[1:];assert mode in ['legacy','fixed']", "revision,label,mode=sys.argv[1:];assert mode=='fixed'")
native=native.replace("work/'ordinary-r282-bin'/target.name", "(work/'ordinary-r284-bin' if target.name=='libqt_plugin.dll' else work/'ordinary-r282-bin')/target.name")
native=native.replace('test_qt_music_library_queries.exe','test_qt_ml_play_request.exe').replace("work/'native-music-real-r283-bin'/program.name", "work/'ordinary-r284-bin'/program.name")
native=native.replace('assert len(cases)==6', 'assert len(cases)==5')
native=native.replace("scope='Real native library queries and generated SQL-backed folder/media/artist records. The legacy criterion selects the preceding audio-model mapping, not a previous executable or Core. No ordinary desktop, Qt model or hardware playback claim.'", "scope='Production MLBaseModel selected Play, MediaLib worker lifetime and real native playlist/database. A bounded delayed snapshot loader forces the source view to disappear before completion; ordinary read cancellation, offset/order/origin and short/invalid results are checked. No ordinary desktop or physical audio claim.'")
write('run-ml-play-request-r284.py',native)
print(json.dumps(dict(prepared=True)))
