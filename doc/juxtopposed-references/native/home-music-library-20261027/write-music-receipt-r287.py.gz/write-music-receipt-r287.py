from pathlib import Path
from hashlib import sha256
import gzip,json,re
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
out=repo/'doc/juxtopposed-references/native/home-music-library-20261027'
assert not out.exists()
manifest=read(work/'inputs-r286.json')
assert all(digest(repo/p)==h for p,h in manifest['files'].items())
accepted=['ui-music-play-r286','ui-music-classic-r286','ui-music-cold-r286']
earlier=['ui-music-before-r274','ui-music-r279','ui-music-fixed-r283']
records={n:read(work/n/'verification.json') for n in accepted+earlier}
guards=['sourceInputsUnchanged','runtimeUnchanged','baseRuntimeUnchanged','fixturesUnchanged',
 'musicFixturesUnchanged','lateFixturesUnchanged','decodeFixturesUnchanged',
 'extraFixturesUnchanged','producerUnchanged','pluginCacheUnchanged']
for name in accepted:
    v=records[name]
    assert v['normalExit'] and v['exitCode']==0 and v['moduleCounts']==['602'] and not v['diagnostics']
    assert all(v[k] for k in guards)
    assert not v['privateCore'] and not v['privateGui'] and not v['forcedCleanupUsed']
assert all(records[n]['runtimeSha256']==records[accepted[0]]['runtimeSha256'] for n in accepted)
native={n:read(work/n/'verification.json') for n in ['music-queries-fixed-r283','music-queries-legacy-r283','ml-play-request-r286']}
for name,v in native.items():
    assert v['cases']==6 and v['qtestCompleted']
    assert all(v[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','baseRuntimeUnchanged',
      'fixturesUnchanged','producerUnchanged','pluginCacheUnchanged'])
    assert not v['forcedCleanupUsed']
    if 'legacy' in name:
        assert v['exitCode']==1 and [f['name'] for f in v['failures']]==['mediaTrackOrderDistinctFromCollectionCount']
    else:assert v['normalExit'] and not v['failures']

def tree(name,obs):return read(work/name/'observations'/obs)['accessibility']['tree']
warm=accepted[0];cold=accepted[2];classic=accepted[1]
assert 'File Name: 1-Unicode song äö.flac' in tree(warm,'03-keyboard-unicode-playing.json')
assert 'Elapsed time: 00:00:06' in tree(warm,'03-keyboard-unicode-playing.json')
assert 'Value: no-match-owned-286' in tree(warm,'08-empty-search-paused.json')
assert 'text 0 items' in tree(warm,'08-empty-search-paused.json')
assert 'text 5 items' in tree(warm,'09-search-clear-five-songs.json')
assert 'Value: First' in tree(warm,'10-filtered-first-song-paused.json')
assert 'File Name: 1-First light.flac' in tree(warm,'11-filtered-keyboard-playing.json')
assert 'Elapsed time: 00:00:09' in tree(warm,'14-video-keyboard-playing.json')
assert 'Video mixed into music folder' not in '\n'.join(l for l in tree(classic,'01-traditional-flat-tracks.json').splitlines() if 'text ' in l and 'Show.S01' not in l)
names=re.findall(r'item \(settable, string\) (.*?) ID:',tree(cold,'02-cold-mixed-folder-track-descending.json'))
assert names==['A long title for checking truncation and focus in the redesigned music library','Second light','First light'],names

# Keep the original false guard. Explain the producer bug using separate identities.
broken=records['ui-music-fixed-r283'];assert broken['runtimeUnchanged'] is False
assert all(digest(work/'ui-music-fixed-r283/runtime'/p)==h for p,h in broken['runtimeSha256'].items())
base=repo/'build-windows/beta-subtitle-sync-20261025/ui-r1/runtime'
ml='plugins/misc/libmedialibrary_plugin.dll'
guard_explanation=dict(originalRuntimeUnchanged=False,
 runtimeStillMatchesRecordedIdentities=True,baseMediaLibrarySha256=digest(base/ml),
 stagedMediaLibrarySha256=broken['runtimeSha256'][ml],
 reason='The r282 producer overwrote expected[ML] with the replacement DLL, then compared the untouched base DLL against that replacement at exit. Its combined guard is false by construction. The r284+ producer preserves independent base and staged identities; all three r286 runs pass both. The original result is not rewritten or promoted to an all-guards pass.')
assert guard_explanation['baseMediaLibrarySha256']!=guard_explanation['stagedMediaLibrarySha256']
out.mkdir();artifacts=[];local=[]
def retain(p,relative=None):
    relative=(relative or p.relative_to(work).as_posix())+'.gz'
    target=out/relative;assert not target.exists()
    raw=p.read_bytes();target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(raw,mtime=0))
    artifacts.append(dict(path=relative,sha256=digest(target),rawSha256=sha256(raw).hexdigest()))
for name in accepted+earlier+list(native)+['music-queries-fixed-r282']:
    root=work/name
    for filename in ['verification.json','launch.json','producer.py','results.xml','observer-recovery-r283.json','ml-copy.json']:
        p=root/filename
        if p.is_file():retain(p)
    if (root/'observations').exists():
        for p in sorted((root/'observations').iterdir()):
            if p.suffix in ['.png','.json']:retain(p)
    for filename in ['vlc.log','stdout.txt','stderr.txt','vlcrc','config-before.txt','config-after.txt','settings-before.ini','settings-after.ini']:
        p=root/filename
        if p.is_file():local.append(dict(path=p.relative_to(work).as_posix(),sha256=digest(p),packaged=False))
for p in sorted((work/'music-components-r279').glob('*.png')):retain(p)
for p in sorted((work/'figma-music-r272').iterdir()):
    if p.suffix in ['.png','.txt']:retain(p)
retain(work/'music-assets-r275/manifest.json')
retain(work/'music-media-r273/manifest.json')
for rev in ['r273','r279','r282','r283','r284','r285','r286']:
    p=work/f'inputs-{rev}.json'
    if p.is_file():retain(p)
sources=[p for p in manifest['files'] if (p.startswith('modules/gui/qt/medialibrary/') and
 p.rsplit('/',1)[-1] in ['mlbasemodel.cpp','mlbasemodel.hpp','mlaudiomodel.cpp','mlvideofoldersmodel.cpp','mlvideofoldersmodel.hpp',
 'MusicDisplay.qml','MusicCategoriesDisplay.qml','MusicSongsDisplay.qml','MusicFoldersDisplay.qml','MusicTracksDisplay.qml','MusicTrackListDisplay.qml'])]
sources+=['include/vlc_media_library.h','modules/misc/medialibrary/medialibrary.cpp',
 'modules/gui/qt/widgets/qml/JuxtopposedCategoryList.qml','modules/gui/qt/widgets/qml/PageExt.qml',
 'modules/gui/qt/tests/test_ml_play_request.cpp','modules/gui/qt/tests/native_library/ml-play-request.mk',
 'modules/gui/qt/tests/test_music_library_queries.cpp','modules/gui/qt/tests/native_library/music-queries.mk',
 'modules/gui/qt/tests/test_juxtopposed_library.py','modules/gui/qt/maininterface/mainui.cpp',
 'modules/gui/qt/Makefile.am','modules/gui/qt/assets.qrc','modules/gui/qt/pixmaps/juxtopposed/ATTRIBUTION.md']
for source in sources:
    p=Path(manifest['sourceCopies'][source]);assert digest(p)==manifest['files'][source]
    retain(p,'sources/'+source)
for name in ['freeze-music-r284.py','run-ui-music-r273.py','run-ui-music-r279.py','run-ui-music-r282.py',
 'run-ui-music-r286.py','run-music-queries-r283.py','run-ml-play-request-r286.py','build-music-r284.sh',
 'build-music-r285.sh','build-music-r286.sh','prepare-music-r273.py','fetch-music-assets-r275.py',
 'prepare-music-r284.py','prepare-music-r285.py','prepare-music-r286.py','write-music-receipt-r287.py']:
    p=work/name
    if p.is_file():retain(p)
builds={}
for rev in ['r284','r285','r286']:
    log=work/f'build-music-{rev}.log';exitfile=work/f'build-music-{rev}-exit.txt'
    builds[rev]=dict(exitCode=int(exitfile.read_text()),logSha256=digest(log),
       errors=[l for l in log.read_text(errors='replace').splitlines() if 'error:' in l or 'undefined reference' in l])
record=dict(status='passed-scoped-music-library-nightly',fullBetaAccepted=False,
 runtimeSha256=records[warm]['runtimeSha256'],nativeResults=native,
 sourceManifestSha256=digest(work/'inputs-r286.json'),sourceInputCount=len(manifest['files']),
 appRuns={n:dict(exitCode=records[n]['exitCode'],allGuards=True) for n in accepted},
 earlierRunRoles={'ui-music-before-r274':'flat-song baseline', 'ui-music-r279':'folders before Sort repair',
 'ui-music-fixed-r283':'Sort repair and reproduced keyboard failure; combined runtime guard is false'},
 guardExplanation=guard_explanation,builds=builds,artifacts=artifacts,localStreams=local,
 figma=dict(fileKey='zdNUYRVOH9lEtIxMYvh8DV',nodes={'858:5001':'category assets/layout',
 '4767:23606':'Songs folder step','4778:24990':'folder track list'},
 fullVisualScore=None,windowsDpiAccepted=False),
 accepted=[
 'Designed Songs now opens real indexed audio folders, including nested and Unicode containing folders, plus an explicit All songs fallback. Mixed video is excluded from audio queries. Original category assets retain24px roots and the measured reflections.',
 'A distinct native media-track criterion maps to TrackId; the existing artist/album track-count criterion keeps its prior meaning. The old audio mapping fails the real query control; the new mapping passes folder membership, typed paging/search and artist-count checks.',
 'Explicit MLBaseModel Play snapshots outlive the source view under MediaLib. Six native functions complete normally, verifying queue order/offset/origin, read cancellation, short/invalid results and service shutdown with a real backend/playlist and a bounded delayed snapshot loader.',
 'Ordinary Enter starts the Unicode song, a filtered First light song and the indexed video. Playback advances; Pause holds it. Returning to the library preserves folder and paused clock. All songs returns5audio, empty search returns0 and clearing restores5. Music continues while navigating to Albums.',
 'Traditional Tracks remains flat and keyboard playback advances in the mini player. Redesigned cold restart retains3folders and mixed-folder descending Track order long/Second/First. All three accepted apps exit0/602modules/zero errors with every source, base/runtime, fixture, producer and cache guard true.'
 ],limits=[
 'The r283 combined runtime guard remains false; its producer compared the old base ML DLL with the new replacement. Separate current hashes verify the recorded staged runtime. This qualification is preserved, not retroactively erased.',
 'The r282 query attempt copied a65024byte libtool launcher rather than the13701303byte executable. No tests/report ran; child exit code was not saved. The recovery record and valid r283 executable/results are distinct. Native fixture compilation r284 failed on private helper access; r285 failed on a missing module-name definition. r286 builds/exits0.',
 'Component r279 passed during the session; only its generated images and test source are retained here. They simulate scale/layout and do not establish OS DPI. Some ordinary accessibility trees lag a rendered transition; settled observations supply acceptance. Search required a second focus action before a visible caret, and real typing rather than set_value.',
 'Disc metadata remains visible but its unsupported independent sort is disabled. Native Track order is album/track grouping, not a global scalar sort by displayed number. Folder entries are indexed containing folders, not a recursive filesystem browser. Search text is not retained through Back/Forward.',
 'The Albums observation contains4native albums, including two Evening Album entries from different directories. Album grouping, complete artist/genre/detail journeys and all category sort/view/search contracts remain to qualify. Initial empty sort criteria can lack a selected Title indicator.',
 'No full surface visual score, Windows DPI/monitor/accessibility acceptance or clean portable-package claim. No new physical endpoint, Windows10, subtitle-format or broad current-GUI regression claim is supplied by this music receipt. All beta gates remain open.'
 ])
(out/'checkpoint.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Music library nightly - 27 October 2026

Core `fdfcfcd5`, ordinary GUI `41079bd8` and library module `13ccdc36`
implement the original category artwork and Songs -> folder -> tracks route.
Real audio queries exclude mixed video, while All songs retains a flat fallback.
Native Track sort now uses media track identity rather than the unrelated
artist/album collection-count criterion. Disc stays a read-only metadata column.

Keyboard Play survives removal of its source view. Six native functions verify
the real service/queue lifetime, selected order, offset and playlist origin,
cancelled reads, removed/invalid rows and normal shutdown. Six real query functions
pass with the new criterion; the old criterion fails its intended control.

Ordinary keyboard playback passes for a Unicode song, filtered song and video.
Empty search/clear, paused and playing navigation, traditional flat Tracks and
cold folder/Track-sort restoration pass in their recorded scopes. Three accepted
apps exit0/602modules/zero errors with all guards true. The
[checkpoint](checkpoint.json) preserves exact identities, captures, native reports,
Figma nodes and earlier failures, including the corrected base/runtime guard.

Complete album/artist/genre journeys, repeated album-title grouping, independent
Disc sort, initial empty sort selection, search-history retention, full design
scores, Windows DPI and final-package gates remain distinct unfinished work.
Raw profiles, databases, application logs and binaries stay local. Continue from
[STATUS](../../../juxtopposed/STATUS.md).
''',encoding='utf-8',newline='\n')
for a in artifacts:
    p=out/a['path'];assert digest(p)==a['sha256'] and sha256(gzip.decompress(p.read_bytes())).hexdigest()==a['rawSha256']
print(out,len(artifacts),'verified artifacts',flush=True)
