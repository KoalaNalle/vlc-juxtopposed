from pathlib import Path
from hashlib import sha256
import gzip,json

work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
out=repo/'doc/juxtopposed-references/native/home-estimator-speed-defaults-20261026'
assert not out.exists()
m=read(work/'inputs-r231.json')
assert all(digest(repo/p)==h for p,h in m['files'].items())
native=read(work/'native-all-software-r230/verification.json')
assert native['normalExit'] and len(native['functions'])==31
assert all(i['type']=='pass' for f in native['functions'] for i in f['incidents'])
for function,count in [('estimatorAppliesMediaTime',24),('timingContextCancellation',12)]:
    assert len(next(f for f in native['functions'] if f['name']==function)['incidents'])==count
assert native['latePictureWarnings']==native['avcodecLateErrors']==0
for name in ['native-scaled-one-before-r229','native-context-one-before-r229']:
    v=read(work/name/'verification.json');assert not v['normalExit'] and v['exitCode']==1
    assert all(v[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged'])
ordinary=['ui-default-fps-r228','ui-default-cold-r228','ui-estimator-scaled-r231']
for name in ordinary:
    v=read(work/name/'verification.json')
    assert v['normalExit'] and not v['diagnostics'] and v['moduleCounts']==['602']
    assert all(v[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','pluginCacheUnchanged'])
pairs=read(work/'ui-estimator-scaled-r231/observations/timed-pairs.json')
for p in pairs:
    p['minimumMediaMs']=(p['secondBefore']-p['firstAfter'])*p['rate']
    p['maximumMediaMs']=(p['secondAfter']-p['firstBefore'])*p['rate']
    assert p['minimumMediaMs'] <= abs(p['observedMediaMs']) <= p['maximumMediaMs']
    assert abs(p['observedMediaMs']) > p['secondAfter']-p['firstBefore']
assert {p['observedMediaMs'] for p in pairs}=={8433,-7756}
defaults=read(work/'ordinary-default-r228.json');assert defaults['passed']
embedded=read(work/'embedded-delay-before-r231/process.json')
assert embedded['normalExit'] and not embedded['result']['passed']
assert embedded['result']['checks']['captions'] and not embedded['result']['checks']['heldFrame']
out.mkdir();artifacts=[];streams=[]
def retain(p,relative=None):
    target=out/((relative or p.relative_to(work).as_posix())+'.gz')
    assert not target.exists();raw=p.read_bytes();target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(raw,mtime=0))
    artifacts.append(dict(path=target.relative_to(out).as_posix(),sha256=digest(target),rawSha256=sha256(raw).hexdigest()))
names=ordinary+['native-scaled-before-r228','native-scaled-one-before-r229',
    'native-context-one-before-r229','native-all-software-r230','embedded-delay-before-r231']
for name in names:
    for p in sorted((work/name).rglob('*')):
        if not p.is_file() or any(x in p.relative_to(work/name).parts for x in
            ['runtime','userdata','appdata','localappdata','temp']):continue
        if p.suffix in ['.log','.txt']:
            streams.append(dict(path=p.relative_to(work).as_posix(),sha256=digest(p),packaged=False))
        elif p.suffix in ['.json','.xml','.png','.py','.qml']:retain(p)
for revision in ['r228','r229','r230','r231']:
    retain(work/f'inputs-{revision}.json');v=read(work/f'inputs-{revision}.json')
    for name in ['modules/gui/qt/player/qml/TracksPageAudio.qml',
                 'modules/gui/qt/player/qml/TracksPageSubtitle.qml',
                 'modules/gui/qt/tests/test_player_subtitle_delay.cpp','modules/demux/mp4/mp4.c']:
        p=Path(v['sourceCopies'][name]);assert digest(p)==v['files'][name]
        retain(p,f'sources/{revision}/{name}')
for p in sorted(work.iterdir()):
    if p.is_file() and p.suffix in ['.py','.sh'] and any(f'r{n}' in p.stem for n in range(228,233)):
        retain(p)
retain(work/'ordinary-default-r228.json')
record=dict(status='scoped-estimator-defaults-checkpoint-beta-incomplete',fullBetaAccepted=False,
    selectedRuntime='build-windows/beta-single-frame-20261025-night/ui-estimator-scaled-r231/runtime',
    runtimeSha256=read(work/'ui-estimator-scaled-r231/verification.json')['runtimeSha256'],
    artifacts=artifacts,localStreams=streams,timedOrdinaryPairs=pairs,savedDefaultFrames=defaults,
    accepted=[
      'Wall-clock estimator corrections become media-time offsets using current playback rate. Rate changes already cancel marks. Pause/resume now cancels unfinished marks without changing applied delays.',
      'The same corrected native executable fails old production handlers for half-speed correction and resume cancellation, then passes the new handlers. All31 software subtitle functions pass, including24 signed correction rows across audio/primary/secondary and four speeds, plus12 seek/rate/pause/resume cancellation rows. No late-picture or avcodec-late errors are recorded.',
      'The new ordinary GUI applies+8433ms and-7756ms at1.5x, both within independently bracketed click-time bounds; Reset clears the adjustment. This verifies UI conversion, not acoustic synchronization.',
      'The ordinary saved-default journey starts at23.976fps, changes FIRST to MIDDLE with current-media Reset0 at the same paused frame513, exits, then cold-restores23.976fps and FIRST. All three native snapshots have identical video regions. The saved configuration retains23.976 throughout. These default journeys used the preceding GUI158 with the same Core224.',
      'All three ordinary processes exit0 with602modules,zero error diagnostics and unchanged source/runtime/fixture/cache guards.'
    ],unresolved=[
      'The first all-row before experiment had18 real rate-contract failures and6 incorrect fixture Reset expectations. Its launcher observation expired at180seconds; a separate observer records natural exit24. The corrected single-row before runs close normally with expected exit1. No forced cleanup occurred.',
      'Ordinary media-key pause while keeping the popup open could not be automated: XF86AudioPlay and MediaPlayPause are unsupported by the tool. Same-object pause cancellation is established by the native QML/player test, not by an ordinary popup teardown.',
      'Embedded English subtitles with+5s/+5.508s at1.5x move held frame300 to298 despite unchanged reported12s; Reset returns300. The read-only probe exits normally with captions and actual WASAPI operating and no late-picture warning. MP4 edit/timestamp mapping needs a separately tested repair.',
      'Older cue-preset ordinary replay, secondary no-track availability, secondary-screen idle fullscreen capture, broader design/DPI/orientation/HDR and final-package gates remain open. All beta gates remain open.'
    ])
(out/'checkpoint.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Estimator speed and saved timing defaults - 26 October 2026

GUI `4d754f60` with Core `ccf72399` scales wall-clock timing marks into native
media time and cancels incomplete pairs across pause/resume. The same corrected
test executable fails the old handlers and passes the new handlers. All 31 native
software subtitle functions pass, including 24 signed speed rows and 12 context
cancellation rows, without late-picture or avcodec-late errors.

The ordinary GUI applies +8433 ms and -7756 ms at 1.5x within independently
bracketed click-time bounds. Reset clears the adjustment. This is UI timing
calibration, not an acoustic synchronization claim. Ordinary same-popup pause
could not be driven by the automation tool's unsupported media keys; the native
same-object cancellation proof remains separate.

An ordinary saved-default/cold-restart journey on the preceding GUI158 and the
same Core224 preserves 23.976 fps defaults while current-media Reset changes the
caption at an identical paused video frame. Three ordinary processes exit 0 with
602 modules, zero error diagnostics and unchanged guards.

Embedded positive-delay coverage now reproduces a separate MP4 held-frame error:
frame 300 becomes 298 at the same reported 12 seconds, then Reset returns 300.
Captions/audio and normal cleanup pass. This remains unfinished; see exact
before evidence, fixture corrections and qualification limits in
[checkpoint.json](checkpoint.json). Raw streams remain local with hashes.
Continue from [STATUS](../../../juxtopposed/STATUS.md); beta gates remain open.
''',encoding='utf-8',newline='\n')
print(str(out),len(artifacts),'artifacts',flush=True)
