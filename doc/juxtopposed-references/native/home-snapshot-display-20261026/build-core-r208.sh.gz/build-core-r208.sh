#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-core-r208.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-core-r208-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 54e3368fe4ac7a1ebf9bd0772ce0499b16c1c4d7911c4d3a9653a6937ca52e9c
test ! -e "$work/core-r208-bin"
make -C "$base/win64/src" -j2 libvlccore.la
mkdir "$work/core-r208-bin"
cp "$base/win64/src/.libs/libvlccore.dll" "$work/core-r208-bin/"
cp "$base/win64/src/player/.deps/libvlccore_la-input.Plo" "$work/core-r208-bin/player-input.Plo"
sha256sum "$work/core-r208-bin/libvlccore.dll"
