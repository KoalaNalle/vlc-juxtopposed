from pathlib import Path
from hashlib import sha256
from PySide6.QtGui import QImage
import gzip, json

work = Path(__file__).resolve().parent
repo = work.parents[1]
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda p: sha256(p.read_bytes()).hexdigest()
out = repo/'doc/juxtopposed-references/native/home-snapshot-display-20261026'
assert not out.exists()
manifest = read(work/'inputs-r211.json')
assert all(digest(repo/p) == h for p, h in manifest['files'].items())
native = ['native-d3d11-r208', 'native-software-r209']
ordinary = ['ui-snapshot-display-r209', 'ui-fullscreen-baseline-r210',
            'ui-snapshot-primary-r211', 'ui-baseline-secondary-r211']
for name in native:
    v = read(work/name/'verification.json')
    assert v['normalExit'] and len(v['functions']) == 29
    assert all(i['type'] == 'pass' for f in v['functions'] for i in f['incidents'])
    assert all(v[k] for k in ['sourceInputsUnchanged', 'runtimeUnchanged', 'fixturesUnchanged'])
for name in ordinary:
    v = read(work/name/'verification.json')
    assert v['normalExit'] and v['moduleCounts'] == ['602']
    assert all(v[k] for k in ['sourceInputsUnchanged', 'runtimeUnchanged',
                             'fixturesUnchanged', 'pluginCacheUnchanged'])
assert not list((work/'ui-baseline-secondary-r211/app-snapshots').glob('*.png'))
assert not read(work/'ui-snapshot-primary-r211/verification.json')['diagnostics']
assert not read(work/'ui-snapshot-display-r209/verification.json')['diagnostics']

images = []
for name in ordinary:
    for p in sorted((work/name/'app-snapshots').glob('*.png')):
        image = QImage(str(p))
        assert not image.isNull() and (image.width(), image.height()) == (960, 540)
        marker = sum(1 << b for b in range(11) if image.pixelColor(32+64*b, 20).red() > 128)
        bright = sum(min(image.pixelColor(x, y).red(), image.pixelColor(x, y).green(),
                         image.pixelColor(x, y).blue()) > 160
                     for y in range(405, 540) for x in range(960))
        rgb = image.convertToFormat(QImage.Format_RGB888)
        pixel_hash = sha256(bytes(rgb.constBits())).hexdigest()
        assert marker == 0 and bright == 2597
        images.append(dict(path=p.relative_to(work).as_posix(), frameMarker=marker,
                           captionPixels=bright, rgbSha256=pixel_hash, sha256=digest(p)))
candidate_images = [i for i in images if '/ui-' not in i['path'] and
                    (i['path'].startswith('ui-snapshot-display-r209/')
                     or i['path'].startswith('ui-snapshot-primary-r211/'))]
assert len(candidate_images) == 3 and len({i['rgbSha256'] for i in candidate_images}) == 1
before_log = (work/'native-d3d11-r204/stderr.txt').read_text(errors='replace')
after_log = (work/'native-d3d11-r208/stderr.txt').read_text(errors='replace')
patterns = ['no matching alpha blending routine', 'blending YUVA to DX11 failed']
blend_before = sum(before_log.count(p) for p in patterns)
blend_after = sum(after_log.count(p) for p in patterns)
assert blend_before == 104 and blend_after == 0

out.mkdir()
artifacts, local_streams = [], []
def retain(p, relative=None):
    target = out/((relative or p.relative_to(work).as_posix()) + '.gz')
    assert not target.exists()
    raw = p.read_bytes()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(raw, mtime=0))
    artifacts.append(dict(path=target.relative_to(out).as_posix(), sha256=digest(target),
                          rawSha256=sha256(raw).hexdigest()))
for name in native + ordinary:
    for p in sorted((work/name).rglob('*')):
        parts = p.relative_to(work/name).parts
        if not p.is_file() or any(x in parts for x in ['runtime', 'userdata', 'temp']):
            continue
        if p.suffix in ['.log', '.txt']:
            local_streams.append(dict(path=p.relative_to(work).as_posix(), sha256=digest(p), packaged=False))
        elif p.suffix in ['.json', '.xml', '.png', '.py']:
            retain(p)
for revision in ['r204', 'r208', 'r209', 'r211']:
    m = read(work/f'inputs-{revision}.json')
    retain(work/f'inputs-{revision}.json')
    for name in ['src/video_output/video_output.c', 'src/video_output/vout_subpictures.c']:
        p = Path(m['sourceCopies'][name])
        assert digest(p) == m['files'][name]
        retain(p, f'sources/{revision}/{name}')
for name in ['build-core-r208.sh', 'build-core-r208-exit.txt', 'run-ui-snapshot-r209.py',
             'run-ui-screen-r211.py', 'snapshot-checkpoint-r210.json',
             'snapshot-fullscreen-r210-debugger.json', 'cleanup-snip-overlay-r210.json',
             'write-snapshot-display-receipt-r212.py']:
    retain(work/name)
p = work/'snapshot-fullscreen-r210-cdb.txt'
local_streams.append(dict(path=p.name, sha256=digest(p), packaged=False))

record = dict(status='scoped-snapshot-checkpoint-beta-incomplete', fullBetaAccepted=False,
    selectedRuntime='build-windows/beta-single-frame-20261025-night/ui-snapshot-primary-r211/runtime',
    runtimeSha256=read(work/'ui-snapshot-primary-r211/verification.json')['runtimeSha256'],
    artifacts=artifacts, localStreams=local_streams, nativeImages=images,
    beforeUnsupportedBlendMessages=blend_before, afterUnsupportedBlendMessages=blend_after,
    accepted=[
      'Hardware and software each pass all29 subtitle functions, with normal cleanup and unchanged guards.',
      'The hardware display retains its own subtitle path during a separate software image export. The normal-orientation source no longer attempts an unsupported YUVA-to-DX11 software blend.',
      'Actual windowed snapshots keep the caption. The matched primary2560x1440 fullscreen capture retains the caption after export and idle. All three candidate PNGs are pixel-identical960x540 images with exact marker0 and2597 caption pixels.',
      'The candidate ordinary processes exit0 with602 modules and no error diagnostics. The old primary baseline retains its two unsupported-blend messages. All recorded guards pass.'
    ],
    unresolved=[
      'Secondary1920x1080 fullscreen at global(-1920,357) loses the caption in idle app captures alongside hidden controls. The earlier Core204 reproduces this before any snapshot is taken. The cause and physical-display outcome remain open; no monitor/DPI or fullscreen interaction acceptance is claimed.',
      'The first Core comparison used different monitors and is confounded. Explicit screen0/1 options and captured dimensions qualify later observations.',
      'The candidate secondary run filenames07/08 describe an intended windowed return, but UIA still reports fullscreen. The f key and first leave-fullscreen button attempt did not complete that action. Do not interpret filenames as successful input evidence.',
      'A noninvasive thread check detached normally and found Qt in its event loop with Responding=true. It does not establish a hang or a renderer cause.',
      'The independent Snipping Tool attempt supplied no accepted image. Its unexposed owned overlay required verified process cleanup; the later blank companion was restored to Rectangle and closed normally. VLC itself never required forced cleanup.',
      'The pre-existing non-normal source-orientation snapshot limitation remains unqualified. No HDR/format matrix, physical screen observation, full visual acceptance or final-package claim is made.',
      'Continue ordinary secondary/per-track timing, estimators, defaults/restart and cue journeys. All beta gates remain open.'
    ])
(out/'checkpoint.json').write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8', newline='\n')
(out/'README.md').write_text('''# Separate snapshot export and subtitle display - 26 October 2026

Core `8dc69606` retains hardware subtitle display while exporting a separate
software image. It avoids the unsupported GPU software-blend attempt; the same
native hardware suite drops from 104 such messages to zero. Hardware/software
each pass all 29 subtitle functions with normal exits and unchanged guards.

Actual windowed and matched primary-screen fullscreen snapshots preserve the
caption. The three candidate PNGs are pixel-identical 960x540 images with exact
frame marker 0 and 2597 caption pixels. The ordinary candidate processes exit 0
with 602 modules and no error diagnostics.

Secondary-screen idle capture remains unresolved. The earlier Core reproduces
caption loss before any snapshot is taken, so this observation is separate from
the new export path. Screen coordinates, the initial confounded comparison,
incomplete fullscreen input attempts, responsive thread evidence and diagnostic
helper cleanup are explicit in [checkpoint.json](checkpoint.json). No physical
display, OS-DPI, source-orientation, full visual or final-package claim is made.

Generated captures and structured evidence are compressed with exact sources and
producers. Raw streams remain local with hashes. This is a scoped development
checkpoint; continue from [STATUS](../../../juxtopposed/STATUS.md).
''', encoding='utf-8', newline='\n')
print(str(out), len(artifacts), 'artifacts', flush=True)
