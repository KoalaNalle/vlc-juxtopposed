from pathlib import Path
from hashlib import sha256
import gzip,json
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
out=repo/'doc/juxtopposed-references/native/home-timing-context-20261026'
assert not out.exists()
before=read(work/'context-before-r80/verification.json')
after=read(work/'context-after-r81/verification.json')
native=read(work/'native-all-r81/verification.json')
ui=read(work/'ui-r81/verification.json')
assert before['exitCode']==4 and after['normalExit'] and native['normalExit'] and ui['normalExit']
assert len(native['functions'])==17
assert all(i['type']=='pass' for f in native['functions'] for i in f['incidents'])
assert all(ui[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','pluginCacheUnchanged'])
out.mkdir();artifacts=[]
def retain(p,name=None):
    raw=p.read_bytes();target=out/((name or p.relative_to(work).as_posix())+'.gz')
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(raw,mtime=0))
    artifacts.append(dict(path=target.relative_to(out).as_posix(),sha256=digest(target),rawSha256=sha256(raw).hexdigest()))
for folder in ['context-before-r80','context-after-r81','native-all-r81']:
    for name in ['verification.json','results.xml']:retain(work/folder/name)
for name in ['verification.json','launch.json']:retain(work/'ui-r81'/name)
for p in sorted((work/'ui-r81').glob('*.jpg')):retain(p)
for p in sorted((work/'ui-r81').glob('*tree.txt')):retain(p)
for name in ['inputs-r80.json','inputs-r81.json','build-r81.sh','build-r81-exit.txt',
             'run-native-context-r78.py','run-ui-ordinary-r81.py','write-context-receipt-r82.py']:
    retain(work/name)
for rev,label in [('r80','before'),('r81','after')]:
    manifest=read(work/f'inputs-{rev}.json')
    for key in ['modules/gui/qt/player/player_controller.cpp','modules/gui/qt/player/player_controller.hpp',
                'modules/gui/qt/player/qml/TracksPageAudio.qml','modules/gui/qt/player/qml/TracksPageSubtitle.qml',
                'modules/gui/qt/tests/test_player_subtitle_delay.cpp']:
        p=Path(manifest['sourceCopies'][key]);assert digest(p)==manifest['files'][key]
        retain(p,'sources/'+label+'/'+key)
record=dict(status='scoped-checkpoint-session-continues',fullBetaAccepted=False,
    runtimeSha256=ui['runtimeSha256'],nativeFunctions=17,artifacts=artifacts,
    nativeBefore='Four Qt-interface cases pass; four direct-native seek/rate cases fail to cancel the same live estimator and hook objects.',
    nativeAfter='All eight audio/subtitle by Qt/native seek/rate cases pass with the same production Connections hooks and estimator objects alive. No delay adjustment is published. Actual time/rate, track roles and raw overrides are checked. Direct rate observers can query the unlocked player.',
    ordinary='Initial half-speed paused FIRST caption. Select 2x, actual Escape returns to tracks with 2x retained. Paused seek to 30s displays MIDDLE; resume and re-pause at 54s displays LAST; Next opens generated ASS media, paused around 18s displays FIRST. Normal Quit, unchanged guards, 602 modules, no diagnostics.',
    limits=['Native hook isolation does not instantiate the whole visual subpage.',
            'Ordinary modal navigation cannot by itself isolate estimator lifetime from cancellation.',
            'After assertions also check settled setup time, actual event result and an unlocked direct observer; the before/after source snapshots retain this distinction.',
            'No complete W1, W2, visual, final-package or beta acceptance.'])
(out/'checkpoint.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Native timing context - 26 October 2026

Core `883f7e51` / ordinary GUI `6e5fa604` is the selected scoped runtime.
Seventeen native subtitle test functions pass, including eight rows that keep
the same actual production Connections hooks and estimators alive across Qt and
direct-native seek/rate events. The before control passes the Qt rows but fails
all four direct-native rows. No timing adjustment is published on cancellation.

The controller now announces native seek starts and paused rate callbacks.
Rate callbacks read the latest actual rate, and direct rate notifications occur
after unlocking. The existing timeline seek-request signal keeps its semantics.
The test uses the actual frozen page hooks, not complete visual page construction;
this native isolation is separate from ordinary modal acceptance. The after test
also strengthens settled setup and actual-result assertions; both sources remain.

The ordinary player starts paused at half speed with the FIRST cue. Selecting
2x and pressing Escape returns to the track list with that rate retained. A paused
seek to 30 seconds shows MIDDLE, resume/re-pause at 54 seconds shows LAST, and Next
opens generated ASS media with a visible FIRST cue when paused around 18 seconds.
Normal Quit exits zero, guards remain unchanged, 602 modules load, and diagnostics
are empty. Only generated media was used.

[checkpoint.json](checkpoint.json) binds exact identities and original gzip
artifacts. Earlier reset and hardware-snapshot receipts retain their distinct
ordinary journeys. This does not close W1, W2 or the beta gates. Continue from
[STATUS](../../../juxtopposed/STATUS.md).
''',encoding='utf-8',newline='\n')
print(str(out),len(artifacts),flush=True)
