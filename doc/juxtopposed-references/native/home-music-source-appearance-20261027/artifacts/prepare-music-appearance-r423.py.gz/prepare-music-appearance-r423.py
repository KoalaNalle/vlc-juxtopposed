from pathlib import Path
work=Path(__file__).resolve().parent
build=(work/'build-music-header-r418.sh').read_text(encoding='utf-8').replace('r418','r423').replace('build-music-header','build-music-appearance').replace('owned-music-header','owned-music-appearance')
(work/'build-music-appearance-r423.sh').write_text(build,encoding='utf-8',newline='\n')
producer=(work/'run-ui-music-header-r418.py').read_text(encoding='utf-8').replace('ordinary-r418-bin','ordinary-r423-bin').replace('GUI418','GUI423')
producer=producer.replace('Check independent folder Back/Forward, real ancestors/current track folder, external folder, list/cover views, source title badge, paused/playing continuity, queue fallback and short-window focus.',
 'Check source placeholder and folder menu contrast in actual Dark/Light/System selections, normal keyboard search, appearance persistence and normal shutdown. This does not repeat or inherit complete GUI418 header acceptance.')
(work/'run-ui-music-appearance-r423.py').write_text(producer,encoding='utf-8',newline='\n')
