#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-music-appearance-r423.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-music-appearance-r423-exit.txt"; exit "$code"' EXIT
ordinary="$base/owned-music-appearance-20261027-r423"
test ! -e "$ordinary"
test ! -e "$work/ordinary-r423-bin"
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = fdfcfcd599588512bb7f3a51e46305b7b0d947b47387dd205851feb45f032b46
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/build-windows/beta-subtitle-sync-20261025/ordinary.mk" -j2 QA_OUT="$ordinary" owned-ordinary-subtitle-sync
mkdir "$work/ordinary-r423-bin"
cp "$ordinary/.libs/libqt_plugin.dll" "$work/ordinary-r423-bin/"
sha256sum "$work/ordinary-r423-bin/"*
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = fdfcfcd599588512bb7f3a51e46305b7b0d947b47387dd205851feb45f032b46
