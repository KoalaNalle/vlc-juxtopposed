from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
receipt=repo/'doc/juxtopposed-references/native/home-music-source-appearance-20261027'
assert not receipt.exists()
source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert source_commit.startswith('e39da9c7ee')
analysis=read(work/'music-appearance-analysis-r428.json');assert analysis['passed']
assert analysis['changedSettingKeys']==['MainWindow/color-scheme-index']
assert read(work/'system-theme-live-r426/outcome.json')['OsValuesUnchanged']
manifest=read(work/'inputs-r423.json')
assert all(digest(repo/name)==value for name,value in manifest['files'].items())
names=['inputs-r423.json','prepare-music-appearance-r423.py','build-music-appearance-r423.sh',
 'build-music-appearance-r423.log','build-music-appearance-r423-exit.txt','run-ui-music-appearance-r423.py',
 'check-music-appearance-r427.py','check-music-appearance-r428.py','music-appearance-analysis-r428.json',
 'system-theme-live-r426/baseline.json','system-theme-live-r426/outcome.json',
 'component-music-placeholder-r422/music-player-verification.json','write-music-appearance-receipt-r429.py']
files=[work/name for name in names]
for run in ['ui-music-appearance-r424','ui-music-appearance-cold-r425']:
    verified=read(work/run/'verification.json')
    assert verified['normalExit'] and not verified['diagnostics'] and verified['moduleCounts']==['602']
    files.extend(work/run/name for name in ['verification.json','vlc.log','stderr.txt','producer.py',
       'launch.json','settings-before.ini','settings-after.ini','config-before.txt','config-after.txt'])
    files.extend(p for p in (work/run/'observations').iterdir() if p.is_file())
receipt.mkdir();(receipt/'artifacts').mkdir();inventory=[]
for path in sorted(set(files)):
    data=path.read_bytes();name=path.relative_to(work).as_posix().replace('/','__')+'.gz'
    target=receipt/'artifacts'/name;target.write_bytes(gzip.compress(data,mtime=0))
    assert gzip.decompress(target.read_bytes())==data
    inventory.append(dict(file='artifacts/'+name,source=path.relative_to(repo).as_posix(),
      sha256=sha256(data).hexdigest(),gzipSha256=digest(target),bytes=len(data),compressedBytes=target.stat().st_size))
checkpoint=dict(sourceCommit=source_commit,runtime='build-windows/beta-single-frame-20261025-night/ui-music-appearance-cold-r425/runtime',
 runtimeSha256=analysis['runtimeSha256'],ordinaryRuns=[dict(name=run,normalExit=True,plugins=602,checkedErrors=0,endingGuardsPassed=True)
 for run in ['ui-music-appearance-r424','ui-music-appearance-cold-r425']],
 appearanceAnalysis=analysis,liveWindowsThemeChangeAccepted=False,screenReaderAccepted=False,
 actualWindowsDpiAccepted=False,fullBetaAccepted=False,finalPackageAccepted=False,
 osThemeValuesUnchanged=True,securityPrivacyChanges=[],firewallRuleChanges=[],artifacts=inventory)
(receipt/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n',encoding='utf-8',newline='\n')
(receipt/'README.md').write_text(f'''# Music source placeholder and theme checks

27 October2026. Source `{source_commit[:10]}`. The source-search placeholder now
uses an explicit theme-aware foreground instead of the Basic control's implicit
placeholder color. This is a scoped appearance follow-up to the
[source-header receipt](../home-music-source-header-20261027/README.md).

The maintained music component checks pass. Ordinary GUI423
`{analysis['runtimeSha256']['plugins/gui/libqt_plugin.dll'][:8]}` on the existing
Core265/library282/recording322 tuple verifies a readable placeholder in native
Dark, Light and current-System modes. Source options, standalone ancestors and
the nested ancestor menu follow Light mode. Search still filters First light
and Escape restores the three-item list while playback stays paused at zero.

System currently resolves to Dark. After normal restart, System remains selected
and displays the same palette. Only `MainWindow/color-scheme-index` changes in
the isolated interface settings; the complete player-profile catalogue remains
identical before/after/cold restart. Both ordinary runs exit0 with602plugins,
zero checked errors and every source/runtime/fixture/producer/cache ending guard.
Their exact binaries, producers, captures and configuration snapshots are retained.

A live Windows appearance-change check was attempted. The explicit Settings
executable launch and fresh window inventory exposed no targetable Settings window.
No OS theme change was performed. Read-only before/after checks confirm the five
recorded appearance values remain unchanged. System selection/restart is not
acceptance of live Windows theme propagation. No security/privacy, firewall or
Defender setting was changed and no firewall rules were added.

The first post-run settings analyzer used the wrong group for the theme key and
stopped with KeyError; the corrected analyzer reads `MainWindow/color-scheme-index`.
That was a harness lookup failure, not an application failure. Earlier immediate
UI observations can precede settled frames; capture04 is the settled Light field.

Complete theme/accent combinations and visual scores, native screen-reader/focus,
actual Windows DPI, multi-instance combinations, integrated regression and final
ordinary-package gates remain open. This GUI's one-line appearance change does
not silently replace the earlier GUI418 behavior receipt or establish full beta
acceptance. All test media is generated; no private media is included.

`checkpoint.json` binds compressed artifacts to their original and compressed
SHA-256. Decompression was verified. Binaries and test profiles remain ignored.
''',encoding='utf-8',newline='\n')
print(json.dumps(dict(sourceCommit=source_commit,artifacts=len(inventory),compressedBytes=sum(i['compressedBytes'] for i in inventory))))
