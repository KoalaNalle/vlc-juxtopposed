from pathlib import Path
from hashlib import sha256
import json
from PySide6.QtCore import QSettings
work=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
records={name:read(work/name/'verification.json') for name in ['ui-music-appearance-r424','ui-music-appearance-cold-r425']}
for r in records.values():
    assert r['normalExit'] and r['exitCode']==0 and r['moduleCounts']==['602'] and not r['diagnostics']
    assert all(r[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','baseRuntimeUnchanged','producerUnchanged','pluginCacheUnchanged','musicFixturesUnchanged','fixturesUnchanged','extraFixturesUnchanged','chapterFixturesUnchanged','lateFixturesUnchanged','decodeFixturesUnchanged'])
assert records['ui-music-appearance-r424']['runtimeSha256']==records['ui-music-appearance-cold-r425']['runtimeSha256']
def settings(path):
    s=QSettings(str(path),QSettings.IniFormat);s.setFallbacksEnabled(False)
    return {k:s.value(k) for k in s.allKeys()}
before=settings(work/'ui-music-appearance-r424/settings-before.ini')
after=settings(work/'ui-music-appearance-r424/settings-after.ini')
cold=settings(work/'ui-music-appearance-cold-r425/settings-after.ini')
assert str(before['General/color-scheme-index'] if 'General/color-scheme-index' in before else before['color-scheme-index'])=='2'
theme_key='General/color-scheme-index' if 'General/color-scheme-index' in after else 'color-scheme-index'
assert str(after[theme_key])=='0' and str(cold[theme_key])=='0'
profile='Juxtopposed/player-profiles'
assert before[profile]==after[profile]==cold[profile]
changes={k:dict(before=before.get(k),after=after.get(k)) for k in before.keys()|after.keys() if before.get(k)!=after.get(k)}
result=dict(passed=True,changedSettingKeys=list(changes),changes=changes,playerProfilesUnchanged=True,
 systemSelectionPersistedAcrossColdStart=True,liveWindowsThemeChangeAccepted=False,
 sourceManifestSha256=sha256((work/'inputs-r423.json').read_bytes()).hexdigest(),runtimeSha256=records['ui-music-appearance-r424']['runtimeSha256'],
 scope='Source placeholder and menu appearance under explicit Dark/Light/current-System selection; no full theme or screen-reader acceptance')
(work/'music-appearance-analysis-r427.json').write_text(json.dumps(result,indent=2,default=str)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(passed=True,changedKeys=list(changes),playerProfilesUnchanged=True,systemSelectionPersistedAcrossColdStart=True)))
