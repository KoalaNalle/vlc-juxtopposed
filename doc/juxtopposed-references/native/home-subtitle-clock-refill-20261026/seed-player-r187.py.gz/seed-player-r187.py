from pathlib import Path
import json
work=Path(__file__).resolve().parent
data=json.loads((work/'inputs-r186.json').read_text())
required=['test/Makefile.am','test/libvlc/test.h','lib/libvlc_internal.h',
          'test/src/player/common.h','test/src/player/modules.c',
          'test/src/player/timers.h','test/src/player/timers.c','test/src/player/abloop.c']
for name in required:
    if name not in data['files']: data['files'][name]='new required input'
(work/'inventory-seed-r187.json').write_text(json.dumps(data,indent=2)+'\n',newline='\n')
print('Added official player test inputs to the next freeze')
