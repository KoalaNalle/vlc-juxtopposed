from pathlib import Path
from hashlib import sha256
import json
work = Path(__file__).resolve().parent
repo = work.parents[1]
inputs = json.loads((work/'inputs-r182.json').read_text())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
name = 'src/player/timer.c'
path = repo/name
assert digest(path) == inputs['files'][name]
text = path.read_text()
old = '''end:
    vlc_mutex_unlock(&player->timer.lock);
    return ret;
}'''
new = '''end:
    if (getenv("VLC_SUBTITLE_CLOCK_TRACE") && out_ts)
        fprintf(stderr, "CLOCK_POINT ret=%d out=%lld best=%p ts=%lld date=%lld state=%d pause=%lld now=%lld seek=%lld/%f video=%p vts=%lld vdate=%lld vseek=%d\\n",
                ret, (long long) (ret == VLC_SUCCESS ? *out_ts : -1),
                (void *) player->timer.best_source.es,
                (long long) player->timer.best_source.point.ts,
                (long long) player->timer.best_source.point.system_date,
                player->timer.update_state, (long long) player->timer.pause_date,
                (long long) system_now, (long long) player->timer.seek_ts,
                player->timer.seek_position, (void *) player->timer.smpte_source.es,
                (long long) player->timer.smpte_source.point.ts,
                (long long) player->timer.smpte_source.point.system_date,
                player->timer.smpte_source.seeking);
    vlc_mutex_unlock(&player->timer.lock);
    return ret;
}'''
assert text.count(old) == 1
path.write_text(text.replace(old,new), newline='\n')
name = 'src/player/input.c'
path = repo/name
assert digest(path) == inputs['files'][name]
text = path.read_text()
old = '''    vlc_mutex_unlock(&player->timer.lock);
    if (have_target)
    {'''
new = '''    if (getenv("VLC_SUBTITLE_CLOCK_TRACE"))
        fprintf(stderr, "CLOCK_REFRESH target=%lld have=%d input=%lld state=%d video=%p vts=%lld vdate=%lld vseek=%d bestts=%lld bestdate=%lld pause=%lld timerstate=%d\\n",
                (long long) target, have_target, (long long) input->time, input->state,
                (void *) video->es, (long long) video->point.ts,
                (long long) video->point.system_date, video->seeking,
                (long long) player->timer.best_source.point.ts,
                (long long) player->timer.best_source.point.system_date,
                (long long) player->timer.pause_date, player->timer.update_state);
    vlc_mutex_unlock(&player->timer.lock);
    if (have_target)
    {'''
assert text.count(old) == 1
path.write_text(text.replace(old,new), newline='\n')
helper = (work/'build-core-r181.sh').read_text().replace('r181','r183').replace(
    '9a6d1dc3a96cd0bfeb1f8dc277977d41d1ad1430ef2b918bb8b41dab02362939',
    '062c82cdd5efdf79aa74bd0d283bba80fe4acf29704c55db1421340799c825a1')
target = work/'build-core-r183.sh'; assert not target.exists()
target.write_text(helper, newline='\n')
helper = (work/'run-native-cold-r162.py').read_text().replace(
    "env=environment(runtime,out);env.pop('VLC_PLUGIN_PATH',None)",
    "env=environment(runtime,out);env.pop('VLC_PLUGIN_PATH',None);env['VLC_SUBTITLE_CLOCK_TRACE']='1'")
target = work/'run-native-clock-r183.py'; assert not target.exists()
target.write_text(helper, newline='\n')
(work/'clock-trace-r183.json').write_text(json.dumps(dict(diagnosticOnly=True,
    restoreManifest='inputs-r182.json',productionCandidate='core-r181-bin/libvlccore.dll',
    selectedRuntimeUnchanged=True),indent=2)+'\n',newline='\n')
print('Prepared diagnostic-only Core and runner; restore r182 source after diagnosis')
