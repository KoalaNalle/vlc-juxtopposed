from pathlib import Path
from hashlib import sha256
import ctypes,json,shutil,subprocess,sys,xml.etree.ElementTree as ET
work=Path(__file__).resolve().parent;repo=work.parents[1]
revision,label=sys.argv[1:]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
manifest=work/f'inputs-{revision}.json';inputs=read(manifest)
assert all(digest(repo/p)==h and digest(Path(inputs['sourceCopies'][p]))==h for p,h in inputs['files'].items())
base=work/'ui-r37/runtime';expected=read(base.parent/'verification.json')['runtimeSha256']
assert all(digest(base/p)==h for p,h in expected.items())
out=work/label;assert not out.exists();out.mkdir()
sys.path.insert(0,str(repo/'test/libvlc'))
from native_http_runtime import stage_runtime,environment
runtime=out/'runtime';stage_runtime(base,runtime)
cache=runtime/'plugins/plugins.dat';assert not cache.exists();shutil.copyfile(base/'plugins/plugins.dat',cache)
target=runtime/'libvlccore.dll';target.unlink();shutil.copyfile(work/'core-r204-bin/libvlccore.dll',target)
subtitle_name='plugins/demux/libsubtitle_plugin.dll'
expected[subtitle_name]=digest(base/subtitle_name)
subtitle=runtime/subtitle_name;subtitle.unlink();shutil.copyfile(work/'subtitle-r130-bin/libsubtitle_plugin.dll',subtitle)
identities={p:digest(runtime/p) for p in expected}
program='test_startup_rate.exe';shutil.copyfile(work/'startup-r46-bin'/program,runtime/program)
media=repo/'build-windows/beta-subtitle-fps-20261024/media-r1/frame-marker.mp4'
media_hash=digest(media);cache_hash=digest(cache)
env=environment(runtime,out);env.pop('VLC_PLUGIN_PATH',None)
env.update(VLC_SUBTITLE_FIXTURE=str(media),VLC_TEST_PLUGIN_PATH=str(runtime/'plugins'),VLC_TEST_TIMEOUT='30')
record=dict(status='starting',sourceManifestSha256=digest(manifest),testExecutableSha256=digest(runtime/program),
    producerSha256=digest(Path(__file__)),runtimeSha256=identities,privateNativeFixture=True,
    ordinaryGuiAccepted=False,fullBetaAccepted=False,forcedCleanupUsed=False)
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.SetErrorMode.argtypes=[ctypes.c_uint];kernel.SetErrorMode.restype=ctypes.c_uint
previous=kernel.SetErrorMode(0x8003)
try:
    with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
        child=subprocess.Popen([str(runtime/program),'-o',str(out/'results.xml')+',xml'],cwd=runtime,env=env,
            stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        record.update(status='running',pid=child.pid);write(out/'verification.json',record)
        print(label,'PID',child.pid,flush=True)
        try:code=child.wait(timeout=180)
        except subprocess.TimeoutExpired:
            record['status']='observation-timeout-process-left-running';write(out/'verification.json',record)
            raise SystemExit('Inspect owned PID; no automatic cleanup/restart')
finally:kernel.SetErrorMode(previous)
tree=ET.parse(out/'results.xml').getroot()
record.update(status='terminal',exitCode=code,normalExit=code==0,
    functions=[dict(name=f.get('name'),incidents=[dict(type=i.get('type'),tag=i.findtext('DataTag',''),
        description=i.findtext('Description','')) for i in f.findall('Incident')],
        messages=[m.findtext('Description','') for m in f.findall('Message')]) for f in tree.findall('TestFunction')],
    sourceInputsUnchanged=all(digest(repo/p)==h for p,h in inputs['files'].items()),
    runtimeUnchanged=all(digest(base/p)==h and digest(runtime/p)==identities[p] for p,h in expected.items()),
    pluginCacheUnchanged=digest(cache)==cache_hash,fixtureUnchanged=digest(media)==media_hash)
write(out/'verification.json',record)
print(json.dumps({p:record[p] for p in ['exitCode','sourceInputsUnchanged','functions']}),flush=True)
