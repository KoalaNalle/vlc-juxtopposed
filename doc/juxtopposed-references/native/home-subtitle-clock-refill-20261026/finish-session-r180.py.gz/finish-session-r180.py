from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
status=(repo/'doc/juxtopposed/STATUS.md').read_text(encoding='utf-8-sig')
assert '**paused' in status
inventory=read(work/'inputs-r180.json')
forbidden={'test/libvlc/native_soxr_reference.py','test/modules/audio_filter/soxr_lifecycle_trace.c',
 'test/modules/audio_filter/soxr_native_reference.c','test/modules/audio_filter/soxr_pcm_trace.c'}
assert not forbidden.intersection(inventory['files'])
assert all(digest(repo/name)==value and digest(Path(inventory['sourceCopies'][name]))==value
           for name,value in inventory['files'].items())
proposal=read(work/'deferred-refresh-candidate-r178/proposal.json')
assert not any(proposal[k] for k in ['applied','compiled','tested'])
assert all(digest(repo/name)==value for name,value in proposal['preimageSha256'].items())
assert digest(work/'deferred-refresh-candidate-r178/candidate.patch')==proposal['patchSha256']
validation=read(work/'checkpoint-verification-r176.json');assert validation['status']=='verified'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head=='5b3eb021c026b4fa595bfec36e1ff0975c3f7bfd'
result=dict(status='paused-checkpoint-ready',fullBetaAccepted=False,reason='User requested stop at08:00 local/computer time.',
    recordedLocal=datetime.now().astimezone().isoformat(),recordedUtc=datetime.now(timezone.utc).isoformat(),
    sourceHead=head,sourceInventory='inputs-r180.json',sourceInputs=len(inventory['files']),sourceInputsUnchanged=True,
    selectedRuntime=validation['selectedOrdinaryRuntime'],selectedRuntimeDirectory='ui-notice-final-r163/runtime',
    receiptArtifacts=sum(r['artifacts'] for r in validation['receipts']),softwareNativeFunctions=26,cueNativeFunctions=13,
    hardwareFailedChecks=4,hardwareFailedFunctions=3,
    next='Review unapplied worker proposal against hardware cold-start and paused-time failures; do not use stale invalid clock values.',
    proposal='deferred-refresh-candidate-r178/proposal.json',proposalApplied=False,
    desktop='All owned tests exited; final process/window and build-lock checks are performed by the caller.',
    commitOrPush=False)
(work/'session-checkpoint-r180.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:result[k] for k in ['status','sourceInputs','sourceInputsUnchanged','receiptArtifacts',
      'softwareNativeFunctions','cueNativeFunctions','hardwareFailedChecks','proposalApplied']}),flush=True)
