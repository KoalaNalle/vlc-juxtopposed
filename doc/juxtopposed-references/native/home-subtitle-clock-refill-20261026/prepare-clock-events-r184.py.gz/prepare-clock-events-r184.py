from pathlib import Path
work = Path(__file__).resolve().parent
repo = work.parents[1]
path = repo/'src/player/timer.c'
text = path.read_text()
old = '''    struct vlc_player_timer_source *source = &player->timer.best_source;
    if (!source->es || es_source_is_master)'''
new = '''    struct vlc_player_timer_source *source = &player->timer.best_source;
    if (getenv("VLC_SUBTITLE_CLOCK_TRACE") && player->timer.update_state == UPDATE_STATE_PAUSED)
        fprintf(stderr, "CLOCK_UPDATE cat=%d master=%d ts=%lld date=%lld bestts=%lld bestdate=%lld seeking=%d\\n",
                es_source ? vlc_es_id_GetCat(es_source) : 0, es_source_is_master,
                (long long) point->ts, (long long) system_date,
                (long long) source->point.ts, (long long) source->point.system_date, source->seeking);
    if (!source->es || es_source_is_master)'''
assert text.count(old)==1
path.write_text(text.replace(old,new),newline='\n')
from hashlib import sha256
previous = sha256((work/'core-r183-bin/libvlccore.dll').read_bytes()).hexdigest()
helper = (work/'build-core-r183.sh').read_text().replace('r183','r184').replace(
    '062c82cdd5efdf79aa74bd0d283bba80fe4acf29704c55db1421340799c825a1', previous)
target=work/'build-core-r184.sh';assert not target.exists();target.write_text(helper,newline='\n')
print('Prepared diagnostic event trace; not a production candidate')
