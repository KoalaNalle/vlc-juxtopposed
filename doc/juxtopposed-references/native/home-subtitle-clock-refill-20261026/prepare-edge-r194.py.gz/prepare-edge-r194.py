from pathlib import Path
work=Path(__file__).resolve().parent
helper=(work/'build-r188.sh').read_text().replace('r188','r194')
target=work/'build-r194.sh';assert not target.exists();target.write_text(helper,newline='\n')
helper=(work/'run-native-cold-r162.py').read_text().replace(
    "elif mode=='cold-origin':command+=['attachmentColdCaptionAtOrigin']",
    "elif mode=='cold-origin':command+=['attachmentColdCaptionAtOrigin']\nelif mode=='selection-pause':command+=['attachmentSelectedJustBeforePause']")
helper=helper.replace("env=environment(runtime,out);env.pop('VLC_PLUGIN_PATH',None)",
    "env=environment(runtime,out);env.pop('VLC_PLUGIN_PATH',None);env['VLC_TEST_NATIVE_VERBOSE']='1'")
target=work/'run-native-edge-r194.py';assert not target.exists();target.write_text(helper,newline='\n')
print('Prepared a deterministic selection-then-pause transition regression')
