from pathlib import Path
work=Path(__file__).resolve().parent
helper=(work/'build-r194.sh').read_text().replace('r194','r196').replace(
    '9dfe025e012ce7d744332dc6b2361b43883966fd751d779fba1a91ed0df57487',
    '72c37a9cc7c43b2fb1d6055d399e1db1aba95fa49bf99b9969bf574477af6d03')
target=work/'build-r196.sh';assert not target.exists();target.write_text(helper,newline='\n')
helper=(work/'run-native-edge-r194.py').read_text().replace(
    "elif mode=='selection-pause':command+=['attachmentSelectedJustBeforePause']",
    "elif mode=='selection-pause':command+=['attachmentSelectedJustBeforePause']\nelif mode=='pending-ab':command+=['subtitleRefreshExpiryKeepsAtoBDeadline']")
target=work/'run-native-edge-r196.py';assert not target.exists();target.write_text(helper,newline='\n')
for old,new in [('run-player-r193.py','run-player-r196.py'),
                ('run-main-startup-r138.py','run-main-startup-r196.py'),
                ('run-rate-startup-r138.py','run-rate-startup-r196.py'),
                ('run-timing-r138.py','run-timing-r196.py'),
                ('run-ui-policy-r186.py','run-ui-policy-r196.py')]:
    helper=(work/old).read_text().replace('core-r136-bin/','core-r195-bin/').replace('core-r185-bin/','core-r195-bin/')
    target=work/new;assert not target.exists();target.write_text(helper,newline='\n')
print('Prepared pending-expiry/A-B interaction regression and current-Core native/ordinary launchers')
