#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
native="$base/owned-single-frame-native-20261026-r182"
ordinary="$base/owned-single-frame-ordinary-20261026-r182"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-r182.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-r182-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 062c82cdd5efdf79aa74bd0d283bba80fe4acf29704c55db1421340799c825a1
test ! -e "$native"
test ! -e "$ordinary"
test ! -e "$work/native-r182-bin"
test ! -e "$work/ordinary-r182-bin"
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/build-windows/beta-subtitle-fps-20261023/native-r1.mk" -j2 FPS_NATIVE_OUT="$native" owned-subtitle-fps-native
mkdir "$work/native-r182-bin"
cp "$native/.libs/test_qt_player_subtitle_delay.exe" "$work/native-r182-bin/"
sha256sum "$work/native-r182-bin/test_qt_player_subtitle_delay.exe"
