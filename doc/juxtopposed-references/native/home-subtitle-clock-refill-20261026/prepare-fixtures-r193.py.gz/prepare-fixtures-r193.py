from pathlib import Path
work=Path(__file__).resolve().parent
for name in ['player-modules-r192.c','player-module-r192.mk','build-r192.sh','run-player-r192.py']:
    text=(work/name).read_text().replace('r192','r193')
    if name.endswith('.mk'):
        text=text.replace('-I$(top_srcdir)/test/src/player', '-DTOP_BUILDDIR=\\\"$(abs_top_builddir)\\\" -I$(top_srcdir)/test/src/player')
    target=work/name.replace('r192','r193');assert not target.exists();target.write_text(text,newline='\n')
print('Added the configured test header build-root define to the private module')
