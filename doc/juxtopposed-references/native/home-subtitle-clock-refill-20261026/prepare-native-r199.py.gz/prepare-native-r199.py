from pathlib import Path
work=Path(__file__).resolve().parent
helper=(work/'build-r198.sh').read_text().replace('r198','r199')
target=work/'build-r199.sh';assert not target.exists();target.write_text(helper,newline='\n')
print('Wait for the fresh native input to apply 1x before measuring A-B wall time')
