from pathlib import Path
work=Path(__file__).resolve().parent
helper=(work/'build-cue-r137.sh').read_text().replace('r137','r200').replace(
    'ad8f4c62a6ab8565388a46d7ad9cb40c817d24d7ac139ba936720e8075f09c6a',
    '72c37a9cc7c43b2fb1d6055d399e1db1aba95fa49bf99b9969bf574477af6d03')
target=work/'build-cue-r200.sh';assert not target.exists();target.write_text(helper,newline='\n')
print('Prepared exact settled-clock cue regression; exact requested microseconds stay strict')
