from pathlib import Path
work=Path(__file__).resolve().parent
helper=(work/'build-r186.sh').read_text().replace('r186','r188')
target=work/'build-r188.sh';assert not target.exists();target.write_text(helper,newline='\n')
print('Prepared encoded-frame identity check; original clock tolerance is unchanged')
