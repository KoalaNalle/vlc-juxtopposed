from pathlib import Path
work=Path(__file__).resolve().parent
helper=(work/'run-player-r188.py').read_text()
old="identities={name:digest(runtime/name) for name in expected}"
new="""support=work/'support-r189/libssp-0.dll'
support_hash=digest(support)
shutil.copyfile(support,runtime/'libssp-0.dll')
identities={name:digest(runtime/name) for name in expected}"""
assert helper.count(old)==1
helper=helper.replace(old,new)
helper=helper.replace("producerSha256=digest(Path(__file__)),runtimeSha256=identities,processes=[],",
    "producerSha256=digest(Path(__file__)),runtimeSha256=identities,supportDllSha256=support_hash,processes=[],")
helper=helper.replace("producerUnchanged=digest(Path(__file__))==record['producerSha256'],",
    "supportDllUnchanged=digest(support)==support_hash and digest(runtime/'libssp-0.dll')==support_hash,\n    producerUnchanged=digest(Path(__file__))==record['producerSha256'],")
helper=helper.replace("and record['runtimeUnchanged']\n", "and record['runtimeUnchanged'] and record['supportDllUnchanged']\n")
target=work/'run-player-r189.py';assert not target.exists();target.write_text(helper,newline='\n')
print('Prepared portable test-only compiler support dependency; no installation')
