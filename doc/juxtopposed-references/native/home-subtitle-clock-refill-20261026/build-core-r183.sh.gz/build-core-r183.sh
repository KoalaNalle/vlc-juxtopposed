#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-core-r183.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-core-r183-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 062c82cdd5efdf79aa74bd0d283bba80fe4acf29704c55db1421340799c825a1
test ! -e "$work/core-r183-bin"
make -C "$base/win64/src" -j2 libvlccore.la
mkdir "$work/core-r183-bin"
cp "$base/win64/src/.libs/libvlccore.dll" "$work/core-r183-bin/"
cp "$base/win64/src/player/.deps/libvlccore_la-input.Plo" "$work/core-r183-bin/player-input.Plo"
sha256sum "$work/core-r183-bin/libvlccore.dll"
