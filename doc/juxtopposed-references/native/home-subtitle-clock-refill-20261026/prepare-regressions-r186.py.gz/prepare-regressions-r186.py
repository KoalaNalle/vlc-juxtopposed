from pathlib import Path
from hashlib import sha256
import json
work=Path(__file__).resolve().parent
core=sha256((work/'core-r185-bin/libvlccore.dll').read_bytes()).hexdigest()
helper=(work/'build-r182.sh').read_text().replace('r182','r186').replace(
    '062c82cdd5efdf79aa74bd0d283bba80fe4acf29704c55db1421340799c825a1',core)
target=work/'build-r186.sh'; assert not target.exists(); target.write_text(helper,newline='\n')
helper=(work/'run-ui-layout-policy-r159.py').read_text().replace('core-r136-bin/','core-r185-bin/')
helper=helper.replace('Ordinary narrow subtitle failure notice, complete detailed error and replacement recovery on the current cue-clock candidate.',
    'Ordinary deferred cold-caption and paused master-clock recovery candidate; strict native outcomes remain separately recorded.')
target=work/'run-ui-policy-r186.py';assert not target.exists();target.write_text(helper,newline='\n')
print('Prepared native held-picture regression and ordinary candidate launcher')
