from pathlib import Path
work=Path(__file__).resolve().parent
helper=(work/'build-core-r181.sh').read_text().replace('r181','r195').replace(
    '9a6d1dc3a96cd0bfeb1f8dc277977d41d1ad1430ef2b918bb8b41dab02362939',
    '9dfe025e012ce7d744332dc6b2361b43883966fd751d779fba1a91ed0df57487')
target=work/'build-core-r195.sh';assert not target.exists();target.write_text(helper,newline='\n')
print('Prepared bounded selection-to-pause refresh candidate; no logging in production sources')
