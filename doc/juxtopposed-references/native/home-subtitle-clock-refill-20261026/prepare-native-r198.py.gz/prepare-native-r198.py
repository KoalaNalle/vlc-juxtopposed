from pathlib import Path
work=Path(__file__).resolve().parent
helper=(work/'build-r197.sh').read_text().replace('r197','r198')
target=work/'build-r198.sh';assert not target.exists();target.write_text(helper,newline='\n')
print('Isolated pending expiry from startup seek by placing A-B around the established playing clock')
