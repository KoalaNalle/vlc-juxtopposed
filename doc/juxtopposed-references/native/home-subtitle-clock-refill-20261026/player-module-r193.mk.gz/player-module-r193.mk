ifndef PLAYER_MODULE_OUT
$(error Fresh PLAYER_MODULE_OUT required)
endif
.PHONY: owned-player-module
owned-player-module: $(PLAYER_MODULE_OUT)/libtest_src_player_plugin.la
$(PLAYER_MODULE_OUT):
	mkdir -p "$@"
$(PLAYER_MODULE_OUT)/test_src_player.lo: $(PLAYER_MODULE_SOURCE) | $(PLAYER_MODULE_OUT)
	$(LIBTOOL) --tag=CC --mode=compile $(CC) $(DEFS) $(DEFAULT_INCLUDES) $(libdemux_mock_plugin_la_CPPFLAGS) $(CPPFLAGS) $(AM_CFLAGS) $(CFLAGS) -DTOP_BUILDDIR=\"$(abs_top_builddir)\" -I$(top_srcdir)/test/src/player -c "$<" -o "$@"
$(PLAYER_MODULE_OUT)/libtest_src_player_plugin.la: $(PLAYER_MODULE_OUT)/test_src_player.lo
	$(libdemux_mock_plugin_la_LINK) $< $(libdemux_mock_plugin_la_LIBADD) $(LIBS)
