from pathlib import Path
from hashlib import sha256
import json, shutil
work=Path(__file__).resolve().parent
repo=work.parents[1]
media=work/'cold-origin-media-r201';assert not media.exists();media.mkdir()
source=repo/'build-windows/beta-subtitle-fps-20261024/media-r1/frame-marker.mp4'
for name in ['Show.S01E01.mp4','Show.S01E02.mp4']:shutil.copyfile(source,media/name)
(media/'external-fps.srt').write_text('1\n00:00:00,000 --> 00:00:02,000\nORIGIN CAPTION\n\n2\n00:00:20,000 --> 00:00:30,000\nSECOND CAPTION\n\n3\n00:00:40,000 --> 00:00:50,000\nENDING CAPTION\n',newline='\n')
(media/'Recovery.srt').write_text('1\n00:00:00,000 --> 00:01:00,000\nRECOVERED CAPTION\n',newline='\n')
(media/'Broken.srt').write_text('A readable file with no subtitle records.\n',newline='\n')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
(media/'manifest.json').write_text(json.dumps(dict(generatedFixturesOnly=True,
    sourceSha256=digest(source),files={p.name:digest(p) for p in media.iterdir() if p.is_file()}),indent=2)+'\n',newline='\n')
helper=(work/'run-ui-policy-r196.py').read_text().replace("media=work/'attachment-media-r85'", "media=work/'cold-origin-media-r201'")
target=work/'run-ui-origin-r201.py';assert not target.exists();target.write_text(helper,newline='\n')
print('Prepared generated origin/timeline and recovery fixtures for ordinary GUI testing')
