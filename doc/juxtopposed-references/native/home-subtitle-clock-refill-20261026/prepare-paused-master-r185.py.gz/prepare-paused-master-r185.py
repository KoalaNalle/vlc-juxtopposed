from pathlib import Path
from hashlib import sha256
import json
work = Path(__file__).resolve().parent
repo = work.parents[1]
clean = json.loads((work/'inputs-r182.json').read_text())
diagnostic = json.loads((work/'inputs-r184.json').read_text())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
for name in ['src/player/input.c', 'src/player/timer.c']:
    path = repo/name
    assert digest(path) == diagnostic['files'][name], name
    original = Path(clean['sourceCopies'][name])
    assert digest(original) == clean['files'][name]
    path.write_bytes(original.read_bytes())
path = repo/'src/player/timer.c'
text = path.read_text()
old = '''    struct vlc_player_timer_source *source = &player->timer.best_source;
    if (!source->es || es_source_is_master)'''
new = '''    struct vlc_player_timer_source *source = &player->timer.best_source;
    /* A paused subtitle redraw can invalidate the audio master's clock without
     * producing another audio buffer. Use a fresh video update in that case;
     * the master regains priority as soon as it publishes again on resume. */
    const bool paused_video = player->timer.update_state == UPDATE_STATE_PAUSED
                           && source->point.system_date == VLC_TICK_INVALID
                           && es_source && vlc_es_id_GetCat(es_source) == VIDEO_ES;
    if (!source->es || es_source_is_master || paused_video)'''
assert text.count(old)==1
path.write_text(text.replace(old,new),newline='\n')
for name in ['src/player/input.c','src/player/timer.c']:
    assert b'VLC_SUBTITLE_CLOCK_TRACE' not in (repo/name).read_bytes()
previous = digest(work/'core-r184-bin/libvlccore.dll')
helper = (work/'build-core-r181.sh').read_text().replace('r181','r185').replace(
    '9a6d1dc3a96cd0bfeb1f8dc277977d41d1ad1430ef2b918bb8b41dab02362939',previous)
target = work/'build-core-r185.sh';assert not target.exists();target.write_text(helper,newline='\n')
receipt=dict(diagnosticSourceRemoved=True,baseManifest='inputs-r182.json',
    reason='Fresh paused video points were ignored after the audio master clock was invalidated.',
    selectedRuntimeUnchanged=True,fullBetaAccepted=False)
(work/'paused-master-r185.json').write_text(json.dumps(receipt,indent=2)+'\n',newline='\n')
print(json.dumps(receipt))
