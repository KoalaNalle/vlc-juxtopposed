from pathlib import Path
from datetime import datetime
import json
work=Path(__file__).resolve().parent;repo=work.parents[1]
helper=(work/'build-r199.sh').read_text().replace('r199','r202')
target=work/'build-r202.sh';assert not target.exists();target.write_text(helper,newline='\n')
helper=(work/'run-native-edge-r196.py').read_text().replace(
    "elif mode=='pending-ab':command+=['subtitleRefreshExpiryKeepsAtoBDeadline']",
    "elif mode=='pending-ab':command+=['subtitleRefreshExpiryKeepsAtoBDeadline']\nelif mode=='reuse':command+=['attachmentReusedMediaCaption']")
target=work/'run-native-reuse-r202.py';assert not target.exists();target.write_text(helper,newline='\n')
receipt=dict(updatedAt=datetime.now().astimezone().isoformat(),candidateCore='core-r195-bin/libvlccore.dll',
    ordinaryGui='ordinary-r158-bin/libqt_plugin.dll',fullBetaAccepted=False,
    setup='ui-origin-setup-r201',originAndRecovery='ui-origin-cold-r201',returnedSource='ui-recovery-cold-r201',
    scopedPasses=['Paused file association applies origin caption without seek/resume.',
        'Cold origin association restores.', 'Invalid readable SRT retains complete accessible inline error.',
        'Valid replacement renders while paused.', 'Cancel preserves the saved replacement.',
        'Replacement survives restart after settling.', 'Second file uses its own embedded subtitle.'],
    failure='After E1-E2-E1, Recovery.srt is loaded and Track 3 selected but no caption renders in playing/paused output.',
    beforeDiagnosticSeek=dict(frameMarker=1349,captionPixels=0),
    afterDiagnosticSeek=dict(frameMarker=608,captionPixels=2597),
    everyOrdinaryProcessNormal=True,sourceRuntimeFixtureCacheGuards=True,
    diagnostics='Snapshot D3D blend warnings remain open; the deliberate bad-file run has nine DVD probe errors.')
(work/'ordinary-reuse-checkpoint-r202.json').write_text(json.dumps(receipt,indent=2)+'\n',newline='\n')
status=repo/'doc/juxtopposed/STATUS.md';text=status.read_text()
old='''5. Next: finish thirteen startup-rate and eleven timing compatibility cases,
   then ordinary cold saved-attachment startup, paused replacement, FPS/cue
   interaction, playing/source-change/restart and normal quit on Core r195/GUI r158.
   Generated origin/timeline fixtures are prepared for the actual window tests.
6. Current source inventory is `inputs-r201.json`. Review helpers before reuse.'''
new='''5. All thirteen startup-rate and eleven timing compatibility cases pass:
   `rate-startup-r201` and `timing-r201`. Ordinary origin save/cold restore,
   accessible invalid-file error, paused replacement and Cancel pass on the
   Core r195/GUI r158 tuple. All three ordinary processes exit 0 with 602 modules
   and unchanged guards; snapshot-preview blend warnings remain open.
6. **New ordinary failure:** E1-E2-E1 loads/selects the saved `Recovery.srt`, but
   its caption is absent while playing and after pausing at 53 seconds. A native
   snapshot has marker 1349 and zero caption pixels. A diagnostic seek to 24
   seconds restores it (marker 608, 2597 caption pixels). Preserve this failure;
   it is not accepted. Local receipt: `ordinary-reuse-checkpoint-r202.json`.
   Next: reproduce an A-B-A transition that retains the started player/video
   output, comparing a fresh item with the reused playlist item; repair before
   ordinary FPS/cue and remaining W1 journeys.
7. Current source inventory is `inputs-r202.json`. Review helpers before reuse.'''
assert old in text;status.write_text(text.replace(old,new),newline='\n')
print('Preserved ordinary failure and prepared A-B-A native reproduction')
