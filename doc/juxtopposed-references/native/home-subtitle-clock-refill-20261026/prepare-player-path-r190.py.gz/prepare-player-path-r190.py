from pathlib import Path
work=Path(__file__).resolve().parent
helper=(work/'run-player-r189.py').read_text()
old="env=environment(runtime,out);env.pop('VLC_PLUGIN_PATH',None)"
new="env=environment(runtime,out);env.pop('VLC_PLUGIN_PATH',None);env['VLC_TEST_PLUGIN_PATH']=str(runtime/'plugins')"
assert helper.count(old)==1
helper=helper.replace(old,new)
target=work/'run-player-r190.py';assert not target.exists();target.write_text(helper,newline='\n')
print('Corrected cross-built test_setup plugin-path override')
