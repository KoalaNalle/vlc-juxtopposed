from pathlib import Path
from hashlib import sha256
import ctypes, json, shutil, subprocess, sys
work=Path(__file__).resolve().parent
repo=work.parents[1]
digest=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',newline='\n')
revision,label,mode=sys.argv[1:]
assert mode in ['abloop','timers','all']
manifest=work/f'inputs-{revision}.json';inputs=read(manifest)
assert all(digest(repo/p)==h and digest(Path(inputs['sourceCopies'][p]))==h for p,h in inputs['files'].items())
base=work/'ui-r77/runtime';expected=read(work/'ui-r77/verification.json')['runtimeSha256']
assert all(digest(base/p)==h for p,h in expected.items())
out=work/label;assert not out.exists();out.mkdir()
sys.path.insert(0,str(repo/'test/libvlc'))
from native_http_runtime import stage_runtime,environment
runtime=out/'runtime';stage_runtime(base,runtime)
target=runtime/'libvlccore.dll';target.unlink();shutil.copyfile(work/'core-r185-bin/libvlccore.dll',target)
support=work/'support-r189/libssp-0.dll'
support_hash=digest(support)
shutil.copyfile(support,runtime/'libssp-0.dll')
identities={name:digest(runtime/name) for name in expected}
env=environment(runtime,out);env.pop('VLC_PLUGIN_PATH',None)
env.pop('VLC_SUBTITLE_CLOCK_TRACE',None)
record=dict(status='starting',sourceManifestSha256=digest(manifest),
    producerSha256=digest(Path(__file__)),runtimeSha256=identities,supportDllSha256=support_hash,processes=[],
    fullBetaAccepted=False,ordinaryGuiAccepted=False,forcedCleanupUsed=False)
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.SetErrorMode.argtypes=[ctypes.c_uint];kernel.SetErrorMode.restype=ctypes.c_uint
previous=kernel.SetErrorMode(0x8003)
try:
    for name in (['abloop','timers'] if mode=='all' else [mode]):
        program='test_src_player_'+name+'.exe'
        shutil.copyfile(work/'player-r187-bin'/program,runtime/program)
        current=dict(name=name,executableSha256=digest(runtime/program))
        with (out/(name+'-stdout.txt')).open('wb') as stdout,(out/(name+'-stderr.txt')).open('wb') as stderr:
            child=subprocess.Popen([str(runtime/program)],cwd=runtime,env=env,
                stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
            current.update(pid=child.pid,status='running');record['processes'].append(current)
            record['status']='running';write(out/'verification.json',record)
            print(name,'PID',child.pid,flush=True)
            try:current['exitCode']=child.wait(timeout=300)
            except subprocess.TimeoutExpired:
                record['status']='observation-timeout-process-left-running';write(out/'verification.json',record)
                raise SystemExit('Inspect recorded owned PID; no automatic cleanup or restart')
            current.update(status='terminal',normalExit=current['exitCode']==0)
            write(out/'verification.json',record)
            if not current['normalExit']:break
finally:kernel.SetErrorMode(previous)
record.update(status='terminal',sourceInputsUnchanged=all(digest(repo/p)==h for p,h in inputs['files'].items()),
    runtimeUnchanged=all(digest(base/p)==h and digest(runtime/p)==identities[p] for p,h in expected.items()),
    supportDllUnchanged=digest(support)==support_hash and digest(runtime/'libssp-0.dll')==support_hash,
    producerUnchanged=digest(Path(__file__))==record['producerSha256'],
    normalExit=all(p['normalExit'] for p in record['processes']))
write(out/'verification.json',record)
print(json.dumps(record),flush=True)
assert record['normalExit'] and record['sourceInputsUnchanged'] and record['runtimeUnchanged'] and record['supportDllUnchanged']
