#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-core-r185.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-core-r185-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 72b1b08c4d9b24b11e93dc5bb22aa145ed155ab3d40599f61a82df5477fb0f5a
test ! -e "$work/core-r185-bin"
make -C "$base/win64/src" -j2 libvlccore.la
mkdir "$work/core-r185-bin"
cp "$base/win64/src/.libs/libvlccore.dll" "$work/core-r185-bin/"
cp "$base/win64/src/player/.deps/libvlccore_la-input.Plo" "$work/core-r185-bin/player-input.Plo"
sha256sum "$work/core-r185-bin/libvlccore.dll"
