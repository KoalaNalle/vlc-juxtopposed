#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-player-r187.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-player-r187-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 9dfe025e012ce7d744332dc6b2361b43883966fd751d779fba1a91ed0df57487
test ! -e "$work/player-r187-bin"
make -C "$base/win64/test" -j2 test_src_player_abloop.exe test_src_player_timers.exe
mkdir "$work/player-r187-bin"
for name in abloop timers; do
    cp "$base/win64/test/.libs/test_src_player_$name.exe" "$work/player-r187-bin/"
done
sha256sum "$work/player-r187-bin/"*.exe
