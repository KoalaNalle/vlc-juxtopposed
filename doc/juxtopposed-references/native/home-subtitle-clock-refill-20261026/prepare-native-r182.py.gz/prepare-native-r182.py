from pathlib import Path
from datetime import datetime
work = Path(__file__).resolve().parent
repo = work.parents[1]
helper = (work / 'build-r167.sh').read_text().replace('r167', 'r182').replace(
    'ad8f4c62a6ab8565388a46d7ad9cb40c817d24d7ac139ba936720e8075f09c6a',
    '062c82cdd5efdf79aa74bd0d283bba80fe4acf29704c55db1421340799c825a1')
target = work / 'build-r182.sh'
assert not target.exists()
target.write_text(helper, encoding='utf-8', newline='\n')
status = repo / 'doc/juxtopposed/STATUS.md'
text = status.read_text(encoding='utf-8')
text = text.replace('Updated 26 October 2026, 18:05 Helsinki.',
                    'Updated '+datetime.now().astimezone().strftime('%d October %Y, %H:%M Helsinki.'))
text = text.replace('1. Repair the hardware cold-start subtitle refresh. The new',
                    '1. Qualify the hardware cold-start subtitle refresh. The new')
text = text.replace('2. The selection-time trace shows',
    '2. Core r181 (`062c82cd`) passes all six strict cold-origin cycles in both\n'
    '   hardware and software without a user seek/resume; marker 0 is retained.\n'
    '   Receipts: `cold-origin-d3d11-r181` and `cold-origin-software-r181` under\n'
    '   the active build run. This is not yet ordinary or broad acceptance.\n'
    '   The selection-time trace shows')
text = text.replace('4. Production player/renderer source bytes were restored to the tested r167\n'
    '   snapshot. The clean native build tree was rebuilt as Core r174; the selected\n'
    '   tested Core remains r136. Final inventory: `inputs-r180.json`; session report:\n'
    '   `session-checkpoint-r180.json`, under the active build run directory above.\n'
    '   Review helpers and refresh inventories before reuse.',
    '4. The deferred worker proposal is applied in current source and built as\n'
    '   Core r181; the selected ordinary Core remains r136. Native r182 adds\n'
    '   held-clock/frame diagnostics without relaxing the two failing assertions.\n'
    '   Current inventory: `inputs-r182.json`, under the active run directory.\n'
    '   Frozen r180 is the previous paused checkpoint; do not rerun its helpers.')
status.write_text(text, encoding='utf-8', newline='\n')
print('Prepared fresh native build and active checkpoint')
