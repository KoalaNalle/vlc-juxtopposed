#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
native="$base/owned-single-frame-native-20261026-r200"
ordinary="$base/owned-single-frame-ordinary-20261026-r200"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-r200.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-r200-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 72c37a9cc7c43b2fb1d6055d399e1db1aba95fa49bf99b9969bf574477af6d03
test ! -e "$native"
test ! -e "$ordinary"
test ! -e "$work/cue-r200-bin"
test ! -e "$work/ordinary-r200-bin"
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$work/cue-r111.mk" -j2 CUE_NATIVE_OUT="$native" owned-subtitle-cue-native
mkdir "$work/cue-r200-bin"
cp "$native/.libs/test_qt_subtitle_cue_timeline.exe" "$work/cue-r200-bin/"
sha256sum "$work/cue-r200-bin/test_qt_subtitle_cue_timeline.exe"
