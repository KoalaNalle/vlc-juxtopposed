#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
native="$base/owned-single-frame-native-20261026-r192"
ordinary="$base/owned-single-frame-ordinary-20261026-r192"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-r192.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-r192-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 9dfe025e012ce7d744332dc6b2361b43883966fd751d779fba1a91ed0df57487
test ! -e "$native"
test ! -e "$ordinary"
test ! -e "$work/native-r192-bin"
test ! -e "$work/ordinary-r192-bin"
make -C "$base/win64/modules" -f Makefile -f "$work/player-module-r192.mk" -j2 PLAYER_MODULE_OUT="$base/owned-player-module-r192" PLAYER_MODULE_SOURCE="$work/player-modules-r192.c" owned-player-module
mkdir "$work/player-module-r192-bin"
cp "$base/owned-player-module-r192/.libs/libtest_src_player_plugin.dll" "$work/player-module-r192-bin/"
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/build-windows/beta-subtitle-fps-20261023/native-r1.mk" -j2 FPS_NATIVE_OUT="$native" owned-subtitle-fps-native
mkdir "$work/native-r192-bin"
cp "$native/.libs/test_qt_player_subtitle_delay.exe" "$work/native-r192-bin/"
sha256sum "$work/native-r192-bin/test_qt_player_subtitle_delay.exe"
