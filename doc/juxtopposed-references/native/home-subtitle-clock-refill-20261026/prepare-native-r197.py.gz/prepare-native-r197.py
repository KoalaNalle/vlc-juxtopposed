from pathlib import Path
work=Path(__file__).resolve().parent
helper=(work/'build-r196.sh').read_text().replace('r196','r197')
target=work/'build-r197.sh';assert not target.exists();target.write_text(helper,newline='\n')
print('Prepared fresh-media A-B fixture with actual startup-state diagnostics')
