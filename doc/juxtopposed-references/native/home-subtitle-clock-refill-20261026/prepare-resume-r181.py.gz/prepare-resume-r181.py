from pathlib import Path
from hashlib import sha256
import json, subprocess

work = Path(__file__).resolve().parent
repo = work.parents[1]
proposal = work / 'deferred-refresh-candidate-r178'
metadata = json.loads((proposal / 'proposal.json').read_text())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
for name, expected in metadata['preimageSha256'].items():
    assert digest(repo / name) == expected, name
assert digest(proposal / 'candidate.patch') == metadata['patchSha256']
subprocess.run(['git', 'apply', '--check', str(proposal / 'candidate.patch')], cwd=repo, check=True)
subprocess.run(['git', 'apply', str(proposal / 'candidate.patch')], cwd=repo, check=True)
helper = (work / 'build-core-r174.sh').read_text()
helper = helper.replace('r174', 'r181').replace(
    '202277204a06e2358956ca62092b29cff0aaa8998767e9531158a3470e4f3550',
    '9a6d1dc3a96cd0bfeb1f8dc277977d41d1ad1430ef2b918bb8b41dab02362939')
destination = work / 'build-core-r181.sh'
assert not destination.exists()
destination.write_text(helper, encoding='utf-8', newline='\n')
status = repo / 'doc/juxtopposed/STATUS.md'
text = status.read_text(encoding='utf-8')
old = '''Updated 26 October 2026. Beta work is **paused ahead of the owner's 08:00
Helsinki cutoff** (06:00 UTC). All owned desktop/native tests have exited;
the desktop is free. Beta and release gates remain unfinished.'''
new = '''Updated 26 October 2026, 18:05 Helsinki. Beta work is **active**, resumed
with the desktop available. Stop owned work and checkpoint by **27 October
08:00 Helsinki** (06:00 UTC). Beta and release gates remain unfinished.'''
assert old in text
text = text.replace(old, new)
text = text.replace('An **unapplied, uncompiled** worker-based proposal is in',
    'The worker-based proposal has now been applied for the **untested r181 candidate**, in')
status.write_text(text, encoding='utf-8', newline='\n')
receipt = dict(appliedProposal=str(proposal), preimageSha256=metadata['preimageSha256'],
    postimageSha256={name:digest(repo/name) for name in metadata['preimageSha256']},
    compiled=False, tested=False, selectedRuntimeUnchanged=True,
    deadlineLocal='2026-10-27T08:00:00+02:00', deadlineUtc='2026-10-27T06:00:00Z')
(work/'resume-r181.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(receipt), flush=True)
