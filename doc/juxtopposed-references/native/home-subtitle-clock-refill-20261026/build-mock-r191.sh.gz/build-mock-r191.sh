#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-mock-r191.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-mock-r191-exit.txt"; exit "$code"' EXIT
test ! -e "$work/mock-r191-bin"
make -C "$base/win64/modules" -j2 libdemux_mock_plugin.la
mkdir "$work/mock-r191-bin"
cp "$base/win64/modules/.libs/libdemux_mock_plugin.dll" "$work/mock-r191-bin/"
sha256sum "$work/mock-r191-bin/libdemux_mock_plugin.dll"
