from pathlib import Path
import json
work=Path(__file__).resolve().parent
data=json.loads((work/'inputs-r190.json').read_text())
for name in ['modules/demux/mock.c','modules/demux/Makefile.am']:
    if name not in data['files']:data['files'][name]='new required input'
(work/'inventory-seed-r191.json').write_text(json.dumps(data,indent=2)+'\n',newline='\n')
helper=(work/'run-player-r190.py').read_text()
old="env.pop('VLC_SUBTITLE_CLOCK_TRACE',None)"
new="""env.pop('VLC_SUBTITLE_CLOCK_TRACE',None)
mock_source=work/'mock-r191-bin/libdemux_mock_plugin.dll'
mock=runtime/'plugins/demux/libdemux_mock_plugin.dll';assert not mock.exists()
shutil.copyfile(mock_source,mock);mock_hash=digest(mock)
cachefile=runtime/'plugins/plugins.dat'
if cachefile.exists():cachefile.unlink()
with (out/'cache-stdout.txt').open('wb') as stdout,(out/'cache-stderr.txt').open('wb') as stderr:
    cache=subprocess.Popen([str(runtime/'vlc-cache-gen.exe'),str(runtime/'plugins')],cwd=runtime,
        env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    write(out/'cache-process.json',dict(status='running',pid=cache.pid))
    try:cachecode=cache.wait(timeout=60)
    except subprocess.TimeoutExpired:raise SystemExit('Inspect owned cache PID; no automatic restart')
write(out/'cache-process.json',dict(status='terminal',pid=cache.pid,exitCode=cachecode))
assert cachecode==0
cache_hash=digest(cachefile)"""
assert helper.count(old)==1
helper=helper.replace(old,new)
helper=helper.replace("supportDllSha256=support_hash,processes=[],", "supportDllSha256=support_hash,mockPluginSha256=mock_hash,pluginCacheSha256=cache_hash,processes=[],")
helper=helper.replace("supportDllUnchanged=digest(support)==support_hash", "mockPluginUnchanged=digest(mock_source)==mock_hash and digest(mock)==mock_hash,\n    pluginCacheUnchanged=digest(cachefile)==cache_hash,\n    supportDllUnchanged=digest(support)==support_hash")
helper=helper.replace("and record['supportDllUnchanged']\n", "and record['supportDllUnchanged'] and record['mockPluginUnchanged'] and record['pluginCacheUnchanged']\n")
target=work/'run-player-r191.py';assert not target.exists();target.write_text(helper,newline='\n')
print('Prepared explicit private mock input dependency and regenerated-cache runner')
