from pathlib import Path
from hashlib import sha256
import gzip, json

work = Path(__file__).resolve().parent
repo = work.parents[1]
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda p: sha256(p.read_bytes()).hexdigest()
out = repo/'doc/juxtopposed-references/native/home-subtitle-clock-refill-20261026'
assert not out.exists()
current = read(work/'inputs-r206.json')
assert all(digest(repo/p) == h and digest(Path(current['sourceCopies'][p])) == h
           for p, h in current['files'].items())

native = ['native-d3d11-r204', 'native-software-r204', 'cue-native-r205',
          'reuse-source-refill-r204']
for name in native:
    v = read(work/name/'verification.json')
    assert v['status'] == 'terminal' and v['exitCode'] == 0
    assert all(v[k] for k in ['sourceInputsUnchanged', 'runtimeUnchanged', 'fixturesUnchanged'])
    assert all(i['type'] == 'pass' for f in v['functions'] for i in f['incidents'])
assert len(read(work/'native-d3d11-r204/verification.json')['functions']) == 29
assert len(read(work/'native-software-r204/verification.json')['functions']) == 29
assert len(read(work/'cue-native-r205/verification.json')['functions']) == 13

ordinary = ['ui-origin-setup-r201', 'ui-origin-cold-r201', 'ui-recovery-cold-r201',
            'ui-reuse-after-r205', 'ui-fps-after-r206', 'ui-playing-fps-r206']
for name in ordinary:
    v = read(work/name/'verification.json')
    assert v['normalExit'] and v['moduleCounts'] == ['602']
    assert all(v[k] for k in ['sourceInputsUnchanged', 'runtimeUnchanged',
                             'fixturesUnchanged', 'pluginCacheUnchanged'])
timing = read(work/'timing-r205/processes.json')
rates = read(work/'rate-startup-r205/verification.json')
assert timing['passed'] and timing['allProcessesNormal'] and len(timing['records']) == 11
assert rates['passed'] and len(rates['records']) == 13
assert all(r['normalExit'] for r in rates['records'])
player = read(work/'player-native-r205/verification.json')
assert player['normalExit'] and all(r['normalExit'] for r in player['processes'])
startup = read(work/'main-startup-r205/verification.json')
assert startup['normalExit'] and len(startup['functions'][1]['incidents']) == 4
assert all(i['type'] == 'pass' for f in startup['functions'] for i in f['incidents'])

out.mkdir()
artifacts, local_streams = [], []
def retain(p, relative=None):
    relative = relative or p.relative_to(work).as_posix()
    target = out/(relative + '.gz')
    assert not target.exists()
    raw = p.read_bytes()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(raw, mtime=0))
    artifacts.append(dict(path=target.relative_to(out).as_posix(), sha256=digest(target),
                          rawSha256=sha256(raw).hexdigest()))

before = ['cold-origin-d3d11-r181', 'cold-origin-software-r181', 'native-d3d11-r182',
          'clock-decode-d3d11-r183', 'clock-decode-d3d11-r184', 'decode-d3d11-r185',
          'native-d3d11-r186', 'native-d3d11-r188', 'native-software-r189',
          'selection-pause-before-software-r194', 'selection-pause-after-software-r195',
          'pending-ab-software-r196', 'pending-ab-software-r197',
          'pending-ab-software-r198', 'pending-ab-d3d11-r199', 'native-d3d11-r198',
          'cue-native-r199', 'reuse-d3d11-before-r202', 'reuse-language-before-r203',
          'player-native-r188', 'player-native-r189', 'player-native-r190',
          'player-native-r191', 'player-native-r193']
intermediate = ['native-d3d11-r199', 'native-software-r200', 'cue-native-r200',
                'main-startup-r200', 'rate-startup-r201', 'timing-r201', 'player-native-r196']
for name in dict.fromkeys(before + intermediate + native + ordinary +
                         ['main-startup-r205', 'rate-startup-r205', 'timing-r205', 'player-native-r205']):
    folder = work/name
    assert folder.is_dir(), name
    for p in sorted(folder.rglob('*')):
        parts = p.relative_to(folder).parts
        if not p.is_file() or any(x in parts for x in ['runtime', 'userdata', 'temp']):
            continue
        if p.suffix in ['.log', '.txt']:
            local_streams.append(dict(path=p.relative_to(work).as_posix(), sha256=digest(p),
                                      bytes=p.stat().st_size, packaged=False))
        elif p.suffix in ['.json', '.xml', '.png', '.jpg', '.py']:
            retain(p)

sources = ['src/player/input.c', 'src/player/player.c', 'src/player/player.h',
           'src/player/timer.c', 'src/input/input.c', 'src/input/input_internal.h',
           'src/input/es_out.c', 'src/input/es_out.h', 'src/video_output/video_output.c',
           'src/video_output/vout_subpictures.c',
           'modules/gui/qt/tests/test_player_subtitle_delay.cpp',
           'modules/gui/qt/tests/test_subtitle_cue_timeline.cpp',
           'modules/gui/qt/tests/vlc_stub_modules.cpp', 'modules/gui/qt/player/qml/Player.qml']
for revision in ['r158', 'r181', 'r185', 'r195', 'r199', 'r200', 'r203', 'r204', 'r206']:
    manifest = work/f'inputs-{revision}.json'
    m = read(manifest)
    retain(manifest)
    for name in sources:
        if name not in m['files']:
            continue
        p = Path(m['sourceCopies'][name])
        assert digest(p) == m['files'][name]
        retain(p, f'sources/{revision}/{name}')
for p in sorted(work.iterdir()):
    if p.is_file() and ((p.suffix in ['.py', '.sh', '.mk', '.c']
                        and any(f'r{n}' in p.name for n in range(180, 208)))
                       or p.name in ['cleanup-abloop-r189.json', 'cleanup-abloop-r190.json',
                                     'ordinary-reuse-checkpoint-r202.json']):
        retain(p)

record = dict(status='scoped-checkpoint-beta-incomplete', fullBetaAccepted=False,
    selectedOrdinaryRuntime=read(work/'ui-playing-fps-r206/verification.json')['runtimeSha256'],
    selectedRuntimePath='build-windows/beta-single-frame-20261025-night/ui-playing-fps-r206/runtime',
    artifacts=artifacts, localStreams=local_streams,
    native=dict(subtitleFunctionsPerVideoMode=29, cueFunctions=13, mainStartupRates=4,
                startupAudioCases=13, timingCases=11, officialPlayerSuites=['abloop', 'timers']),
    repairs=[
      'Bounded source-owned deferred paused subtitle refresh waits for a current video clock; output-clock callbacks never acquire the player lock.',
      'A fresh paused video point can replace an invalid audio master until audio resumes. Same encoded held frame is preserved; the original 100 ms native time bound remains unchanged.',
      'Selection immediately before pause retains its refresh; resume, user seek, recording and input teardown discard obsolete requests. Pending expiry does not force an early A-B loop.',
      'A preloaded external subtitle may have discarded its cue while preferred embedded English was selected. A source-only refill on newly selected tracks revalidates selection and retains delayed cues without seeking audio/video or resetting their PCR.'
    ],
    ordinary=[
      'Core195 origin Save and cold restore, full accessible invalid-file feedback, valid replacement while paused and Cancel preserving that mapping have scoped passes.',
      'The Core195 ordinary warm return loses Recovery.srt despite selected Track3; a native image has zero caption pixels. A diagnostic seek restores 2597 pixels. This failure is retained.',
      'Native203 reproduces the warm failure only for a reused item plus an English preference; three controls pass. Identical native203 rows all pass Core204.',
      'Core204 ordinary cold Recovery caption, second-file embedded caption, and warm returned Recovery caption while playing and paused pass without seek/resume. Native snapshot marker240 contains2597 caption pixels.',
      'At main speed1.5 the QML50-FPS edit displays MIDDLE, legacy reads50, legacy29.97 restores FIRST and QML receives29.97. QML Reset settles at0. A paused24-second seek at50 renders LAST; Reset renders MIDDLE on exactly the same encoded native frame613.',
      'The earlier1.5-speed playing Reset attempt did not reach its intended live control before the short clip completed. It supplies no playing Reset acceptance.',
      'At main speed0.5, external50-FPS subtitles are exhausted beyond32 seconds. Actual playing Reset settles at0 and revives LAST while the native app clock advances through47-50 seconds; no pause/seek is issued for that Reset.',
      'All six ordinary processes exit0 with602 modules and unchanged source/runtime/fixture/cache guards. The last Quit overlaps next-input startup; it is not a stable-first-input playing-Quit claim.'
    ],
    corrections=[
      'Native186 exact RGB-crop equality rejected snapshot conversion rounding although encoded frame IDs matched. The retained final tests require the exact fixture frame ID and preserve the original100ms clock bound.',
      'Cue199 checked a clock before asynchronous redraw settled and saw1us reconciliation. Cue200 waits for settled time and then compares exactly; exact microsecond seek requests remain strict.',
      'Pending-AB196/197 had a narrow setup clock window. Full hardware198 inherited1.5x because rate was set before fresh input startup. Final199 establishes1x after startup before measuring the expiry/AB boundary.',
      'Windows official C tests needed an existing compiler support DLL, private mock demux and a private dynamic copy of builtin test audio modules. Failed harness188-191 runs are not product acceptance.',
      'The old player-native189/190 producer fields say forcedCleanupUsed=false. The separate cleanup receipts prove the verified owned headless PIDs were forcibly stopped after no normal route; those fields are superseded for interpretation, not rewritten.'
    ],
    remaining=[
      'The first replacement cold capture in the Core195 run was blank; the next fresh observation without input showed the caption. No strict first-capture pass or capture-lag cause is claimed.',
      'Actual DX11 snapshot requests still emit YUVA-to-DX11 blend diagnostics and a transient missing displayed caption. The saved PNG has captions after CPU fallback. Snapshot display/preview remains open.',
      'The earlier longer warm ui-cue-r118 caption loss remains separately retained; this receipt does not establish an identical cause.',
      'Current-tuple ordinary secondary/per-track timing, estimators, remaining defaults/restart/cue journeys, online subtitle search, broader consumers, design/DPI/hardware/final-package gates remain unfinished.',
      'Windows10 AUDIOSES and physical endpoint/device/casting limitations remain explicit external deferrals. No beta-ready or release claim is made.'
    ])
(out/'checkpoint.json').write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8', newline='\n')
(out/'README.md').write_text('''# Subtitle clock recovery and saved-source refill - 26 October 2026

Core `54e3368f` with ordinary GUI `3530c5cc` passes the scoped cold-caption,
paused replacement, saved-source warm-return and cross-editor FPS journeys.
This is a development checkpoint; beta, design and package gates remain open.

A deferred refresh now waits for a current paused video clock, preserves its
encoded frame, and survives selection immediately before pause. A fresh paused
video point can replace an invalid audio master until audio resumes. Pending
refresh expiry preserves the independent A-B loop deadline.

The ordinary A-B-A failure is reproduced with a reused media item and preferred
embedded English: the saved external cue was discarded before its track was
selected. A source-only refill repairs the unchanged four-row native comparison
and the actual Next/Previous journey without seeking audio/video or their PCR.

Both hardware and software pass 29 subtitle functions. Thirteen cue functions,
four main startup rates, thirteen audio/rate cases, eleven format/delay/boundary
cases and the official A-B/timer suites also pass. The ordinary1.5x paused
seek/Reset pair retains exact native frame613. A separate0.5x playing Reset
revives an exhausted subtitle while the clock continues.

[checkpoint.json](checkpoint.json) binds exact binaries, sources, tests, native
snapshots, actual captures and normal exits. It preserves failed comparisons,
fixture corrections and harness cleanup qualifications. Raw output streams remain
local with hashes; generated-media captures and structured evidence are retained
here. Native fixtures use a separate support GUI and private C-test modules.

DX11 snapshot blending/preview, the earlier longer warm-caption observation and
the remaining W1/consumer/design/platform/package gates are still open. Read the
receipt's limits before combining evidence, then continue from
[STATUS](../../../juxtopposed/STATUS.md).
''', encoding='utf-8', newline='\n')
print(str(out), len(artifacts), 'artifacts; raw streams retained locally', flush=True)
