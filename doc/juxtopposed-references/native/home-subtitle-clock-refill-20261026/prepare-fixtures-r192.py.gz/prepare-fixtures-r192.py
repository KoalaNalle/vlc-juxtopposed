from pathlib import Path
from datetime import datetime
work=Path(__file__).resolve().parent
repo=work.parents[1]
text=(repo/'test/src/player/modules.c').read_text()
text=text.replace('#undef VLC_DYNAMIC_PLUGIN','/* Built as a private dynamic fixture on Windows. */')
text=text.replace('const char vlc_module_name[] = MODULE_STRING;','')
start=text.index('VLC_EXPORT const vlc_plugin_cb vlc_static_modules[] = {')
text=text[:start]
target=work/'player-modules-r192.c';assert not target.exists();target.write_text(text,newline='\n')
helper=(work/'build-r188.sh').read_text().replace('r188','r192')
helper=helper.replace('make -C "$base/win64/modules/gui/qt"',
    'make -C "$base/win64/modules" -f Makefile -f "$work/player-module-r192.mk" -j2 PLAYER_MODULE_OUT="$base/owned-player-module-r192" PLAYER_MODULE_SOURCE="$work/player-modules-r192.c" owned-player-module\n'
    'mkdir "$work/player-module-r192-bin"\ncp "$base/owned-player-module-r192/.libs/libtest_src_player_plugin.dll" "$work/player-module-r192-bin/"\n'
    'make -C "$base/win64/modules/gui/qt"')
target=work/'build-r192.sh';assert not target.exists();target.write_text(helper,newline='\n')
helper=(work/'run-player-r191.py').read_text()
needle="cachefile=runtime/'plugins/plugins.dat'"
replacement="""aout_source=work/'player-module-r192-bin/libtest_src_player_plugin.dll'
aout=runtime/'plugins/audio_output/libtest_src_player_plugin.dll';assert not aout.exists()
shutil.copyfile(aout_source,aout);aout_hash=digest(aout)
cachefile=runtime/'plugins/plugins.dat'"""
assert helper.count(needle)==1
helper=helper.replace(needle,replacement)
helper=helper.replace('mockPluginSha256=mock_hash,pluginCacheSha256=cache_hash,',
    'mockPluginSha256=mock_hash,privateAoutSha256=aout_hash,pluginCacheSha256=cache_hash,')
helper=helper.replace('mockPluginUnchanged=digest(mock_source)==mock_hash',
    'privateAoutUnchanged=digest(aout_source)==aout_hash and digest(aout)==aout_hash,\n    mockPluginUnchanged=digest(mock_source)==mock_hash')
target=work/'run-player-r192.py';assert not target.exists();target.write_text(helper,newline='\n')
helper=(work/'run-native-cold-r162.py').read_text().replace("env=environment(runtime,out);env.pop('VLC_PLUGIN_PATH',None)",
    "env=environment(runtime,out);env.pop('VLC_PLUGIN_PATH',None);env['VLC_TEST_NATIVE_VERBOSE']='1';env['VLC_COLD_START_CYCLES']='6'")
target=work/'run-native-verbose-r192.py';assert not target.exists();target.write_text(helper,newline='\n')
status='''# Current status

Updated NOW Helsinki. Beta work is **active** with the desktop available.
Checkpoint and stop owned jobs by **27 October 2026, 08:00 Helsinki** (06:00 UTC).
Beta and release gates remain unfinished; no commit/push is authorized.

## Selected checkpoint

- Source base: `5b3eb021c026b4fa595bfec36e1ff0975c3f7bfd`, plus local repairs/docs.
  The four unrelated audio experiments remain untouched.
- Selected ordinary runtime remains Core `ad8f4c62`, GUI `3530c5cc`, subtitle demux
  `11f2b78e`, WASAPI `e5560794`, MKV `f46d8d15`, at
  `build-windows/beta-single-frame-20261025-night/ui-notice-final-r163/runtime`.
  Its scoped evidence is in the [compact subtitle receipt](../juxtopposed-references/native/home-compact-subtitles-20261026/README.md)
  and [cue clock receipt](../juxtopposed-references/native/home-subtitle-cue-clock-20261026/README.md).
- Active run directory: `build-windows/beta-single-frame-20261025-night`.
  Candidate Core r185 is `9dfe025e`; it is not selected for ordinary acceptance.
  Diagnostic-only Cores r183/r184 are retained; their logging is removed from source.

## Current work and next action

1. The deferred refresh proposal is applied. Core r181 passed six cold-origin
   software and six D3D11 cycles without a user seek/resume. A second repair in
   r185 lets a fresh paused video clock replace an invalid audio clock until
   audio resumes; the decoded frame stays unchanged during subtitle recovery.
2. The r185 D3D11 suite with native binary r188 passes all 26 functions, including
   both former paused-clock failures and six origin cycles: `native-d3d11-r188`.
   Source/runtime/fixture guards pass and cleanup exits normally.
3. The equivalent software suite `native-software-r189` retains one intermittent
   origin-caption failure (attachments-first, cycle 1); the second capture is
   also blank. Other functions pass. Do not accept or hide this failure.
   Next: stress the two registration orders with verbose native source/track
   observations, then repair and rerun affected suites and actual ordinary journeys.
4. Official A-B/timer tests needed a compiler support DLL and the noninstalled
   mock-input plugin. First attempts r189/r190 required forced headless cleanup;
   receipts and a debugger stack are retained. r191 reaches a real assertion but
   lacks its builtin fake audio module on Windows. A private dynamic-fixture
   adaptation is being built as r192; this is test infrastructure, not acceptance.
5. Current source inventory is `inputs-r192.json`. Review helpers before reuse.
   Keep one native build writer; do not replace the older tested runtime.

## Remaining beta work and questions

Continue W1, then W2/W3 in [BETA](BETA.md) and [SETTINGS](SETTINGS.md).
Compact notices/recovery and windowed control spacing have scoped ordinary passes;
cue interaction/secondary timing/estimators and full current-tuple journeys remain.
Earlier warm-caption loss and D3D snapshot preview diagnostics remain separate.
Conversion retains scoped exact-output, destination safety, cancellation and
normal-shutdown evidence; older consumer receipts keep their recorded limits.

Online subtitle search/download needs implementation and an owner API-application
decision. Windows 10 AUDIOSES, physical endpoints/device loss, casting and OS-DPI/
monitor checks retain explicit deferrals. All six beta gates remain open.
'''
status=status.replace('NOW',datetime.now().astimezone().strftime('%d October %Y, %H:%M'))
(repo/'doc/juxtopposed/STATUS.md').write_text(status,encoding='utf-8',newline='\n')
print('Prepared explicit Windows fixture adaptation and cold-start stress diagnostics')
