from pathlib import Path
work = Path(__file__).resolve().parent
text = (work/'run-fragment-r245.py').read_text(encoding='utf-8')
needle = "work/'core-r224-bin/libvlccore.dll'"
assert text.count(needle) == 1
target = work/'run-fragment-r253.py'
assert not target.exists()
target.write_text(text.replace(needle, "work/'core-r252-bin/libvlccore.dll'"), encoding='utf-8', newline='\n')
text = (work/'run-fragment-all-r242.py').read_text(encoding='utf-8')
text = text.replace('r242', 'r253')
target = work/'run-fragment-all-r253.py'
assert not target.exists()
target.write_text(text, encoding='utf-8', newline='\n')
print('Prepared unchanged public-API seek regressions for Core252')
