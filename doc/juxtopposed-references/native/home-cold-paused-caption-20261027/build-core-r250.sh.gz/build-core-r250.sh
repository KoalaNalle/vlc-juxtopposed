#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-core-r250.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-core-r250-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = ccf72399765f11541dbcb434a3b088a84127f1595af51755037fa03620dadaeb
test ! -e "$work/core-r250-bin"
make -C "$base/win64/src" -j2 libvlccore.la
mkdir "$work/core-r250-bin"
cp "$base/win64/src/.libs/libvlccore.dll" "$work/core-r250-bin/"
cp "$base/win64/src/player/.deps/libvlccore_la-input.Plo" "$work/core-r250-bin/player-input.Plo"
sha256sum "$work/core-r250-bin/libvlccore.dll"
