from pathlib import Path
from hashlib import sha256
import gzip,json
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
out=repo/'doc/juxtopposed-references/native/home-cold-paused-caption-20261027'
assert not out.exists()
m=read(work/'inputs-r253.json')
assert all(digest(repo/p)==h for p,h in m['files'].items())
analysis=read(work/'cold-caption-analysis-r254.json');assert analysis['passed']
ui=read(work/'ui-cold-fixed-r252/verification.json')
controls=read(work/'cold-start-control-r253/verification.json')
assert controls['passed'] and len(controls['records'])==13
native={}
for name in ['native-cold-software-r253','native-cold-hardware-r253','native-cold-wasapi-r253']:
    v=read(work/name/'verification.json')
    assert v['normalExit'] and all(v[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','producerUnchanged'])
    assert all(i['type']=='pass' for f in v['functions'] for i in f['incidents'])
    assert v['latePictureWarnings']==v['avcodecLateErrors']==0
    native[name]=dict(functions=len(v['functions']),actualWasapiSelected=v['actualWasapiSelected'])
assert native['native-cold-wasapi-r253']['actualWasapiSelected']
matrix=read(work/'fragment-matrix-r253/summary.json')
assert matrix['status']=='terminal' and matrix['allPassed'] and len(matrix['cases'])==12
names=['ui-fragment-cold-export-r248','ui-cold-diagnostic-r250','ui-cold-fixed-r252',
       'cold-native-before-r251','cold-start-control-r253','fragment-matrix-r253']+list(native)
names += [r['label'] for r in matrix['cases']]
out.mkdir();artifacts=[];streams=[]
def retain(p,relative=None):
    target=out/((relative or p.relative_to(work).as_posix())+'.gz')
    assert not target.exists()
    raw=p.read_bytes();target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(raw,mtime=0))
    artifacts.append(dict(path=target.relative_to(out).as_posix(),sha256=digest(target),rawSha256=sha256(raw).hexdigest()))
for name in names:
    for p in sorted((work/name).rglob('*')):
        if not p.is_file() or any(x in p.relative_to(work/name).parts for x in ['runtime','userdata','appdata','localappdata','temp']):continue
        if p.suffix in ['.log','.txt']:streams.append(dict(path=p.relative_to(work).as_posix(),sha256=digest(p),packaged=False))
        elif p.suffix in ['.json','.xml','.png','.py','.qml']:retain(p)
for revision in ['r245','r250','r251','r252','r253']:
    retain(work/f'inputs-{revision}.json')
    v=read(work/f'inputs-{revision}.json');name='src/input/decoder.c'
    p=Path(v['sourceCopies'][name]);assert digest(p)==v['files'][name]
    retain(p,f'sources/{revision}/{name}')
for name in ['test/libvlc/native_paused_video_startup.py','test/libvlc/native_mp4_subtitle_seek.py']:
    p=Path(m['sourceCopies'][name]);assert digest(p)==m['files'][name]
    retain(p,'sources/r253/'+name)
retain(work/'cold-caption-analysis-r254.json')
retain(work/'cold-packet-trace-r249/packets.json')
for p in sorted(work.iterdir()):
    if p.is_file() and p.suffix in ['.py','.sh'] and any(f'r{n}' in p.stem for n in range(250,255)):retain(p)
record=dict(status='tested-nightly-cold-caption-beta-incomplete',fullBetaAccepted=False,
    selectedRuntime='build-windows/beta-single-frame-20261025-night/ui-cold-fixed-r252/runtime',
    runtimeSha256=ui['runtimeSha256'],ordinaryAnalysis=analysis,native=native,
    artifacts=artifacts,localStreams=streams,matrix=matrix,
    accepted=[
      'Already buffered subtitle packets may decode while paused, as they already did after a paused seek. The video-only empty-FIFO path still requests further input only for a pending video frame.',
      'Matched ordinary launch options at1.5x: before Core224 exports frame0 with0 caption pixels; after Core252 exports frame0 with1488 caption pixels before any seek or track change. English was already selected; caption persists while held, then playback advances into MIDDLE and pauses normally.',
      'All13 software startup controls pass across WASAPI/dummy/no audio and rates0.5/1/1.5/2, plus subtitles disabled. Both31-function software and hardware timing suites pass; actual-WASAPI own/inherited large-delay rows pass, with zero late-picture/avcodec-late diagnostics.',
      'All12 public MP4 seek/delay/Reset/resume cases pass again on Core252 and MP4r240. All owned children exit normally with source/runtime/fixture guards preserved; ordinary app exits0 with602 modules and zero error diagnostics.'
    ],unresolved=[
      'The standalone software before-control already passed on Core224 and did not reproduce the ordinary D3D11/Qt startup race. It is preserved as a control, not claimed as a failing before case.',
      'The old cold RGB equality assertion failed: non-caption channels differ between the no-subtitle and blended exports. Marker-zero equality and caption presence are established; pixel-identical video is not claimed for this pair.',
      'Core250 adds temporary local trace logging only. It confirms an opening blank cue reaches the output before the covering80ms cue. The trace code is absent from the candidate source and Core252.',
      'Long/sparse fragment-cue seek cost, other index/live layouts, secondary-screen idle capture, physical display/DPI and the full beta/final-package gates remain open. Native software controls do not establish hardware startup across all configurations.'
    ])
(out/'checkpoint.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Initial paused caption - 27 October 2026

Core `0ab943f0`, ordinary GUI `4d754f60` and MP4 `df15e8ed` show the selected
English caption on the first paused fragmented-MP4 picture, before any seek or
selection action. With matched launch options, Core224 exported marker0 with
zero caption pixels; Core252 exports marker0 with1488. The caption stays held,
normal playback reaches MIDDLE, and the app exits0 with602 modules and no errors.

The decoder consumes subtitle packets already in its FIFO while paused. Its
empty-FIFO path still requests more input only for video. Thirteen software
startup controls, both31-function software/hardware timing suites, real-WASAPI
large-delay rows and twelve MP4 seek/selection cases pass with normal exits and
unchanged guards. The software before-control already passed and is not a
negative reproduction of the ordinary hardware/Qt race.

Temporary Core250 tracing is local evidence and was removed before Core252.
The previous RGB equality assertion remains failed: these exports establish the
same encoded marker and restored caption, not pixel-identical video. Sparse-cue
cost, other fragment/live layouts, secondary-screen idle capture, physical DPI
and all broader beta gates remain open. This is a nightly source checkpoint.

[checkpoint.json](checkpoint.json) retains identities, results, source copies,
compressed generated evidence and limits. Raw streams, binaries and private
profiles are excluded. Continue from [STATUS](../../../juxtopposed/STATUS.md).
''',encoding='utf-8',newline='\n')
for item in artifacts:
    p=out/item['path'];assert digest(p)==item['sha256'] and sha256(gzip.decompress(p.read_bytes())).hexdigest()==item['rawSha256']
print(out,len(artifacts),'verified artifacts')
