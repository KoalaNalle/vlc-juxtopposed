from pathlib import Path
from hashlib import sha256
import json
from PySide6.QtGui import QImage

work=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
before=work/'ui-fragment-cold-export-r248'
after=work/'ui-cold-fixed-r252'
old=read(before/'cold-native-images.json')['observations'][0]
old_image=before/'app-snapshots'/old['path']
new_images=sorted((after/'app-snapshots').glob('*.png'))
assert len(new_images)==1
rows=[]
for label,path in [('before',old_image),('after',new_images[0])]:
    im=QImage(str(path)).convertToFormat(QImage.Format_RGBA8888)
    assert not im.isNull() and (im.width(),im.height())==(960,540)
    raw=bytes(im.bits());stride=im.bytesPerLine()
    row=dict(run=label,path=path.relative_to(work).as_posix(),sha256=digest(path),
        marker=sum(1<<b for b in range(11) if im.pixelColor(32+64*b,20).red()>128),
        captionPixels=sum(raw[y*stride+x*4]>160 and raw[y*stride+x*4+1]>160 and raw[y*stride+x*4+2]>160
                          for y in range(3*im.height()//4,im.height()) for x in range(im.width())))
    rows.append(row)
assert rows[0]['marker']==rows[1]['marker']==0
assert rows[0]['captionPixels']==0 and rows[1]['captionPixels']>1000
for run in [before,after]:
    v=read(run/'verification.json')
    assert v['normalExit'] and not v['diagnostics'] and v['moduleCounts']==['602']
    assert all(v[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','producerUnchanged','pluginCacheUnchanged'])
commands=[read(p/'launch.json') for p in [before,after]]
assert commands[0][1:]==[x.replace(str(after),str(before)) for x in commands[1][1:]]
record=dict(passed=True,observations=rows,matchedLaunchOptions=True,
    scope='Ordinary D3D11/Qt initial paused fragmented-MP4 caption before any seek or track change, at 1.5x. Both exports encode frame marker zero. This is not a pixel-identical video comparison; the previous RGB equality assertion failed and remains recorded.',
    actualDesktopObservations='ui-cold-fixed-r252/observations',fullBetaAccepted=False)
(work/'cold-caption-analysis-r254.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record))
