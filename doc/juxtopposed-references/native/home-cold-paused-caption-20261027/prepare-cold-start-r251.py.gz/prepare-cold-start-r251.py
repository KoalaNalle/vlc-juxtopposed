from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'run-rate-startup-mp4-r237.py').read_text(encoding='utf-8')
text=text.replace('revision,label=sys.argv[1:]','revision,label,core_revision,mode=sys.argv[1:]\nassert mode in ["one","all"]')
text=text.replace("work/'core-r224-bin/libvlccore.dll'","work/f'core-{core_revision}-bin/libvlccore.dll'")
text=text.replace("work/'mp4-r233-bin/libmp4_plugin.dll'","work/'mp4-r240-bin/libmp4_plugin.dll'")
text=text.replace("media=repo/'build-windows/beta-subtitle-fps-20261024/media-r1/frame-marker.mp4'","media=work/'mp4-media-r234/fragmented.mp4'")
marker="    cases.append(('wasapi',1.,False))";assert text.count(marker)==1
text=text.replace(marker,marker+"\n    if mode=='one':cases=[('wasapi',1.5,True)]")
target=work/'run-cold-start-r251.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared unchanged native cold-start worker for the fragmented fixture')
