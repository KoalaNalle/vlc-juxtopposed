from pathlib import Path
import json

work = Path(__file__).resolve().parent
target = work / 'run-ui-music-selection-r296.py'
assert not target.exists()
source = (work / 'run-ui-library-history-r294.py').read_text(encoding='utf-8')
source = source.replace('Library header search-history and native-sort repair on ordinary GUI293/Core265/library282: initial folder-sort feedback and active-filter Back/Forward restoration.', 'Ordinary GUI293/Core265/library282 artist multi-selection Play and successive detail changes, with actual queue/content identities and retained primary playback.')
target.write_text(source, encoding='utf-8', newline='\n')
print(json.dumps({'prepared': True}))
