from pathlib import Path
from hashlib import sha256
import gzip, json, re

work = Path(__file__).resolve().parent
repo = work.parents[1]
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda p: sha256(p.read_bytes()).hexdigest()
root = work / 'ui-music-selection-r296'
record = read(root / 'verification.json')
guards = ['sourceInputsUnchanged', 'runtimeUnchanged', 'baseRuntimeUnchanged', 'fixturesUnchanged',
          'musicFixturesUnchanged', 'lateFixturesUnchanged', 'decodeFixturesUnchanged',
          'extraFixturesUnchanged', 'producerUnchanged', 'pluginCacheUnchanged']
assert record['normalExit'] and record['exitCode'] == 0 and not record['diagnostics']
assert record['moduleCounts'] == ['602'] and all(record[k] for k in guards)
manifest = read(work / 'inputs-r296.json')
assert all(digest(repo / p) == h for p, h in manifest['files'].items())
def tree(name): return read(root / 'observations' / (name + '.json'))['accessibility']['tree']
def queue(name): return re.findall(r'list item \(selectable, settable, string\) (.*?) ID:', tree(name))
tracks = ['First light', 'Second light', 'A long title for checking truncation and focus in the redesigned music library', 'Nested song']
assert queue('05-settled-multi-artist-queue-six-in-order') == ['Show.S01E01.mp4', 'Show.S01E02.mp4'] + tracks
assert queue('12-grid-first-light-advances-ten-queue-items') == ['Show.S01E01.mp4', 'Show.S01E02.mp4'] + tracks + tracks
for name in ['06-single-fixture-detail-six-queue-held-first', '07-another-artist-correct-tracks-held-first',
             '08-fixture-return-correct-tracks-held-first', '09-unicode-artist-correct-single-track-held-first']:
    assert 'Progress Value: 0.5531554999999999' in tree(name)
assert 'text First light' in tree('08-fixture-return-correct-tracks-held-first')
assert 'text Second light' in tree('08-fixture-return-correct-tracks-held-first')
assert 'text Unicode song äö' in tree('09-unicode-artist-correct-single-track-held-first')
assert 'Progress Value: 0.12189891666666666' in tree('12-grid-first-light-advances-ten-queue-items')
out = repo / 'doc/juxtopposed-references/native/home-music-selection-20261027'
assert not out.exists(); out.mkdir()
artifacts = []
def retain(p):
    relative = p.relative_to(work).as_posix() + '.gz'
    target = out / relative; target.parent.mkdir(parents=True, exist_ok=True)
    raw = p.read_bytes(); target.write_bytes(gzip.compress(raw, mtime=0))
    artifacts.append(dict(path=relative, sha256=digest(target), rawSha256=sha256(raw).hexdigest()))
for name in ['verification.json', 'producer.py', 'launch.json', 'staging.json', 'ml-copy.json']:
    p = root / name
    if p.is_file(): retain(p)
for p in sorted((root / 'observations').glob('*')):
    if p.suffix in ['.json', '.png']: retain(p)
for name in ['inputs-r296.json', 'prepare-music-selection-r296.py', 'run-ui-music-selection-r296.py', 'write-music-selection-receipt-r297.py']:
    retain(work / name)
result = dict(status='passed-scoped-ordinary-music-selection', fullBetaAccepted=False,
    runtimeSha256=record['runtimeSha256'], sourceManifestSha256=digest(work / 'inputs-r296.json'),
    sourceInputCount=len(manifest['files']), normalExit=True, allGuards=True,
    observations=[
        'Table: pointer-select Fixture Artist, Shift+Down selects Another Artist too. Return starts First light and appends both artists behind the two initial videos, with exact First/Second/long/Nested order and six queue entries.',
        'After33.18933s Pause, opening one artist only navigates. Fixture/Another/Fixture/Ärtist detail changes show their own actual track names and counts while preserving the same paused First light clock and six-entry queue.',
        'Grid: Fixture Artist plus Shift+Right selects Another Artist. Return appends the same four tracks once, now ten total, and starts the new First light occurrence. The clock advances beyond7s. Normal Quit while playing releases the process with zero error diagnostics/602modules/all source/runtime/fixture/cache guards.'
    ], limits=[
        'This ordinary run uses the same accepted GUI293/Core265/library282; no production code changed for these journeys. Supplied fixtures are generated silent audio and owned video, not private media.',
        'Sidebar changes are successive observed actions, not proof that native requests overlapped in flight. The pending rapid-query race remains separate. Ordinary classic multi-selection, every sort/filter permutation and full visual/DPI/package acceptance are not established.',
        'Initial queue observation04 precedes animation; settled observation05 supplies the visible drawer. UIA does not expose reliable selected row flags, so actual selection highlights plus the resulting exact queue provide the ordinary selection evidence.'
    ], artifacts=artifacts)
(out / 'checkpoint.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
(out / 'README.md').write_text('''# Music selection replay - 27 October 2026

The ordinary GUI293/Core265/library282 now has actual table and grid
multi-selection Play evidence. Selecting Fixture Artist and Another Artist
appends their four real tracks in the expected order and starts the first new
track. The six-item table queue and ten-item repeated grid queue are captured.

Successive artist detail changes retain paused First light at33.18933s and show
the correct artist's tracks/count. Normal Quit while playing exits0/602modules/
zero error diagnostics with every guard intact. No code repair was needed.

See the [checkpoint](checkpoint.json) for identities, captures and exact limits.
This does not establish an in-flight rapid-query race, full category/layout/DPI
acceptance or a clean final package. Continue from
[STATUS](../../../juxtopposed/STATUS.md).
''', encoding='utf-8', newline='\n')
for artifact in artifacts:
    p = out / artifact['path']
    assert digest(p) == artifact['sha256']
    assert sha256(gzip.decompress(p.read_bytes())).hexdigest() == artifact['rawSha256']
print(out, len(artifacts), 'verified artifacts', flush=True)
