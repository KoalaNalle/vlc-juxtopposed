from pathlib import Path
work=Path(__file__).resolve().parent
freeze=(work/'freeze-global-shortcuts-r439.py').read_text(encoding='utf-8')
freeze=freeze.replace("root=work/f'source-{revision}'", "names.update(p.relative_to(repo).as_posix() for p in (repo/'modules/mux/mp4').iterdir() if p.suffix in ['.c','.h'])\nroot=work/f'source-{revision}'")
(work/'freeze-record-overlap-r462.py').write_text(freeze,encoding='utf-8',newline='\n')
unit=(work/'run-record-unit-r321.py').read_text(encoding='utf-8')
unit=unit.replace('len(rows)==12','len(rows)==23').replace("rows[-1]['checks']==11", "rows[-1]['checks']==22")
unit=unit.replace('buffered start-date calculation, not a decoder/output integration test.', 'buffered start-date calculation and finite subtitle interval clipping; no decoder/output integration acceptance.')
(work/'run-record-overlap-unit-r462.py').write_text(unit,encoding='utf-8',newline='\n')
producer=(work/'run-record-overlap-r461.py').read_text(encoding='utf-8')
producer=producer.replace('inputs-r461','inputs-r462').replace('native-record-overlap-r461','native-record-overlap-fixed-r463')
producer=producer.replace("runtime=out/'runtime';stage_runtime(base,runtime)", """runtime=out/'runtime';stage_runtime(base,runtime)
base_identities=dict(identities)
for name in ['plugins/stream_out/libstream_out_record_plugin.dll','plugins/mux/libmux_mp4_plugin.dll']:
    base_identities[name]=digest(base/name)
    target=runtime/name;target.unlink();shutil.copyfile(work/'record-overlap-r462-bin'/Path(name).name,target)
    identities[name]=digest(target)
from native_http_runtime import regenerate_cache
regenerate_cache(runtime,out/'cache')""")
producer=producer.replace('all(digest(base/p)==h for p,h in identities.items()),\n    fixturesUnchanged', 'all(digest(base/p)==h for p,h in base_identities.items()),\n    fixturesUnchanged')
(work/'run-record-overlap-fixed-r463.py').write_text(producer,encoding='utf-8',newline='\n')
