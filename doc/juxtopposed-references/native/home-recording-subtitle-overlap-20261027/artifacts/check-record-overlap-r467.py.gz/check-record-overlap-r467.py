from pathlib import Path
from hashlib import sha256
import json,re,subprocess
from PySide6.QtCore import QSettings

work=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
prefix=['wsl.exe','-d','VLC-Juxtopposed-Home-20261018','--exec']
linux=lambda p:'/mnt/c/'+p.as_posix().split(':/',1)[1]
ordinary=work/'ui-record-overlap-r466'
ui=read(ordinary/'verification.json')
assert ui['normalExit'] and not ui['diagnostics'] and ui['moduleCounts']==['602']
assert all(v for k,v in ui.items() if k.endswith('Unchanged'))
files=list((ordinary/'recordings').glob('*.mp4'));assert len(files)==1
file=files[0]
probe_command=prefix+['/usr/bin/ffprobe','-v','error','-count_frames','-show_entries','stream=index,codec_type,codec_name,nb_read_frames,start_time,duration:format=duration','-of','json',linux(file)]
probe=subprocess.run(probe_command,capture_output=True,text=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
decode_command=prefix+['/usr/bin/ffmpeg','-hide_banner','-v','error','-nostdin','-xerror','-i',linux(file),'-map','0:v:0','-map','0:a:0','-progress','pipe:1','-f','null','-']
decode=subprocess.run(decode_command,capture_output=True,text=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
sub_command=prefix+['/usr/bin/ffmpeg','-hide_banner','-v','error','-nostdin','-i',linux(file),'-map','0:s:0','-c:s','srt','-f','srt','-']
subtitles=subprocess.run(sub_command,capture_output=True,text=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
assert probe.returncode==decode.returncode==subtitles.returncode==0
ordinary_output=dict(file=file.relative_to(work).as_posix(),sha256=digest(file),
    probeCommand=probe_command,probeExit=probe.returncode,probeStderr=probe.stderr,outputProbe=json.loads(probe.stdout),
    decodeCommand=decode_command,decodeExit=decode.returncode,decodeStderr=decode.stderr,decodeProgress=decode.stdout,
    subtitleCommand=sub_command,subtitleExit=subtitles.returncode,subtitleStderr=subtitles.stderr,subtitles=subtitles.stdout)
def time(text):
    h,m,s,ms=map(int,re.split('[:,]',text));return 3600*h+60*m+s+ms/1000
def cues(text):
    return {label:(time(start),time(end)) for start,end,label in re.findall(r'(\d\d:\d\d:\d\d,\d{3}) --> (\d\d:\d\d:\d\d,\d{3})\n(OWNED [A-Z ]+)',text)}
def qualify(case,expected_end):
    assert case['decodeExit']==0 and not case['decodeStderr']
    streams={s['codec_type']:s for s in case['outputProbe']['streams']}
    assert all(int(streams[k]['nb_read_frames'])>0 for k in ['audio','video'])
    start_diff=abs(float(streams['audio']['start_time'])-float(streams['video']['start_time']))
    duration_diff=abs(float(streams['audio']['duration'])-float(streams['video']['duration']))
    assert start_diff<.1 and duration_diff<.15
    found=cues(case['subtitles'])
    assert abs(found['OWNED OVERLAP CUE'][0])<.002
    assert abs(found['OWNED OVERLAP CUE'][1]-expected_end)<.025
    assert abs(found['OWNED LATER CUE'][0]-(expected_end+4))<.025
    assert abs(found['OWNED LATER CUE'][1]-(expected_end+8))<.025
    return dict(cues=found,avStartDifference=start_diff,avDurationDifference=duration_diff,
                videoFrames=int(streams['video']['nb_read_frames']),normalDecode=True)
after=read(work/'native-record-overlap-fixed-r465/verification.json')
assert after['status']=='terminal' and all(v for k,v in after.items() if k.endswith('Unchanged'))
native={extension:qualify(after['cases'][extension],expected) for extension,expected in [('mp4',6.08),('mkv',6.0)]}
ordinary_qualified=qualify(ordinary_output,6.0)
assert ordinary_qualified['cues']['OWNED FINAL CUE']==(20.0,25.0)
before=read(work/'native-record-overlap-r461/verification.json')
intermediate=read(work/'native-record-overlap-fixed-r463/verification.json')
for record in [before,intermediate]:
    assert record['status']=='terminal' and all(v for k,v in record.items() if k.endswith('Unchanged'))
    assert all(c['normalExit'] and c['decodeExit']==0 for c in record['cases'].values())
assert not before['cases']['mp4']['overlapRetained']
assert not before['cases']['mkv']['overlapRetained']
assert 'NED LATER CUE' in before['cases']['mkv']['subtitles']
assert intermediate['cases']['mkv']['overlapRetained'] and not intermediate['cases']['mkv']['laterCueRetained']
midfile=work/'native-record-overlap-fixed-r463'/intermediate['cases']['mkv']['file']
ignore_command=prefix+['/usr/bin/ffprobe','-v','error','-ignore_editlist','1','-select_streams','s:0','-show_packets','-show_data','-of','json',linux(midfile)]
ignored=subprocess.run(ignore_command,capture_output=True,text=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
assert ignored.returncode==0
diagnostic=dict(command=ignore_command,exitCode=0,sha256=digest(midfile),packets=json.loads(ignored.stdout),
    interpretation='Valid later text exists beyond the intermediate edit duration; ignoring edit lists is diagnostic only.')
(work/'record-overlap-intermediate-packets-r467.json').write_text(json.dumps(diagnostic,indent=2)+'\n',encoding='utf-8')
unit=read(work/'native-record-overlap-unit-r464/verification.json')
assert unit['normalExit'] and unit['rows'][-1]==dict(checks=22,failures=0)
assert all(v for k,v in unit.items() if k.endswith('Unchanged'))
assert (ordinary/'config-before.txt').read_bytes()==(ordinary/'config-after.txt').read_bytes()
catalogues=[]
for name in ['settings-before.ini','settings-after.ini']:
    settings=QSettings(str(ordinary/name),QSettings.IniFormat);settings.setFallbacksEnabled(False)
    catalogues.append(json.loads(settings.value('Juxtopposed/player-profiles')))
assert catalogues[0]==catalogues[1]
tree=lambda name:read(ordinary/'observations'/f'{name}.json')['accessibility']['tree']
assert 'button (settable, string) Pause' in tree('04-record-playing-before-stop')
assert 'button (settable, string) Play ' in tree('07-final-player-paused-settled')
result=dict(passed=True,nativeCases=native,ordinary=ordinary_qualified,ordinaryOutput=ordinary_output,
    runtimeSha256=ui['runtimeSha256'],directProductionChecks=22,endingGuardsPassed=True,
    nativeConfigUnchanged=True,playerProfilesUnchanged=True,
    beforeMuxIdentityGuardedDuringRun=False,
    beforeMuxSha256MeasuredAfterRun=digest(work/'native-record-overlap-r461/runtime/plugins/mux/libmux_mp4_plugin.dll'),
    finalMuxIdentityGuardedDuringRun=True,allRecordingFormatsAccepted=False,fullBetaAccepted=False,
    finalPackageAccepted=False,firewallRuleChanges=[],securityPrivacyChanges=[],
    caveats=['Before r461 did not enumerate the mux source/binary; current repeats do. Its observed failure is preserved without retroactive guard claims.',
             'Native dummy-video runs log window closed at teardown; this fixture diagnostic is separate from the ordinary run with zero checked errors.',
             'The ordinary test preseeded one Record tile in its isolated profile; it does not establish customizer-gesture acceptance.'])
(work/'record-overlap-analysis-r467.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k in ['passed','nativeCases','ordinary','directProductionChecks','endingGuardsPassed','nativeConfigUnchanged','playerProfilesUnchanged']},indent=2))
