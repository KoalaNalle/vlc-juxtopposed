from pathlib import Path
work=Path(__file__).resolve().parent
build=(work/'build-record-overlap-r462.sh').read_text(encoding='utf-8').replace('r462','r464')
(work/'build-record-overlap-r464.sh').write_text(build,encoding='utf-8',newline='\n')
producer=(work/'run-record-overlap-fixed-r463.py').read_text(encoding='utf-8')
producer=producer.replace('inputs-r462','inputs-r464').replace('native-record-overlap-fixed-r463','native-record-overlap-fixed-r465').replace('record-overlap-r462-bin','record-overlap-r464-bin')
(work/'run-record-overlap-fixed-r465.py').write_text(producer,encoding='utf-8',newline='\n')
