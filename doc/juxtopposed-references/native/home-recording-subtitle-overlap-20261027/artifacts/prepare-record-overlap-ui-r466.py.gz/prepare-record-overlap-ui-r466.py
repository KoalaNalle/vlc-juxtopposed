from pathlib import Path
work=Path(__file__).resolve().parent
source=(work/'run-ui-global-key-mapping-r452.py').read_text(encoding='utf-8')
source=source.replace('long_media','record_media').replace('long_fixtures','record_fixtures')
source=source.replace('longFixtureSha256','recordFixtureSha256').replace('longFixturesUnchanged','recordFixturesUnchanged')
source=source.replace("record_media=work/'global-shortcut-media-r444'", "record_media=work/'record-overlap-media-r460'")
source=source.replace("str(record_media/'Long shortcut fixture.wav')", "str(record_media/'owned-overlap.mkv')")
source=source.replace('record-fixed-r322-bin','record-overlap-r464-bin')
source=source.replace("base_identities=dict(expected)", "expected['plugins/mux/libmux_mp4_plugin.dll']=digest(base/'plugins/mux/libmux_mp4_plugin.dll')\nbase_identities=dict(expected)")
anchor='identities={p:digest(runtime/p) for p in expected}'
source=source.replace(anchor,"target=runtime/'plugins/mux/libmux_mp4_plugin.dll';target.unlink();shutil.copyfile(work/'record-overlap-r464-bin/libmux_mp4_plugin.dll',target)\n"+anchor)
anchor="unchanged = deepcopy(selected['snapshot']); unchanged['layout'] = old_snapshot['layout']"
source=source.replace(anchor,"selected['snapshot']['layout']['video']['columns'][1] = [ids['RECORD_BUTTON']]\n"+anchor)
source=source.replace('tileNames=[], preseededNativeDefaults=True','tileNames=["RECORD_BUTTON"], preseededNativeDefaults=False')
source=source.replace('Ordinary GUI441 and win_hotkeys452 registration feedback in Controls/editor, current-versus-saved mappings, two-player collisions, actual global delivery and release/restart. Generated media and isolated profiles; no network/security/privacy changes.',
 'Ordinary GUI441 with record464/mux464, real Record tile start/stop and generated Matroska/SRT overlap playback. One Record tile is preseeded only in the isolated test profile; this is not customizer-gesture acceptance. No private hooks or network/security/privacy changes.')
(work/'run-ui-record-overlap-r466.py').write_text(source,encoding='utf-8',newline='\n')
