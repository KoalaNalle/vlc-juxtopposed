from pathlib import Path
from hashlib import sha256
import json,subprocess

work=Path(__file__).resolve().parent
out=work/'record-overlap-media-r460';assert not out.exists();out.mkdir()
source=work/'attachment-media-r85/Show.S01E01.mp4'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
source_hash=digest(source)
captions=out/'owned-overlap.srt'
captions.write_text('1\n00:00:05,000 --> 00:00:16,000\nOWNED OVERLAP CUE\n\n2\n00:00:20,000 --> 00:00:24,000\nOWNED LATER CUE\n\n3\n00:00:30,000 --> 00:00:35,000\nOWNED FINAL CUE\n',encoding='utf-8')
prefix=['wsl.exe','-d','VLC-Juxtopposed-Home-20261018','--exec']
linux=lambda p:'/mnt/c/'+p.as_posix().split(':/',1)[1]
commands=[]
for extension,codec in [('mp4','mov_text'),('mkv','srt')]:
    target=out/('owned-overlap.'+extension)
    command=prefix+['/usr/bin/ffmpeg','-hide_banner','-v','error','-nostdin','-n',
      '-i',linux(source),'-i',linux(captions),'-map','0:v:0','-map','0:a:0','-map','1:0',
      '-map_metadata','-1','-c:v','copy','-c:a','copy','-c:s',codec,'-metadata:s:s:0','language=eng',linux(target)]
    result=subprocess.run(command,capture_output=True,text=True,timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
    commands.append(dict(command=command,exitCode=result.returncode,stderr=result.stderr))
    assert result.returncode==0,result.stderr
    probe=subprocess.run(prefix+['/usr/bin/ffprobe','-v','error','-show_streams','-show_format','-of','json',linux(target)],capture_output=True,text=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    assert probe.returncode==0,probe.stderr
    (out/(extension+'-probe.json')).write_text(probe.stdout,encoding='utf-8')
assert digest(source)==source_hash
record=dict(generatedOnly=True,sourceSha256=source_hash,sourceUnchanged=True,commands=commands,
            files={p.name:digest(p) for p in out.iterdir() if p.is_file()},fullBetaAccepted=False)
(out/'fixture.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
worker=(work/'record-native-trace-r317.py').read_text(encoding='utf-8')
worker=worker.replace("assert mode in ['clean', 'seek', 'seek-no-sub']","assert mode in ['clean']")
assert "time.sleep(26)" in worker
worker=worker.replace('time.sleep(26)','time.sleep(26)')
(work/'record-overlap-worker-r460.py').write_text(worker,encoding='utf-8',newline='\n')
print(json.dumps(dict(generated=list(record['files']),sourceUnchanged=True)))
