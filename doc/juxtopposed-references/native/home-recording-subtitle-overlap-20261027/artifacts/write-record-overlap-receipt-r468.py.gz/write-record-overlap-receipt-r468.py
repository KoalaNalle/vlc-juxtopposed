from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess

work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
receipt=repo/'doc/juxtopposed-references/native/home-recording-subtitle-overlap-20261027'
assert not receipt.exists()
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert commit.startswith('ac762a8bbb')
analysis=read(work/'record-overlap-analysis-r467.json');assert analysis['passed']
manifest=read(work/'inputs-r466.json')
assert all(digest(repo/name)==h for name,h in manifest['files'].items())
names=['inputs-r461.json','inputs-r462.json','inputs-r464.json','inputs-r466.json',
    'prepare-record-overlap-r460.py','record-overlap-worker-r460.py',
    'prepare-record-overlap-fix-r462.py','freeze-record-overlap-r462.py',
    'run-record-overlap-unit-r462.py','prepare-record-overlap-r464.py',
    'prepare-record-overlap-ui-r466.py','run-ui-record-overlap-r466.py',
    'check-record-overlap-r467.py','record-overlap-analysis-r467.json',
    'record-overlap-intermediate-packets-r467.json','write-record-overlap-receipt-r468.py']
for stem in ['build-record-overlap-r462','build-record-overlap-r464']:
    names.extend(stem+suffix for suffix in ['.sh','.log','-exit.txt'])
files=[work/name for name in names]
files.extend(p for p in (work/'record-overlap-media-r460').iterdir() if p.suffix in ['.json','.srt'])
for run in ['native-record-overlap-r461','native-record-overlap-fixed-r463','native-record-overlap-fixed-r465']:
    files.extend(work/run/name for name in ['producer.py','verification.json','mp4-stdout.txt','mp4-stderr.txt','mkv-stdout.txt','mkv-stderr.txt'])
    for case in ['mp4','mkv']:
        files.extend(work/run/case/name for name in ['probe.json','vlc.log','vlcrc'])
for run in ['native-record-overlap-unit-r462','native-record-overlap-unit-r464']:
    files.extend(work/run/name for name in ['verification.json','stdout.txt','stderr.txt'])
run='ui-record-overlap-r466'
files.extend(work/run/name for name in ['producer.py','verification.json','launch.json','vlc.log','stderr.txt',
    'layout-fixture.json','settings-before.ini','settings-after.ini','config-before.txt','config-after.txt'])
files.extend(p for p in (work/run/'observations').iterdir() if p.is_file())
receipt.mkdir();(receipt/'artifacts').mkdir();inventory=[]
for path in sorted(set(files)):
    data=path.read_bytes();name=path.relative_to(work).as_posix().replace('/','__')+'.gz'
    target=receipt/'artifacts'/name;target.write_bytes(gzip.compress(data,mtime=0))
    assert gzip.decompress(target.read_bytes())==data
    inventory.append(dict(file='artifacts/'+name,source=path.relative_to(repo).as_posix(),sha256=sha256(data).hexdigest(),
                          gzipSha256=digest(target),bytes=len(data),compressedBytes=target.stat().st_size))
checkpoint=dict(sourceCommit=commit,runtime='build-windows/beta-single-frame-20261025-night/ui-record-overlap-r466/runtime',
    runtimeSha256=analysis['runtimeSha256'],analysis=analysis,artifacts=inventory,
    fullBetaAccepted=False,finalPackageAccepted=False,independentReviewAccepted=False,
    liveRecordingAccepted=False,allRecordingFormatsAccepted=False,
    indefiniteSubtitleRestorationAccepted=False,firewallRuleChanges=[],securityPrivacyChanges=[])
(receipt/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n',encoding='utf-8')
(receipt/'README.md').write_text(f'''# Recording subtitle overlap and final text packets

27 October 2026. Source `{commit}`. This extends the scoped
[recording-start repair](../home-recording-start-20261027/README.md).
Three concrete defects were observed in generated-file recording:

1. A subtitle beginning before the selected video keyframe was discarded even
   when its known duration extended into the recording. The buffered recording
   path now preserves only that remaining finite interval. Expired/unknown-length
   earlier subtitles remain dropped; audio/video packet times stay unchanged.
2. The MP4 shutdown drain sent queued plain-text samples directly to the writer,
   skipping the normal conversion to length-prefixed MP4 text. Matroska/SRT text
   consequently lost its first two characters. The regular drain now uses the
   same conversion as normal writes; the fragmented route stays as before.
3. An inserted zero-length subtitle clearer could leave the MP4 edit duration at
   the last caption's start. Valid later text existed in the file but normal
   playback excluded it. For that subtitle case, the edit includes the clearer's
   timestamp, retaining the final text interval.

## Verification

The original eleven direct recording-start checks and eleven new finite-interval
checks pass (22/22). They cover remaining duration, unchanged payload/flags, future/
expired/unknown captions, audio/video exclusion, PTS fallback/composition offset
and invalid/overflowing times. They exercise production code, not a decoder/mux
integration by themselves.

The native baseline r461 reproduces overlap loss in both MP4/mov_text and
Matroska/SRT, plus truncated final Matroska text. Its recorded source/binary
inventory did not enumerate the muxer; the observed output is preserved without a
retroactive source/ending-guard claim for that old mux. Its mux hash was measured
after the run and is labeled as such. Fresh fixed inventories include the mux
sources and both replacement DLLs.

Intermediate r463 restores overlap and length-prefixed text, but the Matroska
file's edit still cuts off the later cue. A diagnostic packet dump with edit-list
handling disabled exposes that valid cue at10–14seconds. That diagnostic option
is not used for acceptance. After the duration repair, final native r465 retains
both exact labels with normal decoding: MP4 overlap0–6.080 and later10.080–14.080;
Matroska overlap0–6.000 and later10.000–14.000. Audio/video decode successfully;
start differences are21.146ms/6ms and duration differences below70ms. Every native
ending source/runtime/base/fixture/producer/worker guard passes.

The ordinary GUI441/Core265 test r466 uses record464
`{analysis['runtimeSha256']['plugins/stream_out/libstream_out_record_plugin.dll'][:8]}` and
mux464 `{analysis['runtimeSha256']['plugins/mux/libmux_mp4_plugin.dll'][:8]}` without private hooks.
One Record tile is preseeded only in the isolated test profile; this is not a
customizer-gesture test. The visible Record control starts while paused, the play
control runs the source, Record stops the capture and the player pauses normally.
The saved file decodes811video frames and audio, with6ms start/77.687ms duration
difference. All three full caption labels survive at0–6,10–14and20–25seconds.
The actual stop happened around41seconds of source playback, followed by pause
around47seconds; no exact26-second recording claim is made. The player exits0
with602plugins, zero checked errors and all ending guards. Native config and the
complete player-profile catalogue remain identical before/after.

## Scope still open

The first usable video keyframe still determines recording start. This restores
buffered finite captions crossing that boundary; it does not reconstruct a cue
already consumed before recording was enabled or invent an indefinite duration.
Other codecs/containers, subtitle-only/overlapping-cue combinations, live recording,
repeated rapid start/stop, errors/retry, final-package and broader beta gates remain
separate. Native dummy-video runs log window closed at teardown; that fixture
diagnostic is preserved separately from the ordinary run's zero checked errors.
Immediate UIA states may lag the screen; settled observations identify final pause.
No full visual score, DPI, screen-reader or independent-review acceptance is claimed.

All inputs are generated. Media and binaries remain ignored; the receipt retains
their identities, commands, decoded results, snapshots, failures and producers.
`checkpoint.json` binds compressed artifacts to original/compressed SHA-256 and
every artifact was decompressed and verified. No firewall rules, security/privacy
or Defender settings changed. This is a frozen scoped record, not beta completion.
''',encoding='utf-8')
print(json.dumps(dict(sourceCommit=commit,artifacts=len(inventory),compressedBytes=sum(i['compressedBytes'] for i in inventory))))
