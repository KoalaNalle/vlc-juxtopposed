from pathlib import Path
from hashlib import sha256
import ctypes,json,shutil,subprocess,sys

work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
manifest=work/'inputs-r461.json';inputs=read(manifest)
assert all(digest(repo/p)==h for p,h in inputs['files'].items())
base=work/'ui-global-punctuation-r458/runtime'
identities=read(work/'ui-global-punctuation-r458/verification.json')['runtimeSha256']
assert all(digest(base/p)==h for p,h in identities.items())
media=work/'record-overlap-media-r460'
fixtures={p.name:digest(p) for p in media.iterdir() if p.is_file()}
worker=work/'record-overlap-worker-r460.py';worker_hash=digest(worker)
out=work/'native-record-overlap-r461';assert not out.exists();out.mkdir()
shutil.copyfile(Path(__file__),out/'producer.py')
sys.path.insert(0,str(repo/'test/libvlc'))
from native_http_runtime import stage_runtime,environment
runtime=out/'runtime';stage_runtime(base,runtime)
record=dict(status='starting',sourceManifestSha256=digest(manifest),runtimeSha256=identities,
    fixtureSha256=fixtures,producerSha256=digest(Path(__file__)),workerSha256=worker_hash,
    fullBetaAccepted=False,ordinaryGuiAccepted=False,forcedCleanupUsed=False,privateCore=False,
    privateGui=False,privateRecord=False,cases={},scope='Generated MP4/mov_text and Matroska/SRT subtitle overlap recording, decoded AV and extracted subtitle packets. Native API only.')
save=lambda:(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
save()
kernel=ctypes.WinDLL('kernel32');previous=kernel.SetErrorMode(0x8003)
prefix=['wsl.exe','-d','VLC-Juxtopposed-Home-20261018','--exec']
linux=lambda p:'/mnt/c/'+p.as_posix().split(':/',1)[1]
try:
    for extension in ['mp4','mkv']:
        target=out/extension;envroot=out/(extension+'-environment');envroot.mkdir()
        env=environment(runtime,envroot);env.pop('VLC_PLUGIN_PATH',None)
        command=[sys.executable,str(worker),str(runtime),str(media/('owned-overlap.'+extension)),str(target),'clean']
        with (out/(extension+'-stdout.txt')).open('wb') as stdout,(out/(extension+'-stderr.txt')).open('wb') as stderr:
            child=subprocess.Popen(command,cwd=runtime,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
            record.update(status='running');record['cases'][extension]=dict(status='running',pid=child.pid,command=command);save()
            print(extension,'PID',child.pid,flush=True)
            try:code=child.wait(timeout=90)
            except subprocess.TimeoutExpired:
                record['cases'][extension]['status']='timeout-process-left-running';save()
                raise SystemExit('Inspect same PID; no automatic cleanup/restart')
        case=record['cases'][extension];case.update(status='terminal',exitCode=code,normalExit=code==0)
        save();assert code==0
        case['probe']=read(target/'probe.json')
        files=[p for p in (target/'recordings').iterdir() if p.is_file()]
        assert len(files)==1,files
        file=files[0];case.update(file=file.relative_to(out).as_posix(),sha256=digest(file))
        probe_command=prefix+['/usr/bin/ffprobe','-v','error','-count_frames','-show_entries','stream=index,codec_type,codec_name,nb_read_frames,start_time,duration:format=duration','-of','json',linux(file)]
        probe=subprocess.run(probe_command,capture_output=True,text=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
        case.update(probeCommand=probe_command,probeExit=probe.returncode,probeStderr=probe.stderr,outputProbe=json.loads(probe.stdout) if probe.returncode==0 else None)
        decode_command=prefix+['/usr/bin/ffmpeg','-hide_banner','-v','error','-nostdin','-xerror','-i',linux(file),'-map','0:v:0','-map','0:a:0','-progress','pipe:1','-f','null','-']
        decode=subprocess.run(decode_command,capture_output=True,text=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
        case.update(decodeCommand=decode_command,decodeExit=decode.returncode,decodeStderr=decode.stderr,decodeProgress=decode.stdout)
        sub_command=prefix+['/usr/bin/ffmpeg','-hide_banner','-v','error','-nostdin','-i',linux(file),'-map','0:s:0','-c:s','srt','-f','srt','-']
        subtitles=subprocess.run(sub_command,capture_output=True,text=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
        case.update(subtitleCommand=sub_command,subtitleExit=subtitles.returncode,subtitleStderr=subtitles.stderr,subtitles=subtitles.stdout,
                    overlapRetained='OWNED OVERLAP CUE' in subtitles.stdout,laterCueRetained='OWNED LATER CUE' in subtitles.stdout)
        save();print(extension,'exit',code,'decode',decode.returncode,'overlap',case['overlapRetained'],'later',case['laterCueRetained'],flush=True)
finally:kernel.SetErrorMode(previous)
record.update(status='terminal',sourceInputsUnchanged=all(digest(repo/p)==h for p,h in inputs['files'].items()),
    runtimeUnchanged=all(digest(runtime/p)==h for p,h in identities.items()),baseRuntimeUnchanged=all(digest(base/p)==h for p,h in identities.items()),
    fixturesUnchanged=all(digest(media/p)==h for p,h in fixtures.items()),producerUnchanged=digest(Path(__file__))==record['producerSha256'],workerUnchanged=digest(worker)==worker_hash)
save();assert all(v for k,v in record.items() if k.endswith('Unchanged'))
print(json.dumps({k:v for k,v in record.items() if k.endswith('Unchanged')}),flush=True)
