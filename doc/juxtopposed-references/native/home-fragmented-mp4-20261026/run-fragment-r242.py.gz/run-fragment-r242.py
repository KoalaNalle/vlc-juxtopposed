from pathlib import Path
from hashlib import sha256
import ctypes,json,shutil,subprocess,sys
work=Path(__file__).resolve().parent;repo=work.parents[1]
revision,label,media_kind,rate,audio,mp4_revision,seek_seconds,selection=sys.argv[1:]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
manifest=work/f'inputs-{revision}.json';inputs=read(manifest)
assert all(digest(repo/p)==h for p,h in inputs['files'].items())
base=work/'ui-snapshot-primary-r211/runtime';expected=read(work/'ui-snapshot-primary-r211/verification.json')['runtimeSha256']
expected['plugins/demux/libmp4_plugin.dll']=digest(base/'plugins/demux/libmp4_plugin.dll')
assert all(digest(base/p)==h for p,h in expected.items())
out=work/label;assert not out.exists();out.mkdir()
sys.path.insert(0,str(repo/'test/libvlc'))
from native_http_runtime import stage_runtime,environment
runtime=out/'runtime';stage_runtime(base,runtime)
(runtime/'libvlccore.dll').unlink();shutil.copyfile(work/'core-r224-bin/libvlccore.dll',runtime/'libvlccore.dll')
mp4=runtime/'plugins/demux/libmp4_plugin.dll'
if mp4_revision!='baseline':
    mp4.unlink();shutil.copyfile(work/f'mp4-{mp4_revision}-bin/libmp4_plugin.dll',mp4)
identities={p:digest(runtime/p) for p in expected}
media=(repo/'build-windows/beta-subtitle-fps-20261024/media-r1/frame-marker.mp4' if media_kind=='short'
       else work/'timing-journey-media-r213/Show.S01E01.mp4')
if media_kind not in ['short','long']:
    assert media_kind in ['b0','b4','negative-cts','fragmented','no-edit']
    media=work/'mp4-media-r234'/(media_kind+'.mp4')
subtitle=work/'timing-journey-media-r213/external-fps.srt'
probe=out/'probe';probe.mkdir();worker=work/'probe-fragment-r242.py'
command=[sys.executable,str(worker),str(runtime),str(probe),str(media),str(subtitle),rate,audio,seek_seconds,selection]
record=dict(status='starting',fullBetaAccepted=False,forcedCleanupUsed=False,sourceManifestSha256=digest(manifest),
            producerSha256=digest(Path(__file__)),workerSha256=digest(worker),runtimeSha256=identities,
            mediaSha256=digest(media),subtitleSha256=digest(subtitle),command=command)
kernel=ctypes.WinDLL('kernel32',use_last_error=True);kernel.SetErrorMode.argtypes=[ctypes.c_uint];kernel.SetErrorMode.restype=ctypes.c_uint
previous=kernel.SetErrorMode(0x8003)
try:
    with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=runtime,env=environment(runtime,out),stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        record.update(status='running',pid=child.pid);write(out/'process.json',record);print(label,'PID',child.pid,flush=True)
        try:code=child.wait(timeout=120)
        except subprocess.TimeoutExpired:
            record.update(status='observation-timeout-process-left-running');write(out/'process.json',record)
            raise SystemExit('Inspect owned PID; no automatic restart or cleanup')
finally:kernel.SetErrorMode(previous)
result=read(probe/'result.json') if (probe/'result.json').exists() else None
record.update(status='terminal',exitCode=code,normalExit=code==0,result=result,
    sourceInputsUnchanged=all(digest(repo/p)==h for p,h in inputs['files'].items()),
    runtimeUnchanged=all(digest(runtime/p)==identities[p] and digest(base/p)==h for p,h in expected.items()),
    mediaUnchanged=digest(media)==record['mediaSha256'],subtitleUnchanged=digest(subtitle)==record['subtitleSha256'],
    workerUnchanged=digest(worker)==record['workerSha256'])
write(out/'process.json',record)
print(json.dumps(dict(exitCode=code,passed=bool(result and result['passed']),guards={k:record[k] for k in record if k.endswith('Unchanged')})),flush=True)
