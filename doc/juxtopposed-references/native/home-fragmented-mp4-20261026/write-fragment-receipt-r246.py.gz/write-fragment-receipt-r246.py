from pathlib import Path
from hashlib import sha256
import gzip,json
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
out=repo/'doc/juxtopposed-references/native/home-fragmented-mp4-20261026';assert not out.exists()
m=read(work/'inputs-r245.json');assert all(digest(repo/p)==h for p,h in m['files'].items())
matrix=read(work/'fragment-matrix-r242/summary.json')
assert matrix['status']=='terminal' and matrix['allPassed'] and len(matrix['cases'])==12
checked=read(work/'fragment-checked-in-r245/process.json');assert checked['normalExit'] and checked['result']['passed']
ui=read(work/'ui-fragment-r243/verification.json')
old=read(work/'ui-fragment-cold-before-r244/verification.json')
for v in [ui,old]:
    assert v['normalExit'] and v['moduleCounts']==['602'] and not v['diagnostics']
    assert all(v[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','pluginCacheUnchanged'])
frames=read(work/'ui-fragment-r243/held-frames.json');assert frames['passed'] and frames['identicalPixels']
assert {f['marker'] for f in frames['frames']}=={799}
names=['mp4-fragment-start-r239','mp4-fragment-cue-r240','fragment-both-r241',
       'fragment-matrix-r242','fragment-checked-in-r245','ui-fragment-r243','ui-fragment-cold-before-r244']
names += [r['label'] for r in matrix['cases']]
out.mkdir();artifacts=[];streams=[]
def retain(p,relative=None):
    target=out/((relative or p.relative_to(work).as_posix())+'.gz');assert not target.exists()
    raw=p.read_bytes();target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(raw,mtime=0))
    artifacts.append(dict(path=target.relative_to(out).as_posix(),sha256=digest(target),rawSha256=sha256(raw).hexdigest()))
for name in names:
    for p in sorted((work/name).rglob('*')):
        if not p.is_file() or any(x in p.relative_to(work/name).parts for x in
            ['runtime','userdata','appdata','localappdata','temp']):continue
        if p.suffix in ['.log','.txt']:
            streams.append(dict(path=p.relative_to(work).as_posix(),sha256=digest(p),packaged=False))
        elif p.suffix in ['.json','.xml','.png','.py','.qml']:retain(p)
for revision in ['r239','r240','r241','r242','r243','r244','r245']:
    retain(work/f'inputs-{revision}.json');v=read(work/f'inputs-{revision}.json')
    name='modules/demux/mp4/mp4.c';p=Path(v['sourceCopies'][name]);assert digest(p)==v['files'][name]
    retain(p,f'sources/{revision}/{name}')
name='test/libvlc/native_mp4_subtitle_seek.py';p=Path(m['sourceCopies'][name]);assert digest(p)==m['files'][name]
retain(p,f'sources/r245/{name}')
for p in sorted(work.iterdir()):
    if p.is_file() and p.suffix in ['.py','.sh'] and any(f'r{n}' in p.stem for n in range(239,247)):retain(p)
retain(work/'fragment-ui-media-r242/manifest.json')
record=dict(status='nightly-fragment-seek-checkpoint-beta-incomplete',fullBetaAccepted=False,
    selectedRuntime='build-windows/beta-single-frame-20261025-night/ui-fragment-r243/runtime',
    runtimeSha256=ui['runtimeSha256'],artifacts=artifacts,localStreams=streams,matrix=matrix,ordinaryFrames=frames,
    accepted=[
      'The MP4 fragment-index seek branch keeps its resolved decode start while retaining the requested accurate display cutoff. This removes the previously corrupt picture and accumulated clock drift.',
      'Selected subtitle tracks can require a packet in an earlier video fragment. The branch includes that fragment and starts audio/video at its indexed decode point so a covering long cue is restored.',
      'All12 generated cases pass with actual WASAPI: fragmented seeks at32s across0.5/1/1.5/2x, later52s cue, Finnish, both selected and subtitles disabled, plus no-B-frame, reordered, negative-offset and no-edit layouts. Each applies/reset delays, preserves the held frame, resumes, stops/releases normally and has no late-picture warning.',
      'The checked-in native_mp4_subtitle_seek.py is the tested probe body with a license header. Its separate both-caption rerun passes. Track IDs always come from the native track list.',
      'The ordinary GUI seeks to the middle cue, applies+5s, resets0 and resumes to LAST. Three exports are pixel-identical with marker799. Both candidate and prior-plugin comparison exit0 with602 modules,zero diagnostics and unchanged source/runtime/fixture/cache guards.'
    ],unresolved=[
      'Initial paused ordinary app captures lack the caption before any seek, on both prior MP4r233 and candidate r240. The prior comparison confirms English selected. Seeking restores the caption. This remains open; no native cold export or physical-display result establishes its cause.',
      'The first dual-caption probe used default placements: it rendered English near the middle and Finnish near the bottom, while its assertion searched the upper quarter. Its false result is a fixture-location error, not lost captions. Later probes set explicit primary-bottom/secondary-top positions and pass both bands.',
      'Restoring a selected long cue reads from its earlier fragment. Only the generated20-second cues are qualified here; long/sparse-cue seek cost, other index layouts and live/streaming behavior need further coverage.',
      'One vdummy window-closed diagnostic occurs during normal public-probe teardown. No forced cleanup or abnormal child exit is used. Raw streams stay local.',
      'The MP4 held-frame receipt retains the old corrupt before pictures and independent FFmpeg reference. These scopes do not establish the full MP4 matrix, all beta surfaces, DPI/monitor/design review or a final matched package.'
    ])
(out/'checkpoint.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Fragmented MP4 seeking - 26 October 2026 nightly checkpoint

MP4 `df15e8ed` with Core `ccf72399` and GUI `4d754f60` starts decoding at the
resolved fragment and includes earlier packets for selected long subtitle cues.
The retained before case has corrupt pictures and clock drift; the intermediate
repair fixes video/time, and the final repair also restores the covering cue.

All twelve generated WASAPI seek/delay/Reset/resume cases pass, including four
rates, later cues, either/both/disabled captions and four other MP4 layouts. The
checked-in public-API regression helper also passes its separate dual-caption run.
The first dual-caption probe had an incorrect image-band assumption; later probes
use explicit placement and preserve that fixture correction.

The ordinary app qualifies middle-cue seek, +5s/Reset and playback to LAST. Three
native exports are pixel-identical with marker 799. Candidate and prior-plugin
comparison exit 0 with 602 modules, zero error diagnostics and unchanged guards.

Initial paused app captures still lack a caption before seeking, both before and
after this repair. The cause, native cold-export outcome and physical display
remain unqualified. Long/sparse-cue seek cost, other index/streaming layouts and
broader beta gates also remain open. This is a source nightly checkpoint, not a
beta or release-package declaration. [checkpoint.json](checkpoint.json) contains
exact identities, source copies, evidence and limits. Raw streams stay local.
Continue from [STATUS](../../../juxtopposed/STATUS.md).
''',encoding='utf-8',newline='\n')
print(str(out),len(artifacts),'artifacts',flush=True)
