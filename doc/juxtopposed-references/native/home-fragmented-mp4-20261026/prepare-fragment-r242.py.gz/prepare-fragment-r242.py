from pathlib import Path
from hashlib import sha256
import shutil,json
work=Path(__file__).resolve().parent
text=(work/'probe-fragment-r241.py').read_text(encoding='utf-8')
marker="encoded=[s.encode() for s in options]"
assert text.count(marker)==1
text=text.replace(marker,"options += ['--sub-primary-alignment=8','--secondary-sub-alignment=4','--secondary-sub-margin=0']\n"+marker)
target=work/'probe-fragment-r242.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
text=(work/'run-fragment-r241.py').read_text(encoding='utf-8').replace('probe-fragment-r241.py','probe-fragment-r242.py')
target=work/'run-fragment-r242.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
source=work/'mp4-media-r234/fragmented.mp4';out=work/'fragment-ui-media-r242';assert not out.exists();out.mkdir()
for name in ['Show.S01E01.mp4','Show.S01E02.mp4']:shutil.copyfile(source,out/name)
for name in ['external-fps.srt','Recovery.srt','Broken.srt']:shutil.copyfile(work/'timing-journey-media-r213'/name,out/name)
(out/'manifest.json').write_text(json.dumps(dict(sourceSha256=sha256(source.read_bytes()).hexdigest(),
    files={p.name:sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()},fullBetaAccepted=False),indent=2)+'\n')
text=(work/'run-ui-mp4-r233.py').read_text(encoding='utf-8').replace("work/'mp4-r233-bin/libmp4_plugin.dll'","work/'mp4-r240-bin/libmp4_plugin.dll'")
text=text.replace("media=work/'timing-journey-media-r213'","media=work/'fragment-ui-media-r242'")
target=work/'run-ui-fragment-r242.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared explicit caption-placement probes and ordinary fragment fixtures')
