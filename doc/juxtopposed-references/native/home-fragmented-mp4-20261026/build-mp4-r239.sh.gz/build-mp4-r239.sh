#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-mp4-r239.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-mp4-r239-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = ccf72399765f11541dbcb434a3b088a84127f1595af51755037fa03620dadaeb
test "$(sha256sum "$base/win64/modules/.libs/libmp4_plugin.dll" | cut -d' ' -f1)" = 4f6dcef631542dd5696007c54243f0d0cc0668d0584a00e20640fe9c2994cafc
test ! -e "$work/mp4-r239-bin"
make -C "$base/win64/modules" -j2 libmp4_plugin.la
mkdir "$work/mp4-r239-bin"
cp "$base/win64/modules/.libs/libmp4_plugin.dll" "$work/mp4-r239-bin/"
sha256sum "$work/mp4-r239-bin/libmp4_plugin.dll"
