#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-mp4-r240.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-mp4-r240-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = ccf72399765f11541dbcb434a3b088a84127f1595af51755037fa03620dadaeb
test "$(sha256sum "$base/win64/modules/.libs/libmp4_plugin.dll" | cut -d' ' -f1)" = dac23f7f8981d3a68bf1abca33c0f0eab36c6e18f3ab41c11b0773e382d676c6
test ! -e "$work/mp4-r240-bin"
make -C "$base/win64/modules" -j2 libmp4_plugin.la
mkdir "$work/mp4-r240-bin"
cp "$base/win64/modules/.libs/libmp4_plugin.dll" "$work/mp4-r240-bin/"
sha256sum "$work/mp4-r240-bin/libmp4_plugin.dll"
