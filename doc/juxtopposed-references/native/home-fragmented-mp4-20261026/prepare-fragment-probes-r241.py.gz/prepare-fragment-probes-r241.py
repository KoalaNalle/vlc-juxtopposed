from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'probe-embedded-delay-r231.py').read_text(encoding='utf-8')
marker="rate, audio = float(sys.argv[5]), sys.argv[6]"
assert text.count(marker)==1
text=text.replace(marker,marker+"\nseek_seconds, selection = float(sys.argv[7]), sys.argv[8]\nassert selection in ['eng','fin','both','none']\nassert 0 < seek_seconds < 54")
marker="select_track=bind('libvlc_media_player_select_track',None,C.c_void_p,C.POINTER(Track))"
assert text.count(marker)==1
text=text.replace(marker,marker+"\nselect_ids=bind('libvlc_media_player_select_tracks_by_ids',None,C.c_void_p,C.c_int,C.c_char_p)")
old="""    tracks(True)
    assert wait(lambda:any(t['selected'] and t['language'].lower() in ['en','eng'] for t in tracks()))
    assert seek(player,12_000_000,False)==0"""
new="""    languages = {'eng':['en','eng'], 'fin':['fi','fin'], 'both':['en','eng','fi','fin'], 'none':[]}[selection]
    chosen=[t['id'] for t in tracks() if t['language'].lower() in languages]
    assert len(chosen)==(2 if selection=='both' else 0 if selection=='none' else 1),tracks()
    result.update(seekSeconds=seek_seconds,selection=selection,selectedTrackIds=chosen)
    select_ids(player,2,','.join(chosen).encode())
    assert wait(lambda:{t['id'] for t in tracks() if t['selected']}==set(chosen))
    assert seek(player,int(seek_seconds*1_000_000),False)==0"""
assert text.count(old)==1;text=text.replace(old,new)
marker="    result['observations'].append(row);write()"
assert text.count(marker)==1
text=text.replace(marker,"""    if row['snapshotAvailable']:
        row['secondaryCaptionPixels']=sum(raw[y*stride+x*4]>160 and raw[y*stride+x*4+1]>160 and raw[y*stride+x*4+2]>160
            for y in range(im.height()//4) for x in range(im.width()))
    row['observedMonotonicSeconds']=time.monotonic()
"""+marker)
old="captions=all(r.get('captionPixels',0)>100 for r in result['observations']),"
new="captions=all((r.get('captionPixels',0)==0 and r.get('secondaryCaptionPixels',0)==0) if selection=='none' else (r.get('captionPixels',0)>100 and (selection!='both' or r.get('secondaryCaptionPixels',0)>100)) for r in result['observations']),"
assert text.count(old)==1;text=text.replace(old,new)
target=work/'probe-fragment-r241.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
text=(work/'run-mp4-matrix-r235.py').read_text(encoding='utf-8')
text=text.replace('revision,label,media_kind,rate,audio,mp4_revision=sys.argv[1:]',
                  'revision,label,media_kind,rate,audio,mp4_revision,seek_seconds,selection=sys.argv[1:]')
text=text.replace('probe-embedded-delay-r231.py','probe-fragment-r241.py')
old='str(subtitle),rate,audio]';assert text.count(old)==1;text=text.replace(old,'str(subtitle),rate,audio,seek_seconds,selection]')
target=work/'run-fragment-r241.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared real-track selection and later-cue fragment probes')
