from pathlib import Path
import json,subprocess,sys
work=Path(__file__).resolve().parent
revision=sys.argv[1];out=work/'fragment-matrix-r242';assert not out.exists();out.mkdir()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
record=dict(status='running',fullBetaAccepted=False,forcedCleanupUsed=False,cases=[])
def save():(out/'summary.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
specs=[('fragmented',str(rate),'32','eng') for rate in [.5,1,1.5,2]]
specs += [('fragmented','1.5','52','eng'),('fragmented','1.5','12','fin'),
          ('fragmented','1.5','32','both'),('fragmented','1.5','32','none')]
specs += [(name,'1.5','12','eng') for name in ['b0','b4','negative-cts','no-edit']]
save()
for index,(kind,rate,seek,selection) in enumerate(specs):
    label=f'fragment-matrix-{index+1:02}-r242'
    command=[sys.executable,str(work/'run-fragment-r242.py'),revision,label,kind,rate,'wasapi','r240',seek,selection]
    with (out/(label+'.txt')).open('wb') as stream:
        child=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        record.update(activeLabel=label,activeObserverPid=child.pid);save()
        try:code=child.wait(timeout=150)
        except subprocess.TimeoutExpired:
            record['status']='observer-timeout-inspect-child-before-continuing';save()
            raise SystemExit('Inspect owned matrix observer; no automatic cleanup/continuation')
    assert code==0,(label,code)
    result=read(work/label/'process.json')
    assert result['normalExit'] and all(result[k] for k in
        ['sourceInputsUnchanged','runtimeUnchanged','mediaUnchanged','subtitleUnchanged','workerUnchanged'])
    row=dict(label=label,kind=kind,rate=rate,seekSeconds=seek,selection=selection,
             passed=result['result']['passed'],checks=result['result']['checks'])
    record['cases'].append(row);save();print(json.dumps(row),flush=True)
record.update(status='terminal',allPassed=all(r['passed'] for r in record['cases']))
record.pop('activeObserverPid',None);record.pop('activeLabel',None);save()
print('All twelve cases passed:',record['allPassed'],flush=True)
