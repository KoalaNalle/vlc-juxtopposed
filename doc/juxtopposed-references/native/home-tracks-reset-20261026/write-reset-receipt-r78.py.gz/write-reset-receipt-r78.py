from pathlib import Path
from hashlib import sha256
import gzip,json
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
out=repo/'doc/juxtopposed-references/native/home-tracks-reset-20261026'
assert not out.exists()
before=read(work/'ui-r76/verification.json');after=read(work/'ui-r77/verification.json')
assert before['assertionObserved'] and before['forcedCleanupUsed'] and not before['normalExit']
assert after['normalExit'] and not after['forcedCleanupUsed'] and not after['diagnostics']
assert all(after[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','extraFixturesUnchanged','producerUnchanged','pluginCacheUnchanged'])
native=read(work/'native-after-r77/verification.json')
assert native['normalExit'] and len(native['functions'])==16
assert all(i['type']=='pass' for f in native['functions'] for i in f['incidents'])
navbefore=read(work/'navigation-before-r75/verification.json');navafter=read(work/'navigation-after-r76/verification.json')
assert navbefore['exitCode']==1 and navafter['normalExit']
reset=(work/'ui-r77/primary-reset-after-legacy-tree.txt').read_text(encoding='utf-8')
assert 'Primary subtitle delay Value: 0' in reset and 'Secondary subtitle delay Value: -9000' in reset
signed=(work/'ui-r77/signed-estimates-tree.txt').read_text(encoding='utf-8')
assert 'Primary subtitle delay Value: -5517' in signed and 'Secondary subtitle delay Value: 3621' in signed
audio=(work/'ui-r77/audio-estimate-tree.txt').read_text(encoding='utf-8')
assert 'Value: 4338 ' in audio
out.mkdir();artifacts=[]
def retain(p,name=None):
    raw=p.read_bytes();target=out/((name or p.relative_to(work).as_posix())+'.gz')
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(raw,mtime=0))
    artifacts.append(dict(path=target.relative_to(out).as_posix(),sha256=digest(target),rawSha256=sha256(raw).hexdigest()))
for folder in ['ui-r76','ui-r77']:
    for name in ['verification.json','launch.json']:
        retain(work/folder/name)
    for p in sorted((work/folder).glob('*.jpg')):retain(p)
    for p in sorted((work/folder).glob('*tree.txt')):retain(p)
for name in ['ui-r76/observations-r77.json','ui-r76/reset-debugger.txt',
 'native-after-r77/verification.json','native-after-r77/results.xml',
 'navigation-before-r75/verification.json','navigation-before-r75/results.xml',
 'navigation-after-r76/verification.json','navigation-after-r76/results.xml',
 'inputs-r75.json','inputs-r76.json','inputs-r77.json','build-r77.sh','build-r77-exit.txt',
 'run-ui-ordinary-r76.py','run-ui-ordinary-r77.py','run-native-r60.py','run-navigation-r75.py',
 'record-ui-r76-r77.py','write-reset-receipt-r78.py']:
    retain(work/name)
for rev,label in [('r76','before'),('r77','after')]:
    manifest=read(work/f'inputs-{rev}.json')
    for key in ['modules/gui/qt/player/player_controller.cpp','modules/gui/qt/tests/test_player_subtitle_delay.cpp',
                'modules/gui/qt/player/qml/PlaybackSpeed.qml','modules/gui/qt/tests/test_tracks_cancel_navigation.cpp']:
        p=Path(manifest['sourceCopies'][key]);assert digest(p)==manifest['files'][key]
        retain(p,'sources/'+label+'/'+key)
record=dict(status='scoped-checkpoint-session-continues',fullBetaAccepted=False,
    runtimeSha256=after['runtimeSha256'],nativeFunctions=16,artifacts=artifacts,
    primaryReset='At paused 12s/main rate 1.5x with external primary, Finnish secondary and FPS50, primary +5000ms and secondary -9000ms render distinct cues. After legacy editor open/close, primary Reset returns to 0, secondary remains -9000, and external caption changes FIRST to MIDDLE without asserting.',
    remainingResets='Secondary and FPS resets return to 0, primary/secondary signed estimates are -5517/+3621ms, audio estimate +4338ms then Reset 0. Reopened legacy editor displays audio/primary/secondary 0 and FPS0. Normal Quit and all guards pass; no diagnostic errors.',
    speedEscape='Actual selected 1.5x radio Escape returns to track list on GUI05ab1a15. Before native control fails the new preset case; after all eleven data rows pass. The ordinary speed observation occurred before an independent reset assertion; that whole run is not accepted.',
    failure='UI-r76 asserts in vlc_mutex_trylock. Recorded stack maps addSubtitleDelay -> SyncWidget value update -> SyncControls::advanceSubs -> getInput -> player lock. Noninvasive stack capture stalled on its last thread and was stopped. Abort did not close the failed test; its verified PID alone was stopped. The before run has forcedCleanupUsed=true and no normal-exit acceptance.',
    repair='Relative audio/subtitle delay changes reject invalid estimator values and missing/stale items; only queued native callbacks publish the resulting delay after unlocking. No direct delta notification remains.',
    limits=['Marker clicks establish signed edit and feedback behavior, not perceptual audio synchronization.','This receipt does not yet isolate rate/seek mark cancellation while the synchronization subpage remains alive.','No full W1, 32-surface visual, DPI, package or beta acceptance.'])
(out/'checkpoint.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Track resets and Escape - 26 October 2026

Regular Core `883f7e51` / GUI `979fa7b5` passes the repaired ordinary reset
journey and sixteen native subtitle test functions. This is a scoped checkpoint;
the beta session continues.

The preceding ordinary run exposed a primary Reset assertion after the older
synchronization editor had been opened and closed. A relative subtitle edit
emitted its delta while holding the player lock. The hidden older editor then
updated its widget and tried to query the same player. The captured native stack
confirms that path. Audio used the same notification pattern. Relative edits now
ignore empty estimates/missing or stale items and let the queued native callback
publish the final delay after unlocking.

The exact ordinary sequence passes after repair at paused 12 seconds and main
rate 1.5x: external primary plus Finnish secondary, FPS 50, primary +5000 ms and
secondary -9000 ms. Primary Reset reaches zero, preserves the secondary override
and redraws the external caption. Secondary and automatic-FPS resets also pass.
Primary/secondary estimates apply -5517/+3621 ms independently. Audio applies
+4338 ms then resets to zero. Reopened legacy controls display matching zero
values. These marker clicks verify edits and feedback, not perceptual AV sync.
Normal Quit exits zero with unchanged inputs/binaries/fixtures/cache, 602 modules
and no error diagnostics. The native regression separately checks signed exact
units, final-value notifications and observers that reacquire the normal lock.

The prior failed run is preserved honestly, including its assertion image and
stack. Its noninvasive debugger stalled on the last thread and was stopped.
The observed Abort click did not close VLC; only the verified failed test PID
was then stopped. This run has forced-cleanup and failed-exit flags and is never
accepted as a complete journey.

A separate radio-delegate parent binding repairs Escape from selected playback
speed. The native before control fails that new case; the after control passes
all eleven data rows. Actual Escape after selecting 1.5x returns to the track
list with the rate retained. That ordinary observation preceded the unrelated
reset failure, so it does not turn the earlier whole run into a pass.

[checkpoint.json](checkpoint.json) records exact identities, artifacts and
remaining limits. Gzip retains original bytes; only generated media was used.
Continue from [STATUS](../../../juxtopposed/STATUS.md).
''',encoding='utf-8',newline='\n')
print(str(out),len(artifacts),flush=True)
