from pathlib import Path
from hashlib import sha256
import ctypes,json,shutil,subprocess,sys,xml.etree.ElementTree as ET
work=Path(__file__).resolve().parent;repo=work.parents[1]
revision,label=sys.argv[1:]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
manifest=work/f'inputs-{revision}.json';inputs=read(manifest)
assert all(digest(repo/p)==h and digest(Path(inputs['sourceCopies'][p]))==h for p,h in inputs['files'].items())
out=work/label;assert not out.exists();out.mkdir()
sys.path.insert(0,str(repo/'test/libvlc'))
from native_http_runtime import stage_runtime,environment
base=work/'ui-r73/runtime';expected=read(base.parent/'verification.json')['runtimeSha256']
assert all(digest(base/p)==h for p,h in expected.items())
runtime=out/'runtime';stage_runtime(base,runtime)
program='test_tracks_cancel_navigation.exe';shutil.copyfile(work/'navigation-r75-bin'/program,runtime/program)
pages=out/'pages';pages.mkdir();page_hashes={}
for name in ['TracksListPage.qml','TracksPage.qml','TracksPageSubtitle.qml','TracksPageAudio.qml','PlaybackSpeed.qml','TracksPageSpeed.qml']:
    key='modules/gui/qt/player/qml/'+name;source=Path(inputs['sourceCopies'][key])
    assert digest(source)==inputs['files'][key];shutil.copyfile(source,pages/name);page_hashes[name]=digest(source)
env=environment(runtime,out);env.pop('VLC_PLUGIN_PATH',None)
env.update(QT_QPA_PLATFORM='offscreen',VLC_TRACKS_SOURCE_DIR=str(pages))
record=dict(status='starting',sourceManifestSha256=digest(manifest),testExecutableSha256=digest(runtime/program),
    producerSha256=digest(Path(__file__)),qmlSha256=page_hashes,privateNavigationFixture=True,
    ordinaryGuiAccepted=False,fullBetaAccepted=False,forcedCleanupUsed=False)
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.SetErrorMode.argtypes=[ctypes.c_uint];kernel.SetErrorMode.restype=ctypes.c_uint
previous=kernel.SetErrorMode(0x8003)
try:
    with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
        child=subprocess.Popen([str(runtime/program),'-o',str(out/'results.xml')+',xml'],cwd=runtime,env=env,
            stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        record.update(status='running',pid=child.pid);write(out/'verification.json',record)
        print(label,'PID',child.pid,flush=True)
        try:code=child.wait(timeout=90)
        except subprocess.TimeoutExpired:
            record['status']='observation-timeout-process-left-running';write(out/'verification.json',record)
            raise SystemExit('Inspect owned PID; no automatic cleanup/restart')
finally:kernel.SetErrorMode(previous)
functions=[]
if (out/'results.xml').exists():
    tree=ET.parse(out/'results.xml').getroot()
    functions=[dict(name=f.get('name'),incidents=[dict(type=i.get('type'),tag=i.findtext('DataTag',''),
        description=i.findtext('Description','')) for i in f.findall('Incident')]) for f in tree.findall('TestFunction')]
record.update(status='terminal',exitCode=code,normalExit=code==0,functions=functions,
    sourceInputsUnchanged=all(digest(repo/p)==h for p,h in inputs['files'].items()),
    runtimeUnchanged=all(digest(base/p)==h and digest(runtime/p)==h for p,h in expected.items()),
    frozenQmlUnchanged=all(digest(pages/p)==h for p,h in page_hashes.items()),
    producerUnchanged=digest(Path(__file__))==record['producerSha256'])
write(out/'verification.json',record)
print(json.dumps({p:record[p] for p in ['exitCode','sourceInputsUnchanged','frozenQmlUnchanged','functions']}),flush=True)
raise SystemExit(0 if record['normalExit'] else code or 1)
