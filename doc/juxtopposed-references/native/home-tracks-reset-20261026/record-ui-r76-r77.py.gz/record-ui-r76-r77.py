from pathlib import Path
import json, re
work = Path(__file__).resolve().parent
out = work / 'ui-r76'
write = lambda p, v: p.write_text(json.dumps(v, indent=2)+'\n', encoding='utf-8', newline='\n')
verification = json.loads((out/'verification.json').read_text(encoding='utf-8'))
assert verification['pid'] == 25952 and verification['exitCode'] == 4294967295
verification.update(forcedCleanupUsed=True, assertionObserved=True,
    cleanupReason='Primary Reset asserted after legacy synchronization editor had been opened and closed. Saved screenshots and noninvasive debugger stack. Debugger stalled on its last stack and was stopped; the failed VLC did not close after the observed Abort click, then only its verified PID was stopped.',
    ordinaryGuiAccepted=False)
write(out/'verification.json', verification)
symbols=[]
for line in (out/'qt-symbols.txt').read_text(encoding='utf-8-sig').splitlines():
    match=re.match(r'([0-9a-f]+) . (.*)', line)
    if match: symbols.append((int(match[1],16),match[2]))
mapped=[]
for offset in [0x18dbeeb,0x662270,0x3e1eff,0x3e2055,0x922028,0xf4ef41]:
    address=0x140000000+offset
    base,name=max(s for s in symbols if s[0] <= address)
    mapped.append(dict(moduleOffset=hex(offset),symbol=name,symbolOffset=hex(address-base)))
write(out/'observations-r77.json', dict(
    ordinaryJourneyTerminal='failed-primary-reset-assertion', normalExit=False,
    fullBetaAccepted=False, runtimeSha256=verification['runtimeSha256'],
    sourceManifestSha256=verification['sourceManifestSha256'],
    observations=[
        'Selected 1.5x speed radio then actual Escape returned to track list; selected rate retained.',
        'At paused media time 12s and main rate 1.5x, external FPS 50 changed FIRST to MIDDLE while video remained paused.',
        'Opened legacy synchronization editor, observed 50 fps, entered 29.97 there, closed it; redesigned setting displayed 29.970 and external caption returned to FIRST.',
        'Enabled Select multiple, selected external Track 3 first then embedded Finnish Track 2; both checks and captions present.',
        'Synchronization-page FPS Reset returned 29.97 to 0 after legacy editor had existed; no clamping to 1.',
        'With FPS 50, primary +5000ms changed only external MIDDLE to FIRST. Secondary still inherited category +5000ms until an explicit edit.',
        'Rejected -20000ms outside the offered -10000..10000 range; -9000ms applied. Secondary became Finnish MIDDLE while primary stayed external FIRST and +5000ms.',
        'Primary Reset then showed !vlc_mutex_held(mtx) in threads.c:134. Actual default/reset/shutdown journey did not pass.'
    ], stackMapping=mapped, evidenceScope='Ordinary GUI observations with a later failed reset and forced cleanup, never a successful whole-run acceptance.'))
print(json.dumps(dict(correctedCleanup=True, mappedStack=mapped)),flush=True)
