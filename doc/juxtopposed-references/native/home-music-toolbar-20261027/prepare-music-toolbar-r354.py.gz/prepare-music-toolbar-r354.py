from pathlib import Path
work=Path(__file__).resolve().parent
source=(work/'run-ui-music-default-r352.py').read_text(encoding='utf-8')
source=source.replace('ordinary-r349-bin','ordinary-r354-bin').replace('GUI349','GUI354')
start=source.index("    audio=dict(columns=[[ids[k] for k in ['JUXTO_THUMBNAIL'")
end=source.index('\nunchanged =',start)
source=source[:start]+"    audio=dict(columns=[[ids[k] for k in ['PREVIOUS_BUTTON','JUXTO_BACKWARD_15','PLAY_BUTTON','JUXTO_FORWARD_15','NEXT_BUTTON']],[],[ids[k] for k in ['VOLUME','JUXTO_AUDIO_TRACKS','PLAYLIST_BUTTON']]], timelineAbove=False))"+source[end:]
(work/'run-ui-music-toolbar-r354.py').write_text(source,encoding='utf-8',newline='\n')
source=(work/'build-collection-sort-r344.sh').read_text(encoding='utf-8').replace('r344','r354')
source=source.replace('owned-collection-sort','owned-music-toolbar').replace('owned-native-collection-sort','owned-native-music-toolbar')
source=source.replace('build-collection-sort','build-music-toolbar').replace('native-collections-r354-bin','native-layout-r354-bin')
source=source.replace('tests/native_library/music-queries.mk','tests/native_library/profile-layout.mk')
source=source.replace('MUSIC_QUERIES_OUT=', 'PROPOSAL_OUT=').replace('music-queries-native','player-profile-layout-native')
source=source.replace('test_qt_music_library_queries.exe','test_qt_player_profile_layout.exe')
(work/'build-music-toolbar-r354.sh').write_text(source,encoding='utf-8',newline='\n')
source=(work/'run-ml-query-races-r342.py').read_text(encoding='utf-8')
source=source.replace('test_qt_ml_play_request.exe','test_qt_player_profile_layout.exe').replace('native-query-r342-bin','native-layout-r354-bin')
source=source.replace("base=work/'ui-tooltip-fixed-r337/runtime'", "base=work/'ui-music-sidebar-fixed-r349/runtime'")
start=source.index("    scope='")
end=source.index("')\nkernel=",start)
source=source[:start]+"    scope='Production native profile layout defaults, tile descriptors, saved alternative layout preservation, draft reset/cancel and existing mutations. This is not ordinary seeking or complete visual acceptance."+source[end:]
source=source.replace("assert len(cases)==9 and record['qtestCompleted']", "assert len(cases)>=9 and record['qtestCompleted']")
(work/'run-native-music-toolbar-r354.py').write_text(source,encoding='utf-8',newline='\n')
source=(work/'freeze-music-sidebar-r349.py').read_text(encoding='utf-8')
anchor="names.add('modules/control/globalhotkeys/win32.c')"
source=source.replace(anchor,anchor+"\nnames.update(['modules/gui/qt/maininterface/player_profile_layout.cpp','modules/gui/qt/maininterface/player_profile_layout.hpp','modules/gui/qt/tests/test_player_profile_layout.cpp','modules/gui/qt/tests/native_library/profile-layout.mk','modules/gui/qt/tests/test_juxtopposed_music_toolbar.py'])")
(work/'freeze-music-toolbar-r354.py').write_text(source,encoding='utf-8',newline='\n')
