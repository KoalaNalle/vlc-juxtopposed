from pathlib import Path
from hashlib import sha256
import ctypes,json,shutil,subprocess,sys,xml.etree.ElementTree as ET
work=Path(__file__).resolve().parent;repo=work.parents[1]
revision,label,mode=sys.argv[1:];assert mode=='fixed'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
manifest=work/f'inputs-{revision}.json';m=read(manifest)
assert all(digest(repo/p)==h and digest(Path(m['sourceCopies'][p]))==h for p,h in m['files'].items())
base=work/'ui-music-sidebar-fixed-r349/runtime';original=read(base.parent/'verification.json')['runtimeSha256']
assert all(digest(base/p)==h for p,h in original.items())
out=work/label;assert not out.exists();out.mkdir();shutil.copyfile(Path(__file__),out/'producer.py')
sys.path.insert(0,str(repo/'test/libvlc'))
from native_http_runtime import stage_runtime,environment
runtime=out/'runtime';stage_runtime(base,runtime)
program=runtime/'test_qt_player_profile_layout.exe';shutil.copyfile(work/'native-layout-r357-bin'/program.name,program)
support=runtime/'libssp-0.dll'
if support.exists():support.unlink()
shutil.copyfile(work/'ordinary-r282-bin/libssp-0.dll',support)
expected={name:digest(runtime/name) for name in original}
expected['plugins/misc/libmedialibrary_plugin.dll']=digest(runtime/'plugins/misc/libmedialibrary_plugin.dll')
expected[program.name]=digest(program);expected[support.name]=digest(support)
music=work/'music-media-r273';fixtures={p.relative_to(music).as_posix():digest(p) for p in music.rglob('*') if p.is_file()}
env=environment(runtime,out);env.pop('VLC_PLUGIN_PATH',None);env['VLC_MUSIC_FIXTURE_DIR']=str(music)
if mode=='legacy':env['VLC_MUSIC_OLD_TRACK_CRITERION']='1'
cache=out/'cache';cache.mkdir()
with (cache/'stdout.txt').open('wb') as stdout,(cache/'stderr.txt').open('wb') as stderr:
    child=subprocess.Popen([str(runtime/'vlc-cache-gen.exe'),str(runtime/'plugins')],cwd=runtime,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    write(cache/'process.json',dict(status='running',pid=child.pid))
    try:code=child.wait(timeout=60)
    except subprocess.TimeoutExpired:raise SystemExit('Cache process left running; inspect owned PID')
assert code==0;write(cache/'process.json',dict(status='terminal',exitCode=code))
cachehash=digest(runtime/'plugins/plugins.dat')
record=dict(status='starting',mode=mode,fullBetaAccepted=False,forcedCleanupUsed=False,
    sourceManifestSha256=digest(manifest),producerSha256=digest(Path(__file__)),
    runtimeSha256=expected,fixtureSha256=fixtures,pluginCacheSha256=cachehash,
    scope='Production native profile layout defaults, tile descriptors, saved alternative layout preservation, draft reset/cancel and existing mutations. This is not ordinary seeking or complete visual acceptance.')
kernel=ctypes.WinDLL('kernel32',use_last_error=True);kernel.SetErrorMode.argtypes=[ctypes.c_uint];kernel.SetErrorMode.restype=ctypes.c_uint
previous=kernel.SetErrorMode(0x8003)
try:
    with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
        child=subprocess.Popen([str(program),'-o',str(out/'results.xml')+',xunitxml','-o','-,txt'],cwd=runtime,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        record.update(status='running',pid=child.pid);write(out/'verification.json',record)
        try:code=child.wait(timeout=180)
        except subprocess.TimeoutExpired:
            record.update(status='observer-timeout-process-left-running');write(out/'verification.json',record)
            raise SystemExit('Inspect owned native PID; no automatic cleanup/restart')
finally:kernel.SetErrorMode(previous)
record.update(status='terminal',exitCode=code,normalExit=code==0)
write(out/'verification.json',record)
if not (out/'results.xml').is_file():
    record['testReportMissing']=True;write(out/'verification.json',record)
    raise SystemExit('Native child ended before a test report; inspect terminal record')
root=ET.parse(out/'results.xml').getroot();cases=root.findall('.//testcase')
failures=[dict(name=c.attrib.get('name'),message=c.find('failure').attrib) for c in cases if c.find('failure') is not None]
record.update(status='terminal',exitCode=code,normalExit=code==0,qtestCompleted=any(c.attrib.get('name')=='cleanupTestCase' for c in cases),
    cases=len(cases),failures=failures,
    sourceInputsUnchanged=all(digest(repo/p)==h for p,h in m['files'].items()),
    runtimeUnchanged=all(digest(runtime/p)==h for p,h in expected.items()),
    baseRuntimeUnchanged=all(digest(base/p)==h for p,h in original.items()),
    fixturesUnchanged=all(digest(music/p)==h for p,h in fixtures.items()),
    producerUnchanged=digest(Path(__file__))==record['producerSha256'],pluginCacheUnchanged=digest(runtime/'plugins/plugins.dat')==cachehash)
write(out/'verification.json',record)
assert len(cases)>=9 and record['qtestCompleted']
assert code==(1 if mode=='legacy' else 0)
assert [f['name'] for f in failures]==(['mediaTrackOrderDistinctFromCollectionCount'] if mode=='legacy' else [])
assert all(record[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','baseRuntimeUnchanged','fixturesUnchanged','producerUnchanged','pluginCacheUnchanged'])
print(json.dumps(dict(exitCode=code,mode=mode,cases=len(cases),failures=failures,guards=True)),flush=True)
