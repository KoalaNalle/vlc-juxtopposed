import QtQuick
import QtQuick.Controls.Basic
import "file:///C:/Modding/vlc-juxtopposed/modules/gui/qt/player/qml" as Player
import "file:///C:/Modding/vlc-juxtopposed/modules/gui/qt/dialogs/dialogs/qml" as Dialogs
Item {
 id: root; width: 1280; height: 900
 property alias dialog: customizer
 property alias service: service
 property alias layout: layout
 property int actions: 0
 property bool nativeChecked: false
 Player.JuxtopposedLayoutRow {
  id: stateRow; visible:!customizer.visible; anchors.bottom:parent.bottom; width:parent.width;height:40
  columns:[[94,95],[],[]]; assetBase:"file:///C:/Modding/vlc-juxtopposed/modules/gui/qt/pixmaps/juxtopposed/"
  describe: id=>id===95?({name:"Owned Playlist Name",kind:"metadata",key:"playlist"}):({name:"Owned Favorite",kind:"button",glyph:"x",fontFamily:"Inter"})
  state: id=>({enabled:true,checked:root.nativeChecked})
  metadata: ({playlist:"Owned <mix> & Friends"})
  onActivated: root.actions++
 }
 function findName(item,name) {
  if(item.objectName===name)return item
  for(const child of item.children??[]) {const found=findName(child,name);if(found)return found}
  return null
 }
 QtObject {
  id: layout
  property bool editing: false
  property string lastError: ""
  property var draft: ({video: {columns: [[0],[],[1]], timelineAbove: false}, audio: {columns: [[2],[],[]], timelineAbove: true}})
  property var current: ({video: {columns: [[0],[],[1]], timelineAbove: false}, audio: {columns: [[2],[],[]], timelineAbove: true}})
  property var palette: Array.from({length:31}, function(_,n) {return ({id:n,name:"Owned tile " + n})})

  function cancelEdit() {editing=false}
  function tileInfo(id) {return ({name: "Owned tile " + id, kind: "button"})}
  function update(next) {draft=next}
  function insertTile(player,column,index,id) {const next=JSON.parse(JSON.stringify(draft)); next[player===0?"video":"audio"].columns[column].splice(index,0,id); update(next); return true}
  function moveTile(player,c,i,to,n) {const next=JSON.parse(JSON.stringify(draft)); const columns=next[player===0?"video":"audio"].columns;
   const id=columns[c].splice(i,1)[0];columns[to].splice(c===to&&n>i?n-1:n,0,id);update(next);return true}
  function removeTile(player,c,i) {const next=JSON.parse(JSON.stringify(draft));next[player===0?"video":"audio"].columns[c].splice(i,1);update(next);return true}
  function setTimelineAbove(player,above) {const next=JSON.parse(JSON.stringify(draft));next[player===0?"video":"audio"].timelineAbove=above;update(next);return true}
 }
 QtObject {
  id: service
  property var layout: root.layout
  property bool busy: false
  property bool available: true
  property string lastError: ""
  property bool fail: false
  property int saves: 0
  function beginLayoutEdit() {layout.draft=JSON.parse(JSON.stringify(layout.current));layout.editing=true;return true}
  function saveLayoutDraft() {saves++; if(fail){lastError="Owned save failure. Retry.";return false}layout.current=JSON.parse(JSON.stringify(layout.draft));layout.editing=false;lastError="";return true}
 }
 Button {id: opener; text: "Open"}
 Dialogs.JuxtopposedPlayerCustomizer {
  id: customizer; parent: root; controller: service; assetBase: "file:///C:/Modding/vlc-juxtopposed/modules/gui/qt/pixmaps/juxtopposed/"
  previewComponent: Component {
   Player.JuxtopposedPlaybackBar {
    previewOnly:true; editing:true; controlLayout:customizer.draftData
    describeTile:id=>layout.tileInfo(id); tileState:id=>({enabled:true,glyph:"P",fontFamily:"Inter"});assetBase:"file:///C:/Modding/vlc-juxtopposed/modules/gui/qt/pixmaps/juxtopposed/"
    onPlayPauseRequested:root.actions++
    onTileRequested:root.actions++
    onLayoutTilePressed:(column,index,tile,item,point)=>customizer.beginDrag(column,index,tile,item,point)
    onLayoutTileMoved:(item,point)=>customizer.moveDrag(item,point)
    onLayoutTileReleased:(item,point)=>customizer.endDrag(item,point)
    onLayoutSelectionRequested:(column,index)=>customizer.selection=({column:column,index:index})
    onLayoutRemovalRequested:(column,index)=>{customizer.selection=({column:column,index:index});customizer.removeSelection()}
   }
  }
 }
}