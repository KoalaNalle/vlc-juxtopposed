#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
ordinary="$base/owned-music-toolbar-20261027-r354"
native="$base/owned-native-music-toolbar-20261027-r354"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-music-toolbar-r354.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-music-toolbar-r354-exit.txt"; exit "$code"' EXIT
test ! -e "$ordinary"
test ! -e "$native"
test ! -e "$work/ordinary-r354-bin"
test ! -e "$work/native-layout-r354-bin"
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = fdfcfcd599588512bb7f3a51e46305b7b0d947b47387dd205851feb45f032b46
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/modules/gui/qt/tests/native_library/profile-layout.mk" -j2 PROPOSAL_OUT="$native" player-profile-layout-native
mkdir "$work/native-layout-r354-bin"
cp "$native/.libs/test_qt_player_profile_layout.exe" "$work/native-layout-r354-bin/"
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/build-windows/beta-subtitle-sync-20261025/ordinary.mk" -j2 QA_OUT="$ordinary" owned-ordinary-subtitle-sync
mkdir "$work/ordinary-r354-bin"
cp "$ordinary/.libs/libqt_plugin.dll" "$work/ordinary-r354-bin/"
sha256sum "$work/ordinary-r354-bin/"* "$work/native-layout-r354-bin/"*
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = fdfcfcd599588512bb7f3a51e46305b7b0d947b47387dd205851feb45f032b46
