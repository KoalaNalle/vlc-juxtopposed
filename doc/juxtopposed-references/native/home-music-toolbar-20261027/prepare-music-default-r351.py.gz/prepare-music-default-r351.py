from pathlib import Path
work=Path(__file__).resolve().parent
source=(work/'run-ui-music-sidebar-fixed-r349.py').read_text(encoding='utf-8')
old="""for player in ['video','audio']:
    selected['snapshot']['layout'][player] = dict(columns=[transport, center, right], timelineAbove=True)"""
new="""# Preserve the copied catalogue's authored default layout, rather than the
# preceding customizer test's prepared two-row layout. Check the exact defaults.
assert selected['snapshot']['layout'] == dict(version=1,
    video=dict(columns=[[ids[k] for k in ['PREVIOUS_BUTTON','PLAY_BUTTON','NEXT_BUTTON']],[],right], timelineAbove=False),
    audio=dict(columns=[[ids[k] for k in ['JUXTO_THUMBNAIL','JUXTO_FILE_NAME','JUXTO_ARTIST_NAME']],
       [ids[k] for k in ['RANDOM_BUTTON','PREVIOUS_BUTTON','PLAY_BUTTON','NEXT_BUTTON','LOOP_BUTTON']],
       [ids[k] for k in ['VOLUME','JUXTO_AUDIO_TRACKS','EXTENDED_BUTTON','PLAYLIST_BUTTON']]], timelineAbove=True))"""
assert source.count(old)==1
source=source.replace(old,new).replace("tileNames=extras[variant]", "tileNames=[], preservedAuthoredDefaultLayout=True")
(work/'run-ui-music-default-r351.py').write_text(source,encoding='utf-8',newline='\n')
