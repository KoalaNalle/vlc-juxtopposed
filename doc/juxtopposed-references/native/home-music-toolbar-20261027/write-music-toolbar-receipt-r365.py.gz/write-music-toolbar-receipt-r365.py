from pathlib import Path
from hashlib import sha256
import gzip,json,re
from PySide6.QtCore import QSettings
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
runs=['ui-music-default-r352','ui-music-toolbar-fixed-r360','ui-music-toolbar-cold-r361','ui-music-alternative-r362','ui-music-theme-r363','ui-music-theme-cold-r364']
records={name:read(work/name/'verification.json') for name in runs}
for record in records.values():
    assert record['normalExit'] and record['moduleCounts']==['602'] and not record['diagnostics']
    assert all(v for k,v in record.items() if k.endswith('Unchanged'))
native=read(work/'native-music-toolbar-r357/verification.json')
interim=read(work/'native-music-toolbar-r356/verification.json')
assert native['normalExit'] and native['cases']==12 and native['failures']==[]
assert interim['qtestCompleted'] and [f['name'] for f in interim['failures']]==['resetIsDraftOnlyAndReopenStartsFromAcceptedLayout','savedAlternativeAudioLayoutRemainsUnchanged']
assert all(v for k,v in native.items() if k.endswith('Unchanged'))
component=read(work/'component-music-toolbar-r356/verification.json')
customizer=read(work/'component-customizer-music-r355/verification.json')
assert len(component['checks'])==4 and not component['diagnostics']
assert len(customizer['checks'])==25 and not customizer['diagnostics']
for name in ['ui-music-toolbar-cold-r361','ui-music-theme-cold-r364']:
    fixture=read(work/name/'layout-fixture.json')
    assert fixture['catalogBeforeSha256']==fixture['catalogAfterSha256']
def progress(run,name):
    tree=read(work/run/'observations'/name)['accessibility']['tree']
    return float(re.search(r'Progress Value: ([0-9.eE+-]+)',tree)[1])
assert progress(runs[1],'03-pointer-forward-paused15.json')==0.25
assert progress(runs[1],'04-return-forward-paused30.json')==0.5
assert progress(runs[1],'05-pointer-backward-settled15.json')==0.25
assert progress(runs[1],'06-space-backward-paused-start.json')==1/60000000
assert progress('ui-music-theme-r363','04-light-forward-paused15.json')==progress('ui-music-theme-r363','07-system-blue-music-paused15.json')==0.25
theme={}
for run in ['ui-music-theme-r363','ui-music-theme-cold-r364']:
    settings=QSettings(str(work/run/'settings-after.ini'),QSettings.IniFormat);settings.setFallbacksEnabled(False)
    theme[run]={key:settings.value(key) for key in settings.allKeys() if 'accent' in key.lower() or key.endswith('color-scheme-index')}
assert theme['ui-music-theme-r363']==theme['ui-music-theme-cold-r364']
assets=read(work/'music-toolbar-asset-identities-r358.json');renders=read(work/'music-toolbar-asset-renders-r359.json')
assert all(a['originalDimensions']==a['localDimensions'] for a in assets)
assert all(a['xmlTreeEqual'] or any(r['asset']==a['sourceAsset'] and r['differentPixels']==0 for r in renders) for a in assets)
out=repo/'doc/juxtopposed-references/native/home-music-toolbar-20261027';assert not out.exists();out.mkdir();artifacts=[]
def retain(p):
    name=p.relative_to(work).as_posix()+'.gz';dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True)
    raw=p.read_bytes();dest.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(dest.read_bytes())==raw
    artifacts.append(dict(path=name,sha256=digest(dest),rawSha256=sha256(raw).hexdigest()))
for run in runs:
    for name in ['verification.json','producer.py','launch.json','staging.json','layout-fixture.json']:retain(work/run/name)
    for p in sorted((work/run/'observations').glob('*')):
        if p.suffix in ['.png','.json']:retain(p)
for run in ['native-music-toolbar-r356','native-music-toolbar-r357']:
    for name in ['verification.json','producer.py','results.xml','stdout.txt','stderr.txt']:retain(work/run/name)
for run in ['component-music-toolbar-r355','component-music-toolbar-r356','component-customizer-music-r355']:
    retain(work/run/'verification.json')
    for p in sorted((work/run).glob('*.png')):retain(p)
    if (work/run/'Scene.qml').exists():retain(work/run/'Scene.qml')
for p in sorted((work/'figma-music-toolbar-assets-r357').glob('*.svg')):retain(p)
for name in ['ui-music-default-r351/setup-failure.json','prepare-music-default-r351.py','run-ui-music-default-r351.py','prepare-music-default-r352.py','run-ui-music-default-r352.py',
    'prepare-music-toolbar-r354.py','prepare-music-toolbar-r357.py','prepare-music-toolbar-r360.py',
    'build-music-toolbar-r354.sh','build-music-toolbar-r354-exit.txt','build-music-toolbar-r357.sh','build-music-toolbar-r357-exit.txt',
    'run-ui-music-toolbar-r357.py','run-ui-music-toolbar-cold-r360.py','run-ui-music-alternative-r360.py','run-native-music-toolbar-r354.py','run-native-music-toolbar-r357.py',
    'freeze-music-toolbar-r354.py','freeze-music-toolbar-r360.py','inputs-r352.json','inputs-r356.json','inputs-r357.json','inputs-r360.json',
    'check-music-toolbar-assets-r358.py','render-check-music-assets-r359.py','music-toolbar-asset-identities-r358.json','music-toolbar-asset-renders-r359.json','music-toolbar-design-context-r365.json',
    'write-music-toolbar-receipt-r365.py']:retain(work/name)
sources=['modules/gui/qt/assets.qrc','modules/gui/qt/maininterface/player_profile_layout.cpp','modules/gui/qt/maininterface/player_profile_layout.hpp','modules/gui/qt/player/qml/JuxtopposedLayoutRow.qml','modules/gui/qt/pixmaps/juxtopposed/skip-15-arrow.svg','modules/gui/qt/tests/test_player_profile_layout.cpp','modules/gui/qt/tests/test_juxtopposed_music_toolbar.py']
checkpoint=dict(status='passed-scoped-canonical-music-toolbar-and-preserved-layouts',fullBetaAccepted=False,
    runtimeSha256=records[runs[1]]['runtimeSha256'],sourceSha256={name:digest(repo/name) for name in sources},
    nativeCases=12,componentGroups=4,customizerChecks=25,selectedThemeValues=theme,
    observations=[
      'The ordinary GUI349/default-layout baseline has a two-row music bar with metadata/shuffle/repeat. The canonical Figma music frames instead show54px inline controls with previous/back15/play/forward15/next. The19:28 alternative remains a valid saved customization.',
      'Fresh/reset audio defaults now match the canonical control order. Existing saved audio layouts are not migrated or overwritten. Native reset reads the default timeline choices; the intermediate two native reset failures are retained and the same12-case suite passes after repair.',
      'GUI357 ordinary controls perform paused forward15 to0.25, Return-forward to0.5, pointer-back to0.25 and Space-back to1microsecond/60seconds. Playback stays paused. Audio tracks/queue open and dismiss without moving that held position. Next/Previous switch to real video controls and back to the compact music bar.',
      'Actual small/maximized/fullscreen open/closed states pass. The1920x1080capture shows the54px bar and centred cover; this is scoped geometry evidence, not a complete screen score. The existing source/title-bar context and navigation assets remain separate review work.',
      'A cold app restores the compact layout with identical catalogue values. A separate ordinary run retains the saved alternative metadata/shuffle/repeat layout. Light/System and blue accent update the actual player without moving paused progress0.25; another cold process restores the saved System/blue choice. No Windows-theme-change propagation claim is made.',
      'Nine original exports are checked against nonempty local files/root dimensions and callsites. Seven SVG XML trees match, including the new original19.5002x7.50015skip-arrow export reused in two24px wrappers; the two structurally different volume assets render identically at240x240 with QtSvg. Existing assets remain unchanged. Pointer/Return component activation and original artwork geometry pass separately.',
      'All six ordinary runs exit0/602modules/zero checked errors/all source/runtime/fixture/producer/cache guards. Native12cases, component4groups and existing customizer25checks pass. An initial copied-catalogue setup assertion stopped before app launch; intermediate reset failures and the component font-directory diagnostic are preserved separately.'
    ],limits=[
      'No whole-player9.5/10score, actual OS-DPI, assistive-reader acceptance, Windows theme-change propagation or final-package gate is established. Light/System use the existing functional adaptation where no complete original palette is supplied.',
      'Immediate source/queue transition snapshots can show preceding content or partially animated width; settled observations establish the new state without a bounded latency claim. A1microsecond paused start is the native clamped start, not exact zero.',
      'Copied isolated catalogue/layout/theme preparation is explicit fixture setup, not an ordinary Customize Save/Reset gesture journey. Native save/draft preservation tests have their own scope. Real music/waveform values remain generated fixture data; no original example cover is shipped.',
      'The selected GUI357 tuple is an isolated test runtime. Raw configurations/databases/media/binaries/personal logs remain ignored locally. No dependencies or security/privacy settings changed.'
    ],artifacts=artifacts)
(out/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Compact music toolbar and preserved layouts - 27 October2026

Fresh/reset music defaults now follow the original compact toolbar, including
functional15-second controls and the original arrow artwork. Saved alternative
layouts remain intact. Reset uses the default timeline choice consistently.

Twelve native cases, four component groups and25customizer checks pass. Ordinary
before/fixed, cold-layout, saved-alternative and theme/cold-theme journeys all
exit0/602modules/zero checked errors/all guards. Paused seeking, keyboard
activation, track/queue access and audio/video transitions have actual app evidence.

The [checkpoint](checkpoint.json) records exact binaries, asset comparisons,
intermediate failures and limits. This is scoped layout/interaction/theme
evidence, not full visual, OS-DPI, accessibility or final-package acceptance.
Continue from [STATUS](../../../juxtopposed/STATUS.md).
''',encoding='utf-8',newline='\n')
print(str(out),len(artifacts),'verified artifacts; GUI',checkpoint['runtimeSha256']['plugins/gui/libqt_plugin.dll'])
