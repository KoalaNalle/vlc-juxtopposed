from pathlib import Path
work=Path(__file__).resolve().parent
source=(work/'run-ui-music-toolbar-r357.py').read_text(encoding='utf-8')
assert source.count("selected['snapshot']['layout'] = dict(version=1,")==1
(work/'run-ui-music-toolbar-cold-r360.py').write_text(source.replace("selected['snapshot']['layout'] = dict(version=1,", "assert selected['snapshot']['layout'] == dict(version=1,"),encoding='utf-8',newline='\n')
source=(work/'run-ui-music-default-r352.py').read_text(encoding='utf-8').replace('ordinary-r349-bin','ordinary-r357-bin').replace('GUI349','GUI357')
(work/'run-ui-music-alternative-r360.py').write_text(source,encoding='utf-8',newline='\n')
source=(work/'freeze-music-toolbar-r354.py').read_text(encoding='utf-8')
anchor="names.add('modules/control/globalhotkeys/win32.c')"
source=source.replace(anchor,anchor+"\nnames.update(p.relative_to(repo).as_posix() for p in (work/'figma-music-toolbar-assets-r357').glob('*.svg'))\nnames.update('build-windows/beta-single-frame-20261025-night/'+name for name in ['music-toolbar-asset-identities-r358.json','music-toolbar-asset-renders-r359.json'])")
(work/'freeze-music-toolbar-r360.py').write_text(source,encoding='utf-8',newline='\n')
