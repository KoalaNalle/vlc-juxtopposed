from pathlib import Path
from hashlib import sha256
import ctypes,json,re,shutil,subprocess,sys
from copy import deepcopy
work=Path(__file__).resolve().parent
repo=work.parents[1]
revision,label,previous,rate,association,policy,style,variant=sys.argv[1:]; assert policy in ['0','1','2'] and style in ['redesigned','classic']; assert float(rate) in [0.5,1.0,1.5,2.0] and association in ["baseline","no-associated","software","software-no-associated","dummy-display","direct3d9","dummy-audio","ignore-config","normal-fps","attachments"]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
manifest=work/f'inputs-{revision}.json';inputs=read(manifest)
assert all(digest(repo/p)==h and digest(Path(inputs['sourceCopies'][p]))==h for p,h in inputs['files'].items())
prior=repo/'build-windows/beta-subtitle-sync-20261025'
base=work/'ui-library-history-cold-r294/runtime'
expected=read(work/'ui-library-history-cold-r294/verification.json')['runtimeSha256']
expected['plugins/demux/libmp4_plugin.dll']=digest(base/'plugins/demux/libmp4_plugin.dll')
assert all(digest(base/p)==h for p,h in expected.items())
expected['plugins/stream_out/libstream_out_record_plugin.dll']=digest(base/'plugins/stream_out/libstream_out_record_plugin.dll')
base_identities=dict(expected)
expected['plugins/control/libhotkeys_plugin.dll']=digest(base/'plugins/control/libhotkeys_plugin.dll')
ml_name='plugins/misc/libmedialibrary_plugin.dll'
base_identities[ml_name]=digest(base/ml_name)
out=work/label;assert not out.exists();out.mkdir()
shutil.copyfile(Path(__file__),out/'producer.py')
(out/'app-snapshots').mkdir()
sys.path.insert(0,str(repo/'test/libvlc'))
from native_http_runtime import stage_runtime,environment
runtime=out/'runtime';write(out/'staging.json',stage_runtime(base,runtime))
for relative,source in [('libvlccore.dll',work/'core-r265-bin/libvlccore.dll'),
                        ('plugins/audio_output/libwasapi_plugin.dll',prior/'wasapi-r15-bin/libwasapi_plugin.dll'),
                        ('plugins/gui/libqt_plugin.dll',work/'ordinary-r357-bin/libqt_plugin.dll')]:
    target=runtime/relative;target.unlink();shutil.copyfile(source,target)
ml_name='plugins/misc/libmedialibrary_plugin.dll'
target=runtime/ml_name;target.unlink();shutil.copyfile(work/'ordinary-r282-bin/libmedialibrary_plugin.dll',target)
expected[ml_name]=digest(target)
subtitle_name='plugins/demux/libsubtitle_plugin.dll'
expected[subtitle_name]=digest(base/subtitle_name)
subtitle=runtime/subtitle_name;subtitle.unlink();shutil.copyfile(work/'subtitle-r130-bin/libsubtitle_plugin.dll',subtitle)
mp4=runtime/'plugins/demux/libmp4_plugin.dll'
mp4.unlink();shutil.copyfile(work/'mp4-r240-bin/libmp4_plugin.dll',mp4)
record_plugin=runtime/'plugins/stream_out/libstream_out_record_plugin.dll'
record_plugin.unlink();shutil.copyfile(work/'record-fixed-r322-bin/libstream_out_record_plugin.dll',record_plugin)
identities={p:digest(runtime/p) for p in expected}
chapter_media=work/'chapter-media-r332'
chapter_fixtures={p.name:digest(p) for p in chapter_media.iterdir() if p.is_file()}
media=work/'attachment-media-r85'
music=work/'music-media-r273'
music_fixtures={p.relative_to(music).as_posix():digest(p) for p in music.rglob('*') if p.is_file()}
fixtures={p.name:digest(p) for p in media.iterdir() if p.is_file()}
extra=repo/'build-windows/beta-external-subtitle-acceptance-20261023/media-r1'
extra_fixtures={p.name:digest(p) for p in extra.iterdir() if p.is_file()}
decode=work/'decode-media-r100'
decode_fixtures={p.name:digest(p) for p in decode.iterdir() if p.is_file()}
late=work/'late-media-r104'
late_fixtures={p.name:digest(p) for p in late.iterdir() if p.is_file()}
config=out/'vlcrc'
if previous!='fresh':
    assert read(work/previous/'verification.json')['normalExit']
    shutil.copyfile(work/previous/'config-after.txt',config)
else:
    config.write_text('metadata-network-access=0\nml-network-discovery=0\none-instance=0\nqt-updates-notif=0\nqt-auto-raise=0\nqt-remember-window-geometry=0\nqt-controls-auto-hide=0\nqt-timeline-thumbnails=0\nsub-autodetect-file=0\nsub-language=eng\nsub-track=-1\nsub-track-id=\nsub-delay=0\nsub-fps=23.976\n',encoding='utf-8',newline='\n')
shutil.copyfile(config,out/'config-before.txt')
ini=runtime/'portable/vlc/vlc-qt-interface.ini';ini.parent.mkdir(parents=True,exist_ok=True)
ini.write_text('[General]\ngraphics-api=4\nfiledialog-path='+music.as_uri()+'\n[MainWindow]\ncolor-scheme-index=2\ninterface-scale=1\nplayqueue-panel-docked=true\n',encoding='utf-8',newline='\n')
if previous!='fresh':
    old=work/previous/'runtime/portable/vlc/vlc-qt-interface.ini'
    assert old.is_file()
    ini.unlink();shutil.copyfile(old,ini)
if previous!='fresh':
    oldml=work/previous/'userdata/ml'
    if oldml.is_dir():
        shutil.copytree(oldml,out/'userdata/ml')
        write(out/'ml-copy.json',{p.name:digest(p) for p in oldml.iterdir() if p.is_file()})
from PySide6.QtCore import QSettings
settings = QSettings(str(ini), QSettings.IniFormat)
settings.setFallbacksEnabled(False)
initial_settings = {key: settings.value(key) for key in settings.allKeys()}
catalog = json.loads(settings.value('Juxtopposed/player-profiles'))
old_catalog = deepcopy(catalog)
selected = next(p for p in catalog['profiles'] if p['id'] == catalog['selected'])
old_snapshot = deepcopy(selected['snapshot'])
header = (repo/'modules/gui/qt/player/control_list_model.hpp').read_text(encoding='utf-8')
body = header.split('enum ControlType')[1].split('{',1)[1].split('};',1)[0]
body = re.sub(r'//[^\n]*', '', body)
ids = {}; value = -1
for entry in body.split(','):
    entry = entry.strip()
    if not entry: continue
    if '=' in entry:
        name, raw = entry.split('=',1); value = int(raw.strip(),0)
    else:
        name = entry; value += 1
    ids[name.strip()] = value
extras = {
 'transport': ['SKIP_BACK_BUTTON','SKIP_FW_BUTTON','JUXTO_BACKWARD_15','JUXTO_FORWARD_15',
               'JUXTO_REPLAY','STOP_BUTTON','RECORD_BUTTON','SNAPSHOT_BUTTON',
               'PLAYBACK_SPEED_BUTTON','JUXTO_HDR','JUXTO_ZOOM','JUXTO_PICTURE_IN_PICTURE'],
 'library': ['JUXTO_GO_HOME','JUXTO_PLAYLISTS','BOOKMARK_BUTTON','JUXTO_BOOKMARKS',
             'JUXTO_CHAPTERS','JUXTO_FAVORITE','INFO_BUTTON','JUXTO_RIGHT_SIDEBAR',
             'JUXTO_VLC_SETTINGS','QUIT_BUTTON'],
 'metadata': ['JUXTO_THUMBNAIL','JUXTO_FILE_NAME','JUXTO_ARTIST_NAME',
              'JUXTO_FOLDER_NAME','JUXTO_PLAYLIST_NAME']
}
assert variant in extras
transport = [ids[key] for key in ['PREVIOUS_BUTTON','PLAY_BUTTON','NEXT_BUTTON']]
right = [ids[key] for key in ['VOLUME','JUXTO_AUDIO_TRACKS','LANG_BUTTON','EXTENDED_BUTTON','PLAYLIST_BUTTON']]
center = [ids[key] for key in extras[variant]]
# Seed only the isolated test catalogue with PlayerProfileLayout::defaults().
# The copied older catalogue has an explicit video timeline tile, so preserving
# that catalogue does not establish a clean default layout.
selected['snapshot']['layout'] = dict(version=1,
    video=dict(columns=[[ids[k] for k in ['PREVIOUS_BUTTON','PLAY_BUTTON','NEXT_BUTTON']],[],right], timelineAbove=False),
    audio=dict(columns=[[ids[k] for k in ['JUXTO_THUMBNAIL','JUXTO_FILE_NAME','JUXTO_ARTIST_NAME']],
       [ids[k] for k in ['RANDOM_BUTTON','PREVIOUS_BUTTON','PLAY_BUTTON','NEXT_BUTTON','LOOP_BUTTON']],
       [ids[k] for k in ['VOLUME','JUXTO_AUDIO_TRACKS','EXTENDED_BUTTON','PLAYLIST_BUTTON']]], timelineAbove=True))
unchanged = deepcopy(selected['snapshot']); unchanged['layout'] = old_snapshot['layout']
assert unchanged == old_snapshot
settings.setValue('Juxtopposed/player-profiles', json.dumps(catalog,separators=(',',':')))
settings.sync(); assert settings.status() == QSettings.NoError
assert all(settings.value(key) == value for key,value in initial_settings.items() if key != 'Juxtopposed/player-profiles')
assert json.loads(settings.value('Juxtopposed/player-profiles')) == catalog
write(out/'layout-fixture.json', dict(variant=variant, selected=catalog['selected'],
    originalLayout=old_snapshot['layout'], preparedLayout=selected['snapshot']['layout'],
    tileNames=[], preseededNativeDefaults=True, ids=ids, otherProfileValuesPreserved=True,
    otherInterfaceValuesPreserved=True, preseededFixtureNotGestureAcceptance=True,
    catalogBeforeSha256=sha256(json.dumps(old_catalog,sort_keys=True).encode()).hexdigest(),
    catalogAfterSha256=sha256(json.dumps(catalog,sort_keys=True).encode()).hexdigest()))
del settings

shutil.copyfile(ini,out/'settings-before.ini')
cacheout=out/'cache';cacheout.mkdir()
cacheenv=environment(runtime,cacheout);cacheenv.pop('VLC_PLUGIN_PATH',None)
with (cacheout/'stdout.txt').open('wb') as stdout,(cacheout/'stderr.txt').open('wb') as stderr:
    cache=subprocess.Popen([str(runtime/'vlc-cache-gen.exe'),str(runtime/'plugins')],
      cwd=runtime,env=cacheenv,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    write(cacheout/'process.json',dict(status='running',pid=cache.pid))
    try:cachecode=cache.wait(timeout=60)
    except subprocess.TimeoutExpired:raise SystemExit('Inspect cache PID; no automatic cleanup/restart')
write(cacheout/'process.json',dict(status='terminal',exitCode=cachecode,normalExit=cachecode==0))
assert cachecode==0 and (runtime/'plugins/plugins.dat').exists()
cachehash=digest(runtime/'plugins/plugins.dat')
(out/'recordings').mkdir()
command=[str(runtime/'vlc.exe'),'--intf=qt','--no-one-instance','--no-media-library',
 '--no-crashdump','--no-qt-privacy-ask','--no-qt-updates-notif','--no-metadata-network-access',
 '--no-ml-network-discovery','--config='+str(config),'--file-logging','--log-verbose=2',
 '--verbose=2','--logfile='+str(out/'vlc.log'),'--restore-playback-pos=0',
 '--snapshot-path='+str(out/'app-snapshots'),'--snapshot-format=png','--start-paused',
 '--no-qt-video-autoresize','--qt-controls-auto-hide='+policy,'--qt-controls-hide-timeout=1000',('--qt-juxtopposed-controls' if style=='redesigned' else '--no-qt-juxtopposed-controls'),'--rate='+rate,'--sub-file='+str(media/'external-fps.srt'),str(music/'My Songs/1-First light.flac'),str(media/'Show.S01E02.mp4')]
if association in ['no-associated','software-no-associated']: command=[p for p in command if not p.startswith('--sub-file=')]
if association in ['software','software-no-associated']: command.append('--no-hw-dec')
if association=='dummy-display': command+=['--vout=vdummy','--no-hw-dec']
if association=='direct3d9': command+=['--vout=direct3d9','--no-hw-dec']
if association=='dummy-audio': command+=['--aout=adummy']
if association=='ignore-config': command+=['--ignore-config']
if association in ['normal-fps','attachments']: command+=['--sub-fps=0']
command += ['--input-record-path='+str(out/'recordings')]
if association=='attachments':
    command=[p for p in command if not p.startswith('--sub-file=') and p!='--no-media-library']
    command+=['--media-library']
write(out/'launch.json',command)
record=dict(chapterFixtureSha256=chapter_fixtures,musicFixtureSha256=music_fixtures,lateFixtureSha256=late_fixtures,decodeFixtureSha256=decode_fixtures,status='starting',privateCore=False,privateGui=False,privateRecord=False,fullBetaAccepted=False,
 forcedCleanupUsed=False,sourceManifestSha256=digest(manifest),sourceInputCount=len(inputs['files']),
 producerSha256=digest(Path(__file__)),runtimeSha256=identities,fixtureSha256=fixtures,extraFixtureSha256=extra_fixtures,
 pluginCacheSha256=cachehash,scope='Ordinary recording322/GUI357/Core265/library282 on an isolated generated audio-cover/source-folder and plain-video profile. Recording and snapshots remain in the owned run directory. Network/remote/security/privacy choices are outside this run. Unchanged owned tagged music fixture. Source/runtime/fixture guards and normal exit are required; complete beta gates remain separate.')
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.SetErrorMode.argtypes=[ctypes.c_uint];kernel.SetErrorMode.restype=ctypes.c_uint
previousMode=kernel.SetErrorMode(0x8003)
env=environment(runtime,out);env.pop('VLC_PLUGIN_PATH',None)
try:
    with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=runtime,env=env,stdout=stdout,stderr=stderr,
                               creationflags=subprocess.CREATE_NO_WINDOW)
        record.update(status='running',pid=child.pid);write(out/'verification.json',record)
        print('Owned ordinary GUI',label,'PID',child.pid,flush=True)
        try:record['exitCode']=child.wait(timeout=1800)
        except subprocess.TimeoutExpired:
            record.update(status='observation-timeout-process-left-running');write(out/'verification.json',record)
            raise SystemExit('Inspect owned PID; no automatic cleanup/restart')
finally:kernel.SetErrorMode(previousMode)
shutil.copyfile(config,out/'config-after.txt')
shutil.copyfile(ini,out/'settings-after.ini')
logs='\n'.join((out/p).read_text(encoding='utf-8',errors='replace') for p in ['vlc.log','stderr.txt'])
record.update(chapterFixturesUnchanged=all(digest(chapter_media/p)==h for p,h in chapter_fixtures.items()),musicFixturesUnchanged=all(digest(music/p)==h for p,h in music_fixtures.items()),lateFixturesUnchanged=all(digest(late/p)==h for p,h in late_fixtures.items()),decodeFixturesUnchanged=all(digest(decode/p)==h for p,h in decode_fixtures.items()),status='terminal',normalExit=record['exitCode']==0,
 sourceInputsUnchanged=all(digest(repo/p)==h for p,h in inputs['files'].items()),
 runtimeUnchanged=all(digest(runtime/p)==h for p,h in identities.items()),
 baseRuntimeUnchanged=all(digest(base/p)==h for p,h in base_identities.items()),
 fixturesUnchanged=all(digest(media/p)==h for p,h in fixtures.items()),
 extraFixturesUnchanged=all(digest(extra/p)==h for p,h in extra_fixtures.items()),
 producerUnchanged=digest(Path(__file__))==record['producerSha256'],
 pluginCacheUnchanged=digest(runtime/'plugins/plugins.dat')==cachehash,
 moduleCounts=re.findall(r'plug-ins loaded: (\d+) modules',logs),
 diagnostics=[line for line in logs.splitlines() if re.search(r'\berror:|Assertion failed|Binding loop|ReferenceError|TypeError',line)])
write(out/'verification.json',record)
print('diagnostics',len(record['diagnostics']),'unique',len(set(record['diagnostics'])),flush=True)
print(json.dumps({k:record[k] for k in ['status','pid','exitCode','normalExit','sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','pluginCacheUnchanged','moduleCounts']}),flush=True)

assert record["normalExit"] and not record["diagnostics"]
assert all(record[k] for k in ["chapterFixturesUnchanged","sourceInputsUnchanged","runtimeUnchanged","baseRuntimeUnchanged","musicFixturesUnchanged","fixturesUnchanged","lateFixturesUnchanged","decodeFixturesUnchanged","extraFixturesUnchanged","producerUnchanged","pluginCacheUnchanged"])
