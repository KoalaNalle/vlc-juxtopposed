from pathlib import Path
work=Path(__file__).resolve().parent
for name in ['build-music-toolbar-r354.sh','run-ui-music-toolbar-r354.py','run-native-music-toolbar-r354.py']:
    target=name.replace('r354','r357')
    source=(work/name).read_text(encoding='utf-8').replace('r354','r357').replace('GUI354','GUI357')
    (work/target).write_text(source,encoding='utf-8',newline='\n')
