from pathlib import Path
import json
work=Path(__file__).resolve().parent
source=(work/'run-ui-music-sidebar-fixed-r349.py').read_text(encoding='utf-8')
old="""for player in ['video','audio']:
    selected['snapshot']['layout'][player] = dict(columns=[transport, center, right], timelineAbove=True)"""
new="""# Seed only the isolated test catalogue with PlayerProfileLayout::defaults().
# The copied older catalogue has an explicit video timeline tile, so preserving
# that catalogue does not establish a clean default layout.
selected['snapshot']['layout'] = dict(version=1,
    video=dict(columns=[[ids[k] for k in ['PREVIOUS_BUTTON','PLAY_BUTTON','NEXT_BUTTON']],[],right], timelineAbove=False),
    audio=dict(columns=[[ids[k] for k in ['JUXTO_THUMBNAIL','JUXTO_FILE_NAME','JUXTO_ARTIST_NAME']],
       [ids[k] for k in ['RANDOM_BUTTON','PREVIOUS_BUTTON','PLAY_BUTTON','NEXT_BUTTON','LOOP_BUTTON']],
       [ids[k] for k in ['VOLUME','JUXTO_AUDIO_TRACKS','EXTENDED_BUTTON','PLAYLIST_BUTTON']]], timelineAbove=True))"""
assert source.count(old)==1
source=source.replace(old,new).replace("tileNames=extras[variant]", "tileNames=[], preseededNativeDefaults=True")
(work/'run-ui-music-default-r352.py').write_text(source,encoding='utf-8',newline='\n')
(work/'ui-music-default-r351/setup-failure.json').write_text(json.dumps(dict(
    phase='before-cache-and-app-launch', appLaunched=False, normalAppExit=None,
    cause='The copied older catalogue has an explicit video timeline tile; it is not the native default layout.',
    preservedFailedProducer='run-ui-music-default-r351.py', followup='Seed native defaults in a fresh isolated run, preserving all other profile values.',
    fullBetaAccepted=False),indent=2)+'\n',encoding='utf-8')
