import QtQuick
import "file:///C:/Modding/vlc-juxtopposed/modules/gui/qt/player/qml" as Player
Player.JuxtopposedPlaybackBar {
 id: root; property var actions: []; property bool above: false
 assetBase: "file:///C:/Modding/vlc-juxtopposed/modules/gui/qt/pixmaps/juxtopposed/"
 controlLayout: ({columns:[[3,81,0,80,4],[],[33,97,9]],timelineAbove:above})
 describeTile: id=>({name:String(id),kind:({3:"previous",81:"skip15",0:"play",80:"skip15",4:"next",33:"volume",97:"audio",9:"queue"})[id],backward:id===81})
 tileState: id=>({enabled:true,glyph:"",playing:false,source:id===3?assetBase+"previous.svg":id===4?assetBase+"next.svg":id===0?assetBase+"play.svg":""})
 onTileRequested: id=>{actions=actions.concat([id])}
}