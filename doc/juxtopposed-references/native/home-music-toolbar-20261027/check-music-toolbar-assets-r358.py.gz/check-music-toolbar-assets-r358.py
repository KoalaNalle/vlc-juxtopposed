from pathlib import Path
from hashlib import sha256
import json,xml.etree.ElementTree as ET
work=Path(__file__).resolve().parent;repo=work.parents[1]
pairs=[('1f761.svg','previous.svg'),('617e8.svg','next.svg'),('4ecaf.svg','play.svg'),('bf521.svg','volume.svg'),('432a4.svg','audio.svg'),('0eda2.svg','queue.svg'),('07eaa.svg','volume-background.svg'),('2be1c.svg','volume-fill.svg'),('fa055.svg','skip-15-arrow.svg')]
def structure(element):
    return [element.tag,dict(element.attrib),(element.text or '').strip(),[structure(child) for child in element]]
results=[]
for source,name in pairs:
    reference=work/'figma-music-toolbar-assets-r357'/source
    local=repo/'modules/gui/qt/pixmaps/juxtopposed'/name
    original=ET.parse(reference).getroot();actual=ET.parse(local).getroot()
    results.append(dict(sourceAsset=source,localPath=local.relative_to(repo).as_posix(),
        referenceSha256=sha256(reference.read_bytes()).hexdigest(),localSha256=sha256(local.read_bytes()).hexdigest(),
        xmlTreeEqual=structure(original)==structure(actual),
        originalDimensions={key:original.attrib.get(key) for key in ['width','height','viewBox']},
        localDimensions={key:actual.attrib.get(key) for key in ['width','height','viewBox']},
        elementCounts=[len(list(original.iter())),len(list(actual.iter()))]))
(work/'music-toolbar-asset-identities-r358.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print(json.dumps([dict(asset=r['sourceAsset'],local=r['localPath'],xmlTreeEqual=r['xmlTreeEqual'],elements=r['elementCounts']) for r in results]))
