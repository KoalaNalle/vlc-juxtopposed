from pathlib import Path
from hashlib import sha256
import json,os
os.environ['QT_QPA_PLATFORM']='offscreen'
from PySide6.QtCore import QRectF
from PySide6.QtGui import QGuiApplication,QImage,QPainter
from PySide6.QtSvg import QSvgRenderer
app=QGuiApplication([])
work=Path(__file__).resolve().parent;repo=work.parents[1]
results=[]
for source,name in [('bf521.svg','volume.svg'),('2be1c.svg','volume-fill.svg')]:
    paths=[work/'figma-music-toolbar-assets-r357'/source,repo/'modules/gui/qt/pixmaps/juxtopposed'/name]
    renderings=[]
    for path in paths:
        renderer=QSvgRenderer(str(path));assert renderer.isValid()
        image=QImage(240,240,QImage.Format_ARGB32);image.fill(0)
        painter=QPainter(image);renderer.render(painter,QRectF(0,0,240,240));painter.end()
        renderings.append(image)
    changed=sum(renderings[0].pixel(x,y)!=renderings[1].pixel(x,y) for x in range(240) for y in range(240))
    results.append(dict(asset=source,local=name,renderDimensions=[240,240],differentPixels=changed,
        renderSha256=[sha256(bytes(image.constBits())).hexdigest() for image in renderings]))
(work/'music-toolbar-asset-renders-r359.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print(json.dumps(results))
