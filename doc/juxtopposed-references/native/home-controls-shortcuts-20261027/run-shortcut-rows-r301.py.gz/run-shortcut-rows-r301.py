from pathlib import Path
from hashlib import sha256
import ctypes, json, re, shutil, subprocess, sys

work = Path(__file__).resolve().parent
repo = work.parents[1]
revision, label = sys.argv[1:]
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda p: sha256(p.read_bytes()).hexdigest()
write = lambda p, v: p.write_text(json.dumps(v, indent=2) + '\n', encoding='utf-8', newline='\n')
manifest = read(work / f'inputs-{revision}.json')
assert all(digest(repo / p) == h and digest(Path(manifest['sourceCopies'][p])) == h for p, h in manifest['files'].items())
base = work / 'ui-library-history-cold-r294/runtime'
identities = read(work / 'ui-library-history-cold-r294/verification.json')['runtimeSha256']
assert all(digest(base / p) == h for p, h in identities.items())
out = work / label
assert not out.exists(); out.mkdir()
shutil.copyfile(Path(__file__), out / 'producer.py')
sys.path.insert(0, str(repo / 'test/libvlc'))
from native_http_runtime import stage_runtime, environment
runtime = out / 'runtime'
write(out / 'staging.json', stage_runtime(base, runtime))
name = 'test_qt_controls_dialogs.exe'
shutil.copyfile(work / 'shortcut-rows-r301-bin' / name, runtime / name)
identities = dict(identities, **{name: digest(runtime / name)})
cache = out / 'cache'; cache.mkdir()
env = environment(runtime, cache); env.pop('VLC_PLUGIN_PATH', None)
with (cache / 'stdout.txt').open('wb') as stdout, (cache / 'stderr.txt').open('wb') as stderr:
    child = subprocess.Popen([str(runtime / 'vlc-cache-gen.exe'), str(runtime / 'plugins')], cwd=runtime, env=env,
        stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
    assert child.wait(timeout=60) == 0
cachehash = digest(runtime / 'plugins/plugins.dat')
command = [str(runtime / name), '-o', str(out / 'qtest.txt') + ',txt', '-o', str(out / 'qtest.xml') + ',xml']
write(out / 'launch.json', command)
record = dict(status='starting', fullBetaAccepted=False, forcedCleanupUsed=False,
    runtimeSha256=identities, sourceManifestSha256=digest(work / f'inputs-{revision}.json'),
    sourceInputCount=len(manifest['files']), producerSha256=digest(Path(__file__)),
    scope='Owned native QWidget Controls editor test including initial unfiltered row geometry. Actual controller, native configuration and public widgets; no ordinary VLC renderer, primary playback or capture-equivalence claim.')
env = environment(runtime, out); env.pop('VLC_PLUGIN_PATH', None)
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.SetErrorMode.argtypes = [ctypes.c_uint]; kernel.SetErrorMode.restype = ctypes.c_uint
previous = kernel.SetErrorMode(0x8003)
try:
    with (out / 'stdout.txt').open('wb') as stdout, (out / 'stderr.txt').open('wb') as stderr:
        child = subprocess.Popen(command, cwd=out, env=env, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
        record.update(status='running', pid=child.pid); write(out / 'verification.json', record)
        print('Owned native Controls test PID', child.pid, flush=True)
        try: code = child.wait(timeout=90)
        except subprocess.TimeoutExpired:
            record.update(status='observation-timeout-process-left-running'); write(out / 'verification.json', record)
            raise SystemExit('Inspect owned PID; no forced cleanup/restart')
finally: kernel.SetErrorMode(previous)
text = (out / 'qtest.txt').read_text(encoding='utf-8') if (out / 'qtest.txt').is_file() else ''
failures = re.findall(r'^FAIL!\s*:\s*(.+)$', text, re.MULTILINE)
record.update(status='terminal', exitCode=code, normalExit=code == 0,
    failures=failures, totals=re.findall(r'Totals:.*', text),
    sourceInputsUnchanged=all(digest(repo / p) == h for p, h in manifest['files'].items()),
    runtimeUnchanged=all(digest(runtime / p) == h for p, h in identities.items()),
    baseRuntimeUnchanged=all(digest(base / p) == h for p, h in read(work / 'ui-library-history-cold-r294/verification.json')['runtimeSha256'].items()),
    pluginCacheUnchanged=digest(runtime / 'plugins/plugins.dat') == cachehash,
    producerUnchanged=digest(Path(__file__)) == record['producerSha256'])
write(out / 'verification.json', record)
print(json.dumps({k: record[k] for k in ['exitCode', 'normalExit', 'failures', 'totals', 'sourceInputsUnchanged', 'runtimeUnchanged', 'baseRuntimeUnchanged', 'pluginCacheUnchanged', 'producerUnchanged']}), flush=True)
assert all(record[k] for k in ['sourceInputsUnchanged', 'runtimeUnchanged', 'baseRuntimeUnchanged', 'pluginCacheUnchanged', 'producerUnchanged'])
raise SystemExit(code)
