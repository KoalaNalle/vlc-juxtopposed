from pathlib import Path
from hashlib import sha256
import json, sys

work = Path(__file__).resolve().parent
out = work / 'ui-controls-shortcuts-fixed-r302'
config = out / 'vlcrc'
backup = out / 'vlcrc-before-save-failure'
assert out.resolve().parent == work.resolve()
assert config.resolve().parent == out.resolve() and backup.resolve().parent == out.resolve()
mode, = sys.argv[1:]
digest = lambda p: sha256(p.read_bytes()).hexdigest()
if mode == 'arm':
    assert config.is_file() and not backup.exists()
    identity = digest(config)
    config.rename(backup)
    config.mkdir()
    record = dict(mode=mode, configSha256=identity, onlyOwnedConfigAffected=True)
    (out / 'save-failure-arm.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
elif mode == 'restore':
    before = json.loads((out / 'save-failure-arm.json').read_text(encoding='utf-8'))
    assert config.is_dir() and not any(config.iterdir()) and backup.is_file()
    assert digest(backup) == before['configSha256']
    config.rmdir()
    backup.rename(config)
    assert digest(config) == before['configSha256']
    record = dict(mode=mode, originalRestored=True, configSha256=digest(config), onlyOwnedConfigAffected=True)
    (out / 'save-failure-restored.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
else:
    raise SystemExit('Expected arm or restore')
print(json.dumps(record), flush=True)
