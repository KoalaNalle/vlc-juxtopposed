#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
model="$base/owned-controls-model-20261027-r299"
dialogs="$base/owned-controls-dialogs-20261027-r299"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-shortcut-rows-r299.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-shortcut-rows-r299-exit.txt"; exit "$code"' EXIT
test ! -e "$model"
test ! -e "$dialogs"
test ! -e "$work/shortcut-rows-r299-bin"
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = fdfcfcd599588512bb7f3a51e46305b7b0d947b47387dd205851feb45f032b46
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/modules/gui/qt/tests/native_library/controls.mk" -f "$repo/modules/gui/qt/tests/native_library/controls-dialogs.mk" -j2 PROPOSAL_OUT="$model" CONTROLS_MODEL_OUT="$model" DIALOGS_OUT="$dialogs" controls-preferences-native controls-dialogs-native
mkdir "$work/shortcut-rows-r299-bin"
cp "$dialogs/.libs/test_qt_controls_dialogs.exe" "$work/shortcut-rows-r299-bin/"
sha256sum "$work/shortcut-rows-r299-bin/"*
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = fdfcfcd599588512bb7f3a51e46305b7b0d947b47387dd205851feb45f032b46
