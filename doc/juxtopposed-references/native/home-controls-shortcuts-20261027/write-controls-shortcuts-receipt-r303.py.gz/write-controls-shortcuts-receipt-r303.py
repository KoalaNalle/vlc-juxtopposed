from pathlib import Path
from hashlib import sha256
import gzip, json, re

work = Path(__file__).resolve().parent
repo = work.parents[1]
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda p: sha256(p.read_bytes()).hexdigest()
ordinary_names = ['ui-controls-shortcuts-r298', 'ui-controls-shortcuts-fixed-r302',
                  'ui-controls-shortcuts-cold-r302', 'ui-controls-shortcuts-reset-classic-r302']
ordinary = {name: read(work / name / 'verification.json') for name in ordinary_names}
guards = ['sourceInputsUnchanged', 'runtimeUnchanged', 'baseRuntimeUnchanged',
          'fixturesUnchanged', 'musicFixturesUnchanged', 'lateFixturesUnchanged',
          'decodeFixturesUnchanged', 'extraFixturesUnchanged', 'producerUnchanged',
          'pluginCacheUnchanged']
for name, record in ordinary.items():
    assert record['normalExit'] and record['exitCode'] == 0
    assert record['moduleCounts'] == ['602'] and all(record[k] for k in guards)
    expected = ['main error: cannot read configuration file: Permission denied'] if name == ordinary_names[1] else []
    assert record['diagnostics'] == expected, (name, record['diagnostics'])

native_names = ['native-shortcut-rows-before-r300', 'native-shortcut-rows-fixed-r301']
native = {name: read(work / name / 'verification.json') for name in native_names}
for record in native.values():
    assert all(record[k] for k in ['sourceInputsUnchanged', 'runtimeUnchanged',
        'baseRuntimeUnchanged', 'pluginCacheUnchanged', 'producerUnchanged'])
before, fixed = (native[n] for n in native_names)
assert before['exitCode'] == 1 and len(before['failures']) == 1
assert 'initialShortcutRowsAreReachable' in before['failures'][0]
assert 'height() > 8' in before['failures'][0]
assert '14 passed, 1 failed, 0 skipped' in before['totals'][0]
assert fixed['normalExit'] and fixed['exitCode'] == 0 and not fixed['failures']
assert '15 passed, 0 failed, 0 skipped' in fixed['totals'][0]
manifest = read(work / 'inputs-r302.json')
assert all(digest(repo / p) == h for p, h in manifest['files'].items())

def tree(run, name):
    return read(work / run / 'observations' / (name + '.json'))['accessibility']['tree']

warm, cold, classic = ordinary_names[1:]
assert 'Ctrl+Shift+F12' in tree(warm, '05-save-failure-keeps-shortcut-draft')
assert 'could not be saved' in tree(warm, '05-save-failure-keeps-shortcut-draft')
assert 'Progress Value: 0' in tree(warm, '08-new-shortcut-inactive-before-restart')
assert 'Ctrl+Shift+F12' in tree(warm, '07-saved-shortcut-reopens-visible-unfiltered-table')
assert 'button (settable, string) Pause' in tree(warm, '09-original-space-starts-before-restart')
assert 'button (settable, string) Pause' in tree(cold, '02-custom-shortcut-starts-after-restart')
for name in ['03-custom-shortcut-pauses-after-restart', '04-old-space-does-not-toggle-after-restart',
             '06-native-shortcut-popup-moved-primary-clock-held', '08-reset-editor-reopens-space-default']:
    assert 'Progress Value: 0.08290250120811185' in tree(cold, name)
assert 'tree item (selectable, settable, string) Space' in tree(cold, '08-reset-editor-reopens-space-default')
assert 'Progress Value: 0' in tree(classic, '02-reset-custom-key-inactive')
assert 'Progress Value: 0.08004589158654246' in tree(classic, '04-reset-space-pauses-classic')
arm = read(work / warm / 'save-failure-arm.json')
restore = read(work / warm / 'save-failure-restored.json')
assert arm['configSha256'] == restore['configSha256'] and restore['originalRestored']

def options(path):
    result = {}
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        if line and not line.startswith('#') and '=' in line:
            key, value = line.split('=', 1); result[key] = value
    return result

saved = options(work / warm / 'config-after.txt')
reset = options(work / cold / 'config-after.txt')
assert saved['key-play-pause'] == 'Ctrl+Shift+F12'
assert reset.get('key-play-pause', 'Space') == 'Space'
changes = {key: [saved.get(key), reset.get(key)] for key in saved.keys() | reset.keys()
           if saved.get(key) != reset.get(key)}
assert all(key.startswith(('key-', 'global-key-')) for key in changes), changes

out = repo / 'doc/juxtopposed-references/native/home-controls-shortcuts-20261027'
assert not out.exists(); out.mkdir()
artifacts = []
def retain(p):
    relative = p.relative_to(work).as_posix() + '.gz'
    target = out / relative; target.parent.mkdir(parents=True, exist_ok=True)
    raw = p.read_bytes(); target.write_bytes(gzip.compress(raw, mtime=0))
    artifacts.append(dict(path=relative, sha256=digest(target), rawSha256=sha256(raw).hexdigest()))

for name in ordinary_names + native_names:
    root = work / name
    for filename in ['verification.json', 'producer.py', 'launch.json', 'staging.json',
                     'qtest.txt', 'qtest.xml', 'save-failure-arm.json', 'save-failure-restored.json']:
        p = root / filename
        if p.is_file(): retain(p)
    for p in sorted((root / 'observations').glob('*')):
        if p.suffix in ['.json', '.png']: retain(p)
for filename in ['inputs-r298.json', 'inputs-r300.json', 'inputs-r301.json', 'inputs-r302.json',
    'shortcut-rows-before-r300.json', 'freeze-controls-r299.py', 'build-shortcut-rows-r299.sh',
    'build-shortcut-rows-r301.sh', 'run-shortcut-rows-r300.py', 'run-shortcut-rows-r301.py',
    'run-ui-controls-shortcuts-r302.py', 'shortcut-save-failure-r302.py',
    'write-controls-shortcuts-receipt-r303.py']:
    retain(work / filename)

result = dict(status='passed-scoped-shortcut-editor-repair', fullBetaAccepted=False,
    runtimeSha256=ordinary[warm]['runtimeSha256'], nativeExecutableSha256=fixed['runtimeSha256']['test_qt_controls_dialogs.exe'],
    sourceManifestSha256=digest(work / 'inputs-r302.json'), sourceInputCount=len(manifest['files']),
    resetChangedKeys=changes, normalOrdinaryExit=True, allGuards=True,
    beforeFailure=read(work / 'shortcut-rows-before-r300.json'),
    observations=[
        'Before: GUI293 opens a blank unfiltered shortcut table twice even though native data exists; filtering reveals Play/Pause. The new native row-geometry regression fails exactly one case, with14 other cases passing and normal QTest cleanup.',
        'Removing premature uniform row heights restores per-row hints. Fixed native controller/widget suite passes15/0/0. GUI301 first and repeated unfiltered openings show real rows and a scrollbar.',
        'Ordinary duplicate f assignment reports the Fullscreen conflict. Cancel preserves both original mappings and the paused primary clock. Ctrl+Shift+F12 draft survives an owned configuration-path save failure; original config bytes are restored before retry succeeds.',
        'The running instance retains Space and ignores the newly saved shortcut. A new GUI301 instance uses Ctrl+Shift+F12 for actual play/pause and ignores Space. Its shortcut dialog is moved by dragging the title bar while playback stays paused.',
        'Reset saves Space/defaults with truthful restart feedback and preserves every active non-shortcut native option. A fresh traditional-controls instance ignores the removed custom key and actually plays/pauses with Space.',
        'Four ordinary runs exit0/602modules with all source/runtime/base/fixture/cache/producer guards. Three have zero error diagnostics. The failure/retry run retains exactly the expected configuration read error; its strict no-error runner therefore exits1 after the app exits0. This original result is preserved, not rewritten into a zero-error pass.'
    ], limits=[
        'Full shortcut/action/global-key coverage, screen-reader usability, theme, Windows DPI and final-package replay are separate gates. The native QWidget suite does not supply ordinary playback evidence.',
        'Traditional Simple Preferences opens on the other monitor and can be cancelled, but its Hotkeys category was not reached: Computer Use rejected a target outside the selected owner bounds. Its table visibility is not claimed from that ordinary attempt.',
        'Before observation03 has a misleading blank-table name: its filtered Play/Pause row is actually visible. The first and second unfiltered captures establish the blank-table defect.',
        'Owned generated media only. Raw personal logs, isolated profiles/configs, binaries and private media are not included. No security/privacy settings changed. No forced cleanup.'
    ], artifacts=artifacts)
(out / 'checkpoint.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
(out / 'README.md').write_text('''# Shortcut editor visibility and restart - 27 October 2026

The unfiltered keyboard-shortcut editor was blank on ordinary GUI293. A native
row-geometry test reproduces it (14 pass, 1 fail). Removing premature uniform
row heights restores the real rows on GUI301; the native suite now passes15/0/0.

Ordinary checks cover duplicate-key cancellation, retained draft and retry after
an owned save failure, saved mapping reopen, real play/pause before/after restart,
movable native popup, Reset, and restored Space on a fresh traditional player.
Reset changes only shortcut options. All four ordinary processes exit normally
with every guard intact. The deliberate save-failure run retains its expected
configuration diagnostic and the strict runner's resulting assertion failure;
the other three ordinary runs have zero error diagnostics.

See the [checkpoint](checkpoint.json) for exact identities, captures, failures
and limitations. Traditional Simple Preferences Hotkeys navigation, full action/
accessibility/DPI coverage and final-package acceptance remain separate. Continue
from [STATUS](../../../juxtopposed/STATUS.md).
''', encoding='utf-8', newline='\n')
for artifact in artifacts:
    p = out / artifact['path']
    assert digest(p) == artifact['sha256']
    assert sha256(gzip.decompress(p.read_bytes())).hexdigest() == artifact['rawSha256']
print(out, len(artifacts), 'verified artifacts', flush=True)
