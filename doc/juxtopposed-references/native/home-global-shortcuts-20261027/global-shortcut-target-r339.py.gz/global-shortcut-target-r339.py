from pathlib import Path
from hashlib import sha256
import json,os,sys
work=Path(__file__).resolve().parent;repo=work.parents[1]
out=Path(sys.argv[1]);assert not out.exists();out.mkdir()
os.environ['QT_QUICK_BACKEND']='software'
os.environ['QT_QPA_FONTDIR']=str(repo/'modules/gui/qt/pixmaps/juxtopposed')
from PySide6.QtCore import QTimer,QUrl
from PySide6.QtGui import QColor,QFontDatabase,QGuiApplication
from PySide6.QtQuick import QQuickView
app=QGuiApplication([])
font_id=QFontDatabase.addApplicationFont(str(repo/'modules/gui/qt/pixmaps/juxtopposed/InterVariable.ttf'));assert font_id>=0
source='''import QtQuick
Rectangle {
 width: 480; height: 180; color: "#202020"
 Text {
  anchors.centerIn: parent
  text: "Owned global shortcut test\\nThis window receives keyboard focus."
  color: "#eeeeee"; font.pixelSize: 18; horizontalAlignment: Text.AlignHCenter
 }
}
'''
(out/'target.qml').write_text(source,encoding='utf-8',newline='\n')
view=QQuickView();view.setTitle('Owned VLC global shortcut target')
view.setResizeMode(QQuickView.SizeRootObjectToView)
view.setSource(QUrl.fromLocalFile(str(out/'target.qml')));assert not view.errors()
view.resize(480,180);view.show()
record=dict(status='running',pid=os.getpid(),helperSha256=sha256(Path(__file__).read_bytes()).hexdigest(),
 qmlSha256=sha256((out/'target.qml').read_bytes()).hexdigest(),timedOut=False,fullBetaAccepted=False)
def save():(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
def timeout():record['timedOut']=True;view.close()
QTimer.singleShot(600000,timeout);save();print('Owned keyboard target PID',os.getpid(),flush=True)
code=app.exec()
record.update(status='terminal',exitCode=code,normalExit=code==0,
 helperUnchanged=record['helperSha256']==sha256(Path(__file__).read_bytes()).hexdigest(),
 qmlUnchanged=record['qmlSha256']==sha256((out/'target.qml').read_bytes()).hexdigest())
save();print(json.dumps(record),flush=True)
assert record['normalExit'] and not record['timedOut'] and record['helperUnchanged'] and record['qmlUnchanged']
