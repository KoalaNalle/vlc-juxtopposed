from pathlib import Path
work=Path(__file__).resolve().parent
source=(work/'run-ui-record-fixed-r323.py').read_text(encoding='utf-8')
source=source.replace('ordinary-r311-bin','ordinary-r337-bin').replace('recording322/GUI311','recording322/GUI337')
anchor="shutil.copyfile(config,out/'config-before.txt')"
assert source.count(anchor)==1
source=source.replace(anchor,"""key='global-key-play-pause'
text=config.read_text(encoding='utf-8-sig')
text='\\n'.join(line for line in text.splitlines() if not line.startswith(key+'='))
chord='Ctrl+Alt+Shift+F12'
config.write_text(text+'\\n'+key+'='+chord+'\\n',encoding='utf-8',newline='\\n')
write(out/'global-shortcut-fixture.json',dict(key=key,value=chord,isolatedConfig=True,editorGestureAcceptance=False))
"""+anchor)
source=source.replace('on an isolated generated-media profile.', 'on an isolated generated-media profile with a saved global Play/Pause shortcut. Separate owned focus target and real OS keyboard delivery are required; no public registration success is inferred from config alone.')
(work/'run-ui-global-shortcut-r339.py').write_text(source,encoding='utf-8',newline='\n')
