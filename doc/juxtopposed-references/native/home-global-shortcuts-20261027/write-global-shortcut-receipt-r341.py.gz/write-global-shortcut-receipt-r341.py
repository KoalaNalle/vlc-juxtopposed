from pathlib import Path
from hashlib import sha256
import gzip,json
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
runs=['ui-global-shortcut-a-r339','ui-global-shortcut-b-r340']
records={name:read(work/name/'verification.json') for name in runs}
for record in records.values():
    assert record['normalExit'] and record['exitCode']==0
    assert record['moduleCounts']==['602'] and not record['diagnostics']
    assert all(v for k,v in record.items() if k.endswith('Unchanged'))
target=read(work/'global-shortcut-target-r339/verification.json')
assert target['normalExit'] and not target['timedOut'] and target['helperUnchanged'] and target['qmlUnchanged']
out=repo/'doc/juxtopposed-references/native/home-global-shortcuts-20261027'
assert not out.exists();out.mkdir();artifacts=[]
def retain(p):
    name=p.relative_to(work).as_posix()+'.gz';dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True)
    raw=p.read_bytes();dest.write_bytes(gzip.compress(raw,mtime=0))
    assert gzip.decompress(dest.read_bytes())==raw
    artifacts.append(dict(path=name,sha256=digest(dest),rawSha256=sha256(raw).hexdigest()))
for name in runs:
    for file in ['verification.json','producer.py','launch.json','staging.json','global-shortcut-fixture.json']:
        retain(work/name/file)
    for p in sorted((work/name/'observations').glob('*')):
        if p.suffix in ['.json','.png']:retain(p)
for file in ['inputs-r339.json','inputs-r340.json','run-ui-global-shortcut-r339.py',
 'run-ui-global-shortcut-b-r340.py','prepare-global-shortcuts-r339.py',
 'prepare-global-shortcut-b-r340.py','freeze-global-shortcuts-r340.py',
 'global-shortcut-target-r339.py','global-shortcut-target-r339/verification.json',
 'global-shortcut-target-r339/target.qml','write-global-shortcut-receipt-r341.py']:
    retain(work/file)
result=dict(status='passed-scoped-background-play-pause-and-traditional-navigation',fullBetaAccepted=False,
 runtimeSha256=records[runs[1]]['runtimeSha256'],globalHotkeySourceSha256=digest(repo/'modules/control/globalhotkeys/win32.c'),
 observations=[
  'A uses saved Ctrl+Alt+Shift+F12, B uses saved Ctrl+Alt+Shift+F11 in separate owned configs. Mappings are prepared fixtures, not acceptance of editor gestures. Both are ordinary GUI337/Core265/library282/recording322 with generated media.',
  'OS keyboard delivery targets a separate native owned Qt window. A starts from paused zero, advances, and pauses at progress0.2844143573678159. Foreground settled readback reports17seconds. Background accessibility snapshots can remain stale even when the rendered clock and Play/Pause state change.',
  'B starts E02 from zero and pauses at progress0.2037564113245905, about12seconds. A remains paused at the exact previous progress after both B chords. A closes normally; B still starts through its F11 global chord and advances. B is then paused at progress0.5691123294062755 before settings.',
  'The traditional Advanced Preferences dialog opens from General Advanced Options. Mouse accessibility activation of Simple fails with element unavailable; the native dialog is on the other monitor and not separately returned by the window list. Keyboard navigation selects Simple, follows the category buttons to Hotkeys, and renders the full table including the saved Ctrl+Alt+Shift+F11 value. Escape cancels without saving. The paused player retains progress0.5691123294062755.',
  'Both ordinary applications exit0, load602modules, log zero checked error diagnostics and pass all original source/runtime/fixture/producer/cache guards. The separate focus helper closes normally before its timeout with unchanged helper and QML. No forced cleanup is used.'
 ],limits=[
  'This qualifies two distinct Play/Pause combinations, held-player isolation and survival after the first instance exits. It does not establish all shortcut actions, same-chord conflict feedback, live remapping, both closing orders or broad OS key ownership.',
  'B explicitly guards the Windows global-key DLL and win32.c source in its frozen inventory. A original runtime guard did not enumerate that DLL; no broader binary guard is retroactively claimed for A.',
  'An initial occluded target capture shows VLC pixels; activating the target produces its actual dark window. Several immediate snapshots have stale accessibility text; the later settled screenshots/readbacks are the relevant state evidence.',
  'All profiles and media are owned test fixtures. Raw logs, configs, databases, media and binaries stay ignored locally. No dependency, privacy or security changes were made. Full design, accessibility, Windows DPI and final-package gates remain open.'
 ],artifacts=artifacts)
(out/'checkpoint.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Global Play/Pause and traditional Hotkeys - 27 October 2026

Ordinary GUI337 verifies background Play/Pause through two distinct saved global
shortcuts. The second instance leaves the first player's paused position exactly
unchanged and keeps its shortcut after the first exits. Simple Preferences Hotkeys
is reached by keyboard, displays the mapping, and cancels without altering the
paused clock. Both apps exit0/602modules/zero checked errors/all original guards.

The [checkpoint](checkpoint.json) distinguishes prepared mappings, stale/occluded
captures and the failed accessibility click from the accepted keyboard journey.
All-action and same-chord conflict acceptance remain open. These checks do not
establish full beta readiness; continue from [STATUS](../../../juxtopposed/STATUS.md).
''',encoding='utf-8',newline='\n')
print(out,len(artifacts),'verified artifacts')
