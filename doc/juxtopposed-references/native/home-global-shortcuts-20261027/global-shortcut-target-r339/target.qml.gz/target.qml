import QtQuick
Rectangle {
 width: 480; height: 180; color: "#202020"
 Text {
  anchors.centerIn: parent
  text: "Owned global shortcut test\nThis window receives keyboard focus."
  color: "#eeeeee"; font.pixelSize: 18; horizontalAlignment: Text.AlignHCenter
 }
}
