from pathlib import Path
work = Path(__file__).resolve().parent
source = (work/'run-ui-global-shortcut-r339.py').read_text(encoding='utf-8')
assert source.count("chord='Ctrl+Alt+Shift+F12'") == 1
source = source.replace("chord='Ctrl+Alt+Shift+F12'", "chord='Ctrl+Alt+Shift+F11'")
old = "str(media/'Show.S01E01.mp4'),str(media/'Show.S01E02.mp4')"
assert source.count(old) == 1
source = source.replace(old, "str(media/'Show.S01E02.mp4'),str(media/'Show.S01E01.mp4')")
anchor = 'base_identities=dict(expected)'
assert source.count(anchor) == 1
source = source.replace(anchor, "expected['plugins/control/libwin_hotkeys_plugin.dll']=digest(base/'plugins/control/libwin_hotkeys_plugin.dll')\n" + anchor)
(work/'run-ui-global-shortcut-b-r340.py').write_text(source, encoding='utf-8', newline='\n')
freeze = (work/'freeze-tooltip-r337.py').read_text(encoding='utf-8')
anchor = "names.add('modules/gui/qt/tests/test_pointing_tooltip_text.py')"
assert freeze.count(anchor) == 1
freeze = freeze.replace(anchor, anchor + "\nnames.add('modules/control/globalhotkeys/win32.c')")
(work/'freeze-global-shortcuts-r340.py').write_text(freeze, encoding='utf-8', newline='\n')
