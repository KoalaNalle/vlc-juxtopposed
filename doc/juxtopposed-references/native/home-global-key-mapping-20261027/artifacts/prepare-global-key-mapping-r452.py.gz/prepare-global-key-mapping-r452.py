from pathlib import Path
work=Path(__file__).resolve().parent
for old,new in [('build-global-hotkeys-r432','build-global-key-mapping-r452'),
                ('build-global-hotkey-probe-r436','build-global-key-mapping-probe-r452')]:
    source=(work/(old+'.sh')).read_text(encoding='utf-8')
    source=source.replace(old,new).replace('hotkeys-r432-bin','hotkeys-r452-bin').replace('owned-global-hotkey-probe-r436','owned-global-key-mapping-probe-r452')
    (work/(new+'.sh')).write_text(source,encoding='utf-8',newline='\n')
producer=(work/'run-native-global-hotkeys-r437.py').read_text(encoding='utf-8')
producer=producer.replace('inputs-r436','inputs-r452').replace('native-global-hotkeys-r437','native-global-key-mapping-r453').replace('owned-global-hotkey-probe-r436','owned-global-key-mapping-probe-r452').replace('hotkeys-r432-bin','hotkeys-r452-bin')
producer=producer.replace('assert record[\'normalExit\'] and functions and not failed', "assert record['normalExit'] and functions and not failed\nassert not any(i['type']=='skip' for f in functions for i in f['incidents'])")
(work/'run-native-global-key-mapping-r453.py').write_text(producer,encoding='utf-8',newline='\n')
ordinary=(work/'run-ui-global-shortcuts-long-r444.py').read_text(encoding='utf-8').replace('hotkeys-r432-bin','hotkeys-r452-bin')
ordinary=ordinary.replace("['collision','saved']", "['collision','saved','punctuation']")
ordinary=ordinary.replace("if bindings=='collision':", "if bindings=='punctuation':\n    with config.open('a',encoding='utf-8',newline='\\n') as file:file.write('\\nglobal-key-play-pause=Ctrl+Alt+Shift+;\\n')\nif bindings=='collision':")
ordinary=ordinary.replace('win_hotkeys432','win_hotkeys452')
(work/'run-ui-global-key-mapping-r452.py').write_text(ordinary,encoding='utf-8',newline='\n')
