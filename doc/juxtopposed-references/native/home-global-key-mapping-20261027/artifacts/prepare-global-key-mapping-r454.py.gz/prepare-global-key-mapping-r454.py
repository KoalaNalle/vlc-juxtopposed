from pathlib import Path
work=Path(__file__).resolve().parent
build=(work/'build-global-key-mapping-probe-r452.sh').read_text(encoding='utf-8').replace('r452','r454')
(work/'build-global-key-mapping-probe-r454.sh').write_text(build,encoding='utf-8',newline='\n')
producer=(work/'run-native-global-key-mapping-r453.py').read_text(encoding='utf-8').replace('inputs-r452','inputs-r454').replace('native-global-key-mapping-r453','native-global-key-mapping-r455').replace('owned-global-key-mapping-probe-r452','owned-global-key-mapping-probe-r454')
(work/'run-native-global-key-mapping-r455.py').write_text(producer,encoding='utf-8',newline='\n')
