from pathlib import Path
work=Path(__file__).resolve().parent
build=(work/'build-global-hotkey-probe-r436.sh').read_text(encoding='utf-8').replace('r436','r450')
(work/'build-global-hotkey-probe-r450.sh').write_text(build,encoding='utf-8',newline='\n')
producer=(work/'run-native-global-hotkeys-r437.py').read_text(encoding='utf-8')
producer=producer.replace('inputs-r436','inputs-r450').replace('native-global-hotkeys-r437','native-global-key-mapping-before-r451').replace('owned-global-hotkey-probe-r436','owned-global-hotkey-probe-r450')
producer=producer.replace("assert record['normalExit'] and functions and not failed", "assert code == 2 and {f['name'] for f in failed} == {'punctuationUsesTheCurrentWindowsLayout','supplementaryCharactersCannotRegisterTheirLowByte'}\nrecord.update(expectedNegative=True,expectedFailureObserved=True);save()")
(work/'run-native-global-key-mapping-before-r451.py').write_text(producer,encoding='utf-8',newline='\n')
