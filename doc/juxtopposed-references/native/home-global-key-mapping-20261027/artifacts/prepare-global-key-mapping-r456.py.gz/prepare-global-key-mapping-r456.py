from pathlib import Path
work=Path(__file__).resolve().parent
build=(work/'build-global-key-mapping-probe-r454.sh').read_text(encoding='utf-8').replace('r454','r456')
(work/'build-global-key-mapping-probe-r456.sh').write_text(build,encoding='utf-8',newline='\n')
producer=(work/'run-native-global-key-mapping-r455.py').read_text(encoding='utf-8').replace('inputs-r454','inputs-r456').replace('native-global-key-mapping-r455','native-global-key-mapping-r457').replace('owned-global-key-mapping-probe-r454','owned-global-key-mapping-probe-r456')
(work/'run-native-global-key-mapping-r457.py').write_text(producer,encoding='utf-8',newline='\n')
