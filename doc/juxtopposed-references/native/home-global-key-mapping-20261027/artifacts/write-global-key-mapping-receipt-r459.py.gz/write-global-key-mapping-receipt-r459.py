from pathlib import Path
from hashlib import sha256
import gzip,json,re,subprocess,xml.etree.ElementTree as ET
from PySide6.QtCore import QSettings

work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
receipt=repo/'doc/juxtopposed-references/native/home-global-key-mapping-20261027'
assert not receipt.exists()
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert commit.startswith('546eecd8e1')
manifest=read(work/'inputs-r456.json')
assert all(digest(repo/p)==h for p,h in manifest['files'].items())
native={}
for run,failures in [('native-global-key-mapping-before-r451',2),('native-global-key-mapping-r453',1),('native-global-key-mapping-r457',0)]:
    record=read(work/run/'verification.json')
    assert all(v for k,v in record.items() if k.endswith('Unchanged'))
    root=ET.parse(work/run/'results.xml').getroot()
    failed=root.findall('.//Incident[@type="fail"]')
    skipped=root.findall('.//Incident[@type="skip"]')
    assert len(failed)==failures and not skipped
    assert record['exitCode']==failures
    native[run]=dict(functions=len(root.findall('TestFunction')),failures=failures,skips=0,
                     passIncidents=len(root.findall('.//Incident[@type="pass"]')),
                     exitCode=record['exitCode'],endingGuardsPassed=True)
run='ui-global-punctuation-r458';record=read(work/run/'verification.json')
assert record['normalExit'] and not record['diagnostics'] and record['moduleCounts']==['602']
assert all(v for k,v in record.items() if k.endswith('Unchanged'))
assert record['runtimeSha256']['plugins/control/libwin_hotkeys_plugin.dll']=='28e53fd1d6a0cd10d7c6e106a5ea5a67b3c5118ed74c42fabb0f380a68a183d6'
def tree(name):return read(work/run/'observations'/f'{name}.json')['accessibility']['tree']
def position(name):return float(re.search(r'Progress Value: ([0-9.]+)',tree(name)).group(1))
assert position('01-cold-paused')==0
assert position('03-semicolon-playing-settled')>0
assert 'button (settable, string) Pause' in tree('03-semicolon-playing-settled')
hold=position('05-semicolon-paused-settled')
assert hold>position('03-semicolon-playing-settled')
assert position('09-final-paused')==hold
assert '1 global shortcut is active in this player.' in tree('07-controls-active-settled')
assert 'Ctrl+Alt+Shift+;' in tree('08-editor-semicolon-active')
assert (work/run/'config-before.txt').read_bytes()==(work/run/'config-after.txt').read_bytes()
catalogues=[]
for name in ['settings-before.ini','settings-after.ini']:
    settings=QSettings(str(work/run/name),QSettings.IniFormat);settings.setFallbacksEnabled(False)
    catalogues.append(json.loads(settings.value('Juxtopposed/player-profiles')))
assert catalogues[0]==catalogues[1]
analysis=dict(passed=True,sourceCommit=commit,native=native,ordinaryRun=run,
    runtimeSha256=record['runtimeSha256'],ordinaryEndingGuardsPassed=True,
    ordinaryPhysicalChord='Ctrl+Alt+Shift+comma on the observed Finnish layout, producing semicolon',
    pausedPosition=hold,nativeConfigUnchanged=True,playerProfilesUnchanged=True,
    allKeyboardLayoutsAccepted=False,liveLayoutSwitchAccepted=False,allShortcutActionsAccepted=False,
    actualWindowsDpiAccepted=False,screenReaderAccepted=False,fullBetaAccepted=False,
    firewallRuleChanges=[],securityPrivacyChanges=[])
(work/'global-key-mapping-analysis-r459.json').write_text(json.dumps(analysis,indent=2)+'\n',encoding='utf-8')
names=['inputs-r450.json','inputs-r452.json','inputs-r454.json','inputs-r456.json',
       'freeze-global-shortcuts-r439.py','prepare-global-key-mapping-r450.py',
       'prepare-global-key-mapping-r452.py','prepare-global-key-mapping-r454.py',
       'prepare-global-key-mapping-r456.py','run-ui-global-key-mapping-r452.py',
       'global-key-mapping-analysis-r459.json','write-global-key-mapping-receipt-r459.py']
for stem in ['build-global-hotkey-probe-r450','build-global-key-mapping-r452',
             'build-global-key-mapping-probe-r452','build-global-key-mapping-probe-r454',
             'build-global-key-mapping-probe-r456']:
    names.extend(stem+s for s in ['.sh','.log','-exit.txt'])
files=[work/name for name in names]
for case in native:
    files.extend(work/case/name for name in ['producer.py','verification.json','results.xml','stdout.txt','stderr.txt'])
files.extend(work/run/name for name in ['producer.py','verification.json','launch.json','vlc.log','stderr.txt',
                                     'config-before.txt','config-after.txt','settings-before.ini','settings-after.ini'])
files.extend(p for p in (work/run/'observations').iterdir() if p.is_file())
receipt.mkdir();(receipt/'artifacts').mkdir();inventory=[]
for path in sorted(set(files)):
    data=path.read_bytes();name=path.relative_to(work).as_posix().replace('/','__')+'.gz'
    target=receipt/'artifacts'/name;target.write_bytes(gzip.compress(data,mtime=0))
    assert gzip.decompress(target.read_bytes())==data
    inventory.append(dict(file='artifacts/'+name,source=path.relative_to(repo).as_posix(),sha256=sha256(data).hexdigest(),
                          gzipSha256=digest(target),bytes=len(data),compressedBytes=target.stat().st_size))
checkpoint=dict(sourceCommit=commit,runtime=f'build-windows/beta-single-frame-20261025-night/{run}/runtime',
    runtimeSha256=record['runtimeSha256'],analysis=analysis,artifacts=inventory,
    fullBetaAccepted=False,finalPackageAccepted=False,independentReviewAccepted=False)
(receipt/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n',encoding='utf-8')
(receipt/'README.md').write_text(f'''# Windows global shortcut key translation

27 October 2026. Source `{commit}`. This follows the
[registration feedback receipt](../home-global-shortcut-feedback-20261027/README.md).
The legacy byte fallback could report success while registering a different key:
it interpreted punctuation as a Windows virtual-key number and truncated other
characters. The repaired module translates representable BMP characters through
the registration thread's startup keyboard layout and includes required Shift/
Ctrl/Alt modifiers. Unrepresentable characters, supplementary Unicode, surrogates
and unmapped special keys remain explicitly unavailable. ASCII letter matching
keeps the existing case-insensitive behavior. Explicit Windows mappings now cover
F13–F24, Menu/Print/Pause, browser keys and Volume Mute as well as existing keys.
Reserved F12 and unsupported Meta/Command remain unavailable.

Before r451 reproduces both defects: while the actual semicolon chord is reserved,
the old module reports active; U+10441 also reports active after its low byte
collapses to A. Both negative cases fail as intended, exit2, with all ending guards.
After r457, ten test functions pass with{native['native-global-key-mapping-r457']['passIncidents']}pass incidents,
zero failures/skips and exit0/all guards. The expanded test retains collision,
release/reacquisition, atom-reference cleanup and bounded-report checks. New cases
exercise punctuation, required layout modifiers, nontruncation and eight extended
key rows against actual Windows registration collisions. These tests reserve
chords without injecting keys or changing OS settings.

The first expanded positive run r453 passed the two repairs and seven extended
rows but could not reserve Ctrl+Alt+Shift+Tab. The final test accepts an existing
Windows error1409 as a real collision and then requires the module to report that
same collision; it does not skip the row or remove the existing owner's binding.
An intermediate r454 test build finished, then the implicit-modifier case was
added before its planned r455 run; r455 was not launched. The final run is r457.

Ordinary GUI441 with Windows-hotkeys452
`{record['runtimeSha256']['plugins/control/libwin_hotkeys_plugin.dll'][:8]}` uses the
identified existing Core265 tuple without private hooks. With a saved
Ctrl+Alt+Shift+semicolon Play/Pause mapping, the physical Finnish-layout
Ctrl+Alt+Shift+comma chord starts and pauses the one-hour generated WAV. Controls
shows one active global shortcut; the native editor names the semicolon mapping.
Its paused position remains `{hold}` across opening, inspection and Cancel.
The player exits0 with602plugins, zero checked errors and all source/runtime/base/
fixture/producer/cache guards. Native config and the complete profile catalogue
stay unchanged. The older GUI441 two-player/restart receipt retains its own tuple;
this module change does not silently replace its exact-binary evidence.

Immediate accessibility snapshots can lag the screen; settled observations07–09
establish the final status and retained clock. The startup layout is used until
restart. Live layout changes, other layouts, every shortcut/action, actual DPI,
screen-reader focus, full visual scoring, integrated regression, independent
review and clean-package/beta acceptance remain open. The setup tour was inspected:
its displayed bindings use local key-* mappings, not failed global-key-* bindings.
No new hint code was needed. No firewall/security/privacy/Defender settings changed.

Microsoft documents the character/layout/modifier result in
[VkKeyScanExW](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-vkkeyscanexw),
the actual key identifiers in
[Virtual-Key Codes](https://learn.microsoft.com/en-us/windows/win32/inputdev/virtual-key-codes),
and collision behavior in
[RegisterHotKey](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-registerhotkey).
`checkpoint.json` binds compressed evidence to original and compressed SHA-256;
decompression was verified. Generated media/binaries and isolated profiles remain
ignored. This is a frozen scoped record, not full S32 or beta acceptance.
''',encoding='utf-8')
print(json.dumps(dict(sourceCommit=commit,native=native,artifacts=len(inventory),compressedBytes=sum(i['compressedBytes'] for i in inventory))))
