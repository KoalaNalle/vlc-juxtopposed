#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-global-key-mapping-probe-r454.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-global-key-mapping-probe-r454-exit.txt"; exit "$code"' EXIT
out="$base/owned-global-key-mapping-probe-r454"
test ! -e "$out"
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = fdfcfcd599588512bb7f3a51e46305b7b0d947b47387dd205851feb45f032b46
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/modules/gui/qt/tests/native_library/global-hotkeys.mk" -j2 HOTKEYS_OUT="$out" global-hotkeys-native
sha256sum "$out/.libs/test_qt_global_hotkey_registration.exe"
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = fdfcfcd599588512bb7f3a51e46305b7b0d947b47387dd205851feb45f032b46
