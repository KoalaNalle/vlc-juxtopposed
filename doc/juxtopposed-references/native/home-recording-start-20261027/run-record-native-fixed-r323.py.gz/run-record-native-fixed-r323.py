from pathlib import Path
from hashlib import sha256
import ctypes, json, os, re, subprocess, sys
work=Path(__file__).resolve().parent; repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
manifest=read(work/'inputs-r323.json')
assert all(digest(repo/p)==h for p,h in manifest['files'].items())
base=work/'ui-customizer-draft-r304/runtime'
names=read(work/'ui-customizer-draft-r304/verification.json')['runtimeSha256']
assert all(digest(base/p)==h for p,h in names.items())
out=work/'native-record-fixed-r323'; assert not out.exists(); out.mkdir()
sys.path.insert(0,str(repo/'test/libvlc'))
from native_http_runtime import stage_runtime, environment
runtime=out/'runtime'; stage_runtime(base,runtime)
name='plugins/stream_out/libstream_out_record_plugin.dll'
original_record=digest(base/name)
target=runtime/name;target.unlink();import shutil
shutil.copyfile(work/'record-fixed-r322-bin/libstream_out_record_plugin.dll',target)
names[name]=digest(target)
media=work/'attachment-media-r85/Show.S01E01.mp4'; media_hash=digest(media)
producer_hash=digest(Path(__file__)); worker=work/'record-native-trace-r317.py'; worker_hash=digest(worker)
report=dict(status='running',fullBetaAccepted=False,privateRecord=False,runtimeSha256=names,cases={},sourceManifestSha256=digest(work/'inputs-r323.json'),mediaSha256=media_hash)
def save(): (out/'verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
save()
kernel=ctypes.WinDLL('kernel32'); previous=kernel.SetErrorMode(0x8003)
try:
    for mode in ['clean','seek','seek-no-sub']:
        target=out/mode
        envroot=out/(mode+'-environment');envroot.mkdir()
        env=environment(runtime,envroot);env.pop('VLC_PLUGIN_PATH',None)
        command=[sys.executable,str(worker),str(runtime),str(media),str(target),mode]
        with (out/(mode+'-stdout.txt')).open('wb') as stdout,(out/(mode+'-stderr.txt')).open('wb') as stderr:
            child=subprocess.Popen(command,cwd=runtime,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
            report['cases'][mode]=dict(pid=child.pid,status='running'); save()
            try: code=child.wait(timeout=90)
            except subprocess.TimeoutExpired:
                report['cases'][mode]['status']='timeout-process-left-running';save();raise SystemExit('Inspect owned PID; no automatic cleanup.')
        report['cases'][mode].update(status='terminal',exitCode=code,normalExit=code==0)
        if (target/'probe.json').is_file(): report['cases'][mode]['probe']=read(target/'probe.json')
        save(); print(mode,'exit',code,flush=True)
finally: kernel.SetErrorMode(previous)
report.update(status='terminal',sourceInputsUnchanged=all(digest(repo/p)==h for p,h in manifest['files'].items()),
 runtimeUnchanged=all(digest(runtime/p)==h for p,h in names.items()),baseRuntimeUnchanged=all(digest(base/p)==(original_record if p==name else h) for p,h in names.items()),
 mediaUnchanged=digest(media)==media_hash,producerUnchanged=digest(Path(__file__))==producer_hash,workerUnchanged=digest(worker)==worker_hash)
save(); print(json.dumps({k:v for k,v in report.items() if k.endswith('Unchanged')}),flush=True)
assert all(report[k] for k in report if k.endswith('Unchanged'))
assert all(case['normalExit'] for case in report['cases'].values())
