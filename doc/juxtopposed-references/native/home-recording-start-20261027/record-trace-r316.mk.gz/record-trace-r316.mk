RECORD_TRACE_OUT ?= /root/vlc-juxtopposed-build/owned-record-trace-r316
RECORD_TRACE_SOURCE = /mnt/c/Modding/vlc-juxtopposed/build-windows/beta-single-frame-20261025-night/record-trace-r316.c
$(RECORD_TRACE_OUT)/record.lo: $(RECORD_TRACE_SOURCE)
	mkdir -p $(RECORD_TRACE_OUT)
	$(LTCOMPILE) -c $(RECORD_TRACE_SOURCE) -o $@
$(RECORD_TRACE_OUT)/libstream_out_record_plugin.la: $(RECORD_TRACE_OUT)/record.lo
	$(LINK) $(am_libstream_out_record_plugin_la_rpath) $< $(libstream_out_record_plugin_la_LIBADD) $(LIBS)
.PHONY: owned-record-trace
owned-record-trace: $(RECORD_TRACE_OUT)/libstream_out_record_plugin.la
