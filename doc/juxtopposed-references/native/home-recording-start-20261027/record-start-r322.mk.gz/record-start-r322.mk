RECORD_FIXED_OUT ?= /root/vlc-juxtopposed-build/owned-record-fixed-r322
$(RECORD_FIXED_OUT)/record.lo: $(srcdir)/stream_out/record.c
	mkdir -p $(RECORD_FIXED_OUT)
	$(LTCOMPILE) -c $< -o $@
$(RECORD_FIXED_OUT)/libstream_out_record_plugin.la: $(RECORD_FIXED_OUT)/record.lo
	$(LINK) $(am_libstream_out_record_plugin_la_rpath) $< $(libstream_out_record_plugin_la_LIBADD) $(LIBS)
.PHONY: owned-record-fixed
owned-record-fixed: $(RECORD_FIXED_OUT)/libstream_out_record_plugin.la
