from pathlib import Path
from hashlib import sha256
import ctypes,json,shutil,subprocess,sys
work=Path(__file__).resolve().parent;repo=work.parents[1]
revision,label,binary,expected=sys.argv[1:];expected=int(expected);assert expected in [0,1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
manifest=work/f'inputs-{revision}.json';m=read(manifest)
assert all(digest(repo/p)==h and digest(Path(m['sourceCopies'][p]))==h for p,h in m['files'].items())
base=work/'ui-customizer-library-fixed-r311/runtime';protected=read(base.parent/'verification.json')['runtimeSha256']
assert all(digest(base/p)==h for p,h in protected.items())
out=work/label;assert not out.exists();out.mkdir()
sys.path.insert(0,str(repo/'test/libvlc'))
from native_http_runtime import stage_runtime,environment
runtime=out/'runtime';stage_runtime(base,runtime)
program=runtime/'test_record_start.exe';shutil.copyfile(work/binary/program.name,program)
exe_hash=digest(program)
record=dict(status='starting',scope='Direct production recording translation unit; buffered start-date calculation, not a decoder/output integration test.',fullBetaAccepted=False,
    sourceManifestSha256=digest(manifest),producerSha256=digest(Path(__file__)),testExecutableSha256=exe_hash,runtimeSha256=protected,expectedExitCode=expected,forcedCleanupUsed=False)
kernel=ctypes.WinDLL('kernel32',use_last_error=True);kernel.SetErrorMode.argtypes=[ctypes.c_uint];kernel.SetErrorMode.restype=ctypes.c_uint
previous=kernel.SetErrorMode(0x8003)
try:
    with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
        child=subprocess.Popen([str(program)],cwd=runtime,env=environment(runtime,out),stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        record.update(status='running',pid=child.pid);write(out/'verification.json',record)
        try:code=child.wait(timeout=30)
        except subprocess.TimeoutExpired:raise SystemExit('Inspect owned unit PID; no automatic cleanup/restart')
finally:kernel.SetErrorMode(previous)
rows=[json.loads(s) for s in (out/'stdout.txt').read_text().splitlines()]
record.update(status='terminal',exitCode=code,normalExit=code==0,rows=rows,
    sourceInputsUnchanged=all(digest(repo/p)==h for p,h in m['files'].items()),
    runtimeUnchanged=all(digest(base/p)==h and digest(runtime/p)==h for p,h in protected.items()),
    producerUnchanged=digest(Path(__file__))==record['producerSha256'],executableUnchanged=digest(program)==exe_hash)
write(out/'verification.json',record)
assert code==expected and len(rows)==12
assert rows[-1]['checks']==11 and rows[-1]['failures']==(3 if expected else 0)
assert all(record[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','producerUnchanged','executableUnchanged'])
print(json.dumps(dict(exitCode=code,expected=expected,rows=len(rows),passedRows=sum(r['passed'] for r in rows[:-1]),guards=True)),flush=True)
