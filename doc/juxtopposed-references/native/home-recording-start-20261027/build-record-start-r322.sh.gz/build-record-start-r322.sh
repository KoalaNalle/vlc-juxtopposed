#!/bin/bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-record-start-r322.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-record-start-r322-exit.txt"; exit "$code"' EXIT
core=fdfcfcd599588512bb7f3a51e46305b7b0d947b47387dd205851feb45f032b46
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = "$core"
test ! -e "$base/owned-record-start-fixed-r322"
test ! -e "$base/owned-record-fixed-r322"
make -C "$base/win64/test" -f Makefile -f "$repo/test/record-start-native.mk" -j2 RECORD_START_OUT="$base/owned-record-start-fixed-r322" owned-record-start
make -C "$base/win64/modules" -f Makefile -f "$work/record-start-r322.mk" -j2 owned-record-fixed
mkdir "$work/record-start-fixed-r322-bin" "$work/record-fixed-r322-bin"
cp "$base/owned-record-start-fixed-r322/.libs/test_record_start.exe" "$work/record-start-fixed-r322-bin/"
cp "$base/owned-record-fixed-r322/.libs/libstream_out_record_plugin.dll" "$work/record-fixed-r322-bin/"
sha256sum "$work/record-start-fixed-r322-bin/"* "$work/record-fixed-r322-bin/"*
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = "$core"
