#!/bin/bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-record-start-r320.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-record-start-r320-exit.txt"; exit "$code"' EXIT
out="$base/owned-record-start-before-r320"
test ! -e "$out"
make -C "$base/win64/test" -f Makefile -f "$repo/test/record-start-native.mk" -j2 RECORD_START_OUT="$out" owned-record-start
mkdir "$work/record-start-before-r320-bin"
cp "$out/.libs/test_record_start.exe" "$work/record-start-before-r320-bin/"
sha256sum "$work/record-start-before-r320-bin/"*
