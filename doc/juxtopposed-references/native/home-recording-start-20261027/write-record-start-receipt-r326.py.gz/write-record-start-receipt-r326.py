from pathlib import Path
from hashlib import sha256
import gzip,json,re
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
comparison=read(work/'recording-comparison-r325.json')
assert len(comparison['results'])==6
assert not comparison['results'][0]['decodedAV']
assert not any(r['alignedAV'] for r in comparison['results'][:2])
assert all(r['decodedAV'] and r['alignedAV'] for r in comparison['results'][2:])
before=read(work/'native-record-start-before-r321/verification.json')
fixed=read(work/'native-record-start-fixed-r322/verification.json')
assert before['exitCode']==1 and before['rows'][-1]==dict(checks=11,failures=3)
assert fixed['normalExit'] and fixed['rows'][-1]==dict(checks=11,failures=0)
for record in [before,fixed]:
    assert all(v for k,v in record.items() if k.endswith('Unchanged'))
for name in ['native-record-trace-r317','native-record-fixed-r323']:
    record=read(work/name/'verification.json')
    assert all(v for k,v in record.items() if k.endswith('Unchanged'))
    assert all(case['normalExit'] and case['probe']['stopState']==4 for case in record['cases'].values())
gui={name:read(work/name/'verification.json') for name in ['ui-record-trace-r317','ui-record-fixed-r323']}
for record in gui.values():
    assert record['normalExit'] and record['moduleCounts']==['602'] and not record['diagnostics']
    assert all(v for k,v in record.items() if k.endswith('Unchanged'))
assert gui['ui-record-trace-r317']['privateRecord']
assert not gui['ui-record-fixed-r323']['privateRecord']
out=repo/'doc/juxtopposed-references/native/home-recording-start-20261027'
assert not out.exists();out.mkdir()
traces={}
for name in ['native-record-trace-r317/clean','ui-record-trace-r317']:
    log=work/name/'vlc.log'
    traces[name]=dict(logSha256=digest(log),lines=[s for s in log.read_text(errors='replace').splitlines() if 'record-probe' in s])
assert any('common-start=19999001' in s for r in traces.values() for s in r['lines'])
assert any('chosen=9920001' in s for r in traces.values() for s in r['lines'])
(out/'timestamp-observations.json').write_text(json.dumps(traces,indent=2)+'\n',encoding='utf-8',newline='\n')
artifacts=[]
def retain(p):
    name=p.relative_to(work).as_posix()+'.gz';target=out/name;target.parent.mkdir(parents=True,exist_ok=True)
    raw=p.read_bytes();target.write_bytes(gzip.compress(raw,mtime=0))
    artifacts.append(dict(path=name,sha256=digest(target),rawSha256=sha256(raw).hexdigest()))
for name in ['native-record-start-before-r321','native-record-start-fixed-r322',
    'native-record-trace-r317','native-record-fixed-r323','ui-record-trace-r317','ui-record-fixed-r323']:
    root=work/name
    retain(root/'verification.json')
    for filename in ['producer.py','launch.json','staging.json','layout-fixture.json']:
        if (root/filename).is_file():retain(root/filename)
    for p in sorted(root.glob('*/probe.json')):retain(p)
    for p in sorted((root/'observations').glob('*')):
        if p.suffix in ['.json','.png']:retain(p)
    if name.startswith('native-record-start-'):retain(root/'stdout.txt')
for filename in ['inputs-r317.json','inputs-r320.json','inputs-r321.json','inputs-r322.json','inputs-r323.json',
    'prepare-record-trace-r316.py','record-trace-r316.c','record-trace-r316.mk','build-record-trace-r316.sh',
    'record-native-trace-r317.py','run-record-native-trace-r317.py','run-ui-record-trace-r317.py',
    'freeze-record-start-r318.py','build-record-start-r318.sh','build-record-start-r318-exit.txt',
    'build-record-start-r319.sh','build-record-start-r319-exit.txt',
    'build-record-start-r320.sh','build-record-start-r320-exit.txt','run-record-unit-r321.py',
    'record-start-r322.mk','build-record-start-r322.sh','build-record-start-r322-exit.txt',
    'run-record-native-fixed-r323.py','run-ui-record-fixed-r323.py','inspect-recordings-r325.py',
    'recording-comparison-r325.json','write-record-start-receipt-r326.py']:
    retain(work/filename)
result=dict(status='passed-scoped-sparse-subtitle-recording-start-repair',fullBetaAccepted=False,
    runtimeSha256=gui['ui-record-fixed-r323']['runtimeSha256'],
    sourceSha256={p:digest(repo/p) for p in ['modules/stream_out/record.c','test/modules/stream_out/record_start.c','test/record-start-native.mk']},
    nativeBefore=dict(checks=11,failed=3,expectedExit=1),nativeFixed=dict(checks=11,failed=0,exitCode=0),
    observations=[
        'Timestamp-only diagnostic module: the sparse subtitle packet at19999001 sets the old common start, ahead of the first retained video I-frame at9920001. That I-frame and the next at19920001 are discarded; video waits until29920001. The26-second native recording has no decoded video. The47.7-second desktop recording decodes but its video starts about9.91seconds after audio.',
        'Production OutputStartDate now computes the common start from accepted buffered audio/video streams when present. Sparse subtitles cannot advance it. Subtitle-only output retains the previous rule. Remaining OutputStart/OutputSend behavior is unchanged.',
        'Direct production calculation:8pass/3expectedfail before,11pass after. Cases cover sparse subtitles with AV/audio/multiplevideo, later audio alignment, subtitle-only, audio-only, missing DTS/PTS fallback, absent keyframes, rejected/empty streams and an empty recording.',
        'Ordinary GUI311/Core265/record322: arm paused0, Play, stop recording after28.3wallseconds while primary continues, then normal Quit. Independent FFmpeg decoding yields487video frames/19.48seconds and914audio frames/19.498667seconds. Stream starts differ0.021146seconds. App exits0/602modules/zero errors/all guards.',
        'Three actual public-API native recordings (clean, paused precise seek sequence, seek with subtitles disabled) stop normally and decode aligned AV. Each26-second recording yields431video frames/17.24seconds; audio/video starts differ0.021146seconds and durations differ0.002667seconds. Native outputs use dummy/software devices and do not replace ordinary desktop evidence.'
    ],limits=[
        'Compressed passthrough still starts at a usable keyframe, so this long-GOP fixture omits its initial seconds. This change repairs subtitle-driven extra loss/misalignment; it does not promise frame-exact recording from the clicked time, subtitle overlap reconstruction, every codec/container or final-package acceptance.',
        'The initial native calculation test build needed MODULE_STRING and a module-name definition; r318/r319 compilation/link failures remain local with their nonzero saved results. The later cross-libtool host-path warnings are retained locally; independently staged Windows executables run successfully. No failed build is promoted to a test pass.',
        'Diagnostic module08d00995 is timestamp-only instrumentation and is not the selected ordinary module930205b1. The GUI and Core stay unchanged by this recording build. Before/after outputs and full logs remain ignored locally; only owned captures, reports, source identities and sanitized timestamp lines are retained here.',
        'Full recording preferences, all media formats, accessibility/DPI, physical devices and consolidated final-package replay remain separate beta requirements. Only generated owned media was used. Security/privacy choices were unchanged.'
    ],artifacts=artifacts)
(out/'checkpoint.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Sparse subtitles and recording start - 27 October 2026

A subtitle packet queued near20seconds advanced the common recording start past
the first video keyframe. The next keyframe also fell before that start, leaving
short recordings without usable video and longer recordings misaligned.

The ordinary recording module now aligns audio/video using those streams when
present. Subtitle-only output retains its previous calculation. The direct
production regression fails three cases before and passes all eleven after.

A28.3-second ordinary desktop capture now decodes about19.5seconds of aligned
audio/video. Three native recordings also decode aligned AV; their starts differ
by about21milliseconds. The long-GOP source still needs a usable keyframe, so
this is not frame-exact recording from the clicked time. Original missing-video
and misalignment controls are retained separately.

See the [checkpoint](checkpoint.json) and sanitized
[timestamp observations](timestamp-observations.json) for exact identities and
limitations. This is a scoped recording repair, not complete beta acceptance.
Continue from [STATUS](../../../juxtopposed/STATUS.md).
''',encoding='utf-8',newline='\n')
for artifact in artifacts:
    p=out/artifact['path'];assert digest(p)==artifact['sha256']
    assert sha256(gzip.decompress(p.read_bytes())).hexdigest()==artifact['rawSha256']
print(out,len(artifacts),'verified artifacts',flush=True)
