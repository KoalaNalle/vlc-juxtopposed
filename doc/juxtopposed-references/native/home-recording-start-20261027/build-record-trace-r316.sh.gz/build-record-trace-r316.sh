#!/bin/bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
work=/mnt/c/Modding/vlc-juxtopposed/build-windows/beta-single-frame-20261025-night
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
exec > "$work/build-record-trace-r316.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-record-trace-r316-exit.txt"; exit "$code"' EXIT
test ! -e "$base/owned-record-trace-r316"
test ! -e "$work/record-trace-r316-bin"
make -C "$base/win64/modules" -f Makefile -f "$work/record-trace-r316.mk" -j2 owned-record-trace
mkdir "$work/record-trace-r316-bin"
cp "$base/owned-record-trace-r316/.libs/libstream_out_record_plugin.dll" "$work/record-trace-r316-bin/"
sha256sum "$work/record-trace-r316-bin/"*
