from pathlib import Path
work=Path(__file__).resolve().parent; repo=work.parents[1]
source=(repo/'modules/stream_out/record.c').read_text(encoding='utf-8')
def replace(old,new):
    global source
    assert source.count(old)==1,old
    source=source.replace(old,new)
replace('    OutputSend( p_stream, id, p_buffer );', '''    sout_stream_id_sys_t *diag_id = id;
    if( !p_sys->p_out && !diag_id->p_first )
        msg_Info( p_stream, "record-probe first cat=%d dts=%lld pts=%lld flags=%x", diag_id->fmt.i_cat,
                  (long long)p_buffer->i_dts, (long long)p_buffer->i_pts, p_buffer->i_flags );
    OutputSend( p_stream, id, p_buffer );''')
replace('''        if( i_dts > p_sys->i_dts_start )
            p_sys->i_dts_start = i_dts;''', '''        msg_Info( p_stream, "record-probe start cat=%d head=%lld chosen=%lld found-I=%d",
                  id->fmt.i_cat, (long long)BlockTick(id->p_first), (long long)i_dts,
                  p_block != NULL );
        if( i_dts > p_sys->i_dts_start )
            p_sys->i_dts_start = i_dts;''')
replace('''    sout_stream_id_sys_t *p_cand;
    vlc_tick_t canddts;''', '''    msg_Info( p_stream, "record-probe common-start=%lld", (long long)p_sys->i_dts_start );
    sout_stream_id_sys_t *p_cand;
    vlc_tick_t canddts;''')
replace('''                id->b_wait_key = false;
                id->b_wait_start = false;''', '''                msg_Info( p_stream, "record-probe first-kept-I cat=%d dts=%lld", id->fmt.i_cat, (long long)p_block->i_dts );
                id->b_wait_key = false;
                id->b_wait_start = false;''')
target=work/'record-trace-r316.c'; assert not target.exists()
target.write_text(source,encoding='utf-8',newline='\n')
make='''RECORD_TRACE_OUT ?= /root/vlc-juxtopposed-build/owned-record-trace-r316
RECORD_TRACE_SOURCE = /mnt/c/Modding/vlc-juxtopposed/build-windows/beta-single-frame-20261025-night/record-trace-r316.c
$(RECORD_TRACE_OUT)/record.lo: $(RECORD_TRACE_SOURCE)
\tmkdir -p $(RECORD_TRACE_OUT)
\t$(LTCOMPILE) -c $(RECORD_TRACE_SOURCE) -o $@
$(RECORD_TRACE_OUT)/libstream_out_record_plugin.la: $(RECORD_TRACE_OUT)/record.lo
\t$(LINK) $(am_libstream_out_record_plugin_la_rpath) $< $(libstream_out_record_plugin_la_LIBADD) $(LIBS)
.PHONY: owned-record-trace
owned-record-trace: $(RECORD_TRACE_OUT)/libstream_out_record_plugin.la
'''
(work/'record-trace-r316.mk').write_text(make,encoding='utf-8',newline='\n')
script='''#!/bin/bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
work=/mnt/c/Modding/vlc-juxtopposed/build-windows/beta-single-frame-20261025-night
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
exec > "$work/build-record-trace-r316.log" 2>&1
trap 'code=$?; printf "%s\\n" "$code" > "$work/build-record-trace-r316-exit.txt"; exit "$code"' EXIT
test ! -e "$base/owned-record-trace-r316"
test ! -e "$work/record-trace-r316-bin"
make -C "$base/win64/modules" -f Makefile -f "$work/record-trace-r316.mk" -j2 owned-record-trace
mkdir "$work/record-trace-r316-bin"
cp "$base/owned-record-trace-r316/.libs/libstream_out_record_plugin.dll" "$work/record-trace-r316-bin/"
sha256sum "$work/record-trace-r316-bin/"*
'''
(work/'build-record-trace-r316.sh').write_text(script,encoding='utf-8',newline='\n')
print(target,flush=True)
