from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json, re
work = Path(__file__).resolve().parent
repo = work.parents[1]
digest = lambda p: sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
manifest = work / 'inputs-r388.json'
inputs = read(manifest)
run = work / 'ui-music-nav-fixed-r388'
record = read(run / 'verification.json')
changed = [name for name, identity in inputs['files'].items()
    if digest(repo / name) != identity]
runtime_changed = [name for name, identity in record['runtimeSha256'].items()
    if digest(run / 'runtime' / name) != identity]
assert not changed and not runtime_changed
logs = '\n'.join((run / name).read_text(encoding='utf-8', errors='replace')
    for name in ['vlc.log', 'stderr.txt'])
diagnostics = [line for line in logs.splitlines()
    if re.search(r'\berror:|Assertion failed|Binding loop|ReferenceError|TypeError', line)]
assert not diagnostics
out = work / 'music-navigation-blocked-r394.json'
assert not out.exists()
out.write_text(json.dumps(dict(
    observedUtc=datetime.now(timezone.utc).isoformat(),
    status='blocked-on-manual-firewall-prompt', fullBetaAccepted=False,
    ownedVlcPid=12004, ownedObserverSession=67491,
    observedLiveAt='2026-10-27T08:44:42+02:00',
    normalExitNotYetObserved=True, forcedCleanupUsed=False,
    sourceManifestSha256=digest(manifest), sourceInputCount=len(inputs['files']),
    sourceInputsUnchangedBeforeCheckpoint=not changed,
    runtimeUnchangedBeforeCheckpoint=not runtime_changed,
    checkedDiagnosticCount=len(diagnostics),
    moduleCounts=re.findall(r'plug-ins loaded: (\d+) modules', logs),
    previousStatusSha256=digest(repo / 'doc/juxtopposed/STATUS.md'),
    expectedAdministrativeChange=['doc/juxtopposed/STATUS.md'],
    checkpointEffect='Replacing STATUS to record this block changes one inventoried document. The running observer may later report sourceInputsUnchanged=false for that expected documentation change; do not claim its ending guards passed. Production files and runtime were unchanged at this audit. Inspect the exact final delta and qualify a fresh bounded final run after manual dismissal before the nightly push.',
    recovery='Inspect the same process/session before restarting anything. Dismissal belongs to the owner. Reobserve VLC, finish or normally close the owned test, inspect the producer result and preserve any administrative guard failure explicitly.',
    pendingCommitPush=True, headerReview='music-source-header-review-r393',
    sourceReviewOnly=True, producerSha256=digest(Path(__file__)),
), indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(dict(saved=out.name, sourceInputs=len(inputs['files']),
    sourceInputsUnchanged=True, runtimeUnchanged=True, checkedDiagnostics=0)))
