from pathlib import Path
from hashlib import sha256
import ctypes as C, json, re, shutil
from datetime import datetime, timezone
work = Path(__file__).resolve().parent
repo = work.parents[1]
run = work / 'ui-music-nav-fixed-r388'
out = work / 'navigation-exit-recovery-r395'
out.mkdir(exist_ok=False)
digest = lambda p: sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
initial = read(run / 'verification.json')
inputs = read(work / 'inputs-r388.json')
kernel = C.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [C.c_uint, C.c_bool, C.c_uint]
kernel.OpenProcess.restype = C.c_void_p
kernel.QueryFullProcessImageNameW.argtypes = [C.c_void_p,C.c_uint,C.c_wchar_p,C.POINTER(C.c_uint)]
kernel.QueryFullProcessImageNameW.restype = C.c_bool
kernel.WaitForSingleObject.argtypes = [C.c_void_p,C.c_uint]
kernel.WaitForSingleObject.restype = C.c_uint
kernel.GetExitCodeProcess.argtypes = [C.c_void_p,C.POINTER(C.c_uint)]
kernel.GetExitCodeProcess.restype = C.c_bool
kernel.CloseHandle.argtypes = [C.c_void_p]
handle = kernel.OpenProcess(0x101000, False, 12004)
assert handle, C.get_last_error()
record = dict(status='observing-existing-process', pid=12004,
    fullBetaAccepted=False, forcedCleanupUsed=False,
    originalObserverTimedOut=True, originalReportSha256=digest(run/'verification.json'),
    inputManifestSha256=digest(work/'inputs-r388.json'),
    producerSha256=digest(Path(__file__)), startedUtc=datetime.now(timezone.utc).isoformat())
def save(): (out/'verification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
try:
    path = C.create_unicode_buffer(32768); size = C.c_uint(len(path))
    assert kernel.QueryFullProcessImageNameW(handle, 0, path, C.byref(size))
    assert Path(path.value).resolve() == (run/'runtime/vlc.exe').resolve()
    record['observedExecutable']=path.value
    assert kernel.WaitForSingleObject(handle, 0) == 258
    save(); print('Observing existing VLC PID12004 for normal exit',flush=True)
    wait = kernel.WaitForSingleObject(handle, 180000)
    if wait == 258:
        record['status']='observation-timeout-process-left-running';save()
        raise SystemExit('Inspect same process; no cleanup or restart performed')
    assert wait == 0
    code = C.c_uint(); assert kernel.GetExitCodeProcess(handle, C.byref(code))
    record.update(status='terminal',exitCode=code.value,normalExit=code.value==0,
        endedUtc=datetime.now(timezone.utc).isoformat())
finally:
    kernel.CloseHandle(handle)
logs='\n'.join((run/name).read_text(encoding='utf-8',errors='replace')
    for name in ['vlc.log','stderr.txt'])
changed=[name for name,h in inputs['files'].items() if digest(repo/name)!=h]
record.update(changedInventoriedFiles=changed,
    onlyExpectedStatusChange=changed==['doc/juxtopposed/STATUS.md'],
    runtimeUnchanged=all(digest(run/'runtime'/name)==h for name,h in initial['runtimeSha256'].items()),
    originalReportUnchanged=digest(run/'verification.json')==record['originalReportSha256'],
    producerUnchanged=digest(Path(__file__))==record['producerSha256'],
    moduleCounts=re.findall(r'plug-ins loaded: (\d+) modules',logs),
    diagnostics=[line for line in logs.splitlines() if re.search(r'\berror:|Assertion failed|Binding loop|ReferenceError|TypeError',line)])
save()
print(json.dumps({k:record[k] for k in ['status','exitCode','normalExit','onlyExpectedStatusChange','runtimeUnchanged','moduleCounts']}),flush=True)
assert record['normalExit'] and record['onlyExpectedStatusChange'] and record['runtimeUnchanged']
assert record['originalReportUnchanged'] and record['producerUnchanged'] and not record['diagnostics']
