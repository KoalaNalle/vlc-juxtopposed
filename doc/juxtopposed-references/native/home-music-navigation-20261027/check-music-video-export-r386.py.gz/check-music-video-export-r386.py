from pathlib import Path
from hashlib import sha256
import json, os
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
from PySide6.QtCore import QRectF
from PySide6.QtGui import QGuiApplication, QImage, QPainter
from PySide6.QtSvg import QSvgRenderer
app = QGuiApplication([])
work = Path(__file__).resolve().parent
repo = work.parents[1]
out = work / 'music-video-export-check-r386'
out.mkdir(exist_ok=False)
rows = []
for name, path in [
    ('export', work / 'figma-video-correct-r385/1b0f7.svg'),
    ('existing', repo / 'modules/gui/qt/pixmaps/juxtopposed/sidebar-videos-7c4e4.svg')]:
    renderer = QSvgRenderer(str(path))
    assert renderer.isValid()
    image = QImage(240, 240, QImage.Format_ARGB32)
    image.fill(0xff191919)
    painter = QPainter(image)
    renderer.render(painter, QRectF(0, 0, 240, 240))
    painter.end()
    assert image.save(str(out / (name + '.png')))
    rows.append(dict(name=name, sourceSha256=sha256(path.read_bytes()).hexdigest(),
        defaultSize=[renderer.defaultSize().width(), renderer.defaultSize().height()],
        renderSha256=sha256(bytes(image.constBits())).hexdigest()))
(out / 'comparison.json').write_text(json.dumps(rows, indent=2)+'\n', encoding='utf-8')
print(json.dumps(rows))
