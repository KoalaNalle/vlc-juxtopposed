from pathlib import Path
work=Path(__file__).resolve().parent
source=(work/'build-music-sidebar-r349.sh').read_text(encoding='utf-8').replace('r349','r384').replace('owned-music-sidebar','owned-music-navigation').replace('build-music-sidebar','build-music-navigation')
(work/'build-music-navigation-r384.sh').write_text(source,encoding='utf-8',newline='\n')
source=(work/'run-ui-music-toolbar-cold-r360.py').read_text(encoding='utf-8').replace('ordinary-r357-bin','ordinary-r384-bin').replace('GUI357','GUI384')
start=source.index("scope='Ordinary recording322/");end=source.index("')\nkernel=",start)
source=source[:start]+"scope='Ordinary GUI384 shared music navigation on Core265/library282/recording322. Check rail Add, six destinations/artwork, single active native pin handler, source-panel independence, short focus/scroll and cold/media transitions. Generated owned media and isolated saved native defaults; no network/security/privacy changes."+source[end:]
(work/'run-ui-music-navigation-r384.py').write_text(source,encoding='utf-8',newline='\n')
source=(work/'freeze-music-toolbar-r360.py').read_text(encoding='utf-8')
anchor="names.add('modules/control/globalhotkeys/win32.c')"
source=source.replace(anchor,anchor+"\nnames.update(p.relative_to(repo).as_posix() for p in (work/'figma-music-navigation-r372').glob('*.svg'))\nnames.update('build-windows/beta-single-frame-20261025-night/'+name for name in ['music-navigation-high-fidelity-r379.json','music-navigation-asset-renders-r374.json'])")
(work/'freeze-music-navigation-r384.py').write_text(source,encoding='utf-8',newline='\n')
