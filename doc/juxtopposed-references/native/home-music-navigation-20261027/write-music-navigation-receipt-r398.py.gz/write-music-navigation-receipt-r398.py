from pathlib import Path
from hashlib import sha256
import gzip, json, re, xml.etree.ElementTree as ET
work = Path(__file__).resolve().parent
repo = work.parents[1]
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda p: sha256(p.read_bytes()).hexdigest()
runs = ['ui-music-nav-fixed-r384', 'ui-music-nav-fixed-r388', 'ui-music-nav-final-r397']
records = {name: read(work/name/'verification.json') for name in runs}
for name in [runs[0], runs[2]]:
    record = records[name]
    assert record['normalExit'] and record['moduleCounts'] == ['602'] and not record['diagnostics']
    assert all(value for key, value in record.items() if key.endswith('Unchanged'))
assert records[runs[1]]['status'] == 'observation-timeout-process-left-running'
recovery = read(work/'navigation-exit-recovery-r395/verification.json')
assert recovery['normalExit'] and recovery['exitCode'] == 0
assert recovery['onlyExpectedStatusChange'] and recovery['runtimeUnchanged'] and not recovery['diagnostics']
assert recovery['originalReportUnchanged'] and recovery['producerUnchanged']
before = read(work/'component-music-nav-before-r382/verification.json')
fixed = read(work/'component-music-nav-final-r391/verification.json')
assert before['negativeBaselineReproduced'] and fixed['normalExit']
assert before['sourceInputsUnchanged'] and fixed['sourceInputsUnchanged']
assert before['helperSha256'] == fixed['helperSha256'] == digest(work/'run-component-music-navigation-r382.py')
assert before['sourceSha256']['modules/gui/qt/tests/test_juxtopposed_music_player.py'] == fixed['sourceSha256']['modules/gui/qt/tests/test_juxtopposed_music_player.py']
assert all(digest(repo/name) == value for name, value in fixed['sourceSha256'].items())

def tree(run, name):
    return read(work/run/'observations'/name)['accessibility']['tree']

def progress(run, name):
    return float(re.search(r'Progress Value: ([0-9.eE+-]+)', tree(run, name))[1])

assert progress(runs[2], '01-cold-music-pin.json') == progress(runs[2], '03-cold-pin-folder-settled.json') == 0
assert progress(runs[2], '05-home-while-playing.json') > 0
assert progress(runs[2], '10-pointer-pause-settled.json') > progress(runs[2], '05-home-while-playing.json')
returned = tree(runs[2], '17-audio-return-held-single-pane.json')
assert returned.count('Library navigation ID:') == 1 and 'Music player ID:' in returned
assert 'button (settable, string) Play ID:' in returned
assert 'musicSourceName' in returned and 'juxtopposedSidebarPin0' in returned
asset = repo/'modules/gui/qt/pixmaps/juxtopposed/music-navigation-music-8b7f6.svg'
assert asset.read_bytes() == (work/'figma-music-navigation-r372/8b7f6.svg').read_bytes()
root = ET.parse(asset).getroot()
assert root.get('width') == root.get('height') == '24'
assert not (repo/'modules/gui/qt/pixmaps/juxtopposed/music-navigation-video-1b0f7.svg').exists()
assert digest(work/'figma-video-correct-r385/1b0f7.svg') == '75b1efc01fbf135aafec9e8d89201da74b33fef70b0ab35a0e89d83e8ef7e9c7'
out = repo/'doc/juxtopposed-references/native/home-music-navigation-20261027'
assert not out.exists()
out.mkdir()
artifacts = []

def retain(path):
    name = path.relative_to(work).as_posix() + '.gz'
    destination = out/name
    destination.parent.mkdir(parents=True, exist_ok=True)
    raw = path.read_bytes()
    destination.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(destination.read_bytes()) == raw
    artifacts.append(dict(path=name, sha256=digest(destination), rawSha256=sha256(raw).hexdigest()))

for run in runs:
    for name in ['verification.json', 'producer.py', 'launch.json', 'staging.json', 'layout-fixture.json']:
        retain(work/run/name)
    allowed = (set(['01','02','05','06','07','08','09','10','11','12','13','14']) if run == runs[0]
        else set(['01','02','03','04','05','06','07','08','10','11','12','13']) if run == runs[1]
        else {f'{i:02}' for i in range(1, 18)})
    for path in sorted((work/run/'observations').iterdir()):
        if path.suffix in ['.json', '.png'] and path.name[:2] in allowed:
            retain(path)
for name in ['component-music-nav-before-r382', 'component-music-nav-fixed-r383', 'component-music-nav-final-r391']:
    for filename in ['verification.json', 'stdout.txt', 'stderr.txt']:
        retain(work/name/filename)
    for path in sorted((work/name/'captures').glob('*.json')):
        retain(path)
for name in ['inputs-r384.json','inputs-r388.json','inputs-r397.json',
    'run-component-music-navigation-r382.py','prepare-music-navigation-r384.py',
    'prepare-music-navigation-r388.py','freeze-music-navigation-r384.py',
    'build-music-navigation-r384.sh','build-music-navigation-r384-exit.txt',
    'build-music-navigation-r388.sh','build-music-navigation-r388-exit.txt',
    'run-ui-music-navigation-r384.py','run-ui-music-navigation-r388.py',
    'music-navigation-high-fidelity-r379.json','music-navigation-asset-renders-r374.json',
    'figma-video-correct-r385/1b0f7.svg','check-music-video-export-r386.py',
    'music-video-export-check-r386/comparison.json','music-video-export-check-r386/export.png',
    'music-video-export-check-r386/existing.png','observe-navigation-exit-r395.py',
    'navigation-exit-recovery-r395/verification.json','audit-blocked-navigation-r394.py',
    'music-navigation-blocked-r394.json','music-source-header-review-r393/design-context.json',
    'music-source-header-review-r393/source-identities.json','write-music-navigation-receipt-r398.py']:
    retain(work/name)
checkpoint = dict(status='passed-scoped-ordinary-music-navigation-repair', fullBetaAccepted=False,
    runtimeSha256=records[runs[2]]['runtimeSha256'], sourceSha256=fixed['sourceSha256'],
    ordinaryExitCodes={runs[0]:0,runs[1]:'original observer timed out; separate exact-process recovery exit0',runs[2]:0},
    newArtwork=dict(path=asset.relative_to(repo).as_posix(), sha256=digest(asset), rootDimensions=[24,24], mirror=True,
        designNode='I4778:25149;4778:24994', exportedFilename='8b7f6.svg', unchangedOriginalExport=True),
    observations=[
        'The earlier GUI357 ordinary review retained in home-home-navigation-review-20261027 finds an inert music rail Add and a partial four-route list. The maintained new geometry/seam component regression fails the50px assertion on the old production component and passes after, with the same test and helper.',
        'The music presentation now loads the established service-backed JuxtopposedNavigationPane, inheriting all six destinations, native Add/pins and availability. Only the active music or video player pane owns its native pin callbacks. Music uses the original50px rail and377px wide source panel; the existing standalone component seam remains supported.',
        'GUI384 opens rail Add, chooses Folder through the real native picker, persists My Songs, opens its generated contents and returns to the same paused0 track. Home, Recent, Videos and Music open without starting that paused track. Source-panel Add remains a distinct queue action.',
        'Visual inspection rejects GUI384 because Figma design context names1b0f7.svg for Videos but the instructed download renders a gear. A fresh child context renders the expected folder/play screenshot while returning that same gear asset. The existing original sidebar-videos-7c4e4.svg matches the reference render and is reused. The filled Music original8b7f6.svg with its authored mirror is added unchanged; unrelated sidebar assets stay intact.',
        'GUI388 cold startup restores the folder pin. Wheel scrolling and Up/Down keyboard movement keep pin, Add and wrapped Home visible in602x421. Rail Add opens its menu; separate source-panel Add opens the file chooser, and Cancel retains paused0. Playlists remains paused. Network opens while music advances, then Windows presents a firewall prompt.',
        'The owner dismisses that prompt with Cancel. Original observer67491 had already timed out and is retained as an inconclusive producer, not a pass. A separate read-only process handle validates the exact still-running executable and then observes normal Ctrl+Q exit0. Runtime and original timeout report remain unchanged; STATUS is the sole expected administrative source difference. No forced cleanup is used.',
        'Fresh inputs-r397 final run uses the same corrected GUI388. Its saved pin opens My Songs after restart at paused0; returning and playing music, opening Home and returning retain the media and advance the clock. Pointer Pause holds. Next starts the queued generated video; the existing video drawer still opens with the pin. Previous returns to music with one visible inline navigation pane and the retained pin. Pointer Pause again holds, then normal Quit exits0.',
        'GUI384 and the fresh GUI388 final run each exit0 with602plugins, zero checked diagnostics and every ending source/runtime/base/fixture/helper/cache guard true. The final maintained music component test passes on the final source; the shared-navigation test separately reports route/focus/unavailable-library/scaled-layout success. These supplied-component tests do not qualify native services or OS-DPI.'
    ], limits=[
        'This is a nightly-scoped navigation repair, not full S11/S28 or beta acceptance. Music source header and title-strip context, whole-screen visual scoring, themes, actual Windows DPI, screen-reader behavior, all pin descriptor/reorder/error combinations and final-package acceptance remain separate.',
        'All seven rail slot references were compared with the cached original navigation subtree. New Music and reused Videos are checked against rendered design/native state; the rejected gear export remains evidence, not a runtime asset. The new navigation pane is neutral in the player while library selection styling remains unchanged.',
        'Immediate media/view/accessibility captures can show the preceding UI or transient0 clock. Settled captures establish the current state; no bounded transition latency or complete queue equality is claimed. Space pressed during the return transition did not establish Pause, so this receipt qualifies the explicit pointer Pause and does not claim transition-time keyboard acceptance. Accessible focus text can lag actual keyboard focus; visual keyboard outlines and component focus tests have narrower scopes.',
        'The Alt+Left probe in the existing browse-tree page showed no visible back navigation; this does not qualify Back/Forward and remains part of the separate header/navigation review. Single active player pin ownership is additionally established by the production activeSurface predicates; no private runtime handler counter was added.',
        'Native chooser and Network/security captures containing personal shell metadata, raw configurations, databases, media, binaries and personal logs stay ignored. The owner handled the only prompt in these runs. No firewall rules, dependencies or security/privacy settings were added or changed for this receipt.'
    ], artifacts=artifacts)
(out/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Music navigation rail -27 October2026

The music player now reuses the native shared navigation pane: Home/Recent and
the other destinations, working Add/pins, original artwork and a50px rail with
a377px wide source panel. The hidden video pane yields native pin callbacks to
the active music presentation.

The maintained component regression fails before and passes after. Ordinary
checks cover a real saved folder pin, restart, short-window wheel/keyboard
navigation, independent Add actions, library destinations, paused/playing media
and audio/video drawer transitions. The fresh final run exits0 with602plugins,
no checked errors and every ending guard true.

The [checkpoint](checkpoint.json) preserves the intermediate wrong-icon finding,
Figma export/render discrepancy, firewall observation timeout and separate normal
exit recovery. These are retained separately from the fresh accepted final run.
Raw personal chooser/Network/security captures are excluded.

Full player/header fidelity, accessibility, Windows DPI, all pin variants and
final-package gates remain open. Continue from [STATUS](../../../juxtopposed/STATUS.md).
''',encoding='utf-8',newline='\n')
print(str(out),len(artifacts),'verified artifacts')
