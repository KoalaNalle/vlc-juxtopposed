from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
work=Path(__file__).resolve().parent;repo=work.parents[1]
label,mode=sys.argv[1:];assert mode in ['before','fixed']
out=work/label;assert not out.exists();out.mkdir()
names=['modules/gui/qt/tests/test_juxtopposed_music_player.py','modules/gui/qt/player/qml/JuxtopposedMusicPlayer.qml','modules/gui/qt/player/qml/Player.qml','modules/gui/qt/maininterface/qml/JuxtopposedNavigationPane.qml']
digest=lambda p:sha256(p.read_bytes()).hexdigest()
sources={name:digest(repo/name) for name in names}
with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
    child=subprocess.run([sys.executable,str(repo/names[0]),'--output-dir',str(out/'captures')],cwd=repo,stdout=stdout,stderr=stderr,timeout=90)
errors=(out/'stderr.txt').read_text(encoding='utf-8',errors='replace')
record=dict(exitCode=child.returncode,normalExit=child.returncode==0,mode=mode,sourceSha256=sources,
    sourceInputsUnchanged=all(digest(repo/name)==h for name,h in sources.items()),helperSha256=digest(Path(__file__)),fullBetaAccepted=False,
    negativeBaselineReproduced=mode=='before' and child.returncode==1 and 'Music rail must retain the original 50px width' in errors)
(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
assert record['sourceInputsUnchanged']
assert record['negativeBaselineReproduced'] if mode=='before' else record['normalExit']
print(json.dumps(record))
