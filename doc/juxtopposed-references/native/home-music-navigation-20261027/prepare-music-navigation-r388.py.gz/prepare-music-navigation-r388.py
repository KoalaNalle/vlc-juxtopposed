from pathlib import Path
work = Path(__file__).resolve().parent
for source, target, replacements in [
    ('build-music-navigation-r384.sh', 'build-music-navigation-r388.sh', [('r384', 'r388')]),
    ('run-ui-music-navigation-r384.py', 'run-ui-music-navigation-r388.py', [('ordinary-r384-bin', 'ordinary-r388-bin'), ('GUI384', 'GUI388')]),
]:
    path = work / target
    assert not path.exists()
    data = (work / source).read_text(encoding='utf-8')
    for old, new in replacements:
        data = data.replace(old, new)
    path.write_text(data, encoding='utf-8', newline='\n')
