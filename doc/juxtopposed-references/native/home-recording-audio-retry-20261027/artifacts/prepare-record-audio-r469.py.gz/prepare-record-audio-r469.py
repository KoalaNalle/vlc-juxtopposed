from pathlib import Path
from hashlib import sha256
import json,subprocess

work=Path(__file__).resolve().parent
out=work/'record-audio-media-r469';assert not out.exists();out.mkdir()
source=work/'music-media-r273/My Songs/1-First light.flac'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
before=digest(source)
prefix=['wsl.exe','-d','VLC-Juxtopposed-Home-20261018','--exec']
linux=lambda p:'/mnt/c/'+p.as_posix().split(':/',1)[1]
commands=[]
for extension,codec in [('wav','pcm_s16le'),('flac','flac'),('mp3','libmp3lame')]:
    target=out/('owned-record-audio.'+extension)
    command=prefix+['/usr/bin/ffmpeg','-hide_banner','-v','error','-nostdin','-n','-i',linux(source),
       '-map','0:a:0','-map_metadata','-1','-vn','-c:a',codec,'-ar','44100','-ac','1',linux(target)]
    result=subprocess.run(command,capture_output=True,text=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    commands.append(dict(command=command,exitCode=result.returncode,stderr=result.stderr))
    assert result.returncode==0,result.stderr
    probe=subprocess.run(prefix+['/usr/bin/ffprobe','-v','error','-show_streams','-show_format','-of','json',linux(target)],capture_output=True,text=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
    assert probe.returncode==0,probe.stderr
    (out/(extension+'-probe.json')).write_text(probe.stdout,encoding='utf-8')
assert digest(source)==before
record=dict(generatedOnly=True,sourceSha256=before,sourceUnchanged=True,commands=commands,
            files={p.name:digest(p) for p in out.iterdir() if p.is_file()},fullBetaAccepted=False)
(out/'fixture.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
worker=(work/'record-overlap-worker-r460.py').read_text(encoding='utf-8')
start=worker.index("    report['recordStartTime']=get_time(player)")
end=worker.index('\nfinally:',start)
worker=worker[:start]+'''    report['segments']=[]
    for index in range(2):
        before=get_time(player)
        record(player,True,str(records).encode('utf-8')); time.sleep(.3)
        armed=get_time(player)
        assert abs(armed-before)<50_000, 'Arming recording advanced a paused clock'
        pause(player,0); wait(lambda:state(player)==2,5,'playing deadline')
        time.sleep(8)
        ending=get_time(player)
        record(player,False,str(records).encode('utf-8')); time.sleep(.3)
        pause(player,1); wait(lambda:state(player)==3,5,'pause deadline')
        held=get_time(player);time.sleep(.3)
        assert abs(get_time(player)-held)<50_000, 'Paused clock did not hold after recording'
        report['segments'].append(dict(index=index,start=before,armed=armed,recordStop=ending,paused=held))
'''+worker[end:]
(work/'record-audio-worker-r469.py').write_text(worker,encoding='utf-8',newline='\n')
print(json.dumps(dict(fixtures=list(record['files']),sourceUnchanged=True)))
