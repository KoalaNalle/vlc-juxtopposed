from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess

work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
receipt=repo/'doc/juxtopposed-references/native/home-recording-audio-retry-20261027'
assert not receipt.exists()
manifest=read(work/'inputs-r472.json');assert all(digest(repo/p)==h for p,h in manifest['files'].items())
audio=read(work/'native-record-audio-r470/verification.json')
retry=read(work/'native-record-retry-r472/verification.json')
for record in [audio,retry]:
    assert record['status']=='terminal' and record['passed']
    assert all(v for k,v in record.items() if k.endswith('Unchanged'))
    assert all(c['normalExit'] for c in record['cases'].values())
assert audio['runtimeSha256']==retry['runtimeSha256']
rows=[]
for name,case in audio['cases'].items():
    assert len(case['outputs'])==2
    for index,output in enumerate(case['outputs']):
        assert output['decodeExit']==output['probeExit']==0 and not output['decodeStderr']
        rows.append(dict(input=name,segment=index+1,codec=output['probe']['streams'][0]['codec_name'],
            pcmSamples=output['decodedPcmSamples'],decodedSeconds=output['decodedSeconds'],
            observedPlaybackSeconds=output['observedPlaybackSeconds'],
            absoluteClockDifference=abs(output['decodedSeconds']-output['observedPlaybackSeconds'])))
assert retry['cases']['wav']['probe']['blockedMarkerUnchanged']
assert len(retry['cases']['wav']['outputs'])==1
text=(work/'native-record-retry-r472/wav/vlc.log').read_text(encoding='utf-8',errors='replace')
assert 'record error: failed to open output' in text and 'file access output opened' in text
assert not any('error:' in (work/'native-record-audio-r470'/name/'vlc.log').read_text(encoding='utf-8',errors='replace') for name in audio['cases'])
analysis=dict(passed=True,audioOutputs=rows,maxClockDifference=max(r['absoluteClockDifference'] for r in rows),
    retryPrimarySurvived=True,retrySamePlayerDecoded=True,blockedMarkerUnchanged=True,
    endingGuardsPassed=True,ordinaryErrorFeedbackAccepted=False,strictSampleBoundaryAccepted=False,
    strictConversionTailAccepted=False,fullBetaAccepted=False,firewallRuleChanges=[],securityPrivacyChanges=[])
(work/'record-audio-retry-analysis-r473.json').write_text(json.dumps(analysis,indent=2)+'\n',encoding='utf-8')
names=['inputs-r470.json','inputs-r472.json','prepare-record-audio-r469.py','record-audio-worker-r469.py',
    'prepare-record-retry-r472.py','record-retry-worker-r472.py','freeze-record-overlap-r462.py',
    'record-audio-retry-analysis-r473.json','write-record-audio-receipt-r473.py']
files=[work/name for name in names]
files.extend(p for p in (work/'record-audio-media-r469').iterdir() if p.suffix=='.json')
for run,cases in [('native-record-audio-r470',['wav','flac','mp3']),('native-record-retry-r472',['wav'])]:
    files.extend(work/run/name for name in ['producer.py','verification.json'])
    for case in cases:
        files.extend(work/run/(case+suffix) for suffix in ['-stdout.txt','-stderr.txt'])
        files.extend(work/run/case/name for name in ['probe.json','vlc.log','vlcrc'])
files.append(work/'native-record-retry-r472/wav/blocked-output')
receipt.mkdir();(receipt/'artifacts').mkdir();inventory=[]
for path in sorted(set(files)):
    data=path.read_bytes();name=path.relative_to(work).as_posix().replace('/','__')+'.gz'
    target=receipt/'artifacts'/name;target.write_bytes(gzip.compress(data,mtime=0));assert gzip.decompress(target.read_bytes())==data
    inventory.append(dict(file='artifacts/'+name,source=path.relative_to(repo).as_posix(),sha256=sha256(data).hexdigest(),gzipSha256=digest(target),bytes=len(data),compressedBytes=target.stat().st_size))
checkpoint=dict(sourceCommit='ac762a8bbbbd88b7f4f52cde1d2128ed1d65127b',
    checkpointCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
    runtimeSha256=audio['runtimeSha256'],analysis=analysis,artifacts=inventory,
    ordinaryErrorFeedbackAccepted=False,fullBetaAccepted=False,finalPackageAccepted=False)
(receipt/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n',encoding='utf-8')
table='\n'.join(f"| {r['input']} {r['segment']} | {r['codec']} | {r['pcmSamples']} | {r['decodedSeconds']:.6f} | {r['observedPlaybackSeconds']:.6f} |" for r in rows)
(receipt/'README.md').write_text(f'''# Audio-only recording and native destination retry

27 October 2026. No production change follows the recording464/mux464 repair in
source `ac762a8bbb`. This is additional native API evidence on the identified
GUI441/Core265/record464/mux464 tuple, not an ordinary desktop or complete beta pass.

Each generated WAV/FLAC/MP3 input is recorded twice in the same player. Recording
is armed while paused, then stopped after about eight seconds of playback. Arming
does not advance the paused clock; pause after stop holds. All six saved files
decode completely to mono44.1kHzPCM with no FFmpeg decoding errors. WAV stays PCM
WAV, FLAC uses the existing Ogg-FLAC path and MP3 stays MP3. Child exits are normal,
all source/runtime/base/fixture/producer/worker guards pass, and the three ordinary
native-format logs contain no error lines.

| Input / segment | Output codec | Decoded PCM samples | Decoded seconds | Observed API clock span |
| --- | --- | ---: | ---: | ---: |
{table}

These are real decoded counts, not exact recording-boundary acceptance. Packet/
queue timing differs from the observed playback clock by up to
{analysis['maxClockDifference']:.6f}seconds (the second FLAC recording). The predeclared
0.65-second bound passes. No bit-exact onset/tail or the separate strict88,200sample
conversion regression is claimed by this recording check.

A separate WAV test supplies an owned file where the output folder should be.
The first output fails to open as intended. Playback remains running; after pause,
a valid folder is supplied to the second recording in the same player. That file
decodes successfully. The marker's bytes remain unchanged, and all guards/normal
exits pass. The expected output-open diagnostics are retained, including the
unhelpful Windows message ending in No error. No ordinary error-dialog feedback,
automatic failure-state correction or settings/picker retry is accepted here;
that visible journey remains the next check.

Inputs are generated from the already-owned music fixture, whose hash is checked
unchanged. Media, raw decoded PCM and binaries remain ignored. The compressed
receipt retains commands, exact identities, producer/worker scripts, outcomes and
diagnostics. Every artifact was decompressed and verified against its SHA-256.
Other formats, live capture, unknown timing, full action/state/error combinations,
physical endpoints, accessibility/DPI and clean-package/beta gates remain open.
No dependencies, firewall rules or security/privacy/Defender settings changed.
''',encoding='utf-8')
print(json.dumps(dict(artifacts=len(inventory),compressedBytes=sum(i['compressedBytes'] for i in inventory),maxClockDifference=analysis['maxClockDifference'])))
