from pathlib import Path
from hashlib import sha256
import ctypes,json,shutil,subprocess,sys

work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
manifest=work/'inputs-r472.json';inputs=read(manifest)
assert all(digest(repo/p)==h for p,h in inputs['files'].items())
base=work/'ui-record-overlap-r466/runtime'
identities=read(work/'ui-record-overlap-r466/verification.json')['runtimeSha256']
assert all(digest(base/p)==h for p,h in identities.items())
media=work/'record-audio-media-r469';fixtures={p.name:digest(p) for p in media.iterdir() if p.is_file()}
worker=work/'record-retry-worker-r472.py';worker_hash=digest(worker)
out=work/'native-record-retry-r472';assert not out.exists();out.mkdir()
shutil.copyfile(Path(__file__),out/'producer.py')
sys.path.insert(0,str(repo/'test/libvlc'))
from native_http_runtime import stage_runtime,environment,regenerate_cache
runtime=out/'runtime';stage_runtime(base,runtime);regenerate_cache(runtime,out/'cache')
record=dict(status='starting',sourceManifestSha256=digest(manifest),runtimeSha256=identities,
    fixtureSha256=fixtures,producerSha256=digest(Path(__file__)),workerSha256=worker_hash,
    fullBetaAccepted=False,ordinaryGuiAccepted=False,forcedCleanupUsed=False,
    strictConversionTailAccepted=False,cases={},scope='Generated WAV invalid file-as-directory destination then valid retry in the same player, paused arming/holding, primary survival and full decoded recovery PCM. Native API only; expected output-open errors are retained.')
save=lambda:(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
save()
prefix=['wsl.exe','-d','VLC-Juxtopposed-Home-20261018','--exec']
linux=lambda p:'/mnt/c/'+p.as_posix().split(':/',1)[1]
kernel=ctypes.WinDLL('kernel32');previous=kernel.SetErrorMode(0x8003)
try:
    for extension in ['wav']:
        target=out/extension;envroot=out/(extension+'-environment');envroot.mkdir()
        env=environment(runtime,envroot);env.pop('VLC_PLUGIN_PATH',None)
        command=[sys.executable,str(worker),str(runtime),str(media/('owned-record-audio.'+extension)),str(target),'clean']
        with (out/(extension+'-stdout.txt')).open('wb') as stdout,(out/(extension+'-stderr.txt')).open('wb') as stderr:
            child=subprocess.Popen(command,cwd=runtime,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
            record['status']='running';record['cases'][extension]=dict(status='running',pid=child.pid,command=command);save()
            print(extension,'PID',child.pid,flush=True)
            try:code=child.wait(timeout=65)
            except subprocess.TimeoutExpired:
                record['cases'][extension]['status']='timeout-process-left-running';save()
                raise SystemExit('Inspect same PID; no automatic cleanup/restart')
        case=record['cases'][extension];case.update(status='terminal',exitCode=code,normalExit=code==0)
        save();assert code==0
        case['probe']=read(target/'probe.json')
        files=sorted(p for p in (target/'recordings').iterdir() if p.is_file())
        assert len(files)==1,files
        case['outputs']=[]
        for index,file in enumerate(files):
            output=dict(file=file.relative_to(out).as_posix(),sha256=digest(file),bytes=file.stat().st_size)
            probe_command=prefix+['/usr/bin/ffprobe','-v','error','-show_streams','-show_format','-of','json',linux(file)]
            probe=subprocess.run(probe_command,capture_output=True,text=True,timeout=25,creationflags=subprocess.CREATE_NO_WINDOW)
            output.update(probeCommand=probe_command,probeExit=probe.returncode,probeStderr=probe.stderr,probe=json.loads(probe.stdout) if probe.returncode==0 else None)
            pcm=target/f'decode-{index}.pcm'
            decode_command=prefix+['/usr/bin/ffmpeg','-hide_banner','-v','error','-nostdin','-n','-xerror','-i',linux(file),'-map','0:a:0','-ac','1','-ar','44100','-c:a','pcm_s16le','-f','s16le',linux(pcm)]
            decode=subprocess.run(decode_command,capture_output=True,text=True,timeout=25,creationflags=subprocess.CREATE_NO_WINDOW)
            count=pcm.stat().st_size//2 if pcm.exists() else 0
            output.update(decodeCommand=decode_command,decodeExit=decode.returncode,decodeStderr=decode.stderr,decodedPcmSamples=count,decodedPcmSha256=digest(pcm) if pcm.exists() else None)
            segment=case['probe']['segments'][index+1]
            expected=(segment['recordStop']-segment['start'])/1_000_000
            output.update(observedPlaybackSeconds=expected,decodedSeconds=count/44100)
            case['outputs'].append(output);save()
            assert probe.returncode==decode.returncode==0 and not decode.stderr
            assert count>0 and abs(count/44100-expected)<.65,output
            assert all(stream['codec_type']=='audio' for stream in output['probe']['streams'])
        print(extension,'failed destination preserved playback; recovery decodes',flush=True)
finally:kernel.SetErrorMode(previous)
record.update(status='terminal',passed=True,sourceInputsUnchanged=all(digest(repo/p)==h for p,h in inputs['files'].items()),
    runtimeUnchanged=all(digest(runtime/p)==h for p,h in identities.items()),baseRuntimeUnchanged=all(digest(base/p)==h for p,h in identities.items()),
    fixturesUnchanged=all(digest(media/p)==h for p,h in fixtures.items()),producerUnchanged=digest(Path(__file__))==record['producerSha256'],workerUnchanged=digest(worker)==worker_hash)
save();assert all(v for k,v in record.items() if k.endswith('Unchanged'))
print(json.dumps({k:v for k,v in record.items() if k.endswith('Unchanged')}),flush=True)
