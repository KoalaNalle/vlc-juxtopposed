from pathlib import Path
from hashlib import sha256
import ctypes,json,shutil,subprocess,sys
work=Path(__file__).resolve().parent;repo=work.parents[1]
revision,label,core_label=sys.argv[1:]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
manifest=work/f'inputs-{revision}.json';inputs=read(manifest)
assert all(digest(repo/p)==h and digest(Path(inputs['sourceCopies'][p]))==h for p,h in inputs['files'].items())
base=work/'ui-r69/runtime';protected=read(base.parent/'verification.json')['runtimeSha256']
assert all(digest(base/p)==h for p,h in protected.items())
out=work/label;assert not out.exists();out.mkdir()
sys.path.insert(0,str(repo/'test/libvlc'))
from native_http_runtime import stage_runtime,environment
runtime=out/'runtime';stage_runtime(base,runtime)
shutil.copyfile(base/'plugins/plugins.dat',runtime/'plugins/plugins.dat')
core=runtime/'libvlccore.dll';core.unlink();shutil.copyfile(work/core_label/'libvlccore.dll',core)
identities={p:digest(runtime/p) for p in protected}
media=repo/'build-windows/beta-subtitle-fps-20261024/media-r1/frame-marker.mp4'
worker=repo/'test/libvlc/native_paused_video_startup.py'
worker_hash,media_hash,producer_hash=digest(worker),digest(media),digest(Path(__file__))
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.SetErrorMode.argtypes=[ctypes.c_uint];kernel.SetErrorMode.restype=ctypes.c_uint
previous=kernel.SetErrorMode(0x8003);records=[]
try:
    for index,(hardware,caption) in enumerate([(True,True),(False,True),(True,False)]):
        case=out/f'{index+1:02}-{int(hardware)}-{int(caption)}';case.mkdir();probe=case/'probe';probe.mkdir()
        extra=['--rate=1.5','--vout=direct3d11','--hw-dec' if hardware else '--no-hw-dec']
        if not caption:extra+=['--no-spu']
        cfg=dict(name=case.name,media=str(media),audio='wasapi',video=True,extraOptions=extra,expectedSubtitleAtStart=caption)
        config=case/'config.json';write(config,cfg)
        env=environment(runtime,case);env.pop('VLC_PLUGIN_PATH',None)
        row=dict(status='starting',case=case.name,hardwareRequested=hardware,captionExpected=caption,forcedCleanupUsed=False,fullBetaAccepted=False)
        with (case/'stdout.txt').open('wb') as stdout,(case/'stderr.txt').open('wb') as stderr:
            child=subprocess.Popen([sys.executable,str(worker),'--config',str(config),'--runtime',str(runtime),'--output',str(probe)],cwd=runtime,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
            row.update(status='running',pid=child.pid);write(case/'process.json',row)
            print(case.name,'PID',child.pid,flush=True)
            try:code=child.wait(timeout=90)
            except subprocess.TimeoutExpired:raise SystemExit('Inspect owned native child; no automatic cleanup/restart')
        result=read(probe/'result.json') if (probe/'result.json').exists() else None
        log=(probe/'native.log').read_text(encoding='utf-8',errors='replace')
        hw_selected='d3d11va: Using D3D11VA (' in log and '4cc DX11' in log
        d3d_selected='using vout display module "direct3d11"' in log
        row.update(status='terminal',exitCode=code,normalExit=code==0,result=result,hardwareSelected=hw_selected,direct3d11Selected=d3d_selected,passed=bool(code==0 and result and result['passed'] and hw_selected==hardware and d3d_selected))
        write(case/'process.json',row);records.append(row);write(out/'verification.json',dict(status='running',records=records))
        first=(result or {}).get('observations',[{}])[0]
        print(case.name,'exit',code,'hardware',hw_selected,'D3D11',d3d_selected,'bright',first.get('brightPixels'),'passed',row['passed'],flush=True)
        if code!=0:raise SystemExit('Inspect abnormal exit before continuing')
finally:kernel.SetErrorMode(previous)
record=dict(status='terminal',passed=all(r['passed'] for r in records),records=records,runtimeSha256=identities,sourceManifestSha256=digest(manifest),fixtureSha256=media_hash,workerSha256=worker_hash,fullBetaAccepted=False,sourceInputsUnchanged=all(digest(repo/p)==h for p,h in inputs['files'].items()),runtimeUnchanged=all(digest(base/p)==h and digest(runtime/p)==identities[p] for p,h in protected.items()),fixturesUnchanged=digest(media)==media_hash,workerUnchanged=digest(worker)==worker_hash,producerUnchanged=digest(Path(__file__))==producer_hash)
write(out/'verification.json',record)
assert all(record[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','workerUnchanged','producerUnchanged'])
print(json.dumps(dict(cases=len(records),passed=record['passed'],normalExits=all(r['normalExit'] for r in records))),flush=True)
