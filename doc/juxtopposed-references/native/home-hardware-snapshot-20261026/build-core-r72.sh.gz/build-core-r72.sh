#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-core-r72.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-core-r72-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 05ec8a7a04506d26d1b66edef329cf62a83a68352167439505ed2d972812a10a
test ! -e "$work/core-r72-bin"
make -C "$base/win64/src" -j2 libvlccore.la
mkdir "$work/core-r72-bin"
cp "$base/win64/src/.libs/libvlccore.dll" "$work/core-r72-bin/"
cp "$base/win64/src/video_output/.deps/libvlccore_la-video_output.Plo" "$work/core-r72-bin/video_output.Plo"
sha256sum "$work/core-r72-bin/libvlccore.dll"
