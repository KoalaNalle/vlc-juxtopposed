from pathlib import Path
from hashlib import sha256
import json
from PySide6.QtGui import QImage
work=Path(__file__).resolve().parent
rows=[]
for label in ['ui-r59','ui-r73']:
    for p in sorted((work/label/'app-snapshots').glob('*.png')):
        im=QImage(str(p));assert not im.isNull()
        rgba=im.convertToFormat(QImage.Format_RGBA8888);pixels=bytes(rgba.bits())
        bright=sum(pixels[i]>160 and pixels[i+1]>160 and pixels[i+2]>160 for i in range(0,len(pixels),4))
        rows.append(dict(run=label,path=p.relative_to(work).as_posix(),sha256=sha256(p.read_bytes()).hexdigest(),width=im.width(),height=im.height(),brightPixels=bright))
assert len([r for r in rows if r['run']=='ui-r73'])==4
assert all(r['brightPixels']>1000 and [r['width'],r['height']]==[960,540] for r in rows if r['run']=='ui-r73')
assert all(r['brightPixels']==0 for r in rows if r['run']=='ui-r59')
record=dict(passed=True,scope='Pixel analysis of actual ordinary VLC saved PNG files for generated flat-colour caption media; separate from Computer Use screenshots and from full visual acceptance',rows=rows,fullBetaAccepted=False)
(work/'snapshot-analysis-r74.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record))
