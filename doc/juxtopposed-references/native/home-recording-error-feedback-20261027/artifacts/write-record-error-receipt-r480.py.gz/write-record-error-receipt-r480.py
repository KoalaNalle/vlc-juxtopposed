from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess

work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
receipt=repo/'doc/juxtopposed-references/native/home-recording-error-feedback-20261027'
assert not receipt.exists()
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert commit.startswith('9bc894ae8e')
analysis=read(work/'record-error-analysis-r479.json');assert analysis['passed']
manifest=read(work/'inputs-r476.json');assert all(digest(repo/p)==h for p,h in manifest['files'].items())
names=['inputs-r474.json','inputs-r475.json','inputs-r476.json','prepare-record-error-ui-r474.py',
    'run-ui-record-error-before-r474.py','prepare-record-error-callback-r475.py',
    'record-error-callback-worker-r475.py','freeze-record-error-r475.py','prepare-record-error-fix-r476.py',
    'build-record-error-r476.sh','build-record-error-r476.log','build-record-error-r476-exit.txt',
    'run-ui-record-error-fixed-r478.py','check-record-error-r479.py','record-error-analysis-r479.json',
    'write-record-error-receipt-r480.py']
files=[work/name for name in names]
for run in ['native-record-error-before-r475','native-record-error-fixed-r477']:
    files.extend(work/run/name for name in ['producer.py','verification.json','wav-stdout.txt','wav-stderr.txt'])
    files.extend(work/run/'wav'/name for name in ['probe.json','vlc.log','vlcrc','blocked-output'])
files.extend(work/'native-record-error-unit-r476'/name for name in ['verification.json','stdout.txt','stderr.txt'])
for run in ['ui-record-error-before-r474','ui-record-error-fixed-r478']:
    files.extend(work/run/name for name in ['producer.py','verification.json','launch.json','vlc.log','stderr.txt',
        'layout-fixture.json','settings-before.ini','settings-after.ini','config-before.txt','config-after.txt'])
    files.extend(p for p in (work/run/'observations').iterdir() if p.is_file())
files.extend(work/'ui-record-error-fixed-r478'/name for name in ['destination-repair.json','blocked-output.original.txt'])
files.append(work/'ui-record-error-before-r474/blocked-output')
receipt.mkdir();(receipt/'artifacts').mkdir();inventory=[]
for path in sorted(set(files)):
    data=path.read_bytes();name=path.relative_to(work).as_posix().replace('/','__')+'.gz'
    target=receipt/'artifacts'/name;target.write_bytes(gzip.compress(data,mtime=0));assert gzip.decompress(target.read_bytes())==data
    inventory.append(dict(file='artifacts/'+name,source=path.relative_to(repo).as_posix(),sha256=sha256(data).hexdigest(),
                          gzipSha256=digest(target),bytes=len(data),compressedBytes=target.stat().st_size))
checkpoint=dict(sourceCommit=commit,runtime='build-windows/beta-single-frame-20261025-night/ui-record-error-fixed-r478/runtime',
    runtimeSha256=analysis['runtimeSha256'],analysis=analysis,artifacts=inventory,
    fullBetaAccepted=False,finalPackageAccepted=False,independentReviewAccepted=False,
    toastDetailsActionAccepted=False,allOutputWriteFailuresAccepted=False,firewallRuleChanges=[],securityPrivacyChanges=[])
(receipt/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n',encoding='utf-8')
(receipt/'README.md').write_text(f'''# Recording destination error feedback and recovery

27 October 2026. Source `{commit}`. A recording whose output could not be opened
previously failed only in the log. The ordinary player showed no save-error notice.
The recording module now reports final output-open failures through VLC's existing
dialog service, with the destination and folder/write-access/free-space guidance.
The message is emitted once for this failure, while ordinary logging is preserved.
No new dialog framework, Core ABI, GUI rebuild or dependencies are introduced.

## Evidence

- Ordinary before r474: a generated Matroska recording points at an owned file
  instead of a directory. The output fails, no file is saved and no error notice
  appears. The source keeps playing and pauses normally. The three expected
  output-open log errors and normal exit/all ending guards are retained.
- Native public API before/after r475/r477: the same generated WAV failure/retry
  test registers LibVLC's public error callback. Before, it receives no dialog;
  after, it receives exactly one Recording failed error with the blocked path and
  guidance. The primary input survives and a valid-folder retry in the same player
  decodes. Markers stay unchanged; normal exits and every guard pass.
- All22 direct recording production checks still pass after the module change.
- Ordinary GUI441/Core265/record476
  `{analysis['runtimeSha256']['plugins/stream_out/libstream_out_record_plugin.dll'][:8]}`
  /mux464 r478: the failed output produces the visible red Recording failed
  alert while the one-hour generated WAV continues playing. Ctrl+M / Errors shows
  the complete retained destination and guidance. Playback pauses and its exact
  position holds while the details are inspected and closed.
- The owned marker is renamed, preserving its bytes, and a directory is created
  at the same test path. The existing player then records successfully without a
  restart or settings change. The recovered file contains177,600mono8kHz16-bit
  PCM samples (22.2seconds), all matching the generated silent input, and FFmpeg
  decodes it with zero errors. Final pause holds at
  `{analysis['finalPausedPosition']}` before normal quit. Native config and the
  complete player-profile catalogue remain identical.

Both ordinary runs exit0 with602plugins and all source/runtime/base/fixture/
producer/cache guards. Each has the same three controlled output-open diagnostic
lines and no unexpected checked diagnostics. This is an intentional failure test,
not a claim of zero log errors. The ordinary negative uses Matroska; the recovery
uses a one-hour WAV to avoid EOF during inspection. Native before/after use the
same WAV scenario. One Record tile is preseeded only in each isolated test profile;
this does not qualify a customizer gesture.

## Remaining limits

The first Show Details click did not establish that route opening: the following
window observations show no details dialog. The existing notice hides after five
seconds, which can expire during automation. Details were verified through the
retained Errors history instead. Do not claim the toast button or its keyboard/
focus behavior accepted from that attempt. The current source routes that button
to the same messages service, but source inspection alone is not desktop evidence.

This repair reports final output-open failure. Mid-write disk-full/disconnection,
every error/retry combination, localization, actual DPI, screen-reader/focus,
complete visual scoring, independent review and clean-package/beta gates remain
open. Older subtitle-overlap and other-format receipts retain their own exact
module identities; this six-line error-report change does not silently replace them.
No exact recording-boundary or strict conversion-tail claim is added here.

Media and binaries remain ignored. The receipt preserves generated-fixture
identities, callback/ordinary captures, diagnostics, normal exits, producers and
the reversible destination-repair journal. `checkpoint.json` binds original and
compressed SHA-256; every artifact was decompressed and verified. No firewall
rules, security/privacy or Defender settings changed. This is a frozen scoped
record, not full beta acceptance.
''',encoding='utf-8')
print(json.dumps(dict(sourceCommit=commit,artifacts=len(inventory),compressedBytes=sum(i['compressedBytes'] for i in inventory))))
