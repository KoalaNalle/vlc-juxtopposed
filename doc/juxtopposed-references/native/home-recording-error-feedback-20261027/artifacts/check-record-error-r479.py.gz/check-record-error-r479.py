from pathlib import Path
from hashlib import sha256
import json,re,subprocess,wave
from PySide6.QtCore import QSettings

work=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
before=read(work/'native-record-error-before-r475/verification.json')
after=read(work/'native-record-error-fixed-r477/verification.json')
for record in [before,after]:
    assert record['status']=='terminal' and record['passed']
    assert all(v for k,v in record.items() if k.endswith('Unchanged'))
    assert record['cases']['wav']['normalExit']
    assert record['cases']['wav']['probe']['blockedMarkerUnchanged']
assert before['cases']['wav']['probe']['errorDialogs']==[]
errors=after['cases']['wav']['probe']['errorDialogs']
assert len(errors)==1 and errors[0]['title']=='Recording failed' and 'recording folder' in errors[0]['message']
ui_names=['ui-record-error-before-r474','ui-record-error-fixed-r478']
for name in ui_names:
    record=read(work/name/'verification.json')
    assert record['normalExit'] and record['moduleCounts']==['602']
    assert record['expectedOutputOpenFailure'] and not record['unexpectedDiagnostics']
    assert all(v for k,v in record.items() if k.endswith('Unchanged'))
    assert len(record['diagnostics'])==3
ordinary=work/ui_names[1]
tree=lambda name:read(ordinary/'observations'/f'{name}.json')['accessibility']['tree']
position=lambda name:float(re.search(r'Progress Value: ([0-9.]+)',tree(name)).group(1))
assert 'Recording failed' in tree('05-failed-stop-error')
assert 'VLC could not create the recording file at:' in tree('09-errors-history-details')
assert 'recording folder exists and is writable' in tree('09-errors-history-details')
assert position('10-details-closed-paused')==position('11-retry-armed-paused')
assert position('16-final-paused-settled')==position('17-paused-hold-before-quit')
assert position('17-paused-hold-before-quit')>position('11-retry-armed-paused')
repair=read(ordinary/'destination-repair.json');assert repair['MarkerUnchanged']
assert digest(ordinary/'blocked-output.original.txt').upper()==repair['MarkerSha256']
files=list((ordinary/'blocked-output').glob('*.wav'));assert len(files)==1
file=files[0]
with wave.open(str(file),'rb') as audio:
    sample_rate=audio.getframerate();samples=audio.getnframes();channels=audio.getnchannels();sample_width=audio.getsampwidth()
    pcm=audio.readframes(samples)
assert sample_rate==8000 and channels==1 and sample_width==2 and samples>8000
assert len(pcm)==samples*2 and not any(pcm)
linux='/mnt/c/'+file.as_posix().split(':/',1)[1]
command=['wsl.exe','-d','VLC-Juxtopposed-Home-20261018','--exec','/usr/bin/ffmpeg','-hide_banner','-v','error','-nostdin','-xerror','-i',linux,'-map','0:a:0','-f','null','-']
decode=subprocess.run(command,capture_output=True,text=True,timeout=25,creationflags=subprocess.CREATE_NO_WINDOW)
assert decode.returncode==0 and not decode.stderr
unit=read(work/'native-record-error-unit-r476/verification.json');assert unit['normalExit'] and unit['rows'][-1]==dict(checks=22,failures=0)
assert all(v for k,v in unit.items() if k.endswith('Unchanged'))
assert (ordinary/'config-before.txt').read_bytes()==(ordinary/'config-after.txt').read_bytes()
catalogues=[]
for name in ['settings-before.ini','settings-after.ini']:
    settings=QSettings(str(ordinary/name),QSettings.IniFormat);settings.setFallbacksEnabled(False)
    catalogues.append(json.loads(settings.value('Juxtopposed/player-profiles')))
assert catalogues[0]==catalogues[1]
record=read(ordinary/'verification.json')
analysis=dict(passed=True,runtimeSha256=record['runtimeSha256'],nativeErrorCallbacksBefore=0,nativeErrorCallbacksAfter=1,
    ordinaryErrorToastObserved=True,ordinaryErrorHistoryGuidanceObserved=True,samePlayerRecoveryDecoded=True,
    recoveredFile=file.relative_to(work).as_posix(),recoveredFileSha256=digest(file),recoveredPcmSamples=samples,
    sampleRate=sample_rate,recoveredSeconds=samples/sample_rate,decodedPcmSha256=sha256(pcm).hexdigest(),
    decodeCommand=command,decodeExit=decode.returncode,decodeStderr=decode.stderr,
    markerUnchanged=True,nativeConfigUnchanged=True,playerProfilesUnchanged=True,endingGuardsPassed=True,
    finalPausedPosition=position('17-paused-hold-before-quit'),directProductionChecks=22,
    toastDetailsActionAccepted=False,allOutputWriteFailuresAccepted=False,fullBetaAccepted=False,
    caveats=['The first toast Show Details attempt did not establish opening: it was followed by no window; the five-second timeout can expire during automation. Error details were verified through Ctrl+M / Errors history.',
             'The ordinary negative uses generated Matroska, while recovery uses a one-hour generated WAV to avoid EOF; native before/after use the same WAV failure/retry scenario.',
             'Expected output-open diagnostics remain in both ordinary logs. Their controlled failures are distinct from unexpected errors.'],
    firewallRuleChanges=[],securityPrivacyChanges=[])
(work/'record-error-analysis-r479.json').write_text(json.dumps(analysis,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in analysis.items() if k not in ['runtimeSha256','decodeCommand','caveats']},indent=2))
