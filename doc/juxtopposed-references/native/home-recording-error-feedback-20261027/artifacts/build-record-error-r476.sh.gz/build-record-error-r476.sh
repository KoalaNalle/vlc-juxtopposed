#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-record-error-r476.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-record-error-r476-exit.txt"; exit "$code"' EXIT
out="$work/record-overlap-r476-bin"
test ! -e "$out"
mkdir "$out"
core=fdfcfcd599588512bb7f3a51e46305b7b0d947b47387dd205851feb45f032b46
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = "$core"
sha256sum "$repo/modules/stream_out/record.c" "$repo/modules/mux/mp4/mp4.c" "$repo/test/modules/stream_out/record_start.c" > "$out/inputs.sha256"
make -C "$base/win64/test" -f Makefile -f "$repo/test/record-start-native.mk" -j2 RECORD_START_OUT="$base/owned-record-overlap-unit-r476" owned-record-start
make -C "$base/win64/modules" -j2 libstream_out_record_plugin.la libmux_mp4_plugin.la
cp "$base/owned-record-overlap-unit-r476/.libs/test_record_start.exe" "$out/"
cp "$base/win64/modules/.libs/libstream_out_record_plugin.dll" "$out/"
cp "$base/win64/modules/.libs/libmux_mp4_plugin.dll" "$out/"
sha256sum -c "$out/inputs.sha256"
sha256sum "$out/"*.dll "$out/"*.exe
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = "$core"
