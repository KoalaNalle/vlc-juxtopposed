from pathlib import Path
work=Path(__file__).resolve().parent
source=(work/'run-ui-record-overlap-r466.py').read_text(encoding='utf-8')
source=source.replace("(out/'recordings').mkdir()", "(out/'recordings').mkdir()\nblocked=out/'blocked-output';blocked.write_text('Owned recording error marker\\n',encoding='utf-8')\nblocked_marker=digest(blocked)")
source=source.replace("'--input-record-path='+str(out/'recordings')", "'--input-record-path='+str(blocked)")
source=source.replace("assert record[\"normalExit\"] and not record[\"diagnostics\"]", """record['expectedOutputOpenFailure']=any('record error: failed to open output' in line for line in record['diagnostics'])
allowed=['file error: cannot create ','stream_out_standard error: no suitable sout access module','record error: failed to open output']
record['unexpectedDiagnostics']=[line for line in record['diagnostics'] if not any(value in line for value in allowed)]
write(out/'verification.json',record)
assert record['normalExit'] and record['expectedOutputOpenFailure'] and not record['unexpectedDiagnostics']""")
source=source.replace('Ordinary GUI441 with record464/mux464, real Record tile start/stop and generated Matroska/SRT overlap playback. One Record tile is preseeded only in the isolated test profile; this is not customizer-gesture acceptance. No private hooks or network/security/privacy changes.',
 'Ordinary GUI441 with record464/mux464, invalid file-as-folder recording destination and visible failure/recovery observations. One Record tile is preseeded only in the isolated profile. Expected output-open diagnostics are retained; no private hooks or security/privacy changes.')
(work/'run-ui-record-error-before-r474.py').write_text(source,encoding='utf-8',newline='\n')
