from pathlib import Path
work=Path(__file__).resolve().parent
worker=(work/'record-retry-worker-r472.py').read_text(encoding='utf-8')
anchor="instance=new(len(args),(C.c_char_p*len(args))(*args)); assert instance"
replacement='''error_dialogs=[]
ErrorCallback=C.CFUNCTYPE(None,ptr,C.c_char_p,C.c_char_p)
@ErrorCallback
def error_callback(data,title,message):
    error_dialogs.append(dict(title=(title or b'').decode('utf-8','replace'),message=(message or b'').decode('utf-8','replace')))
set_error_callback=bind('libvlc_dialog_set_error_callback',None,ptr,ErrorCallback,ptr)
'''+anchor+'''
set_error_callback(instance,error_callback,None)'''
assert anchor in worker;worker=worker.replace(anchor,replacement)
worker=worker.replace("report['files']=[", "report['errorDialogs']=error_dialogs\nreport['files']=[")
(work/'record-error-callback-worker-r475.py').write_text(worker,encoding='utf-8',newline='\n')
producer=(work/'run-record-retry-r472.py').read_text(encoding='utf-8')
producer=producer.replace('inputs-r472','inputs-r475').replace('native-record-retry-r472','native-record-error-before-r475').replace('record-retry-worker-r472.py','record-error-callback-worker-r475.py')
producer=producer.replace("case['probe']=read(target/'probe.json')", "case['probe']=read(target/'probe.json')\n        assert case['probe']['errorDialogs']==[],case['probe']['errorDialogs']\n        record.update(expectedNegative=True,errorFeedbackAccepted=False)")
(work/'run-record-error-before-r475.py').write_text(producer,encoding='utf-8',newline='\n')
freeze=(work/'freeze-record-overlap-r462.py').read_text(encoding='utf-8')
freeze=freeze.replace("root=work/f'source-{revision}'", "names.update(['include/vlc_dialog.h','include/vlc/libvlc_dialog.h'])\nroot=work/f'source-{revision}'")
(work/'freeze-record-error-r475.py').write_text(freeze,encoding='utf-8',newline='\n')
