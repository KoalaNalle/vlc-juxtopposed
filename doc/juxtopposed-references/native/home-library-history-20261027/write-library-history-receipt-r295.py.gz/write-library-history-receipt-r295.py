from pathlib import Path
from hashlib import sha256
import gzip, json, re

work = Path(__file__).resolve().parent
repo = work.parents[1]
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda p: sha256(p.read_bytes()).hexdigest()
out = repo / 'doc/juxtopposed-references/native/home-library-history-20261027'
assert not out.exists()
manifest = read(work / 'inputs-r294.json')
assert all(digest(repo / p) == h for p, h in manifest['files'].items())
before = 'ui-library-history-before-r292'
accepted = ['ui-library-history-fixed-r294', 'ui-library-history-classic-r294', 'ui-library-history-cold-r294']
records = {name: read(work / name / 'verification.json') for name in [before] + accepted}
guards = ['sourceInputsUnchanged', 'runtimeUnchanged', 'baseRuntimeUnchanged', 'fixturesUnchanged',
          'musicFixturesUnchanged', 'lateFixturesUnchanged', 'decodeFixturesUnchanged',
          'extraFixturesUnchanged', 'producerUnchanged', 'pluginCacheUnchanged']
for name, v in records.items():
    assert v['normalExit'] and v['exitCode'] == 0 and not v['diagnostics'] and v['moduleCounts'] == ['602'], name
    assert all(v[k] for k in guards), name
    assert not v['privateCore'] and not v['privateGui'] and not v['forcedCleanupUsed']
for name in accepted[1:]:
    assert records[name]['runtimeSha256'] == records[accepted[0]]['runtimeSha256']

def tree(run, name):
    return read(work / run / 'observations' / (name + '.json'))['accessibility']['tree']
warm, classic, cold = accepted
failed = tree(before, '03-failure-back-clears-query-and-selects-other-artist')
assert '3 items' in failed and 'Search library Value: Fixture' not in failed
for name in ['04-back-restores-fixture-one-result', '06-back-retains-independent-artists-query']:
    t = tree(warm, name)
    assert 'Search library Value: Fixture' in t and '1 item' in t and 'Progress Value: 0 ID:' in t
assert 'Search library Value: Missing' in tree(warm, '07-forward-restores-detail-missing-query')
assert '0 items' in tree(warm, '07-forward-restores-detail-missing-query')
assert 'Search library Value:' not in tree(warm, '09-forward-keeps-cleared-detail-query')
assert 'Morning Album' in tree(warm, '09-forward-keeps-cleared-detail-query')
assert 'Search library Value: My' in tree(warm, '14-back-restores-native-folder-filter')
assert 'My Songs' in tree(warm, '16-settled-playing-forward-my-songs-empty-query')
assert 'Progress Value: 0.2175965239706054' in tree(warm, '16-settled-playing-forward-my-songs-empty-query')
assert 'Search library Value: My' in tree(warm, '17-playing-back-restores-my-then-paused')
assert 'Progress Value: 0.41664123244071916' in tree(warm, '17-playing-back-restores-my-then-paused')
assert 'Value: Fixture' in tree(classic, '04-classic-back-restores-filter-popup')
assert 'Value: Fixture Artist' in tree(classic, '05-classic-edit-restored-query-with-space-paused')
assert 'Progress Value: 0 ID:' in tree(classic, '05-classic-edit-restored-query-with-space-paused')
t = tree(classic, '07-classic-settled-escape-popup-closed-three-artists')
assert ' edit ' not in t and all(name in t for name in ['Ärtist', 'Fixture Artist', 'Another Artist'])
assert 'Progress Value: 0 ID:' in tree(classic, '08-classic-table-enter-navigates-keeps-video-paused')
t = tree(cold, '01-cold-songs-ascending-and-empty-query')
assert 'Search library Value:' not in t and '3 items' in t
folder_names = re.findall(r'button \(settable, string\) (.*?) ID:', t)
assert [n for n in folder_names if n in ['My Songs', 'Nested collection', 'Näive Songs']] == ['My Songs', 'Nested collection', 'Näive Songs']
component = read(work / 'component-history-r293d/verification.json')
assert component['passed'] and not component['messages'] and len(component['completed']) == 15
for source, h in component['sourceSha256'].items():
    assert digest(repo / source) == h
assert int((work / 'build-library-history-r293-exit.txt').read_text()) == 0
staging = {name: read(work / name / 'staging.json') for name in accepted}
assert all(v['copiedLinkLimitFiles'] > 0 for v in staging.values())
out.mkdir()
artifacts, local = [], []

def retain(p, relative=None):
    relative = (relative or p.relative_to(work).as_posix()) + '.gz'
    target = out / relative
    assert not target.exists()
    raw = p.read_bytes()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(raw, mtime=0))
    artifacts.append(dict(path=relative, sha256=digest(target), rawSha256=sha256(raw).hexdigest()))

for name in [before] + accepted:
    root = work / name
    for filename in ['verification.json', 'launch.json', 'producer.py', 'staging.json', 'ml-copy.json']:
        p = root / filename
        if p.is_file(): retain(p)
    for p in sorted((root / 'observations').glob('*')):
        if p.suffix in ['.png', '.json']: retain(p)
    for filename in ['vlc.log', 'stdout.txt', 'stderr.txt', 'config-before.txt', 'config-after.txt', 'settings-before.ini', 'settings-after.ini']:
        p = root / filename
        if p.is_file(): local.append(dict(path=p.relative_to(work).as_posix(), sha256=digest(p), packaged=False))
for name in ['component-history-r293a', 'component-history-r293b', 'component-history-r293c', 'component-history-r293d']:
    retain(work / name / 'verification.json')
for name in ['inputs-r292.json', 'inputs-r293.json', 'inputs-r294.json',
             'prepare-library-history-r292.py', 'prepare-library-history-r293.py', 'prepare-library-history-r294.py',
             'run-ui-library-history-r292.py', 'run-ui-library-history-r293.py', 'run-ui-library-history-r294.py',
             'library-history-r293-staging-failure.json', 'build-library-history-r293.sh',
             'write-library-history-receipt-r295.py']:
    retain(work / name)
for source in ['modules/gui/qt/widgets/qml/PageExt.qml', 'modules/gui/qt/widgets/qml/GridSortFilterControls.qml',
               'modules/gui/qt/tests/test_page_loader_routes.py', 'test/libvlc/native_http_runtime.py']:
    p = Path(manifest['sourceCopies'][source])
    assert digest(p) == manifest['files'][source]
    retain(p, 'sources/' + source)
old = read(work / 'inputs-r292.json')
for source in ['modules/gui/qt/widgets/qml/PageExt.qml', 'modules/gui/qt/widgets/qml/GridSortFilterControls.qml']:
    retain(Path(old['sourceCopies'][source]), 'preimage/' + source)
record = dict(status='passed-scoped-library-history-nightly', fullBetaAccepted=False,
    runtimeSha256=records[warm]['runtimeSha256'], sourceManifestSha256=digest(work / 'inputs-r294.json'),
    sourceInputCount=len(manifest['files']), componentResult=component,
    otherComponentCheck=dict(command='test_juxtopposed_library.py --output-dir build-windows/beta-single-frame-20261025-night/component-library-r293', exitCode=0,
        scope='Existing offscreen header, media row, folder/category roles/actions and simulated scales. No OS DPI or native query claim.'),
    ordinaryRuns={name: dict(exitCode=0, allGuards=True, role='before failure' if name == before else 'accepted scoped replay') for name in records},
    staging=staging, build=dict(exitCode=0, logSha256=digest(work / 'build-library-history-r293.log')),
    artifacts=artifacts, localStreams=local,
    accepted=[
        'GUI290 before failure: Artists query Fixture narrows to one artist; opening details and Back clears it to three artists with a different first item. Initial Songs Alphabetic menu is unmarked despite actual native title sorting. The before process exits normally with all guards; that does not accept its failed navigation.',
        'PageExt stores its SearchCtx pattern in the current session history entry. PageLoader restores the alias as an initial leaf property before row selection. Both current entry identity and exact route guard outgoing signals; no search string is added to persistent settings.',
        'GUI293 Artists Back restores Fixture and one artist; detail starts fresh, independently retains Missing/zero results on Forward, and Clear stays cleared after Back/Forward. Songs My filter survives native folder drill-down; the new track page has an empty query. Paused primary video stays at0.',
        'Songs sort projection uses the native model fallback when the saved criterion is empty. The menu marks Alphabetic; selecting the current criterion reverses native folder order and saves the explicit key. Cold startup restores ascending My/Nested/Näive order and the marked menu with an empty query.',
        'Primary video continues during folder Forward/Back:13s and paused24.998474s are observed on the same media; the parent My query returns. Traditional Back reopens Fixture popup/one artist; editing with a space preserves video0, Escape clears/closes, table Enter only navigates, and returning keeps cleared filter and selected Fixture.',
        'All three final apps exit0/602modules/zero error diagnostics with source, staged/base runtime, fixtures, producer and cache guards true. The shared staging helper uses byte-identical copies only for EMLINK/Windows1142; the real saturated source exercises521 copied files and preserves base runtime hashes.'
    ], limits=[
        'Component history uses production PageExt/PageLoader/StackViewExt/MainViewLoader with supplied dependencies and real Qt property maps; it does not execute C++ NavigationHistory or the actual classic SearchBox. Ordinary apps provide those scoped flows. Initial component attempts failed on adapter syntax/missing attached property/typed PySide pointer conversion before the final adapter repair.',
        'The first GUI293 stage reached Windows1142 on AUTHORS.txt before launching VLC. That failed output remains separate. A fresh run used the narrow copy fallback, without deleting old runtimes or changing application behavior.',
        'Some immediate UIA trees/screenshots show transitions or stale predecessors; settled captures are acceptance. Warm observation15 precedes the Forward transition; observation16 supplies the actual destination. Classic observation06 precedes popup-close animation; observation07 proves closure. Initial search clicks sometimes only focus Back; typing follows a visible caret. Complete accessibility geometry remains open.',
        'Ctrl+F was tried as a search shortcut but is VLC Open Folder. Its picker was cancelled without selecting a folder; no shortcut change or search-shortcut acceptance is claimed.',
        'Sort arrows/selection were assessed in actual menu captures, not its incomplete UIA tree. Search history is session-only by design. No full category matrix, visual score, Windows DPI, multi-selection Play, rapid in-flight artist changes, physical endpoint, Windows10 or consolidated final-package acceptance.'
    ])
(out / 'checkpoint.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
(out / 'README.md').write_text('''# Library history nightly - 27 October 2026

Core `fdfcfcd5`, ordinary GUI `4dfe9fb9` and library `13ccdc36` restore each
library search filter with its session Back/Forward entry. A fresh entry starts
empty, Clear remains cleared, and an outgoing page cannot overwrite a newer
entry for the same route. Traditional controls initialize their search popup
from the restored context instead of clearing it during construction.

Songs now marks its actual native alphabetical fallback and reverses the order
when the current criterion is selected. The explicit choice persists after a
cold restart; search text remains session-only. Artist/detail and folder journeys
preserve paused/playing primary video. Redesigned, traditional and cold ordinary
apps all exit0/602modules/zero error diagnostics with every guard true.

The [checkpoint](checkpoint.json) retains source/binary identities, before failures,
component results, ordinary captures, staging recovery and exact qualifications.
The staging helper now copies files only when Windows' hard-link limit is reached;
existing runtimes are preserved. No complete surface, visual/DPI, full media or
final-package gate closes from this receipt. Continue from
[STATUS](../../../juxtopposed/STATUS.md).
''', encoding='utf-8', newline='\n')
for artifact in artifacts:
    p = out / artifact['path']
    assert digest(p) == artifact['sha256']
    assert sha256(gzip.decompress(p.read_bytes())).hexdigest() == artifact['rawSha256']
print(out, len(artifacts), 'verified artifacts', flush=True)
