from pathlib import Path
import json

work = Path(__file__).resolve().parent
target = work / 'run-ui-library-history-r294.py'
assert not target.exists()
source = (work / 'run-ui-library-history-r293.py').read_text(encoding='utf-8')
source = source.replace("runtime=out/'runtime';stage_runtime(base,runtime)", "runtime=out/'runtime';write(out/'staging.json',stage_runtime(base,runtime))")
target.write_text(source, encoding='utf-8', newline='\n')
(work / 'library-history-r293-staging-failure.json').write_text(json.dumps({
    'appRun': 'ui-library-history-fixed-r293',
    'appLaunched': False,
    'error': 'Windows 1142: AUTHORS.txt reached the filesystem hard-link count limit during stage_runtime.',
    'recovery': 'The shared runtime staging helper copies only files whose link count is exhausted. Other staging errors still fail; accepted runtimes remain untouched.',
    'buildPassed': True,
    'GUI293Sha256': '4dfe9fb9a96cf7576c12dad10ae286ccd17d580a3a5c90902d718668c9b7a4de',
    'fullBetaAccepted': False,
}, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'prepared': True}))
