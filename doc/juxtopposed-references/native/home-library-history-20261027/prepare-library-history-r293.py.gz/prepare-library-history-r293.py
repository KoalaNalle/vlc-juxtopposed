from pathlib import Path
import json

work = Path(__file__).resolve().parent
def write(name, text):
    target = work / name
    assert not target.exists()
    target.write_text(text, encoding='utf-8', newline='\n')

runner = (work / 'run-ui-library-history-r292.py').read_text(encoding='utf-8')
runner = runner.replace('ordinary-r290-bin', 'ordinary-r293-bin')
runner = runner.replace('Library header baseline on ordinary GUI290', 'Library header search-history and native-sort repair on ordinary GUI293')
write('run-ui-library-history-r293.py', runner)
builder = (work / 'build-music-details-r290.sh').read_text(encoding='utf-8')
builder = builder.replace('r290', 'r293').replace('music-details', 'library-history')
write('build-library-history-r293.sh', builder)
print(json.dumps({'prepared': True}))
