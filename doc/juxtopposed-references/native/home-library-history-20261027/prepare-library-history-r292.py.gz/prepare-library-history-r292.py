from pathlib import Path
import json
work = Path(__file__).resolve().parent
target = work / 'run-ui-library-history-r292.py'
assert not target.exists()
source = (work / 'run-ui-music-details-r290.py').read_text(encoding='utf-8')
source = source.replace("scope='Ordinary album, artist and genre detail workflows on the new GUI290/Core265/library282 tuple, using the unchanged generated tagged audio/video fixture. Actual observations, playback independence and normal exit are required; complete design/DPI/package gates remain separate.'", "scope='Library header baseline on ordinary GUI290/Core265/library282: initial folder-sort feedback and active-filter Back/Forward restoration. Unchanged owned tagged music fixture. Source/runtime/fixture guards and normal exit are required; complete beta gates remain separate.'")
target.write_text(source, encoding='utf-8', newline='\n')
print(json.dumps({'prepared': True}))
