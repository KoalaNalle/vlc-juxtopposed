#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
native="$base/owned-single-frame-native-20261026-r222"
ordinary="$base/owned-single-frame-ordinary-20261026-r222"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-r222.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-r222-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = efe5ae8d951d2ab4e457c722460682d5395f5ced28b2ab831ea2ca5372683ab7
test ! -e "$native"
test ! -e "$ordinary"
test ! -e "$work/native-r222-bin"
test ! -e "$work/ordinary-r222-bin"
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/build-windows/beta-subtitle-fps-20261023/native-r1.mk" -j2 FPS_NATIVE_OUT="$native" owned-subtitle-fps-native
mkdir "$work/native-r222-bin"
cp "$native/.libs/test_qt_player_subtitle_delay.exe" "$work/native-r222-bin/"
sha256sum "$work/native-r222-bin/test_qt_player_subtitle_delay.exe"
