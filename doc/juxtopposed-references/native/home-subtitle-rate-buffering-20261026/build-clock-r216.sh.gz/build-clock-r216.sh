#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-clock-r216.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-clock-r216-exit.txt"; exit "$code"' EXIT
test ! -e "$work/clock-r216-bin"
make -C "$base/win64/test" -j2 test_src_clock_clock.exe
mkdir "$work/clock-r216-bin"
cp "$base/win64/test/.libs/test_src_clock_clock.exe" "$work/clock-r216-bin/"
sha256sum "$work/clock-r216-bin/test_src_clock_clock.exe"
