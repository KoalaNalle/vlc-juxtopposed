#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-core-r220.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-core-r220-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 6e112dda0b98622579ff7569caf5e82d8e35f95d41ab4b52dded42187f8b0901
test ! -e "$work/core-r220-bin"
make -C "$base/win64/src" -j2 libvlccore.la
mkdir "$work/core-r220-bin"
cp "$base/win64/src/.libs/libvlccore.dll" "$work/core-r220-bin/"
cp "$base/win64/src/player/.deps/libvlccore_la-input.Plo" "$work/core-r220-bin/player-input.Plo"
sha256sum "$work/core-r220-bin/libvlccore.dll"

make -C "$base/win64/test" -j2 test_src_clock_clock.exe
mkdir "$work/clock-r220-bin"
cp "$base/win64/test/.libs/test_src_clock_clock.exe" "$work/clock-r220-bin/"
sha256sum "$work/clock-r220-bin/test_src_clock_clock.exe"
