from pathlib import Path
from hashlib import sha256
import gzip, json

work = Path(__file__).resolve().parent
repo = work.parents[1]
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda p: sha256(p.read_bytes()).hexdigest()
out = repo/'doc/juxtopposed-references/native/home-subtitle-rate-buffering-20261026'
assert not out.exists()
manifest = read(work/'inputs-r226.json')
assert all(digest(repo/p) == h for p, h in manifest['files'].items())
native = ['native-large-wasapi-d3d11-r223', 'native-large-wasapi-d3d11-r224',
          'native-all-d3d11-r224', 'native-all-software-r225']
for name in native:
    v = read(work/name/'verification.json')
    assert all(v[k] for k in ['sourceInputsUnchanged', 'runtimeUnchanged', 'fixturesUnchanged'])
    if name.endswith('r223'):
        assert not v['normalExit'] and v['actualWasapiSelected']
    else:
        assert v['normalExit']
        assert all(i['type'] == 'pass' for f in v['functions'] for i in f['incidents'])
for name in ['native-all-d3d11-r224', 'native-all-software-r225']:
    assert len(read(work/name/'verification.json')['functions']) == 30
assert read(work/'native-large-wasapi-d3d11-r224/verification.json')['actualWasapiSelected']
ordinary = read(work/'ui-timing-after-r226/verification.json')
assert ordinary['normalExit'] and ordinary['moduleCounts'] == ['602'] and not ordinary['diagnostics']
assert all(ordinary[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','pluginCacheUnchanged'])
assert read(work/'clock-all-r220/process.json')['normalExit']
assert read(work/'player-native-r226/verification.json')['normalExit']
timing = read(work/'timing-r226/processes.json')
assert len(timing['records']) == 11 and all(v['passed'] for v in timing['records'])
names = native + ['clock-before-r217','clock-before-r218','clock-before-r219',
    'clock-after-r220','clock-all-r220', 'delay-resume-short-wasapi-r214',
    'delay-resume-short-1x-wasapi-r214','delay-resume-diagnostic-r215',
    'delay-resume-clockfix-r220','delay-resume-sourcefix-r221',
    'ui-long-timing-r213','ui-timing-after-r226','player-native-r226','timing-r226']
assert all((work/n).is_dir() for n in names)
out.mkdir()
artifacts, streams = [], []
def retain(p, relative=None):
    target = out/((relative or p.relative_to(work).as_posix())+'.gz')
    assert not target.exists()
    raw = p.read_bytes()
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(raw,mtime=0))
    artifacts.append(dict(path=target.relative_to(out).as_posix(),sha256=digest(target),rawSha256=sha256(raw).hexdigest()))
for name in names:
    for p in sorted((work/name).rglob('*')):
        if not p.is_file() or any(s in p.relative_to(work/name).parts for s in
            ['runtime','userdata','appdata','localappdata','temp']): continue
        if p.suffix in ['.log','.txt']:
            streams.append(dict(path=p.relative_to(work).as_posix(),sha256=digest(p),packaged=False))
        elif p.suffix in ['.json','.xml','.png','.py','.qml']:
            retain(p)
for revision in ['r214','r216','r219','r220','r221','r222','r223','r224','r225','r226']:
    m = read(work/f'inputs-{revision}.json')
    retain(work/f'inputs-{revision}.json')
    for name in ['src/clock/clock.c','src/clock/input_clock.c','src/clock/input_clock.h',
                 'src/input/input.c','src/input/es_out.c','src/input/es_out.h',
                 'test/src/clock/clock.c','modules/gui/qt/tests/test_player_subtitle_delay.cpp',
                 'modules/gui/qt/tests/vlc_stub_modules.cpp']:
        if name not in m['sourceCopies']: continue
        p = Path(m['sourceCopies'][name]); assert digest(p)==m['files'][name]
        retain(p,f'sources/{revision}/{name}')
for p in sorted(work.iterdir()):
    if p.is_file() and p.suffix in ['.py','.sh','.mk','.c'] and any(
        f'r{n}' in p.stem for n in range(214,228)):
        retain(p)
record = dict(status='scoped-rate-buffering-checkpoint-beta-incomplete',fullBetaAccepted=False,
    selectedRuntime='build-windows/beta-single-frame-20261025-night/ui-timing-after-r226/runtime',
    runtimeSha256=ordinary['runtimeSha256'],artifacts=artifacts,localStreams=streams,
    accepted=[
      'Clock delay and shifted cue timestamps agree across 48 combinations of rates, signs, paused/playing and reference clocks. The unchanged new test fails the prior clock. All 13 clock scenarios pass with a private Windows tracer bridge.',
      'External subtitle preroll uses its own source rather than seeking main audio/video. Before repair, paused positive offsets move the encoded marker from 300 to 298; the same probe after repair retains marker300 and visible captions, then resumes normally through actual WASAPI.',
      'Removing temporary track delay no longer leaves it embedded in the network jitter floor. The unchanged large-delay test fails Core221 on resumed frame324 at14.24s; Core224 resumes on frame354 at14.199s with actual WASAPI, with no late-picture or avcodec-late errors.',
      'All 30 native subtitle test functions pass with software and D3D11 video. These full suites use dummy audio and record respectively two and one startup late-picture warnings, without avcodec late errors. Cold-selection cycles are three per registration order, six total.',
      'Official A-B and timer tests and eleven format/delay cases separately pass Core224. Their GUI identities differ from the ordinary candidate and are recorded per run.',
      'The ordinary Core224/GUI158 process supports signed primary/secondary timing marks, independent Reset, FPS changes, seek cancellation and input-change cancellation. Captions stay visible through extended playback. Normal exit0,602 modules,zero error diagnostics and all source/runtime/fixture/cache guards pass.'
    ],unresolved=[
      'Wall-clock estimator marks still need scaling into media time at nondefault playback speeds. Pause/resume cancellation needs native and ordinary verification. Signed ordinary values are state checks, not acoustic calibration.',
      'Embedded subtitles with a large positive delay, including inheritance from a category delay, need exact-frame coverage. External-only source preroll acceptance does not settle this separate case.',
      'Ordinary saved-default/cold-restart and earlier cue-preset journeys remain unfinished on the selected tuple.',
      'The first two Windows clock attempts fail tracer fixture discovery, not the clock contract. Later bridge setup is test-only and is absent from ordinary packages.',
      'The short public probe may record one expected vdummy window-closed teardown diagnostic. The earlier ordinary baseline records extensive late-video diagnostics; it is retained as a failure, not accepted playback.',
      'Secondary-screen idle fullscreen caption capture and broader orientation/HDR, design, OS-DPI and final-package qualification remain open. All beta gates remain open.'
    ])
(out/'checkpoint.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Subtitle rate and temporary buffering - 26 October 2026

Core `ccf72399` corrects delay scaling at nondefault rates, separates external
subtitle preroll from the main media seek and removes temporary track offsets
from the network jitter floor when they are reset. The retained before tests
fail on the old behaviors; the same tests pass the repairs.

The clock contract covers 48 combinations and all 13 clock scenarios pass.
Actual WASAPI playback passes the large-delay/reset/resume regression. Both
software and D3D11 video pass all 30 native subtitle functions; these full
suites use dummy audio and retain two and one startup late-picture warnings.
Official A-B/timer tests and eleven format/delay cases separately pass Core224.

The ordinary candidate exits normally with 602 modules, zero error diagnostics
and unchanged guards after independent timing/Reset, seek/input cancellation
and extended caption playback. Its signed estimator checks do not establish
correct calibration at nondefault speed; rate scaling and pause cancellation
remain next. Embedded positive-delay exact-frame coverage, saved-default/cold
restart and the older cue journey also remain open.

[checkpoint.json](checkpoint.json) records exact identities, scopes, fixture
corrections and remaining risks. Generated evidence, source copies and helpers
are compressed with hashes. Raw diagnostic streams stay local. This is a
development checkpoint, not beta or final-package acceptance. Continue from
[STATUS](../../../juxtopposed/STATUS.md).
''',encoding='utf-8',newline='\n')
print(str(out),len(artifacts),'artifacts',flush=True)
