from pathlib import Path
from hashlib import sha256
import ctypes,json,shutil,subprocess,sys
work=Path(__file__).resolve().parent;repo=work.parents[1]
revision,label,binary,scenario=sys.argv[1:]
digest=lambda p:sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',newline='\n')
manifest=work/f'inputs-{revision}.json';inputs=read(manifest)
assert all(digest(repo/p)==h for p,h in inputs['files'].items())
base=work/'ui-snapshot-primary-r211/runtime';expected=read(work/'ui-snapshot-primary-r211/verification.json')['runtimeSha256']
assert all(digest(base/p)==h for p,h in expected.items())
out=work/label;assert not out.exists();out.mkdir()
sys.path.insert(0,str(repo/'test/libvlc'))
from native_http_runtime import stage_runtime,environment
runtime=out/'runtime';stage_runtime(base,runtime)
program='test_src_clock_clock.exe';shutil.copyfile(work/f'clock-{binary}-bin'/program,runtime/program)
support=work/'support-r189/libssp-0.dll';shutil.copyfile(support,runtime/'libssp-0.dll')
bridge=runtime/'plugins/logger/libclock_test_bridge_plugin.dll';assert not bridge.exists()
shutil.copyfile(work/'clock-r218-bin/libclock_test_bridge_plugin.dll',bridge);bridge_hash=digest(bridge)
env=environment(runtime,out);env.pop('VLC_PLUGIN_PATH',None);env['VLC_TEST_PLUGIN_PATH']=str(runtime/'plugins')
cachefile=runtime/'plugins/plugins.dat';cachefile.unlink(missing_ok=True)
with (out/'cache-stdout.txt').open('wb') as cout,(out/'cache-stderr.txt').open('wb') as cerr:
    cache=subprocess.run([str(runtime/'vlc-cache-gen.exe'),str(runtime/'plugins')],cwd=runtime,env=env,stdout=cout,stderr=cerr,timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
assert cache.returncode==0
cache_hash=digest(cachefile)
command=[str(runtime/program)]+([] if scenario=='all' else [scenario,'--ignore-config'])
record=dict(status='starting',fullBetaAccepted=False,forcedCleanupUsed=False,command=command,
    executableSha256=digest(runtime/program),sourceManifestSha256=digest(manifest),
    producerSha256=digest(Path(__file__)),runtimeSha256=expected,bridgeSha256=bridge_hash,pluginCacheSha256=cache_hash,supportSha256=digest(support))
kernel=ctypes.WinDLL('kernel32',use_last_error=True);kernel.SetErrorMode.argtypes=[ctypes.c_uint];kernel.SetErrorMode.restype=ctypes.c_uint
previous=kernel.SetErrorMode(0x8003)
try:
    with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=runtime,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        record.update(status='running',pid=child.pid);write(out/'process.json',record);print(label,'PID',child.pid,flush=True)
        try:code=child.wait(timeout=180)
        except subprocess.TimeoutExpired:
            record.update(status='observation-timeout-process-left-running');write(out/'process.json',record)
            raise SystemExit('Inspect owned PID; no automatic cleanup or restart')
finally:kernel.SetErrorMode(previous)
record.update(status='terminal',exitCode=code,normalExit=code==0,
    sourceInputsUnchanged=all(digest(repo/p)==h for p,h in inputs['files'].items()),
    runtimeUnchanged=all(digest(runtime/p)==h and digest(base/p)==h for p,h in expected.items()),
    executableUnchanged=digest(runtime/program)==record['executableSha256'],
    bridgeUnchanged=digest(bridge)==bridge_hash,pluginCacheUnchanged=digest(cachefile)==cache_hash)
write(out/'process.json',record)
print(json.dumps({k:record[k] for k in ['exitCode','normalExit','sourceInputsUnchanged','runtimeUnchanged','executableUnchanged']}),flush=True)
