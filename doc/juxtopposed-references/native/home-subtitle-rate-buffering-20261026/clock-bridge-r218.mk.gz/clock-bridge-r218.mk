ifndef CLOCK_BRIDGE_OUT
$(error Fresh CLOCK_BRIDGE_OUT required)
endif
.PHONY: owned-clock-bridge
owned-clock-bridge: $(CLOCK_BRIDGE_OUT)/libclock_test_bridge_plugin.la
$(CLOCK_BRIDGE_OUT):
	mkdir -p "$@"
$(CLOCK_BRIDGE_OUT)/clock_bridge.lo: $(CLOCK_BRIDGE_SOURCE) | $(CLOCK_BRIDGE_OUT)
	$(LIBTOOL) --tag=CC --mode=compile $(CC) $(DEFS) $(DEFAULT_INCLUDES) $(libdemux_mock_plugin_la_CPPFLAGS) $(CPPFLAGS) $(AM_CFLAGS) $(CFLAGS) -c "$<" -o "$@"
$(CLOCK_BRIDGE_OUT)/libclock_test_bridge_plugin.la: $(CLOCK_BRIDGE_OUT)/clock_bridge.lo
	$(libdemux_mock_plugin_la_LINK) $< $(libdemux_mock_plugin_la_LIBADD) $(LIBS)
