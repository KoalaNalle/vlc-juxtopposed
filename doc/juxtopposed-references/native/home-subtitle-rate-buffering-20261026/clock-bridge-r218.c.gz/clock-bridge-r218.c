/* Private Windows unit-test runtime only; never an ordinary package plugin. */
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <vlc_common.h>
#include <vlc_plugin.h>
#include <vlc_tracer.h>
static const struct vlc_tracer_operations *Open(vlc_object_t *obj, void **opaque)
{
    typedef const struct vlc_tracer_operations *(*opener)(vlc_object_t *, void **);
    opener callback = var_InheritAddress(obj, "clock-test-open");
    return callback ? callback(obj, opaque) : NULL;
}
vlc_module_begin()
    set_callback(Open)
    set_capability("tracer", 0)
    add_shortcut("test_clock_clock")
vlc_module_end()
