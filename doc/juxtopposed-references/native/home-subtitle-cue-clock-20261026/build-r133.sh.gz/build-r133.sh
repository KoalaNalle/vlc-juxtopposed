#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
native="$base/owned-single-frame-native-20261026-r133"
ordinary="$base/owned-single-frame-ordinary-20261026-r133"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-r133.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-r133-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = f33bec1fcc121d3654177d0962847e57abb8f5e67a0da957cd4c5d3139e38126
test ! -e "$native"
test ! -e "$ordinary"
test ! -e "$work/native-r133-bin"
test ! -e "$work/ordinary-r133-bin"
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/build-windows/beta-subtitle-fps-20261023/native-r1.mk" -j2 FPS_NATIVE_OUT="$native" owned-subtitle-fps-native
mkdir "$work/native-r133-bin"
cp "$native/.libs/test_qt_player_subtitle_delay.exe" "$work/native-r133-bin/"
sha256sum "$work/native-r133-bin/test_qt_player_subtitle_delay.exe"
