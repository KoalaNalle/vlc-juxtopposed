#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-core-r117.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-core-r117-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 7288ceccd0ca10f5ea439410b664441315e69c767920374e953854c80e660811
test ! -e "$work/core-r117-bin"
make -C "$base/win64/src" -j2 libvlccore.la
mkdir "$work/core-r117-bin"
cp "$base/win64/src/.libs/libvlccore.dll" "$work/core-r117-bin/"
cp "$base/win64/src/player/.deps/libvlccore_la-input.Plo" "$work/core-r117-bin/player-input.Plo"
sha256sum "$work/core-r117-bin/libvlccore.dll"
