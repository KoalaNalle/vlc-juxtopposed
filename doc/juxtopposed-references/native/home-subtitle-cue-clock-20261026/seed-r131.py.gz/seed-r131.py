from pathlib import Path
import json
work=Path(__file__).resolve().parent
manifest=json.loads((work/'inputs-r130.json').read_text(encoding='utf-8'))
manifest['files']['modules/demux/subtitle.c']='newly-inventoried'
(work/'seed-r131.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
