#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-core-r130.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-core-r130-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = fc8cc67d95de51057fa8885a9c492b7b196a68f967fef6c3beaff0ca460662ed
test ! -e "$work/core-r130-bin"
make -C "$base/win64/src" -j2 libvlccore.la
mkdir "$work/core-r130-bin"
cp "$base/win64/src/.libs/libvlccore.dll" "$work/core-r130-bin/"
cp "$base/win64/src/player/.deps/libvlccore_la-input.Plo" "$work/core-r130-bin/player-input.Plo"
sha256sum "$work/core-r130-bin/libvlccore.dll"

make -C "$base/win64/modules" -j2 libsubtitle_plugin.la
mkdir "$work/subtitle-r130-bin"
cp "$base/win64/modules/.libs/libsubtitle_plugin.dll" "$work/subtitle-r130-bin/"
sha256sum "$work/subtitle-r130-bin/libsubtitle_plugin.dll"
