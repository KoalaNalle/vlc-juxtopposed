from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
work=Path(__file__).resolve().parent;repo=work.parents[1]
label=sys.argv[1];out=work/label;assert not out.exists();out.mkdir()
source=repo/'modules/gui/qt/player/qml/JuxtopposedSubtitleCueTimeline.qml'
test=repo/'modules/gui/qt/tests/test_juxtopposed_subtitle_timeline.py'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
before=dict(qml=digest(source),test=digest(test))
with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
    child=subprocess.Popen([sys.executable,str(test),'--output-dir',str(out/'output')],cwd=repo,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    code=child.wait(timeout=60)
(out/'verification.json').write_text(json.dumps(dict(exitCode=code,sourceSha256=before,inputsUnchanged=before==dict(qml=digest(source),test=digest(test)),scope='Production cue QML with supplied controller; native/ordinary results are separate.',fullBetaAccepted=False),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Cue component exit',code,flush=True)
raise SystemExit(code)
