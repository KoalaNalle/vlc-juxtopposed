#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-core-r136.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-core-r136-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = f33bec1fcc121d3654177d0962847e57abb8f5e67a0da957cd4c5d3139e38126
test ! -e "$work/core-r136-bin"
make -C "$base/win64/src" -j2 libvlccore.la
mkdir "$work/core-r136-bin"
cp "$base/win64/src/.libs/libvlccore.dll" "$work/core-r136-bin/"
cp "$base/win64/src/player/.deps/libvlccore_la-input.Plo" "$work/core-r136-bin/player-input.Plo"
sha256sum "$work/core-r136-bin/libvlccore.dll"
