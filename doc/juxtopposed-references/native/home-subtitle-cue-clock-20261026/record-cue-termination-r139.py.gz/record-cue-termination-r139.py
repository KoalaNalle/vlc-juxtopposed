from pathlib import Path
import json
work=Path(__file__).resolve().parent
out=work/'cue-regression-r135/observed-termination.json'
assert not out.exists()
out.write_text(json.dumps(dict(status='abnormal-native-termination-preserved',
    originalVerificationStatus='running-stale-after-parent-XML-parse-error',
    childPid=20092,childAbsentConfirmed=True,childExitCode=None,
    stderr='Assertion failed: position >= 0, src/player/timer.c line 334',
    xml='Incomplete during actualNormalLockAndExactMicrosecondSeekRequest',
    forcedCleanupUsed=False,normalExit=False,
    note='The original runner did not persist its child exit code before XML parsing failed. Do not infer that the stale running record means a child is still alive.',
    fullBetaAccepted=False),indent=2)+'\n',encoding='utf-8',newline='\n')
