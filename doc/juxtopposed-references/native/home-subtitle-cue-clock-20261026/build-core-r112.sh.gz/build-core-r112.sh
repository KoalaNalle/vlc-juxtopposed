#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-core-r112.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-core-r112-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 883f7e51c57be0de40e8c6a47db6ca3f60ac4cdb98920a9846b9a5e8ce8adb22
test ! -e "$work/core-r112-bin"
make -C "$base/win64/src" -j2 libvlccore.la
mkdir "$work/core-r112-bin"
cp "$base/win64/src/.libs/libvlccore.dll" "$work/core-r112-bin/"
cp "$base/win64/src/input/.deps/libvlccore_la-decoder.Plo" "$work/core-r112-bin/decoder.Plo"
sha256sum "$work/core-r112-bin/libvlccore.dll"
