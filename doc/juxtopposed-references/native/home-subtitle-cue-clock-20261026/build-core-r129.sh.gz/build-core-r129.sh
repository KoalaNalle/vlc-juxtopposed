#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-core-r129.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-core-r129-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 7bc1189b71d4e2490eef773af85ec1cebe5d93aab2eefa8735b1cdeec8792224
test ! -e "$work/core-r129-bin"
make -C "$base/win64/src" -j2 libvlccore.la
mkdir "$work/core-r129-bin"
cp "$base/win64/src/.libs/libvlccore.dll" "$work/core-r129-bin/"
cp "$base/win64/src/player/.deps/libvlccore_la-input.Plo" "$work/core-r129-bin/player-input.Plo"
sha256sum "$work/core-r129-bin/libvlccore.dll"
