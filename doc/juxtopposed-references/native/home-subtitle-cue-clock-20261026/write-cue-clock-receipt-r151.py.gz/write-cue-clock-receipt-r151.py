from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
out=repo/'doc/juxtopposed-references/native/home-subtitle-cue-clock-20261026'
assert not out.exists()
final_ui='ui-cue-ready-r151'
ui=read(work/final_ui/'verification.json')
assert ui['normalExit'] and all(ui[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','pluginCacheUnchanged'])
for name,count in [('native-final-r136',25),('cue-settled-r138',13),('timeline-key-after-r150',13)]:
    v=read(work/name/'verification.json')
    assert v['exitCode']==0 and len(v['functions'])==count
    assert all(i['type']=='pass' for f in v['functions'] for i in f['incidents'])
    assert all(v[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged'])
assert read(work/'rate-startup-r138/verification.json')['passed']
assert read(work/'timing-r138/processes.json')['passed']
assert read(work/'late-boundary-final-d3d11-r138/verification.json')['exitCode']==0
assert read(work/'cue-focus-before-r142/verification.json')['exitCode']==1
assert read(work/'cue-component-final-r150/verification.json')['exitCode']==0
out.mkdir();artifacts=[]
def retain(path,name=None):
    raw=path.read_bytes();relative=name or path.relative_to(work).as_posix()
    target=out/(relative+'.gz');assert not target.exists()
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(raw,mtime=0))
    artifacts.append(dict(path=target.relative_to(out).as_posix(),sha256=digest(target),rawSha256=sha256(raw).hexdigest()))
runs=['cue-before-r111','cue-core-only-r112','native-core-regression-r113',
 'cue-timeline-after-r113','cue-settled-r114','cue-stable-r115','cue-clock-trace-r116',
 'cue-final-r117','native-final-core-r117','ui-cue-r118','ui-cue-cold-r119',
 'late-fps-control-r121','late-preset-pixels-r122','late-preset-d3d11-r123',
 'late-preset-d3d11-r124','ui-cue-software-r125','ui-cue-hw-control-r126',
 'ui-cue-timeline-r127','late-fps-boundary-software-r127','late-fps-boundary-d3d11-r127',
 'late-boundary-capture-software-r128','late-boundary-trace-r129',
 'late-boundary-origin-software-r131','late-boundary-origin-trace-r131',
 'late-boundary-picture-software-r132','late-boundary-final-d3d11-r134',
 'cue-regression-r135','cue-final-r136','native-final-r136','cue-settled-r138',
 'late-boundary-final-d3d11-r138','main-startup-final-r146','rate-startup-r138','timing-r138',
 'ui-cue-fixed-r138','cue-focus-before-r140','cue-focus-before-r141','cue-focus-before-r142',
 'cue-focus-after-r144','cue-focus-after-r145','cue-component-final-r150',
 'ui-cue-focus-r146','timeline-key-before-r148','timeline-key-after-r150',final_ui]
for name in runs:
    root=work/name;assert root.is_dir(),name
    for p in sorted(root.rglob('*')):
        parts=p.relative_to(root).parts
        if p.is_file() and 'runtime' not in parts and p.suffix in ['.json','.xml','.log','.jpg','.png','.txt']:
            if p.name in ['config-before.txt','config-after.txt']:continue
            retain(p)
sources=['src/input/decoder.c','src/player/input.c','src/player/timer.c',
 'src/video_output/video_output.c','src/video_output/vout_subpictures.c','modules/demux/subtitle.c',
 'modules/gui/qt/player/subtitle_cue_data.cpp','modules/gui/qt/player/subtitle_cue_timeline.cpp',
 'modules/gui/qt/player/qml/JuxtopposedSubtitleCueTimeline.qml',
 'modules/gui/qt/maininterface/interface_window_handler.cpp',
 'modules/gui/qt/tests/test_subtitle_cue_timeline.cpp','modules/gui/qt/tests/test_player_subtitle_delay.cpp',
 'modules/gui/qt/tests/test_juxtopposed_subtitle_timeline.py',
 'modules/gui/qt/tests/test_shared_modal_hotkeys.cpp','modules/gui/qt/tests/vlc_stub_modules.cpp']
for revision in ['r111','r117','r128','r129','r131','r132','r136','r138','r143','r146','r148','r150']:
    manifest=read(work/f'inputs-{revision}.json');retain(work/f'inputs-{revision}.json')
    for name in sources:
        if name not in manifest['files']:continue
        p=Path(manifest['sourceCopies'][name]);assert digest(p)==manifest['files'][name]
        retain(p,f'sources/{revision}/{name}')
preimage=subprocess.check_output(['git','show','5b3eb021c026b4fa595bfec36e1ff0975c3f7bfd:modules/demux/subtitle.c'],cwd=repo)
p=work/'subtitle-preimage-r151.c';assert not p.exists();p.write_bytes(preimage)
retain(p,'preimage/5b3eb021/modules/demux/subtitle.c')
helpers=['build-core-r112.sh','build-core-r117.sh','build-core-r129.sh','build-core-r130.sh','build-core-r132.sh','build-core-r136.sh',
 'build-r128.sh','build-r133.sh','build-r135.sh','build-cue-r137.sh','build-hotkeys-r147.sh','build-hotkeys-r149.sh','build-gui-r150.sh',
 'run-native-cue-r136.py','run-native-hotkeys-r148.py','run-native-subtitle-r130.py','run-ui-cue-r150.py',
 'run-timing-r138.py','run-rate-startup-r138.py','run-main-startup-r138.py','run-cue-component-r140.py',
 'seed-r131.py','record-cue-termination-r139.py','write-cue-clock-receipt-r151.py']
for name in helpers:retain(work/name)
record=dict(status='scoped-checkpoint-session-continues',fullBetaAccepted=False,artifacts=artifacts,
 selectedOrdinaryRuntime=ui['runtimeSha256'],
 native=dict(subtitleFunctions=25,cueFunctions=13,timelineKeyRows=11,mainStartupRates=4,startupCases=13,timingCases=11),
 ordinaryChecks=['Cold saved 30-fps preset, timeline availability after changing FPS to zero, and actual caption at exact20s.',
 'Right pans the cue viewport without the former native10s video jump. Return and Space select the cue while paused; Minus and Equal change viewport span.',
 'Pointer drag applies969ms subtitle delay, which appears as0.969s in actual player settings. Return seeks the shifted cue and the caption appears.',
 'Ctrl+R reloads the cue snapshot. Escape with the cue tooltip visible dismisses that popup first; a second Escape closes the timeline while retaining fullscreen and the paused caption.',
 'Normal Ctrl+Q exits with source/runtime/fixture/cache guards unchanged,602 modules and no diagnostics.'],
 repairs=['Release obsolete first-picture buffering acknowledgement after decoder flush.',
 'Keep repeated paused redraws in media-relative units and represent a zero request by position.',
 'Read before-first-cue timeline capability from the actual selected primary video output.',
 'Scale subtitle media time without adding the timestamp origin twice.',
 'Select paused subtitles against the displayed picture clock.',
 'Retain cue focus across asynchronous viewport/delegate changes and reserve timeline keys before native player shortcuts.'],
 beforeFailures=['cue-before-r111 retains its shutdown hang, CDB stacks and explicit forced cleanup.',
 'cue-stable-r115 retains a 40ms repeated-redraw drift; diagnostic Core r116 is not selected.',
 'late-boundary-capture-software-r128 and trace-r129 have zero caption pixels at marker500 after FPS reset; retained-FPS control passes.',
 'Origin-only plugin r130 still fails; trace shows one remaining tick at the frozen pause date.',
 'cue-regression-r135 retains timer-origin assertion and partial XML. Its child exit code was not saved by the old runner; observed-termination.json records absence without inventing it.',
 'cue-focus-before-r142 reproduces asynchronous delegate focus loss; ui-cue-focus-r146 shows the additional native shortcut interception.',
 'timeline-key-before-r148 fails all ten original key rows; final run adds and passes Shift+Plus too.'],
 testSetup=['The r134 negative-control seek at19.96s landed on frame500 rather than499; r135 uses the unambiguous19s marker475, retains the failed setup, and keeps exact20s positive and40s expiry checks.',
 'The r136 cue fixture compared a completion notification before clock-point delivery settled. r137 waits for an unchanged clock and no pending seek for250ms; the exact before/after equality is retained.',
 'The first focus harness attempt changed supplied playback position before its old color assertion; r141 restores that fixture state. Only queued native-style completion in r142 reproduces the focus defect.',
 'The old manifest did not inventory subtitle.c. It is explicitly seeded at r131; the unchanged HEAD preimage and staged plugin hashes preserve the before identity.'],
 limits=['The single longer warm caption-loss observation in ui-cue-r118 is retained; fresh software/hardware controls recover on middle-cue seek. Do not claim a reproducible cause for the longer loss.',
 'Component, native, ordinary desktop and final-package acceptance have distinct scope.',
 'Native suites use their recorded support GUI binaries. Only the ordinary capture uses the selected production GUI.',
 'The ordinary Escape check needed two presses while a tooltip was visible. Do not describe it as unconditional single-key dismissal.',
 'The native caption boundary includes negative before/after controls in software and actual D3D11; parsed SRT availability alone is not renderer truth.',
 'Windows OS DPI, final matched package, all surface acceptance and other beta gates remain open.'])
(out/'checkpoint.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Subtitle cue clock and keyboard checkpoint - 26 October 2026

This scoped receipt preserves before failures and repairs for paused cue seeking,
decoder flush/shutdown, repeated redraw timing, before-first-cue timeline access,
external subtitle timestamp normalization and timeline keyboard ownership.
It is not full beta or final-package acceptance.

Native checks pass 25 subtitle functions, thirteen cue functions, eleven timeline
key rows, four main-startup rates, thirteen startup/audio cases and eleven
delay/boundary cases. Software and actual D3D11 frame checks include no caption
before the cue, the exact cue start, the middle of the cue and expiry afterward.
The focus component test uses queued completion and viewport recreation; native
key routing separately executes the exact production routing method.

The ordinary selected tuple, captures and normal exits are bound by
[checkpoint.json](checkpoint.json). Native fixtures use their separately recorded
support GUI binaries. See the checkpoint limits and setup corrections before
combining evidence. The earlier longer warm caption-loss observation remains
preserved and must not be silently treated as explained by the boundary repair.

The hang and forced cleanup, a later timer assertion with incomplete XML, and
diagnostic Cores are retained. They are not candidate runtimes. Frozen sources,
helpers, checksums, logs and captures are compressed alongside the receipt.
Continue from [STATUS](../../../juxtopposed/STATUS.md).
''',encoding='utf-8',newline='\n')
print(str(out),len(artifacts),flush=True)
