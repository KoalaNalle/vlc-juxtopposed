from pathlib import Path
from hashlib import sha256
import ctypes,json,shutil,subprocess,sys
work=Path(__file__).resolve().parent;repo=work.parents[1]
revision,label=sys.argv[1:]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
manifest=work/f'inputs-{revision}.json';inputs=read(manifest)
assert all(digest(repo/p)==h and digest(Path(inputs['sourceCopies'][p]))==h for p,h in inputs['files'].items())
base=work/'ui-r59/runtime';protected=read(base.parent/'verification.json')['runtimeSha256']
assert all(digest(base/p)==h for p,h in protected.items())
out=work/label;assert not out.exists();out.mkdir()
sys.path.insert(0,str(repo/'test/libvlc'))
from native_http_runtime import stage_runtime,environment
runtime=out/'runtime';stage_runtime(base,runtime)
shutil.copyfile(base/'plugins/plugins.dat',runtime/'plugins/plugins.dat')
target=runtime/'libvlccore.dll';target.unlink();shutil.copyfile(work/'core-r136-bin/libvlccore.dll',target)
subtitle_name='plugins/demux/libsubtitle_plugin.dll'
protected[subtitle_name]=digest(base/subtitle_name)
subtitle=runtime/subtitle_name;subtitle.unlink();shutil.copyfile(work/'subtitle-r130-bin/libsubtitle_plugin.dll',subtitle)
identities={p:digest(runtime/p) for p in protected}

media=repo/'build-windows/beta-subtitle-fps-20261024/media-r1/frame-marker.mp4'
worker=repo/'test/libvlc/native_paused_video_startup.py';worker_hash=digest(worker)
media_hash=digest(media);records=[]
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.SetErrorMode.argtypes=[ctypes.c_uint];kernel.SetErrorMode.restype=ctypes.c_uint
previous=kernel.SetErrorMode(0x8003)
try:
    cases=[(audio,rate,True) for audio in ['wasapi','dummy','none'] for rate in [1.,.5,1.5,2.]]
    cases.append(('wasapi',1.,False))
    for index,(audio,rate,caption) in enumerate(cases):
        case=out/f'{index+1:02}-{audio}-{rate:g}-{int(caption)}'
        case.mkdir();probe=case/'probe';probe.mkdir()
        extra=['--rate='+str(rate)]
        if not caption:extra+=['--no-spu']
        cfg=dict(name=case.name,media=str(media),audio=audio,video=True,
            extraOptions=extra,expectedSubtitleAtStart=caption)
        config=case/'config.json';write(config,cfg)
        env=environment(runtime,case);env.pop('VLC_PLUGIN_PATH',None)
        row=dict(status='starting',case=case.name,forcedCleanupUsed=False,fullBetaAccepted=False)
        with (case/'stdout.txt').open('wb') as stdout,(case/'stderr.txt').open('wb') as stderr:
            child=subprocess.Popen([sys.executable,str(worker),'--config',str(config),'--runtime',str(runtime),'--output',str(probe)],
                cwd=runtime,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
            row.update(status='running',pid=child.pid);write(case/'process.json',row)
            print(case.name,'PID',child.pid,flush=True)
            try:code=child.wait(timeout=90)
            except subprocess.TimeoutExpired:raise SystemExit('Inspect owned child; no automatic cleanup/restart')
        result=read(probe/'result.json') if (probe/'result.json').exists() else None
        row.update(status='terminal',exitCode=code,normalExit=code==0,result=result,
            passed=bool(code==0 and result and result['passed']))
        write(case/'process.json',row);records.append(row)
        write(out/'verification.json',dict(status='running',records=records))
        first=(result or {}).get('observations',[{}])[0]
        print(case.name,'exit',code,'brightPixels',first.get('brightPixels'),'rate',first.get('rate'),'passed',row['passed'],flush=True)
        if code!=0:raise SystemExit('Inspect abnormal exit before continuing')
finally:kernel.SetErrorMode(previous)
record=dict(status='terminal',passed=all(r['passed'] for r in records),records=records,
    sourceManifestSha256=digest(manifest),runtimeSha256=identities,fixtureSha256=media_hash,
    workerSha256=worker_hash,producerSha256=digest(Path(__file__)),fullBetaAccepted=False,
    sourceInputsUnchanged=all(digest(repo/p)==h for p,h in inputs['files'].items()),
    runtimeUnchanged=all(digest(base/p)==h and digest(runtime/p)==identities[p] for p,h in protected.items()),
    fixturesUnchanged=digest(media)==media_hash,workerUnchanged=digest(worker)==worker_hash)
write(out/'verification.json',record)
assert all(record[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','workerUnchanged'])
print(json.dumps(dict(cases=len(records),passed=record['passed'],normalExits=all(r['normalExit'] for r in records))),flush=True)
