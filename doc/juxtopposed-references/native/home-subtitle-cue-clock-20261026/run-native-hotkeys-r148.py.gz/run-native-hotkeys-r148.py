from pathlib import Path
from hashlib import sha256
import ctypes,json,shutil,subprocess,sys,xml.etree.ElementTree as ET
work=Path(__file__).resolve().parent;repo=work.parents[1]
revision,label,binary,core,mode=sys.argv[1:];read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
manifest=work/f'inputs-{revision}.json';inputs=read(manifest)
assert all(digest(repo/p)==h and digest(Path(inputs['sourceCopies'][p]))==h for p,h in inputs['files'].items())
base=work/'ui-r77/runtime';expected=read(work/'ui-r77/verification.json')['runtimeSha256']
assert all(digest(base/p)==h for p,h in expected.items())
out=work/label;assert not out.exists();out.mkdir()
sys.path.insert(0,str(repo/'test/libvlc'))
from native_http_runtime import stage_runtime,environment
runtime=out/'runtime';stage_runtime(base,runtime)
target=runtime/'libvlccore.dll';target.unlink();shutil.copyfile(work/core,target)
program='test_qt_shared_modal_hotkeys.exe';shutil.copyfile(work/f'cue-{binary}-bin'/program,runtime/program)
subtitle_name='plugins/demux/libsubtitle_plugin.dll'
expected[subtitle_name]=digest(base/subtitle_name)
subtitle=runtime/subtitle_name;subtitle.unlink();shutil.copyfile(work/'subtitle-r130-bin/libsubtitle_plugin.dll',subtitle)
identities={p:digest(runtime/p) for p in expected}
media=repo/'build-windows/duration-fixtures-20261014'
fixtures={name:digest(media/name) for name in ['subtitle-style.mp4','duration-cues.srt','paused-seek-colors.mp4']}
late=work/'attachment-media-r85/Show.S01E01.mp4';latehash=digest(late)
env=environment(runtime,out);env.pop('VLC_PLUGIN_PATH',None)
env.update(VLC_TIMELINE_FIXTURE_DIR=str(media),VLC_TIMELINE_LATE_VIDEO=str(late))
command=[str(runtime/program)]
if mode=='routing':command+=['mouseFocusedTimelineKeepsOwnKeys']
elif mode=='late':command+=['actualSelectedExternalSource','pausedBeforeFirstCueStillHasTimeline']
elif mode=='seek':command+=['actualSelectedExternalSource','nativeDelayInheritanceOverrideAndFpsGuard','actualCueSeekAndStaleRequestGuards']
elif mode!='all':raise ValueError(mode)
command+=['-o',str(out/'results.xml')+',xml']
record=dict(status='starting',sourceManifestSha256=digest(manifest),producerSha256=digest(Path(__file__)),testExecutableSha256=digest(runtime/program),runtimeSha256=identities,fixtureSha256=fixtures,lateVideoSha256=latehash,privateNativeFixture=True,ordinaryGuiAccepted=False,fullBetaAccepted=False,forcedCleanupUsed=False)
kernel=ctypes.WinDLL('kernel32',use_last_error=True);kernel.SetErrorMode.argtypes=[ctypes.c_uint];kernel.SetErrorMode.restype=ctypes.c_uint
previousMode=kernel.SetErrorMode(0x8003)
try:
    with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=runtime,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        record.update(status='running',pid=child.pid);write(out/'verification.json',record);print('Owned native cue PID',child.pid,flush=True)
        try:record['exitCode']=child.wait(timeout=180)
        except subprocess.TimeoutExpired:
            record['status']='observation-timeout-process-left-running';write(out/'verification.json',record);raise SystemExit('Inspect owned PID; no automatic cleanup or restart')
finally:kernel.SetErrorMode(previousMode)
record.update(status='terminal',normalExit=record['exitCode']==0,sourceInputsUnchanged=all(digest(repo/p)==h for p,h in inputs['files'].items()),runtimeUnchanged=all(digest(base/p)==h and digest(runtime/p)==identities[p] for p,h in expected.items()),fixturesUnchanged=all(digest(media/p)==h for p,h in fixtures.items()) and digest(late)==latehash,producerUnchanged=digest(Path(__file__))==record['producerSha256'])
if (out/'results.xml').exists():
    try:
        root=ET.parse(out/'results.xml').getroot()
    except ET.ParseError as error:
        record['xmlError']=str(error);write(out/'verification.json',record);raise SystemExit('Child terminated with incomplete XML; inspect retained stderr and recorded exit')
    record['functions']=[dict(name=f.attrib.get('name'),incidents=[dict(type=i.attrib.get('type'),description=i.findtext('Description','')) for i in f.findall('Incident')]) for f in root.findall('TestFunction')]
write(out/'verification.json',record);print(json.dumps({k:record[k] for k in ['status','exitCode','sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','functions'] if k in record}),flush=True)
assert record['normalExit'] and record['sourceInputsUnchanged'] and record['runtimeUnchanged'] and record['fixturesUnchanged']
