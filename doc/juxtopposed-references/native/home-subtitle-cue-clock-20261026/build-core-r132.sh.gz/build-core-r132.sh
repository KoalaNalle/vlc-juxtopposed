#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-core-r132.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-core-r132-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 3e218b1ef1d20c324f65b686ddb51e1604ddc6c3f19c8476859f7dbfb432f85d
test ! -e "$work/core-r132-bin"
make -C "$base/win64/src" -j2 libvlccore.la
mkdir "$work/core-r132-bin"
cp "$base/win64/src/.libs/libvlccore.dll" "$work/core-r132-bin/"
cp "$base/win64/src/player/.deps/libvlccore_la-input.Plo" "$work/core-r132-bin/player-input.Plo"
sha256sum "$work/core-r132-bin/libvlccore.dll"
