from pathlib import Path
from hashlib import sha256
import gzip, json, subprocess

work=Path(__file__).resolve().parent; repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
receipt=repo/'doc/juxtopposed-references/native/home-global-shortcut-feedback-20261027'
assert not receipt.exists()
source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert source_commit.startswith('a6cd73445c')
analysis=read(work/'global-shortcut-analysis-r448.json'); assert analysis['passed']
manifest=read(work/'inputs-r444.json')
assert all(digest(repo/p)==h for p,h in manifest['files'].items())
names=['inputs-r430.json','inputs-r432.json','inputs-r434.json','inputs-r436.json',
       'inputs-r439.json','inputs-r441.json','inputs-r444.json',
       'freeze-global-hotkeys-r430.py','freeze-global-shortcuts-r439.py',
       'prepare-global-hotkeys-long-r444.py','run-ui-global-shortcuts-r441.py',
       'run-ui-global-shortcuts-long-r444.py','global-shortcut-media-r444/fixture.json',
       'check-global-shortcuts-r448.py','global-shortcut-analysis-r448.json',
       'write-global-shortcut-receipt-r449.py']
for stem in ['build-global-hotkey-probe-r430','build-global-hotkeys-r432',
             'build-global-hotkey-probe-r434','build-global-hotkey-probe-r436',
             'build-global-shortcut-model-r439','build-global-shortcuts-ui-r441']:
    names += [stem+suffix for suffix in ['.sh','.log','-exit.txt']]
files=[work/name for name in names]
for run in ['native-global-hotkeys-before-r431','native-global-hotkeys-r433',
            'native-global-hotkeys-r435','native-global-hotkeys-r437','native-global-shortcut-model-r440']:
    files.extend(work/run/name for name in ['verification.json','results.xml','stderr.txt','stdout.txt','producer.py'])
component=work/'component-global-shortcut-feedback-r438'
files.extend(p for p in component.iterdir() if p.is_file())
for run in ['ui-global-hotkeys-a-r442','ui-global-hotkeys-b-r443',
            'ui-global-hotkeys-a-r445','ui-global-hotkeys-b-r446','ui-global-hotkeys-cold-r447']:
    record=read(work/run/'verification.json')
    assert record['normalExit'] and not record['diagnostics'] and record['moduleCounts']==['602']
    assert all(value for key,value in record.items() if key.endswith('Unchanged'))
    files.extend(work/run/name for name in ['verification.json','vlc.log','stderr.txt','producer.py',
                                          'launch.json','settings-before.ini','settings-after.ini',
                                          'config-before.txt','config-after.txt'])
    files.extend(p for p in (work/run/'observations').iterdir() if p.is_file())
receipt.mkdir(); (receipt/'artifacts').mkdir(); inventory=[]
for path in sorted(set(files)):
    data=path.read_bytes(); name=path.relative_to(work).as_posix().replace('/','__')+'.gz'
    target=receipt/'artifacts'/name; target.write_bytes(gzip.compress(data,mtime=0))
    assert gzip.decompress(target.read_bytes())==data
    inventory.append(dict(file='artifacts/'+name,source=path.relative_to(repo).as_posix(),
                          sha256=sha256(data).hexdigest(),gzipSha256=digest(target),
                          bytes=len(data),compressedBytes=target.stat().st_size))
checkpoint=dict(sourceCommit=source_commit,
    runtime='build-windows/beta-single-frame-20261025-night/ui-global-hotkeys-cold-r447/runtime',
    runtimeSha256=analysis['runtimeSha256'],analysis=analysis,artifacts=inventory,
    independentReviewAccepted=False,allShortcutActionsAccepted=False,
    actualWindowsDpiAccepted=False,screenReaderAccepted=False,fullBetaAccepted=False,
    finalPackageAccepted=False,firewallRuleChanges=[],securityPrivacyChanges=[])
(receipt/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n',encoding='utf-8')
(receipt/'README.md').write_text(f'''# Windows global shortcut registration feedback

27 October 2026. Source `{source_commit}`. The Windows backend now reports which
global bindings actually registered, including a bounded list of failed keys.
Controls and the native shortcut editor show that running result separately from
saved mappings. A collision identifies the action/key and explains the restart
requirement. Search for Global Shortcuts retains the status and Edit action.
Unsupported Meta/Command modifiers and reserved F12 are reported explicitly.
Every successful global-atom reference is balanced during shutdown, including
multiple bindings of one action. The transient report belongs to one VLC root;
it does not save preferences or claim a new mapping is already active.

## Evidence

- Before r431: the previous plugin lacks the versioned report and the negative
  test fails during initialization as expected. No later scenarios ran.
- Final real Windows module test r437: six functions including initialization/
  cleanup pass, zero failures/skips. It checks inactive defaults, active/partial
  registration, same-chord error1409, another independent binding, release and
  reacquisition, owned atom balancing, explicit unsupported keys and the32-row
  error bound. It loads the real module without synthetic key delivery.
- Native Controls model r440: twenty functions pass. Supplied-report seams check
  status parsing, bounds, malformed/future input, warnings and unchanged running
  feedback after saving a replacement. This consumer seam is distinct from the
  real Windows registration test. Maintained QML r438 passes nine groups,
  including searchable read-only feedback without a preference write.
- Ordinary GUI441 `{analysis['runtimeSha256']['plugins/gui/libqt_plugin.dll'][:8]}`,
  Windows-hotkeys432 `{analysis['runtimeSha256']['plugins/control/libwin_hotkeys_plugin.dll'][:8]}`,
  Core265 and the identified existing tuple run without private hooks.
  Player A owns Ctrl+Alt+Shift+F8/F9; B reports0active/2unavailable and names both
  conflicts in Controls and the editor. With B focused, F8 starts A and F9 pauses
  A; B remains paused at zero. A's held position remains
  `{analysis['ownerPausedPosition']}` during B's editing and until A exits normally.
- B saves Ctrl+Alt+Shift+F10 through the real editor. The saved/restart message
  appears, the running F8/F9 failures remain, and F10 has no pre-restart effect.
  Closing A does not silently activate B's rejected bindings. After normal B
  exit and a cold start with its saved configuration, the status is1active,
  the editor contains F10, and F10 starts/pauses playback. The final held position
  is `{analysis['coldPausedPosition']}`. Search retains the feedback and Edit action.
- The three long-fixture runs exit0 with602plugins, zero checked errors and all
  source/runtime/base/fixture/producer/cache ending guards. Only B's
  `global-key-play-pause` native config key changes; the complete player profile
  catalogues remain identical across all three runs. No private media is included.

## Preserved limitations and preliminary outcomes

The first positive test r433 assumed registration had finished as soon as the
report existed. It observed starting; the corrected harness waits for a ready
state. r435 skipped atom balancing because another owner already had a play-pause
atom; the final test uses an initially absent stop atom and does not touch another
owner's reference. The preliminary ordinary r442/r443 runs exit normally with all
guards, but the60-second fixture reached EOF during inspection. They do not
establish the intended key journey. The repeat uses a generated one-hour silent
WAV with its own identity and ending guard.

Immediate and occluded UI captures can lag actual playback; assertions use settled
foreground observations. Native-modal element indexes were sometimes unavailable;
fresh screenshots and visible controls completed the journey. r447 observation06
shows General despite its early filename; observation07 establishes the active
count. Editor Escape was inconclusive through automation; explicit Cancel worked.
UIA still reports a stale focused element, so these captures do not establish
screen-reader/focus acceptance. No OS DPI or complete visual score is claimed.

This closes the scoped registration/conflict feedback gap, not every shortcut or
S32. Audit the legacy mapping of other keys/punctuation and remaining action/hint
paths separately. Actual Windows DPI, themes, accessibility, remaining instance
combinations, integrated regression, independent review and clean-package/beta
gates remain open. Older tested runtimes remain recoverable.

No firewall rules, security/privacy or Defender settings changed. The API basis is
Microsoft's [RegisterHotKey](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-registerhotkey),
[UnregisterHotKey](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-unregisterhotkey)
and [system error codes](https://learn.microsoft.com/en-us/windows/win32/debug/system-error-codes--1300-1699-).
`checkpoint.json` binds source, binaries, fixtures and compressed evidence with
SHA-256; every artifact was decompressed and verified. Binaries, media and isolated
profiles remain in ignored build output. This receipt is a frozen scoped record.
''',encoding='utf-8')
print(json.dumps(dict(sourceCommit=source_commit,artifacts=len(inventory),compressedBytes=sum(i['compressedBytes'] for i in inventory))))
