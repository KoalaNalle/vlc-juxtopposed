from pathlib import Path
from hashlib import sha256
import json,shutil,sys
work=Path(__file__).resolve().parent
repo=work.parents[1]
prior,revision=sys.argv[1:]
old=json.loads(Path(prior).read_text(encoding='utf-8'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
names={p for p in old['files'] if (repo/p).is_file()
       and not p.startswith('build-windows/beta-subtitle-sync-20261025/')}
names.update(p.relative_to(repo).as_posix() for p in work.iterdir()
             if p.suffix in ('.py','.sh','.mk','.cpp','.h','.c'))
names.update(['AGENTS.md','README.md','.gitattributes',
              'test/src/interface/controls.c','test/controls-native.mk',
              'test/libvlc/native_controls.py','test/libvlc/native_paused_video_startup.py'])
names.update(['test/src/clock/clock.c','src/clock/clock.c','src/clock/clock.h'])
names.add('build-windows/beta-subtitle-sync-20261025/ordinary.mk')
names.update(['modules/gui/qt/tests/test_pointing_tooltip_text.py','modules/gui/qt/tests/test_juxtopposed_titlebar.py'])
names.update(p.relative_to(repo).as_posix() for p in (work/'figma-music-header-r400').glob('*.svg'))
names.update(['modules/control/globalhotkeys/win32.c','modules/control/Makefile.am',
 'modules/gui/qt/tests/test_global_hotkey_registration.cpp','modules/gui/qt/tests/native_library/global-hotkeys.mk',
 'modules/gui/qt/dialogs/preferences/controls_shortcuts.cpp','modules/gui/qt/dialogs/preferences/controls_shortcuts.hpp',
 'modules/gui/qt/tests/juxtopposed_controls_preferences_fixture.py'])
names.update(['modules/gui/qt/player/local_music_folder.cpp','modules/gui/qt/player/local_music_folder.hpp','modules/gui/qt/tests/test_local_music_folder.cpp','modules/gui/qt/tests/media_player_probe.c','modules/gui/qt/tests/network_stream_probe.c'])
names.update(p.relative_to(repo).as_posix() for p in (work/'figma-music-navigation-r372').glob('*.svg'))
names.update('build-windows/beta-single-frame-20261025-night/'+name for name in ['music-navigation-high-fidelity-r379.json','music-navigation-asset-renders-r374.json'])
names.update(p.relative_to(repo).as_posix() for p in (work/'figma-music-toolbar-assets-r357').glob('*.svg'))
names.update('build-windows/beta-single-frame-20261025-night/'+name for name in ['music-toolbar-asset-identities-r358.json','music-toolbar-asset-renders-r359.json'])
names.update(['modules/gui/qt/maininterface/player_profile_layout.cpp','modules/gui/qt/maininterface/player_profile_layout.hpp','modules/gui/qt/tests/test_player_profile_layout.cpp','modules/gui/qt/tests/native_library/profile-layout.mk','modules/gui/qt/tests/test_juxtopposed_music_toolbar.py'])
names.add('build-windows/beta-single-frame-20261025-night/collection-native-policy-r344.json')
names.update('build-windows/beta-single-frame-20261025-night/figma-music-r347/'+name for name in ['review-context.json','music-open.png','music-closed.png'])
names.add('test/libvlc/native_mp4_subtitle_seek.py')
names.update(['src/player/timer.c','src/player/player.h','test/src/player/timer_cache.c','test/player-timer-cache-native.mk'])
names.update(['test/src/player/timers.c','test/src/player/timers.h','test/src/player/common.h'])
if (repo/'test/libvlc/native_timeshift.py').exists():
    names.add('test/libvlc/native_timeshift.py')
for directory in ['modules/gui/qt/medialibrary','modules/gui/qt/widgets/qml','modules/gui/qt/pixmaps/juxtopposed']:
    names.update(p.relative_to(repo).as_posix() for p in (repo/directory).rglob('*')
                 if p.is_file() and p.suffix in ['.cpp','.hpp','.qml','.svg','.md'])
names.update(['modules/gui/qt/maininterface/mainui.cpp','modules/gui/qt/Makefile.am','modules/gui/qt/assets.qrc',
              'modules/gui/qt/tests/test_juxtopposed_library.py','modules/gui/qt/tests/test_page_loader_routes.py'])
names.update(['include/vlc_media_library.h','modules/misc/medialibrary/medialibrary.cpp',
              'modules/gui/qt/tests/test_music_library_queries.cpp','modules/gui/qt/tests/native_library/music-queries.mk',
              'modules/gui/qt/tests/network_stream_probe.c','modules/gui/qt/util/winpthreads_shutdown.cpp'])
names.update(['modules/gui/qt/tests/test_ml_play_request.cpp','modules/gui/qt/tests/native_library/ml-play-request.mk'])
names.update(['modules/gui/qt/tests/test_controls_dialogs.cpp',
 'modules/gui/qt/tests/native_library/controls-dialogs.mk',
 'modules/gui/qt/tests/native_library/controls.mk',
 'modules/gui/qt/tests/native_library/run_controls.py',
 'modules/control/hotkeys.c','src/misc/actions.c',
 'modules/gui/qt/dialogs/preferences/preferences_widgets.cpp',
 'modules/gui/qt/dialogs/preferences/preferences_widgets.hpp'])
names.update(['modules/stream_out/record.c','src/input/es_out.c','src/input/input.c',
 'lib/media_player.c','include/vlc/libvlc_media_player.h'])
names.update(['modules/gui/qt/tests/test_shared_modal_hotkeys.cpp','modules/gui/qt/tests/generate_shared_modal_hotkey_test.py','modules/gui/qt/tests/native_library/key-routing.mk','modules/gui/qt/util/queue_find_key_scope.hpp','modules/gui/qt/util/vlchotkeyconverter.cpp','modules/gui/qt/util/vlchotkeyconverter.hpp'])
names.update(['modules/gui/qt/tests/test_customizer_routes.py','test/modules/stream_out/record_start.c','test/record-start-native.mk','test/Makefile.am'])
names.update(['modules/gui/qt/tests/test_controls_preferences.cpp','modules/gui/qt/tests/test_juxtopposed_controls_settings.py',
 'modules/gui/qt/tests/native_library/controls.mk','modules/gui/qt/maininterface/controls_preferences_model.cpp',
 'modules/gui/qt/maininterface/controls_preferences_model.hpp','modules/gui/qt/dialogs/dialogs/qml/JuxtopposedDialogsHost.qml',
 'modules/gui/qt/dialogs/dialogs/qml/JuxtopposedControlsSettings.qml'])
forbidden={'test/libvlc/native_soxr_reference.py',
 'test/modules/audio_filter/soxr_lifecycle_trace.c',
 'test/modules/audio_filter/soxr_native_reference.c',
 'test/modules/audio_filter/soxr_pcm_trace.c'}
assert not names.intersection(forbidden)
root=work/f'source-{revision}';assert not root.exists();root.mkdir()
files={p:digest(repo/p) for p in sorted(names)}
copies={};fresh=0
for name,h in files.items():
    if old['files'].get(name)==h:
        target=Path(old['sourceCopies'][name])
    else:
        target=root/name;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(repo/name,target);fresh+=1
    assert digest(target)==h
    copies[name]=str(target)
(work/f'inputs-{revision}.json').write_text(json.dumps(dict(files=files,sourceCopies=copies,
 sourceCount=len(files),newCopies=fresh,fullBetaAccepted=False),indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(revision=revision,inputs=len(files),newCopies=fresh)),flush=True)
