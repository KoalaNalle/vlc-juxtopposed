from pathlib import Path
from hashlib import sha256
import ctypes, json, shutil, subprocess, sys, xml.etree.ElementTree as ET
work = Path(__file__).resolve().parent
repo = work.parents[1]
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda p: sha256(p.read_bytes()).hexdigest()
inputs = read(work/'inputs-r432.json')
assert all(digest(repo/name) == h for name,h in inputs['files'].items())
base = work/'ui-music-appearance-cold-r425/runtime'
expected = read(work/'ui-music-appearance-cold-r425/verification.json')['runtimeSha256']
expected['plugins/control/libwin_hotkeys_plugin.dll']=digest(base/'plugins/control/libwin_hotkeys_plugin.dll')
assert all(digest(base/name) == h for name,h in expected.items())
out = work/'native-global-hotkeys-r433'
assert not out.exists(); out.mkdir()
shutil.copyfile(Path(__file__), out/'producer.py')
sys.path.insert(0, str(repo/'test/libvlc'))
from native_http_runtime import stage_runtime, environment
runtime = out/'runtime'
staging = stage_runtime(base,runtime)
base_expected=dict(expected)
target_plugin=runtime/'plugins/control/libwin_hotkeys_plugin.dll'
target_plugin.unlink();shutil.copyfile(work/'hotkeys-r432-bin/libwin_hotkeys_plugin.dll',target_plugin)
expected['plugins/control/libwin_hotkeys_plugin.dll']=digest(target_plugin)
# Libtool's small launcher carries WSL-only paths; stage the linked Windows PE.
source = '/root/vlc-juxtopposed-build/owned-global-hotkey-probe-r430/.libs/test_qt_global_hotkey_registration.exe'
prefix = ['wsl.exe','-d','VLC-Juxtopposed-Home-20261018','--']
identity = subprocess.run(prefix+['sha256sum',source],capture_output=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
assert identity.returncode == 0
native_hash = identity.stdout.decode().split()[0]
program = runtime/'test_qt_global_hotkey_registration.exe'
target = '/mnt/c/'+str(program.resolve()).replace('\\','/')[3:]
copied = subprocess.run(prefix+['cp',source,target],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
assert copied.returncode == 0 and digest(program) == native_hash
command = [str(program),'-o',str(out/'results.xml')+',xml']
record = dict(status='starting',privateNativeFixture=True,ordinaryGuiAccepted=False,fullBetaAccepted=False,
    forcedCleanupUsed=False, sourceManifestSha256=digest(work/'inputs-r432.json'),
    producerSha256=digest(Path(__file__)),testExecutableSha256=native_hash,
    runtimeSha256=expected,staging=staging,command=command,
    scope='Actual Windows global-hotkey module registration status, independent instance collisions, release/reopen, multiple-binding atom cleanup and bounded unsupported results. Native hidden receiver windows only; no key injection or ordinary GUI acceptance.')
def save(): (out/'verification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
kernel = ctypes.WinDLL('kernel32',use_last_error=True)
kernel.SetErrorMode.argtypes=[ctypes.c_uint]; kernel.SetErrorMode.restype=ctypes.c_uint
previous = kernel.SetErrorMode(0x8003)
env = environment(runtime,out); env.pop('VLC_PLUGIN_PATH',None)
try:
    with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
        child = subprocess.Popen(command,cwd=runtime,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        record.update(status='running',pid=child.pid);save()
        print('Native global-hotkey registration PID',child.pid,flush=True)
        try: code=child.wait(timeout=180)
        except subprocess.TimeoutExpired:
            record['status']='observation-timeout-process-left-running';save()
            raise SystemExit('Inspect same PID; no automatic cleanup/restart')
finally: kernel.SetErrorMode(previous)
root = ET.parse(out/'results.xml').getroot() if (out/'results.xml').exists() else None
functions = [dict(name=f.get('name'),incidents=[dict(type=i.get('type'),description=i.findtext('Description','')) for i in f.findall('Incident')],messages=[dict(type=m.get('type'),text=m.findtext('Description','')) for m in f.findall('Message')]) for f in root.findall('TestFunction')] if root is not None else []
record.update(status='terminal',exitCode=code,normalExit=code==0,functions=functions,
    sourceInputsUnchanged=all(digest(repo/name)==h for name,h in inputs['files'].items()),
    baseRuntimeUnchanged=all(digest(base/name)==h for name,h in base_expected.items()),
    runtimeUnchanged=all(digest(runtime/name)==h for name,h in expected.items()),
    producerUnchanged=digest(Path(__file__))==record['producerSha256'],
    testExecutableUnchanged=digest(program)==native_hash)
save()
failed=[f for f in functions if any(i['type']=='fail' for i in f['incidents'])]
print(json.dumps(dict(exitCode=code,functions=len(functions),failed=failed,guards={k:v for k,v in record.items() if k.endswith('Unchanged')})),flush=True)
assert record['normalExit'] and functions and not failed
assert all(v for k,v in record.items() if k.endswith('Unchanged'))
