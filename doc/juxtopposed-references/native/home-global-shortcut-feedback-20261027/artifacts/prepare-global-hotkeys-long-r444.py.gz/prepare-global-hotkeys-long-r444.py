from pathlib import Path
from hashlib import sha256
import json, wave

work = Path(__file__).resolve().parent
media = work / 'global-shortcut-media-r444'
assert not media.exists()
media.mkdir()
target = media / 'Long shortcut fixture.wav'
with wave.open(str(target), 'wb') as output:
    output.setnchannels(1)
    output.setsampwidth(2)
    output.setframerate(8000)
    for _ in range(3600):
        output.writeframesraw(bytes(16000))
manifest = dict(generated=True, privateMedia=False, durationSeconds=3600,
                sampleRate=8000, channels=1, sampleWidth=2,
                files={target.name: sha256(target.read_bytes()).hexdigest()})
(media / 'fixture.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')

source = (work / 'run-ui-global-shortcuts-r441.py').read_text(encoding='utf-8')
source = source.replace("music=work/'music-media-r273'", "music=work/'music-media-r273'\nlong_media=work/'global-shortcut-media-r444'\nlong_fixtures={p.name:digest(p) for p in long_media.iterdir() if p.is_file()}")
source = source.replace("str(music/'My Songs/1-First light.flac')", "str(long_media/'Long shortcut fixture.wav')")
source = source.replace("record=dict(chapterFixtureSha256=", "record=dict(longFixtureSha256=long_fixtures,chapterFixtureSha256=")
source = source.replace("record.update(chapterFixturesUnchanged=", "record.update(longFixturesUnchanged=all(digest(long_media/p)==h for p,h in long_fixtures.items()),chapterFixturesUnchanged=")
source = source.replace('for k in ["chapterFixturesUnchanged"', 'for k in ["longFixturesUnchanged","chapterFixturesUnchanged"')
assert source != (work / 'run-ui-global-shortcuts-r441.py').read_text(encoding='utf-8')
new = work / 'run-ui-global-shortcuts-long-r444.py'
assert not new.exists()
new.write_text(source, encoding='utf-8', newline='\n')
print(json.dumps(manifest))
