#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-global-hotkeys-r432.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-global-hotkeys-r432-exit.txt"; exit "$code"' EXIT
out="$work/hotkeys-r432-bin"
test ! -e "$out"
mkdir "$out"
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = fdfcfcd599588512bb7f3a51e46305b7b0d947b47387dd205851feb45f032b46
sha256sum "$repo/modules/control/globalhotkeys/win32.c" > "$out/inputs.sha256"
make -C "$base/win64/modules" -j2 libwin_hotkeys_plugin.la
cp "$base/win64/modules/.libs/libwin_hotkeys_plugin.dll" "$out/"
sha256sum -c "$out/inputs.sha256"
sha256sum "$out/libwin_hotkeys_plugin.dll"
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = fdfcfcd599588512bb7f3a51e46305b7b0d947b47387dd205851feb45f032b46
