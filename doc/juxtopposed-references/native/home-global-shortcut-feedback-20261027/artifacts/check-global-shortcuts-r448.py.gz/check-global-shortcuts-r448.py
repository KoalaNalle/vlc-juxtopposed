from pathlib import Path
from hashlib import sha256
import json, re, xml.etree.ElementTree as ET
from PySide6.QtCore import QSettings

work = Path(__file__).resolve().parent
repo = work.parents[1]
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda p: sha256(p.read_bytes()).hexdigest()
runs = ['ui-global-hotkeys-a-r445', 'ui-global-hotkeys-b-r446', 'ui-global-hotkeys-cold-r447']
verified = {}
for run in runs:
    record = read(work/run/'verification.json')
    assert record['normalExit'] and record['exitCode'] == 0 and not record['diagnostics']
    assert record['moduleCounts'] == ['602']
    assert all(v for k,v in record.items() if k.endswith('Unchanged'))
    assert not any(record[k] for k in ['privateCore','privateGui','privateRecord','forcedCleanupUsed','fullBetaAccepted'])
    verified[run] = record
assert all(v['runtimeSha256'] == verified[runs[0]]['runtimeSha256'] for v in verified.values())
manifest = read(work/'inputs-r444.json')
assert all(digest(repo/p) == h for p,h in manifest['files'].items())

def tree(run, name):
    return read(work/run/'observations'/f'{name}.json')['accessibility']['tree']
def position(run, name):
    return float(re.search(r'Progress Value: ([0-9.]+)', tree(run,name)).group(1))
def has(run, name, text):
    assert text in tree(run,name), (run,name,text)
a,b,c = runs
assert position(a,'01-a-cold-paused') == 0
assert position(a,'03-a-playing-settled') > 0
has(a,'03-a-playing-settled','button (settable, string) Pause')
hold = position(a,'05-a-paused-settled')
assert hold > position(a,'03-a-playing-settled')
has(a,'05-a-paused-settled','button (settable, string) Play ')
assert position(a,'07-a-still-paused-before-quit') == hold
for name in ['01-b-cold-paused','02-b-after-global-f8','03-b-still-paused','04-b-after-global-f9',
             '09-b-new-key-before-restart','10-b-owner-closed-still-paused']:
    assert position(b,name) == 0
has(a,'06-a-controls-active-two','2 global shortcuts are active in this player.')
for name in ['05-b-controls-conflicts','06-b-editor-current-conflicts',
             '08-b-saved-restart-required-current-conflicts','11-b-owner-closed-current-conflicts-retained']:
    has(b,name,'0 active, 2 unavailable')
    has(b,name,'Ctrl+Alt+Shift+F8 is already used')
    has(b,name,'Ctrl+Alt+Shift+F9 is already used')
has(b,'07-b-new-key-unsaved','Ctrl+Alt+Shift+F10')
has(b,'08-b-saved-restart-required-current-conflicts','Shortcuts saved. Restart VLC')
assert position(c,'01-cold-paused') == 0
assert position(c,'03-cold-f10-playing-settled') > 0
has(c,'03-cold-f10-playing-settled','button (settable, string) Pause')
cold_hold = position(c,'05-cold-f10-paused-settled')
assert position(c,'10-cold-final-paused') == cold_hold
has(c,'07-cold-controls-active-one','1 global shortcut is active in this player.')
has(c,'08-cold-editor-saved-f10-active','Ctrl+Alt+Shift+F10')
has(c,'09-cold-global-shortcuts-search','Search global settings Value: Global Shortcuts')
has(c,'09-cold-global-shortcuts-search','Edit Keyboard Shortcuts')

def config(path):
    return dict(line.split('=',1) for line in path.read_text(encoding='utf-8-sig').splitlines()
                if line and not line.startswith('#') and '=' in line)
changed = {}
profiles = []
for run in runs:
    before,after = (config(work/run/name) for name in ['config-before.txt','config-after.txt'])
    changed[run] = sorted(k for k in before.keys()|after.keys() if before.get(k) != after.get(k))
    for name in ['settings-before.ini','settings-after.ini']:
        settings=QSettings(str(work/run/name),QSettings.IniFormat)
        settings.setFallbacksEnabled(False)
        profiles.append(json.loads(settings.value('Juxtopposed/player-profiles')))
assert changed[a] == [] and changed[b] == ['global-key-play-pause'] and changed[c] == []
assert config(work/b/'config-after.txt')['global-key-play-pause'] == 'Ctrl+Alt+Shift+F10'
assert config(work/b/'config-after.txt') == config(work/c/'config-before.txt')
assert all(p == profiles[0] for p in profiles)

native = {}
for run,expected in [('native-global-hotkeys-before-r431',(1,0)),
                     ('native-global-hotkeys-r433',(1,0)),
                     ('native-global-hotkeys-r435',(0,1)),
                     ('native-global-hotkeys-r437',(0,0)),
                     ('native-global-shortcut-model-r440',(0,0))]:
    record=read(work/run/'verification.json')
    assert all(v for k,v in record.items() if k.endswith('Unchanged'))
    root=ET.parse(work/run/'results.xml').getroot()
    failures=len(root.findall('.//Incident[@type="fail"]'))
    skipped=len(root.findall('.//Incident[@type="skip"]'))
    assert (failures,skipped) == expected,(run,failures,skipped)
    native[run]=dict(functions=len(root.findall('TestFunction')),failures=failures,skipped=skipped,
                     exitCode=record['exitCode'],endingGuardsPassed=True)
component=read(work/'component-global-shortcut-feedback-r438/verification.json')
assert component['passed'] and component['checkCount'] == 9
analysis=dict(passed=True,runtimeSha256=verified[a]['runtimeSha256'],native=native,
              ordinaryRuns=runs,ordinaryEndingGuardsPassed=True,componentGroups=9,
              ownerPausedPosition=hold,coldPausedPosition=cold_hold,changedConfigKeys=changed,
              playerProfilesUnchanged=True,actualGlobalDeliveryToOtherPlayer=True,
              savedMappingWaitsForRestart=True,collisionClearedAfterSavedRestart=True,
              screenReaderAccepted=False,desktopDpiAccepted=False,fullBetaAccepted=False,
              firewallRuleChanges=[],securityPrivacyChanges=[],
              caveats=['Immediate/occluded snapshots can lag; assertions use settled foreground states.',
                       'r447 observation06 is General despite its early filename; observation07 proves the active count.',
                       'r442/r443 ended normally but the short input reached EOF; they do not establish the intended key journey.',
                       'Editor Escape was inconclusive through automation; explicit Cancel succeeded.'])
(work/'global-shortcut-analysis-r448.json').write_text(json.dumps(analysis,indent=2)+'\n',encoding='utf-8')
print(json.dumps(analysis,indent=2))
