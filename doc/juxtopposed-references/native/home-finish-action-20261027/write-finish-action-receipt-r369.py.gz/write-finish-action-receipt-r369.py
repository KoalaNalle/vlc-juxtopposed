from pathlib import Path
from hashlib import sha256
import gzip,json,re
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
runs=['ui-finish-eof-r366','ui-finish-manual-r367','ui-finish-stop-policy-r368']
records={run:read(work/run/'verification.json') for run in runs}
for record in records.values():
    assert record['normalExit'] and record['moduleCounts']==['602'] and not record['diagnostics']
    assert all(v for k,v in record.items() if k.endswith('Unchanged'))
def value(run,file,key):
    text=(work/run/file).read_text(encoding='utf-8-sig')
    matches=re.findall(r'^'+re.escape(key)+r'=(.*)$',text,re.M);assert len(matches)<=1
    if matches:return matches[0]
    defaults=re.findall(r'^#'+re.escape(key)+r'=(.*)$',text,re.M);assert len(defaults)<=1
    return defaults[0] if defaults else None
config={run:{file:{key:value(run,file,key) for key in ['play-and-exit','play-and-stop','loop','repeat','random']} for file in ['config-before.txt','config-after.txt']} for run in runs}
assert config[runs[0]]['config-before.txt']['play-and-exit'] in [None,'0']
assert config[runs[0]]['config-after.txt']['play-and-exit']=='1'
assert config[runs[1]]['config-before.txt']['play-and-exit']==config[runs[1]]['config-after.txt']['play-and-exit']=='1'
assert config[runs[2]]['config-before.txt']['play-and-exit']=='1' and config[runs[2]]['config-after.txt']['play-and-exit']=='0'
def progress(run,name):
    text=read(work/run/'observations'/name)['accessibility']['tree']
    return float(re.search(r'Progress Value: ([0-9.eE+-]+)',text)[1])
assert progress(runs[0],'01-playback-before-finish-save.json')==progress(runs[0],'03-after-finish-save-held0.json')==0
assert progress(runs[1],'02-paused-first-before-native-stop.json')==0
assert progress(runs[2],'03-stop-policy-before-stop-key.json')==0
logEvidence={}
for run in runs:
    lines=(work/run/'vlc.log').read_text(encoding='utf-8',errors='replace').splitlines()
    logEvidence[run]=[dict(line=n+1,text=line) for n,line in enumerate(lines) if line in ['main debug: EOF reached','qt debug: requesting exit...','main debug: exiting']]
assert any(line['text']=='qt debug: requesting exit...' for line in logEvidence[runs[0]])
out=repo/'doc/juxtopposed-references/native/home-finish-action-20261027';assert not out.exists();out.mkdir();artifacts=[]
def retain(p):
    name=p.relative_to(work).as_posix()+'.gz';dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True)
    raw=p.read_bytes();dest.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(dest.read_bytes())==raw
    artifacts.append(dict(path=name,sha256=digest(dest),rawSha256=sha256(raw).hexdigest()))
for run in runs:
    for name in ['verification.json','producer.py','launch.json','staging.json','layout-fixture.json']:retain(work/run/name)
    for p in sorted((work/run/'observations').glob('*')):
        if p.suffix in ['.png','.json']:retain(p)
for name in ['prepare-finish-action-r366.py','run-ui-finish-action-r366.py','freeze-music-toolbar-r360.py','inputs-r366.json','write-finish-action-receipt-r369.py']:retain(work/name)
checkpoint=dict(status='passed-ordinary-playback-finish-action',fullBetaAccepted=False,
    runtimeSha256=records[runs[0]]['runtimeSha256'],selectedConfigValues=config,sanitizedLogEvidence=logEvidence,
    sourceSha256={name:digest(repo/name) for name in ['modules/gui/qt/maininterface/playback_preferences_model.cpp','modules/gui/qt/maininterface/qml/PlaybackPreferences.qml'] if (repo/name).is_file()},
    observations=[
      'On GUI357, ordinary Playback Preferences saves Quit VLC while the first audio item remains paused at exact progress0. Stop after each item becomes disabled under the Quit policy.',
      'Next starts the final queued video. After a paused seek near56seconds and Play, the video reaches natural queue completion and VLC exits normally without a Quit/Stop/close action. The observer action and bounded EOF/Qt exit log lines have separate scopes.',
      'A fresh process restores Quit VLC from the saved native configuration. With the first queued audio item paused at0, the native Stop shortcut S closes VLC normally. A subsequent screenshot request finds no target; the matching process exits0, not a capture-only disappearance.',
      'A separate copied-profile run changes Quit VLC back to Stop without moving the paused input. Stop after each item becomes available again. The same S shortcut returns to Home and leaves the app open; there are zero Qt exit requests before the later explicit Ctrl+Q cleanup.',
      'All three ordinary runs exit0/602modules/zero checked errors/all source/runtime/fixture/producer/cache guards. The first file omits play-and-exit and the UI shows Stop; saving writes1. The next run retains1; clearing writes the commented default0. Null entries in the selected-file-values summary mean absent, not a measured native value. No production change was needed for this workflow.'
    ],limits=[
      'This qualifies the two implemented finish choices, current paused save, cold persistence, final-item completion and manual Stop on this generated local audio/video tuple. Repeat/shuffle/stop-after-each interactions, all source types and final-package acceptance retain their separate gates.',
      'A demux EOF log line alone does not prove queue completion: local audio can read ahead while paused. The natural-completion and manual-Stop observations/action timing distinguish those paths.',
      'Immediate seek/frame/accessibility snapshots can precede settled output. The final near-tail paused position corrects slightly as native timing settles; no exact paused-tail seek or bounded transition latency is claimed.',
      'Only VLC application behavior was exercised. No machine sleep/shutdown, security/privacy choice, dependency or user media was changed. Raw configuration/database/media/logs remain ignored locally.'
    ],artifacts=artifacts)
(out/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Ordinary playback finish action - 27 October2026

The current ordinary GUI357 saves Quit VLC without moving paused playback,
restores it after restart and exits normally at final queue completion or manual
Stop. Changing back to Stop keeps the same app open on Home after stopping.

All three runs exit0/602modules/zero checked errors/all guards. No production
repair was needed. The [checkpoint](checkpoint.json) records exact binaries,
saved values, actions, bounded log evidence and the remaining interaction limits.
This does not complete the full Playback or final-package gates.
''',encoding='utf-8',newline='\n')
print(str(out),len(artifacts),'verified artifacts')
