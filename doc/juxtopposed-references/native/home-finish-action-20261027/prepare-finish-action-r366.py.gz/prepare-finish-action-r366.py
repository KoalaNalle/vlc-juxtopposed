from pathlib import Path
work=Path(__file__).resolve().parent
source=(work/'run-ui-music-toolbar-cold-r360.py').read_text(encoding='utf-8')
start=source.index("scope='Ordinary recording322/")
end=source.index("')\nkernel=",start)
source=source[:start]+"scope='Ordinary GUI357/Core265/library282/recording322 Playback Finish action with isolated generated audio/video. Check native Quit VLC selection, paused-save independence, real queue completion and manual Stop separately. No OS sleep/shutdown or network/security/privacy action is in scope."+source[end:]
(work/'run-ui-finish-action-r366.py').write_text(source,encoding='utf-8',newline='\n')
