from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
work=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
revision=sys.argv[1]
out=work/'mp4-matrix-r236';assert not out.exists();out.mkdir()
record=dict(status='running',fullBetaAccepted=False,forcedCleanupUsed=False,
            producerSha256=sha256(Path(__file__).read_bytes()).hexdigest(),cases=[])
def save():(out/'summary.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
save()
for name in ['b0','b4','negative-cts','fragmented','no-edit']:
    for phase,mp4 in [('before','baseline'),('after','r233')]:
        label='mp4-b0-before-r235' if name=='b0' and phase=='before' else f'mp4-{name}-{phase}-r236'
        if label!='mp4-b0-before-r235':
            command=[sys.executable,str(work/'run-mp4-matrix-r235.py'),revision,label,name,'1.5','wasapi',mp4]
            with (out/(label+'.txt')).open('wb') as stream:
                child=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
                record.update(activeLabel=label,activeObserverPid=child.pid);save()
                try: code=child.wait(timeout=150)
                except subprocess.TimeoutExpired:
                    record['status']='observer-timeout-inspect-child-before-continuing';save()
                    raise SystemExit('Inspect owned matrix observer; no automatic cleanup or continuation')
            assert code==0,(label,code)
        result=read(work/label/'process.json')
        assert result['normalExit'] and all(result[k] for k in
            ['sourceInputsUnchanged','runtimeUnchanged','mediaUnchanged','subtitleUnchanged','workerUnchanged'])
        record['cases'].append(dict(name=name,phase=phase,label=label,passed=result['result']['passed'],
            checks=result['result']['checks'],frames=[r.get('frameMarker') for r in result['result']['observations'][:6]],
            mediaSha256=result['mediaSha256'],mp4Sha256=result['runtimeSha256']['plugins/demux/libmp4_plugin.dll']))
        save();print(name,phase,result['result']['passed'],record['cases'][-1]['frames'],flush=True)
record.update(status='terminal',allAfterPassed=all(r['passed'] for r in record['cases'] if r['phase']=='after'))
record.pop('activeObserverPid',None);record.pop('activeLabel',None);save()
print('All after cases pass:',record['allAfterPassed'],flush=True)
