from pathlib import Path
work=Path(__file__).resolve().parent
for old,new,ordinary in [('run-embedded-delay-r231.py','run-embedded-delay-r233.py',False),
                         ('run-native-rate-r229.py','run-native-mp4-r233.py',False),
                         ('run-ui-timing-r230.py','run-ui-mp4-r233.py',True)]:
    text=(work/old).read_text(encoding='utf-8')
    marker="assert all(digest(base/p)==h for p,h in expected.items())"
    assert text.count(marker)==1
    text=text.replace(marker,"expected['plugins/demux/libmp4_plugin.dll']=digest(base/'plugins/demux/libmp4_plugin.dll')\n"+marker)
    marker="identities={p:digest(runtime/p) for p in expected}"
    assert text.count(marker)==1
    text=text.replace(marker,"mp4=runtime/'plugins/demux/libmp4_plugin.dll'\nmp4.unlink();shutil.copyfile(work/'mp4-r233-bin/libmp4_plugin.dll',mp4)\n"+marker)
    target=work/new;assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared MP4 probe, native and ordinary producers')
