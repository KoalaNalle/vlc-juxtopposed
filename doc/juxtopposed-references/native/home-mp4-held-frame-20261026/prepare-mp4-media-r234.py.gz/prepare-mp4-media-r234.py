from pathlib import Path
from hashlib import sha256
import json,subprocess
work=Path(__file__).resolve().parent;repo=work.parents[1]
source=repo/'build-windows/beta-subtitle-fps-20261024/media-r1/frame-marker.mp4'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert digest(source)=='fd82d189533aa73d9715596d9856d27960cf76c76df1baaa0632672660c9b42d'
out=work/'mp4-media-r234';assert not out.exists();out.mkdir()
posix=lambda p:'/mnt/c/'+str(p.resolve()).replace('\\','/')[3:]
prefix=['wsl.exe','-d','VLC-Juxtopposed-Home-20261018','--']
cases={
 'b0':['-c:v','libx264','-preset','ultrafast','-crf','6','-bf','0','-g','250','-threads','2'],
 'b4':['-c:v','libx264','-preset','ultrafast','-crf','6','-bf','4','-g','250','-threads','2'],
 'negative-cts':['-movflags','+negative_cts_offsets'],
 'fragmented':['-movflags','+frag_keyframe+empty_moov+default_base_moof'],
 'no-edit':['-use_editlist','0']}
records=[]
for name,options in cases.items():
    target=out/(name+'.mp4')
    command=prefix+['/usr/bin/ffmpeg','-nostdin','-hide_banner','-n','-i',posix(source),
        '-map','0','-c','copy']+options+[posix(target)]
    with (out/(name+'-generation.log')).open('wb') as stream:
        code=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,timeout=150,
                            creationflags=subprocess.CREATE_NO_WINDOW).returncode
    assert code==0,(name,code)
    probe=subprocess.run(prefix+['/usr/bin/ffprobe','-v','error','-show_entries',
        'stream=index,codec_type,codec_name,start_time,has_b_frames,nb_frames,duration:format=duration',
        '-of','json',posix(target)],capture_output=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
    assert probe.returncode==0
    info=json.loads(probe.stdout);assert len([s for s in info['streams'] if s['codec_type']=='subtitle'])==2
    records.append(dict(name=name,command=command,sha256=digest(target),metadata=info))
    print('Prepared',name,flush=True)
tools=subprocess.run(prefix+['/usr/bin/sha256sum','/usr/bin/ffmpeg','/usr/bin/ffprobe'],
    capture_output=True,timeout=15,creationflags=subprocess.CREATE_NO_WINDOW)
assert tools.returncode==0
(out/'manifest.json').write_text(json.dumps(dict(sourceSha256=digest(source),
    producerSha256=digest(Path(__file__)),tools=tools.stdout.decode(),cases=records,fullBetaAccepted=False),indent=2)+'\n')
