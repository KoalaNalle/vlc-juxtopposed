from pathlib import Path
from hashlib import sha256
import gzip,json
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
out=repo/'doc/juxtopposed-references/native/home-mp4-held-frame-20261026';assert not out.exists()
m=read(work/'inputs-r237.json');assert all(digest(repo/p)==h for p,h in m['files'].items())
before=read(work/'native-inherit-before-r235/verification.json')
after=read(work/'native-inherit-after-r235/verification.json')
assert not before['normalExit'] and after['normalExit'] and after['actualWasapiSelected']
assert all(i['type']=='pass' for f in after['functions'] for i in f['incidents'])
assert after['latePictureWarnings']==after['avcodecLateErrors']==0
hardware=read(work/'native-all-d3d11-mp4-r233/verification.json')
assert hardware['normalExit'] and len(hardware['functions'])==31
assert all(i['type']=='pass' for f in hardware['functions'] for i in f['incidents'])
startup=read(work/'main-startup-mp4-r237/verification.json');assert startup['normalExit']
rates=read(work/'rate-startup-mp4-r237/verification.json');assert rates['passed'] and len(rates['records'])==13
ui=read(work/'ui-embedded-inherit-r237/verification.json')
assert ui['normalExit'] and ui['moduleCounts']==['602'] and not ui['diagnostics']
assert all(ui[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','pluginCacheUnchanged'])
frames=read(work/'ui-embedded-inherit-r237/held-frames.json');assert frames['passed'] and frames['identicalPixels']
assert {f['marker'] for f in frames['frames']}=={301}
matrix=read(work/'mp4-matrix-r236/summary.json');assert matrix['status']=='terminal'
assert all(r['passed'] for r in matrix['cases'] if r['phase']=='after' and r['name']!='fragmented')
assert all(not r['passed'] for r in matrix['cases'] if r['name']=='fragmented')
assert not next(r for r in matrix['cases'] if r['name']=='b4' and r['phase']=='before')['passed']
names=['embedded-delay-before-r231','embedded-delay-after-r233','native-all-d3d11-mp4-r233',
       'native-inherit-before-r235','native-inherit-after-r235','mp4-b0-before-r235',
       'mp4-matrix-r236','mp4-fragment-reference-r237','main-startup-mp4-r237',
       'rate-startup-mp4-r237','ui-embedded-inherit-r237']
names += [r['label'] for r in matrix['cases'] if r['label']!='mp4-b0-before-r235']
out.mkdir();artifacts=[];streams=[]
def retain(p,relative=None):
    target=out/((relative or p.relative_to(work).as_posix())+'.gz');assert not target.exists()
    raw=p.read_bytes();target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(raw,mtime=0))
    artifacts.append(dict(path=target.relative_to(out).as_posix(),sha256=digest(target),rawSha256=sha256(raw).hexdigest()))
for name in names:
    for p in sorted((work/name).rglob('*')):
        if not p.is_file() or any(x in p.relative_to(work/name).parts for x in
            ['runtime','userdata','appdata','localappdata','temp']):continue
        if p.suffix in ['.log','.txt']:
            streams.append(dict(path=p.relative_to(work).as_posix(),sha256=digest(p),packaged=False))
        elif p.suffix in ['.json','.xml','.png','.py','.qml']:retain(p)
for revision in ['r231','r233','r235','r236','r237']:
    retain(work/f'inputs-{revision}.json');v=read(work/f'inputs-{revision}.json')
    for name in ['modules/demux/mp4/mp4.c','modules/gui/qt/tests/test_player_subtitle_delay.cpp']:
        p=Path(v['sourceCopies'][name]);assert digest(p)==v['files'][name];retain(p,f'sources/{revision}/{name}')
for p in sorted(work.iterdir()):
    if p.is_file() and p.suffix in ['.py','.sh'] and any(f'r{n}' in p.stem for n in range(233,239)):retain(p)
retain(work/'mp4-media-r234/manifest.json')
record=dict(status='scoped-mp4-edit-checkpoint-beta-incomplete',fullBetaAccepted=False,
    selectedRuntime='build-windows/beta-single-frame-20261025-night/ui-embedded-inherit-r237/runtime',
    runtimeSha256=ui['runtimeSha256'],artifacts=artifacts,localStreams=streams,matrix=matrix,ordinaryFrames=frames,
    accepted=[
      'MP4 edit-list eligibility uses the first presentation time, including known composition delay, rather than decode start alone. Decoder preroll before the first displayed frame no longer changes timeline mapping. Tracks without a known composition delta retain the old comparison.',
      'The unchanged embedded English public probe fails old MP4 on paused frame300->298 with+5/+5.508s at1.5x, then passes the repaired plugin with held frame300, visible captions and actual WASAPI resume.',
      'The same inherited-secondary Qt test executable fails old MP4 on+5s, then both own-secondary and inherited-secondary rows pass the candidate through FPS changes, offsets, independent Reset and resume with actual WASAPI and hardware video. Snapshot names are unique per data row.',
      'All31 hardware subtitle functions pass with dummy audio; three startup late-picture warnings and zero avcodec-late errors are retained. Four main-player startup rates and thirteen audio/rate cases pass separately, with fresh plugin caches and unchanged guards.',
      'Four generated MP4 layouts pass after repair: no B frames, up-to-four B frames, negative composition offsets and no edit list. The reordered edit-list layout reproduces the old failure. Negative-offset/no-edit references are frame299/298 rather than300 and remain stable; no absolute-origin equivalence is claimed.',
      'The ordinary GUI shows+5s inherited by both embedded tracks, then an independent-9s secondary offset surviving primary Reset. Three native exports before/inherited/Reset are pixel-identical with marker301. Playback resumes with both captions. Normal exit0,602 modules,zero diagnostics and all source/runtime/fixture/cache guards pass.'
    ],unresolved=[
      'Fragmented MP4 seeking produces missing/corrupt held pictures and unstable clocks on both old and repaired plugins. Independent FFmpeg seeking decodes the same generated file correctly. This is a pre-existing VLC fragment-seek issue, not an accepted matrix case or an established bad fixture.',
      'The ordinary signed estimator and saved-default receipts precede this MP4 plugin. Their unchanged feature implementations retain scoped evidence, not final-package acceptance.',
      'Continue the fragment-seek investigation, older ordinary cue-preset replay, no-secondary disabled state, fullscreen idle capture and broader W2-W5/design/DPI/package gates. No complete beta claim is made.'
    ])
(out/'checkpoint.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# MP4 edit-list held-frame repair - 26 October 2026

MP4 plugin `4f6dcef6` with Core `ccf72399` and GUI `4d754f60` bases edit-list
eligibility on presentation time. Decoder preroll for reordered video no longer
moves the paused frame when a large subtitle offset is applied. The unchanged
embedded and inherited-secondary regressions fail the prior plugin and pass this
candidate, including actual WASAPI and hardware-video resume.

All 31 hardware subtitle functions, four main startup rates and thirteen
audio/rate cases pass separately. Three startup late-picture warnings remain
recorded in the full hardware suite. Four generated MP4 layouts pass after the
repair. Fragmented MP4 seeking still fails identically before/after; an independent
FFmpeg seek decodes that file correctly. That separate defect remains open.

The ordinary app qualifies inherited and independent secondary delays/Reset and
normal resume. Three native exports are pixel-identical with marker 301. It exits
0 with 602 modules, zero error diagnostics and unchanged guards.

[checkpoint.json](checkpoint.json) preserves exact tuples, source copies, before
failures, all matrix cases and qualification limits. Raw streams stay local.
Continue from [STATUS](../../../juxtopposed/STATUS.md); beta gates remain open.
''',encoding='utf-8',newline='\n')
print(str(out),len(artifacts),'artifacts',flush=True)
