from pathlib import Path
work=Path(__file__).resolve().parent
for kind,table in [('main-startup','expected'),('rate-startup','protected')]:
    text=(work/f'run-{kind}-r226.py').read_text(encoding='utf-8')
    marker=f'assert all(digest(base/p)==h for p,h in {table}.items())'
    assert text.count(marker)==1
    text=text.replace(marker,f"{table}['plugins/demux/libmp4_plugin.dll']=digest(base/'plugins/demux/libmp4_plugin.dll')\n"+marker)
    if kind=='main-startup':
        old="cache=runtime/'plugins/plugins.dat';assert not cache.exists();shutil.copyfile(base/'plugins/plugins.dat',cache)"
    else:
        old="shutil.copyfile(base/'plugins/plugins.dat',runtime/'plugins/plugins.dat')"
    assert text.count(old)==1;text=text.replace(old,"cache=runtime/'plugins/plugins.dat';assert not cache.exists()")
    marker=f'identities={{p:digest(runtime/p) for p in {table}}}'
    assert text.count(marker)==1
    text=text.replace(marker,"""mp4=runtime/'plugins/demux/libmp4_plugin.dll'
mp4.unlink();shutil.copyfile(work/'mp4-r233-bin/libmp4_plugin.dll',mp4)
cacheout=out/'cache';cacheout.mkdir()
with (cacheout/'stdout.txt').open('wb') as stdout,(cacheout/'stderr.txt').open('wb') as stderr:
    cachechild=subprocess.Popen([str(runtime/'vlc-cache-gen.exe'),str(runtime/'plugins')],
        cwd=runtime,env=environment(runtime,cacheout),stdout=stdout,stderr=stderr,
        creationflags=subprocess.CREATE_NO_WINDOW)
    write(cacheout/'process.json',dict(status='running',pid=cachechild.pid))
    try:cachecode=cachechild.wait(timeout=60)
    except subprocess.TimeoutExpired:raise SystemExit('Inspect owned cache PID; no automatic cleanup/restart')
write(cacheout/'process.json',dict(status='terminal',exitCode=cachecode,normalExit=cachecode==0))
assert cachecode==0 and cache.exists()
cache_hash=digest(cache)
"""+marker)
    if kind=='rate-startup':
        text=text.replace("fixturesUnchanged=digest(media)==media_hash,workerUnchanged=digest(worker)==worker_hash)",
            "fixturesUnchanged=digest(media)==media_hash,workerUnchanged=digest(worker)==worker_hash,pluginCacheUnchanged=digest(cache)==cache_hash)")
    target=work/f'run-{kind}-mp4-r237.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared startup and audio/rate regression producers with fresh plugin caches')
