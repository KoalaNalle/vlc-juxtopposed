from pathlib import Path
work=Path(__file__).resolve().parent
text=(work/'run-embedded-delay-r233.py').read_text(encoding='utf-8')
text=text.replace('revision,label,media_kind,rate,audio=sys.argv[1:]','revision,label,media_kind,rate,audio,mp4_revision=sys.argv[1:]')
old="mp4.unlink();shutil.copyfile(work/'mp4-r233-bin/libmp4_plugin.dll',mp4)"
new="if mp4_revision!='baseline':\n    mp4.unlink();shutil.copyfile(work/f'mp4-{mp4_revision}-bin/libmp4_plugin.dll',mp4)"
assert text.count(old)==1;text=text.replace(old,new)
old="       else work/'timing-journey-media-r213/Show.S01E01.mp4')"
new="       else work/'timing-journey-media-r213/Show.S01E01.mp4')\nif media_kind not in ['short','long']:\n    assert media_kind in ['b0','b4','negative-cts','fragmented','no-edit']\n    media=work/'mp4-media-r234'/(media_kind+'.mp4')"
assert text.count(old)==1;text=text.replace(old,new)
target=work/'run-mp4-matrix-r235.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
text=(work/'run-native-mp4-r233.py').read_text(encoding='utf-8')
text=text.replace('revision,label,core_name,mode,binary_revision,video_mode,audio=sys.argv[1:]',
                  'revision,label,core_name,mode,binary_revision,video_mode,audio,mp4_revision=sys.argv[1:]')
assert text.count(old)==0
old="mp4.unlink();shutil.copyfile(work/'mp4-r233-bin/libmp4_plugin.dll',mp4)"
assert text.count(old)==1;text=text.replace(old,"if mp4_revision!='baseline':\n    mp4.unlink();shutil.copyfile(work/f'mp4-{mp4_revision}-bin/libmp4_plugin.dll',mp4)")
old="if mode=='large-delays':command+=['largeTrackDelaysKeepHeldFrameAndResume']"
assert text.count(old)==1;text=text.replace(old,old+"\nelif mode=='large-inherit':command+=['largeTrackDelaysKeepHeldFrameAndResume:inherited-secondary']")
target=work/'run-native-mp4-r235.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
text=(work/'build-r229.sh').read_text(encoding='utf-8').replace('r229','r235')
target=work/'build-r235.sh';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared inherited-delay and MP4 matrix producers')
