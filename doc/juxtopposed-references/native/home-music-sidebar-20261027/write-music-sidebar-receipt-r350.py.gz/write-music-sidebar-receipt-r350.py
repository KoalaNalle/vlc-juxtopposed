from pathlib import Path
from hashlib import sha256
import gzip,json,re
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
runs=['ui-music-sidebar-before-r347','ui-music-sidebar-fixed-r349']
records={name:read(work/name/'verification.json') for name in runs}
for record in records.values():
    assert record['normalExit'] and record['moduleCounts']==['602'] and not record['diagnostics']
    assert all(v for k,v in record.items() if k.endswith('Unchanged'))
before=read(work/'component-music-sidebar-before-r348/verification.json')
fixed=read(work/'component-music-sidebar-fixed-r349/verification.json')
assert before['negativeBaselineReproduced'] and fixed['normalExit']
assert before['helperSha256']==fixed['helperSha256']==digest(work/'run-component-music-sidebar-r348.py')
assert before['sourceSha256']['modules/gui/qt/tests/test_juxtopposed_music_player.py']==fixed['sourceSha256']['modules/gui/qt/tests/test_juxtopposed_music_player.py']
assert before['sourceInputsUnchanged'] and fixed['sourceInputsUnchanged']
def progress(name):
    observation=read(work/runs[1]/'observations'/name)
    return float(re.search(r'Progress Value: ([0-9.eE+-]+)',observation['accessibility']['tree'])[1])
held=progress('08-closed-view-paused-settled.json')
assert held==progress('10-reopened-paused-position-settled.json')
asset=repo/'modules/gui/qt/pixmaps/juxtopposed/titlebar-navigation-b130a.svg'
root_tag=re.search(r'<svg\b[^>]*>',asset.read_text(encoding='utf-8'))[0]
assert 'width="24"' in root_tag and 'height="24"' in root_tag
out=repo/'doc/juxtopposed-references/native/home-music-sidebar-20261027'
assert not out.exists();out.mkdir();artifacts=[]
def retain(p):
    name=p.relative_to(work).as_posix()+'.gz';dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True)
    raw=p.read_bytes();dest.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(dest.read_bytes())==raw
    artifacts.append(dict(path=name,sha256=digest(dest),rawSha256=sha256(raw).hexdigest()))
for name in runs:
    for file in ['verification.json','producer.py','launch.json','staging.json','layout-fixture.json']:retain(work/name/file)
    for p in sorted((work/name/'observations').glob('*')):
        if p.suffix in ['.json','.png']:retain(p)
for name in ['component-music-sidebar-before-r348','component-music-sidebar-fixed-r349']:
    retain(work/name/'verification.json')
    for file in ['stdout.txt','stderr.txt']:
        retain(work/name/file)
    for p in sorted((work/name/'captures').glob('*.json')):retain(p)
for file in ['figma-music-r347/music-open.png','figma-music-r347/music-closed.png','figma-music-r347/review-context.json',
 'inputs-r347.json','inputs-r349.json','run-component-music-sidebar-r348.py',
 'prepare-music-sidebar-before-r347.py','run-ui-music-sidebar-before-r347.py',
 'prepare-music-sidebar-fixed-r349.py','run-ui-music-sidebar-fixed-r349.py',
 'freeze-music-sidebar-r349.py','build-music-sidebar-r349.sh','build-music-sidebar-r349-exit.txt',
 'write-music-sidebar-receipt-r350.py']:retain(work/file)
result=dict(status='passed-scoped-music-sidebar-open-close-repair',fullBetaAccepted=False,
 runtimeSha256=records[runs[1]]['runtimeSha256'],sourceSha256=fixed['sourceSha256'],
 heldPausedProgress=held,staticToggleAsset=dict(path=asset.relative_to(repo).as_posix(),sha256=digest(asset),rootTag=root_tag,
  designAsset='b130a.svg',qrcAlias='titlebar-navigation.svg',unchanged=True),
 observations=[
  'Figma high-fidelity contexts and1920x1080screenshots for4767:23726 and4778:25123 show music without/with the inline sidebar. The native GUI344 baseline instead opens an expanded navigation overlay on top of the music source list, leaving the designed closed view unreachable.',
  'The existing title-bar navigation button now controls the inline music sidebar while the music presentation is active; video retains its existing expanded navigation drawer. The original24x24 b130a navigation SVG/qrc alias/callsite is reused unchanged. Real dynamic cover art remains media data; no design screenshot or example album art is added as an app asset.',
  'The production component regression fails the closed-panel assertion before and passes after with the same test/helper. It checks focus handoff to controls, current-row focus on reopen, no activation signal, held selection and centred cover; the existing source/search/sort/metadata/empty/error and five simulated-scale layouts also pass.',
  'Ordinary GUI349 closes/reopens the music source panel in602x421 and1920x1032windows. Space starts and pauses First light while the panel is hidden. Reopening preserves the exact paused progress; Down selects Second light without starting it, then Return activates the real second track and its orange artwork.',
  'Hiding the sidebar while Second light plays retains playback; Space pauses the closed view. Previous starts the queued video, whose expanded navigation drawer still opens. Next while that drawer is open returns to Second light and the remembered closed music view; the old drawer is absent once the new presentation settles.',
  'Both ordinary apps exit0/602modules/zero checked errors/all source/runtime/fixture/producer/cache guards. The fixed normal shutdown takes longer while owned media work drains; it completes without forced cleanup.'
 ],limits=[
  'This qualifies the sidebar states and interaction, not a whole-player fidelity score. The owned customizer fixture has a two-row control bar, unlike the54px canonical Figma bar, and generated blue/orange artwork; canonical cover sizing, all static assets/states, theme, Windows OS-DPI and final-package review remain open.',
  'Immediate source-transition captures contain the preceding drawer or a fallback cover before the settled audio/video output. Settled observations establish the new state; no bounded transition latency or complete queue equality claim is made. Accessibility focus text can lag; actual keyboard effects and component focus checks have separate scopes.',
  'The sidebar choice is per-player session state and defaults open on a fresh player. It is not a new saved profile/global preference. Traditional controls and native playback architecture are preserved.',
  'Figma was read only. Raw configurations, databases, media, binaries and personal logs remain ignored locally. No dependencies or security/privacy settings changed.'
 ],artifacts=artifacts)
(out/'checkpoint.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Music sidebar open/closed states - 27 October 2026

Figma's paired music frames expose a missing state: the old native toggle opens
another navigation drawer over the source list. The repaired toggle hides and
reopens the inline music sidebar; video navigation retains its original behavior.

The same component regression fails before and passes after. Ordinary GUI349
verifies small/maximized states, exact paused-position retention, closed-view
Play/Pause, reopened Down/Enter activation and audio/video transitions. Both
ordinary runs exit0/602modules/zero checked errors/all guards.

The [checkpoint](checkpoint.json) retains the original Figma renders, source/asset
identities and stale-capture limitations. This is a scoped interaction repair;
canonical player sizing, complete visual scores, OS-DPI and final-package gates
remain open. Continue from [STATUS](../../../juxtopposed/STATUS.md).
''',encoding='utf-8',newline='\n')
print(out,len(artifacts),'verified artifacts')
