from pathlib import Path
work=Path(__file__).resolve().parent
source=(work/'run-ui-music-sidebar-before-r347.py').read_text(encoding='utf-8')
source=source.replace('ordinary-r344-bin','ordinary-r349-bin').replace('GUI344','GUI349')
(work/'run-ui-music-sidebar-fixed-r349.py').write_text(source,encoding='utf-8',newline='\n')
source=(work/'build-tooltip-r337.sh').read_text(encoding='utf-8').replace('r337','r349').replace('owned-tooltip-ordinary','owned-music-sidebar').replace('build-customizer-r349','build-music-sidebar-r349')
(work/'build-music-sidebar-r349.sh').write_text(source,encoding='utf-8',newline='\n')
source=(work/'freeze-collection-sort-r344.py').read_text(encoding='utf-8')
anchor="names.add('build-windows/beta-single-frame-20261025-night/collection-native-policy-r344.json')"
assert source.count(anchor)==1
source=source.replace(anchor,anchor+"\nnames.update('build-windows/beta-single-frame-20261025-night/figma-music-r347/'+name for name in ['review-context.json','music-open.png','music-closed.png'])")
(work/'freeze-music-sidebar-r349.py').write_text(source,encoding='utf-8',newline='\n')
