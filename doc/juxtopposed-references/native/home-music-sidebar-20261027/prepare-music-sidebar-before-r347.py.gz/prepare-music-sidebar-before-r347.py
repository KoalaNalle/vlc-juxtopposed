from pathlib import Path
work=Path(__file__).resolve().parent
source=(work/'run-ui-collection-sort-r344.py').read_text(encoding='utf-8')
old="str(chapter_media/'Owned chapters.mp4')"
assert source.count(old)==1
source=source.replace(old,"str(music/'My Songs/1-First light.flac')")
source=source.replace('an isolated generated three-chapter MP4/native-chapter and plain-source profile','an isolated generated audio-cover/source-folder and plain-video profile')
(work/'run-ui-music-sidebar-before-r347.py').write_text(source,encoding='utf-8',newline='\n')
