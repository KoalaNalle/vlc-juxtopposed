#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
ordinary="$base/owned-single-frame-ordinary-20261026-r68"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-ordinary-r68.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-ordinary-r68-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 05ec8a7a04506d26d1b66edef329cf62a83a68352167439505ed2d972812a10a
test ! -e "$ordinary"
test ! -e "$work/ordinary-r68-bin"
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/build-windows/beta-subtitle-sync-20261025/ordinary.mk" -j2 QA_OUT="$ordinary" owned-ordinary-subtitle-sync
mkdir "$work/ordinary-r68-bin"
cp "$ordinary/.libs/libqt_plugin.dll" "$work/ordinary-r68-bin/"
sha256sum "$work/ordinary-r68-bin/libqt_plugin.dll"
