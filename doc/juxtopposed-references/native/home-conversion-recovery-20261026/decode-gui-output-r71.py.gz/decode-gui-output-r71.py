from pathlib import Path
from hashlib import sha256
import json,os,sys,wave,array
work=Path(__file__).resolve().parent;repo=work.parents[1]
sys.path.insert(0,str(repo/'test/libvlc'))
from native_http_runtime import environment
from native_flac_drain import Runtime
root=work/'ui-r69';out=root/'native-decode-restored';out.mkdir()
runtime=root/'runtime'
os.environ.update(environment(runtime,out));os.environ.pop('VLC_PLUGIN_PATH',None)
os.environ['VLC_LIB_PATH']=str(runtime/'plugins')
source=work/'conversion-fixtures-r69/missing owned source.wav';result=root/'error-retry.flac'
before=json.loads((work/'conversion-fixtures-r69/before.json').read_text(encoding='utf-8'))
fixtures=work/'conversion-fixtures-r69'
assert all(sha256((fixtures/p).read_bytes()).hexdigest()==h for p,h in before['files'].items())
engine=Runtime(runtime,out);events,pcm=engine.stage(result,'gui-restored-output-decode')
values=array.array('h');values.frombytes(pcm)
with wave.open(str(source),'rb') as w:frames=w.getnframes();original=w.readframes(frames)
report=dict(scope='Fully decode ordinary GUI retry output after owned missing source restored',passed=events['eos'] and len(values)==frames and pcm==original,events=events,decodedFrames=len(values),expectedFrames=frames,pcmEqualsMonoSource=pcm==original,outputSha256=sha256(result.read_bytes()).hexdigest(),coreSha256=sha256((runtime/'libvlccore.dll').read_bytes()).hexdigest(),originalsUnchanged=all(sha256((fixtures/p).read_bytes()).hexdigest()==h for p,h in before['files'].items()),fullBetaAccepted=False)
(out/'verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(report));assert report['passed'] and report['originalsUnchanged']
