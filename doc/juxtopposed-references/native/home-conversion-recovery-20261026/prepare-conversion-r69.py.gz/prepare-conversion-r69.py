from pathlib import Path
from hashlib import sha256
import json,wave
work=Path(__file__).resolve().parent
root=work/'conversion-fixtures-r69';root.mkdir()
prior=work/'conversion-fixtures-r67'
short=prior/'missing owned source.wav'
corrupt=prior/'corrupt source ä.wav'
for source in [short,corrupt]:(root/source.name).write_bytes(source.read_bytes())
with wave.open(str(prior/'long owned noise.wav'),'rb') as w:block=w.readframes(44100)
assert len(block)==88200
with wave.open(str(root/'one hour owned noise.wav'),'wb') as w:
    w.setnchannels(1);w.setsampwidth(2);w.setframerate(44100)
    for i in range(3600):w.writeframesraw(block)
files={p.name:sha256(p.read_bytes()).hexdigest() for p in root.iterdir() if p.is_file()}
(root/'before.json').write_text(json.dumps(dict(files=files,scope='Owned generated conversion fixtures; no personal media'),indent=2)+'\n',encoding='utf-8',newline='\n')
driver=(work/'run-ui-conversion-r67.py').read_text(encoding='utf-8')
driver=driver.replace('ordinary-r33-bin','ordinary-r68-bin').replace('conversion-fixtures-r67','conversion-fixtures-r69')
driver=driver.replace(" '--fullscreen','--rate='+rate", " '--rate='+rate")
(work/'run-ui-conversion-r69.py').write_text(driver,encoding='utf-8',newline='\n')
print(json.dumps(dict(fixtureSizes={p.name:p.stat().st_size for p in root.iterdir() if p.is_file()},files=files)))
