"""Finish the new, uncommitted review draft with the additional render comparison.
Does not alter any previously committed/frozen receipt.
"""
from pathlib import Path
from hashlib import sha256
import gzip,json
work=Path(__file__).resolve().parent;repo=work.parents[1]
out=repo/'doc/juxtopposed-references/native/home-home-navigation-review-20261027'
checkpoint=json.loads((out/'checkpoint.json').read_text(encoding='utf-8'))
renders=json.loads((work/'music-navigation-asset-renders-r374.json').read_text(encoding='utf-8'))
assert [r['differentPixels']==0 for r in renders]==[True,False,False]
checkpoint['assetRenderComparisons']=renders
checkpoint['findings'][3]='Four shared SVG XML trees match the paired-frame exports. The structurally different Home asset renders identically at240x240 with QtSvg; Video and Music have different rendered pixels and need their exact frame/state variants assessed before reusing a shared descriptor blindly. No artwork or production implementation was changed in this audit.'
for name in ['write-home-review-r373.py','render-check-navigation-r374.py','music-navigation-asset-renders-r374.json','finalize-home-review-r375.py']:
    raw=(work/name).read_bytes();dest=out/(name+'.gz');dest.write_bytes(gzip.compress(raw,mtime=0))
    artifact=dict(path=name+'.gz',sha256=sha256(dest.read_bytes()).hexdigest(),rawSha256=sha256(raw).hexdigest())
    checkpoint['artifacts']=[a for a in checkpoint['artifacts'] if a['path']!=artifact['path']]+[artifact]
for artifact in checkpoint['artifacts']:
    data=(out/artifact['path']).read_bytes();assert sha256(data).hexdigest()==artifact['sha256']
    assert sha256(gzip.decompress(data)).hexdigest()==artifact['rawSha256']
(out/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Finalized new review draft:',len(checkpoint['artifacts']),'verified artifacts')
