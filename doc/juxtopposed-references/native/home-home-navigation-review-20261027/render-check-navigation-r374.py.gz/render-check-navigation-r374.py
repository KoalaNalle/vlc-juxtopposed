from pathlib import Path
from hashlib import sha256
import json,os
os.environ['QT_QPA_PLATFORM']='offscreen'
from PySide6.QtCore import QRectF
from PySide6.QtGui import QGuiApplication,QImage,QPainter
from PySide6.QtSvg import QSvgRenderer
app=QGuiApplication([])
work=Path(__file__).resolve().parent;repo=work.parents[1]
results=[]
for source,name in [('27471.svg','sidebar-home-inactive-27471.svg'),('1b0f7.svg','sidebar-videos-7c4e4.svg'),('8b7f6.svg','sidebar-music-61ad2.svg')]:
    paths=[work/'figma-music-navigation-r372'/source,repo/'modules/gui/qt/pixmaps/juxtopposed'/name]
    renderings=[]
    for path in paths:
        renderer=QSvgRenderer(str(path));assert renderer.isValid()
        image=QImage(240,240,QImage.Format_ARGB32);image.fill(0)
        painter=QPainter(image);renderer.render(painter,QRectF(0,0,240,240));painter.end()
        renderings.append(image)
    changed=sum(renderings[0].pixel(x,y)!=renderings[1].pixel(x,y) for x in range(240) for y in range(240))
    results.append(dict(asset=source,local=name,renderDimensions=[240,240],differentPixels=changed,
        renderSha256=[sha256(bytes(image.constBits())).hexdigest() for image in renderings]))
(work/'music-navigation-asset-renders-r374.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print(json.dumps(results))
