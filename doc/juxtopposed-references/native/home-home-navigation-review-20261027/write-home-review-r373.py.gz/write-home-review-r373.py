from pathlib import Path
from hashlib import sha256
import gzip,json,re,xml.etree.ElementTree as ET
work=Path(__file__).resolve().parent;repo=work.parents[1]
digest=lambda p:sha256(p.read_bytes()).hexdigest()
pairs=[('27471.svg','sidebar-home-inactive-27471.svg'),('1b0f7.svg','sidebar-videos-7c4e4.svg'),('8b7f6.svg','sidebar-music-61ad2.svg'),('6db55.svg','sidebar-network-6db55.svg'),('c9326.svg','sidebar-playlists-c9326.svg'),('50e8b.svg','sidebar-recent-50e8b.svg'),('bfdda.svg','sidebar-add-bfdda.svg')]
def structure(element):return [element.tag,dict(element.attrib),(element.text or '').strip(),[structure(child) for child in element]]
assets=[]
for reference,name in pairs:
    target=repo/'modules/gui/qt/pixmaps/juxtopposed'/name
    original=work/'figma-music-navigation-r372'/reference
    a,b=ET.parse(original).getroot(),ET.parse(target).getroot()
    assets.append(dict(originalAsset=reference,localPath=target.relative_to(repo).as_posix(),originalSha256=digest(original),localSha256=digest(target),
        xmlTreeEqual=structure(a)==structure(b),originalDimensions={k:a.attrib.get(k) for k in ['width','height','viewBox']},localDimensions={k:b.attrib.get(k) for k in ['width','height','viewBox']}))
sources=['modules/gui/qt/player/qml/Player.qml','modules/gui/qt/player/qml/JuxtopposedMusicPlayer.qml','modules/gui/qt/maininterface/qml/JuxtopposedNavigation.qml','modules/gui/qt/maininterface/qml/JuxtopposedNavigationPane.qml']
player=(repo/sources[0]).read_text(encoding='utf-8');music=(repo/sources[1]).read_text(encoding='utf-8');shared=(repo/sources[3]).read_text(encoding='utf-8')
block=player.split('navigationRoutes: [',1)[1].split(']',1)[0]
# URI arrays contain closing brackets, so take the complete block by its next handler.
block=player.split('navigationRoutes: [',1)[1].split('onActivationRequested:',1)[0]
nativeRoutes=re.findall(r'key: "([^"]+)"',block)
sharedRoutes=re.findall(r'key: "([^"]+)"',shared.split('routes: [',1)[1].split('StringListMenu',1)[0])
assert nativeRoutes==['video','music','network','playlists']
assert sharedRoutes==['home','video','music','network','playlists','recent']
navigation=music.split('MainInterface.JuxtopposedNavigation {',1)[1].split('\n    Rectangle {',1)[0]
assert 'onAddRequested' not in navigation
out=repo/'doc/juxtopposed-references/native/home-home-navigation-review-20261027';assert not out.exists();out.mkdir();artifacts=[]
def retain(p):
    name=p.relative_to(work).as_posix()+'.gz';dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True)
    raw=p.read_bytes();dest.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(dest.read_bytes())==raw
    artifacts.append(dict(path=name,sha256=digest(dest),rawSha256=sha256(raw).hexdigest()))
for name in ['audit-home-history-r371.py','home-history-observation-r371.json','write-home-review-r373.py','render-check-navigation-r374.py','music-navigation-asset-renders-r374.json']:retain(work/name)
for p in sorted((work/'figma-music-navigation-r372').glob('*.svg')):retain(p)
for folder,name in [('ui-music-toolbar-fixed-r360','02-compact-default-maximized-open'),('ui-finish-stop-policy-r368','04-stop-policy-keeps-app-open-home')]:
    for p in sorted((work/folder/'observations').glob(name+'*')):
        if p.suffix in ['.json','.png']:retain(p)
record=dict(status='open-home-policy-and-music-navigation-followup',fullBetaAccepted=False,implementationChanged=False,
    sourceSha256={name:digest(repo/name) for name in sources},figma=dict(fileKey='zdNUYRVOH9lEtIxMYvh8DV',nodeId='4778:25123',sidebarNode='4778:25149',reusedHighFidelityContext=True,referenceRailWidth=50,referenceTotalSidebarWidth=427),
    musicRoutes=nativeRoutes,sharedRoutes=sharedRoutes,assets=assets,assetRenderComparisons=json.loads((work/'music-navigation-asset-renders-r374.json').read_text(encoding='utf-8')),
    findings=[
      'The music presentation supplies four routes and font icons. The paired original Figma music frame has Home/Video/Music/Network/Playlists/Recent plus Add; the existing shared NavigationPane already implements all six routes, original artwork, pins and Add handlers.',
      'The standalone navigation inside JuxtopposedMusicPlayer has no Add-request handler. Its separate source-panel Add emits the root addRequested signal and is handled by Player; that does not automatically handle the child rail Add signal. This is a source finding; an ordinary rail-Add click has not yet been replayed.',
      'The music rail currently declares46px and the wide source panel380px, while the original paired frame uses50px rail/427px total. Source header/breadcrumb/actions and title-bar source context remain separate unassessed presentation work.',
      'Four shared SVG XML trees match the paired-frame exports. The structurally different Home asset renders identically at240x240 with QtSvg; Video and Music have different rendered pixels and need their exact frame/state variants assessed before reusing a shared descriptor blindly. No artwork or production implementation was changed in this audit.',
      'The Stop-policy Home screenshot contains the video that reached EOF in the preceding copied-profile test. A read-only owned-database query finds last_position0.995987,duration-1,play_count0. The recent-video query does not by itself define a completed-item policy.'
    ],nextAction=[
      'Qualify the exact Music-player route asset/state variants and repair inline navigation using the established shared service/component. Preserve a single active handler for pins/collections: the hidden video drawer must not compete with a music pane.',
      'Exercise rail Add and Home/Recent/other destinations, source-panel Add, short-window scrolling/focus, unavailable-library states, pins and paused/playing independence. Keep original static assets; do not replace them with font approximations.',
      'Ask whether Continue Watching should retain all recently watched videos or only unfinished items. If resume-only is chosen, filter before pagination/limiting with a native count/order/search/event contract; do not invent a completion threshold from this one read-only observation.'
    ],limits=['Read-only design/source/database observation, not a runtime repair or a full visual/behavior pass. The raw owned database remains ignored and unchanged. Exact original source/header semantics and all applicable beta gates remain open.'],artifacts=artifacts)
(out/'checkpoint.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Home policy and music navigation follow-up - 27 October2026

This is an open review finding, not an accepted repair. The music rail supplies
four routes/font icons and has no Add-request handler; the existing shared pane
has six routes, original artwork, pins and Add wiring. The original paired Figma
frame also exposes a rail-width difference and two asset-state variants to review.

The [checkpoint](checkpoint.json) records source identities, original exports,
ordinary observations and the implementation/verification steps still needed.
It also preserves a separate Continue Watching policy question: should completed
videos remain as recently watched items, or should this section be resume-only?
No completion threshold or database change was introduced.
''',encoding='utf-8',newline='\n')
print(str(out),len(artifacts),'verified artifacts; differing route assets:',[a['originalAsset'] for a in assets if not a['xmlTreeEqual']])
