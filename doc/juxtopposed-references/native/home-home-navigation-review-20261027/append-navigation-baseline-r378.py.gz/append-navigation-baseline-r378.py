from pathlib import Path
from hashlib import sha256
import gzip,json,re
work=Path(__file__).resolve().parent;repo=work.parents[1]
out=repo/'doc/juxtopposed-references/native/home-home-navigation-review-20261027'
record=json.loads((out/'checkpoint.json').read_text(encoding='utf-8'))
run=work/'ui-music-nav-before-r377';baseline=json.loads((run/'verification.json').read_text(encoding='utf-8'))
assert baseline['normalExit'] and baseline['moduleCounts']==['602'] and not baseline['diagnostics']
assert all(v for k,v in baseline.items() if k.endswith('Unchanged'))
after=json.loads((run/'observations/02-rail-add-no-actions-open.json').read_text(encoding='utf-8'))
assert 'Progress Value: 0 ' in after['accessibility']['tree']
assert len(json.loads((run/'observations/window-inventory.json').read_text(encoding='utf-8'))['windows'])==1
record['ordinaryBaseline']=dict(runtimeSha256=baseline['runtimeSha256'],normalExit=True,moduleCounts=['602'],checkedDiagnostics=[],allGuards=True,
    expectedFailure='The enabled music navigation rail Add item button opens no action menu or file chooser after clicking. Only its tooltip appears. Home and Recent are absent from the inline route list.',
    currentPausedProgress=0,fullBetaAccepted=False)
record['findings'][1]='The standalone navigation inside JuxtopposedMusicPlayer has no Add-request handler. Its separate source-panel Add emits the handled root addRequested signal. Ordinary GUI357 now confirms the rail failure: clicking enabled Add item produces only its tooltip, with no action menu/file chooser and unchanged paused0. The matching app then exits normally with all guards.'
files=[run/name for name in ['verification.json','producer.py','launch.json','staging.json','layout-fixture.json']]
files+=sorted(p for p in (run/'observations').glob('*') if p.suffix in ['.png','.json'])
files+=[work/'inputs-r377.json',Path(__file__)]
for source in files:
    name=source.relative_to(work).as_posix()+'.gz';target=out/name;target.parent.mkdir(parents=True,exist_ok=True)
    raw=source.read_bytes();target.write_bytes(gzip.compress(raw,mtime=0))
    record['artifacts'].append(dict(path=name,sha256=sha256(target.read_bytes()).hexdigest(),rawSha256=sha256(raw).hexdigest()))
for artifact in record['artifacts']:
    data=(out/artifact['path']).read_bytes();assert sha256(data).hexdigest()==artifact['sha256']
    assert sha256(gzip.decompress(data)).hexdigest()==artifact['rawSha256']
(out/'checkpoint.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
with (out/'README.md').open('a',encoding='utf-8',newline='\n') as stream:
    stream.write('''
The ordinary GUI357 baseline now confirms the rail Add failure: clicking the
enabled button opens no actions or chooser, only its tooltip, while paused0 stays
unchanged. The app exits0/602modules/zero checked errors/all guards. This preserves
the failure for repair; it does not accept the navigation path as beta-ready.
''')
print('Preserved ordinary navigation failure:',len(record['artifacts']),'verified artifacts')
