from pathlib import Path
from hashlib import sha256
import json,sqlite3,subprocess
work=Path(__file__).resolve().parent;repo=work.parents[1]
db=work/'ui-finish-stop-policy-r368/userdata/ml/ml.db'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
before=digest(db)
with sqlite3.connect(db.as_uri()+'?mode=ro',uri=True) as connection:
    connection.execute('PRAGMA query_only=ON');connection.row_factory=sqlite3.Row
    rows=[dict(row) for row in connection.execute('SELECT id_media,title,filename,duration,last_position,last_time,play_count,is_present FROM Media WHERE filename COLLATE BINARY IN (?,?,?) ORDER BY filename COLLATE BINARY',('Show.S01E01.mp4','Show.S01E02.mp4','Video mixed into music folder.mp4'))]
assert digest(db)==before
sources=['modules/gui/qt/medialibrary/qml/JuxtopposedHomePage.qml','modules/gui/qt/medialibrary/mlrecentvideomodel.cpp']
record=dict(status='read-only-home-history-policy-observation',fullBetaAccepted=False,sourceSha256={name:digest(repo/name) for name in sources},
    ownedDatabaseSha256=before,databaseUnchanged=True,rows=rows,
    observation='Continue Watching currently uses the native recent-video history query. The ordinary Stop-policy Home screenshot includes the video that reached final queue completion in the preceding copied-profile run. Determine intended completed-item behavior before treating native history inclusion as a defect.',
    pending='If resume-only filtering is intended, qualify count/limit/search/order and metadata-reset events against native queries; do not filter only the four already-limited UI cards or invent a completion threshold from this observation.')
(work/'home-history-observation-r371.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record,indent=2))
