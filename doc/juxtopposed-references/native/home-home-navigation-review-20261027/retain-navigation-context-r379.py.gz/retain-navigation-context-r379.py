from pathlib import Path
from hashlib import sha256
import gzip,json
work=Path(__file__).resolve().parent;repo=work.parents[1]
out=repo/'doc/juxtopposed-references/native/home-home-navigation-review-20261027'
record=json.loads((out/'checkpoint.json').read_text(encoding='utf-8'))
for source in [work/'music-navigation-high-fidelity-r379.json',Path(__file__)]:
    raw=source.read_bytes();name=source.name+'.gz';dest=out/name;dest.write_bytes(gzip.compress(raw,mtime=0))
    assert gzip.decompress(dest.read_bytes())==raw
    record['artifacts'].append(dict(path=name,sha256=sha256(dest.read_bytes()).hexdigest(),rawSha256=sha256(raw).hexdigest()))
record['figma']['retainedHighFidelitySubtree']='music-navigation-high-fidelity-r379.json.gz'
(out/'checkpoint.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Retained original navigation subtree:',len(record['artifacts']),'artifacts')
