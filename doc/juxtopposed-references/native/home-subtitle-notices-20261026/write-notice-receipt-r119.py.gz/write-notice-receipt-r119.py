from pathlib import Path
from hashlib import sha256
import gzip,json
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));digest=lambda p:sha256(p.read_bytes()).hexdigest()
out=repo/'doc/juxtopposed-references/native/home-subtitle-notices-20261026';assert not out.exists()
assert read(work/'notification-before-r107/verification.json')['exitCode']==1
assert read(work/'notification-after-r109/verification.json')['exitCode']==0
uis={n:read(work/n/'verification.json') for n in ['ui-notice-r109','ui-notice-cold-r110']}
for v in uis.values():assert v['normalExit'] and all(v[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','pluginCacheUnchanged'])
out.mkdir();artifacts=[]
def retain(path,name=None):
    raw=path.read_bytes();target=out/((name or path.relative_to(work).as_posix())+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(raw,mtime=0))
    artifacts.append(dict(path=target.relative_to(out).as_posix(),sha256=digest(target),rawSha256=sha256(raw).hexdigest()))
for n in ['notification-before-r107','notification-after-r108','notification-after-r109']:
    for p in sorted((work/n).rglob('*')):
        if p.is_file():retain(p)
for n in uis:
    for name in ['verification.json','launch.json','vlc.log']:retain(work/n/name)
    for pattern in ['*.jpg','*tree.txt']:
        for p in sorted((work/n).glob(pattern)):retain(p)
for revision in ['r107','r109','r110']:
    manifest=read(work/f'inputs-{revision}.json');retain(work/f'inputs-{revision}.json')
    for name in ['widgets/qml/FloatingNotification.qml','widgets/qml/SubtitleLabel.qml','widgets/qml/LabelExt.qml','tests/test_floating_notification.py','dialogs/dialogs/qml/JuxtopposedSubtitleAttachments.qml']:
        key='modules/gui/qt/'+name;source=Path(manifest['sourceCopies'][key]);assert digest(source)==manifest['files'][key];retain(source,f'sources/{revision}/{key}')
for name in ['build-r109.sh','build-r109-exit.txt','run-notice-components-r107.py','run-ui-notice-r109.py','run-ui-notice-cold-r110.py','write-notice-receipt-r119.py']:retain(work/name)
record=dict(status='scoped-checkpoint-session-continues',fullBetaAccepted=False,artifacts=artifacts,runtimeSha256={n:v['runtimeSha256'] for n,v in uis.items()},
    before='The 400px supplied-state window produces a 1872px notice extending beyond both edges.',
    after='Production notice width is bounded by its host, with full wrapping and an accessible alert name. 400/800px and short-message component cases pass without truncation.',
    ordinary='GUI 195471d3 / Core 883f7e51. Actual 602x421 detailed load error wraps, its entire text is in UIA, and Save/Cancel remain visible. Actual reopened-input toast is captured at 962x541. Both processes exit normally with unchanged guards and 602 modules.',
    diagnostics='Intentional malformed SRT probes retain expected DVD probe errors. First run has nine and cold/reopened run has eighteen. No clean-log claim for these negative controls.',
    limits=['Component wrapping does not establish actual narrow-window toast or Windows OS DPI acceptance.','Ordinary detailed error and transient notice are distinct observations.','Remaining beta gates and online search remain open.'])
(out/'checkpoint.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Subtitle notices and accessible recovery - 26 October 2026

The floating notice now stays within its host width and wraps its complete text.
A failing before control produced a 1872-pixel notice in a 400-pixel window.
Production QML, actual SubtitleLabel/LabelExt, and supplied theme/notifier state
pass narrow/ordinary widths and a shorter message. The full alert name is checked.
These component dimensions do not establish Windows OS DPI acceptance.

On ordinary GUI `195471d3` / Core `883f7e51`, the detailed subtitle-load error
wraps inside a 602x421 dialog; its full name is exposed through UIA, with Save and
Cancel visible. The transient notice is separately captured after an actual
input reopen in a 962x541 player. Actual narrow-toast wrapping remains to combine.
Both processes close normally with 602 modules and unchanged source/runtime/
fixture/cache guards. Expected DVD probe errors from the malformed SRT remain.

[checkpoint.json](checkpoint.json) binds immutable source, layout, capture and
process artifacts. The preceding [load-recovery receipt](../home-subtitle-load-restore-20261026/README.md)
retains actual replacement and cold caption return on its own tuples.
Continue from [STATUS](../../../juxtopposed/STATUS.md); beta acceptance is unfinished.
''',encoding='utf-8',newline='\n')
print(str(out),len(artifacts),flush=True)
