from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
work=Path(__file__).resolve().parent;repo=work.parents[1]
revision,label=sys.argv[1:];digest=lambda p:sha256(p.read_bytes()).hexdigest()
inputs=json.loads((work/f'inputs-{revision}.json').read_text(encoding='utf-8'))
assert all(digest(repo/p)==h for p,h in inputs['files'].items())
out=work/label;assert not out.exists();out.mkdir()
with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
    proc=subprocess.Popen([sys.executable,str(repo/'modules/gui/qt/tests/test_floating_notification.py'),'--output-dir',str(out/'component')],stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    print('Component PID',proc.pid,flush=True);code=proc.wait(timeout=60)
unchanged=all(digest(repo/p)==h for p,h in inputs['files'].items())
record=dict(exitCode=code,sourceInputsUnchanged=unchanged,suppliedStateComponent=True,ordinaryGuiAccepted=False,fullBetaAccepted=False)
(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(record),flush=True)
assert unchanged and code==0
