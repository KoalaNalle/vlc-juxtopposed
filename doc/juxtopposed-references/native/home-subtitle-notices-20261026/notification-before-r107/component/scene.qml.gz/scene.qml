import QtQuick
import QtQuick.Controls.Basic as C
C.ApplicationWindow {
 visible: true; width: 400; height: 600; color: "#444444"
 FloatingNotification { objectName: "notices"; anchors { bottom: parent.bottom; left: parent.left; right: parent.right; margins: 16 } }
}
