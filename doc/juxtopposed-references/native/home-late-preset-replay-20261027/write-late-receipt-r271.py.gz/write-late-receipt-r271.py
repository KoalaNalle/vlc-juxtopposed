from pathlib import Path
from hashlib import sha256
import gzip,json,re
from PySide6.QtCore import QSettings,QByteArray
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
out=repo/'doc/juxtopposed-references/native/home-late-preset-replay-20261027'
assert not out.exists()
names=['ui-late-preset-r269','ui-late-cold-r270']
manifest=read(work/'inputs-r269.json')
assert all(digest(repo/p)==h for p,h in manifest['files'].items())
records={n:read(work/n/'verification.json') for n in names}
for v in records.values():
    assert v['normalExit'] and v['exitCode']==0 and v['moduleCounts']==['602'] and not v['diagnostics']
    assert all(v[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','extraFixturesUnchanged','lateFixturesUnchanged','decodeFixturesUnchanged','producerUnchanged','pluginCacheUnchanged'])
    assert not v['privateCore'] and not v['privateGui'] and not v['forcedCleanupUsed']
assert records[names[0]]['runtimeSha256']==records[names[1]]['runtimeSha256']
warm=read(work/names[0]/'frame-measurements.json')['frames']
cold=read(work/names[1]/'frame-measurements.json')['frames']
assert [(r['marker'],r['captionPixels']) for r in warm]==[(426,2062),(426,0),(500,2062),(498,0),(499,0),(500,2062),(625,2062),(426,2062)]
assert [(r['marker'],r['captionPixels']) for r in cold]==[(426,2062)]
def tree(name,observation):return read(work/name/'observations'/observation)['accessibility']['tree']
def actual(name,observation,fps,preset=None):
    t=tree(name,observation)
    assert re.search(r'edit[^\n]*Subtitle frame rate Value: '+re.escape(f'{fps:.3f}')+r' fps',t)
    if preset:assert preset in t
    return dict(observation=observation,fps=fps,preset=preset)
checks=[actual(names[0],'23-default-settled-fps0.json',0,'Default Preset'),
        actual(names[0],'24-named-settled-fps30.json',30,'Before first cue 30 fps'),
        actual(names[0],'28-next-default-fps0.json',0,'Default Preset'),
        actual(names[0],'29-return-first-preset.json',30,'Before first cue 30 fps'),
        actual(names[1],'03-cold-subtitle-fps30.json',30,'Before first cue 30 fps')]
catalogs={}
for n in names:
    s=QSettings(str(work/n/'settings-after.ini'),QSettings.IniFormat)
    raw=s.value('Juxtopposed/SubtitlePresets/v1');raw=bytes(raw) if isinstance(raw,QByteArray) else raw.encode()
    catalog=json.loads(raw);p=[p for p in catalog['presets'] if p['name']=='Before first cue 30 fps']
    assert len(p)==1 and p[0]['fps']==30
    catalogs[n]=dict(preset=p[0],catalogSha256=sha256(raw).hexdigest(),profileSha256=digest(work/n/'settings-after.ini'))
    config=(work/n/'config-after.txt').read_text(encoding='utf-8-sig')
    assert re.search(r'^sub-fps=23\.976$',config,re.M)
out.mkdir();artifacts=[];streams=[]
def retain(p,relative=None):
    rel=(relative or p.relative_to(work).as_posix())+'.gz';target=out/rel
    assert not target.exists();raw=p.read_bytes();target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(raw,mtime=0))
    artifacts.append(dict(path=rel,sha256=digest(target),rawSha256=sha256(raw).hexdigest()))
for n in names:
    for p in sorted((work/n).rglob('*')):
        if not p.is_file() or any(x in p.relative_to(work/n).parts for x in ['runtime','userdata','appdata','localappdata','temp']):continue
        if p.suffix in ['.log','.txt','.ini']:streams.append(dict(path=p.relative_to(work).as_posix(),sha256=digest(p),packaged=False))
        elif p.suffix in ['.json','.png','.py']:retain(p)
retain(work/'inputs-r269.json')
for source in ['src/player/timer.c','src/input/decoder.c','modules/gui/qt/maininterface/subtitle_preset_model.cpp','modules/gui/qt/player/qml/PlaybackSettingsMenu.qml','modules/gui/qt/player/qml/TracksPageSubtitle.qml']:
    p=Path(manifest['sourceCopies'][source]);assert digest(p)==manifest['files'][source];retain(p,'sources/'+source)
for name in ['run-ui-late-r265.py','inspect-late-r270.py','write-late-receipt-r271.py']:retain(work/name)
record=dict(status='passed-scoped-ordinary-late-preset-replay',fullBetaAccepted=False,
    runtimeSha256=records[names[0]]['runtimeSha256'],sourceManifestSha256=digest(work/'inputs-r269.json'),
    warmFrames=warm,coldFrames=cold,actualSettings=checks,generatedCatalogs=catalogs,
    artifacts=artifacts,localStreams=streams,
    accepted=[
      'At held source frame426/17.04s, the selected external late cue is visible at30fps. Explicit classic FPS Reset applies0 and removes it without advancing the held video. Native exports preserve marker426.',
      'At normal0fps, native frame498 and499 have no cue; one-frame advance to500/20.00s shows it. At frame625/25.00s it remains visible.',
      'Applying Default then saved30fps updates both actual controls and preset state while source progress remains25.00s. The second file loads its own caption and Default0; returning restores the first file saved30 and its early cue.',
      'A normal cold restart restores actual30fps and selected external Track3 before the first cue. Seeking17.04s shows the late cue and exports frame426. The named catalog entry remains30; native saved global sub-fps remains23.976, distinct from the launch override0 and current per-media association.',
      'Both ordinary GUI runs exit0 normally, load602modules and have no error diagnostics. Source/runtime/fixture/producer/plugin-cache guards pass.'
    ],limits=[
      'The inherited runner scope text incorrectly says ten-minute media; the actual generated attachment fixture is60.011s, SHA256fd82d189533aa73d9715596d9856d27960cf76c76df1baaa0632672660c9b42d. The encoded source marker distinguishes the observed frames within it.',
      'Next/Previous begin ordinary playback; each new file was explicitly paused before inspection. No claim that switching retains pause is made.',
      'Some accessibility trees lag the rendered frame by one observation. Settled captures/checks supply acceptance. Cold observation02 is named actual-fps30 but shows the Playback tab; observation03 supplies the actual subtitle FPS.',
      'An initial boundary slider request landed at500, not499. Exact499/500 evidence comes from observed frame-next actions and native exports; requested slider values alone are not exact-time evidence.',
      'Some immediate screenshots after export omit captions, while later settled observations and native exports contain them. The separate fullscreen/secondary-display/capture issue is still open.',
      'This is generated-fixture ordinary timing/persistence evidence, not all subtitle formats, physical display/DPI, all preset failure/retry flows or final-package acceptance.'
    ])
(out/'checkpoint.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Ordinary late-cue preset replay - 27 October 2026

Core `fdfcfcd5`, ordinary GUI `8e92470c` and MP4 `df15e8ed` pass the older
generated late-cue journey at playback speed1.5. At held frame426/17.04s, the
30fps external cue is visible; explicit FPS Reset0 removes it at that same frame.
At normal timing it is absent on frame499 and appears on frame500/20.00s.

Applying Default and the named30fps preset updates actual settings without moving
the held25s picture. The second file uses its own caption and Default0; returning
restores the first file's preset and early cue. A normal cold restart restores
actual30fps, selected external Track3 and the early cue. The saved catalog remains
30fps and the separate native global default remains23.976.

Both apps exit normally with602modules, no error diagnostics and unchanged
source/runtime/fixture/producer/cache guards. [checkpoint.json](checkpoint.json)
binds the generated observations and exports to the exact source and binary
identities. It also preserves stale-tree, filename, slider and inherited-runner
scope qualifications. Raw profiles/logs and binaries remain local.

Broader preset failures, formats, physical display/DPI, the fullscreen idle
capture issue and the beta gates remain open. Continue from
[STATUS](../../../juxtopposed/STATUS.md).
''',encoding='utf-8',newline='\n')
for a in artifacts:
    p=out/a['path'];assert digest(p)==a['sha256'] and sha256(gzip.decompress(p.read_bytes())).hexdigest()==a['rawSha256']
print(out,len(artifacts),'verified artifacts',flush=True)
