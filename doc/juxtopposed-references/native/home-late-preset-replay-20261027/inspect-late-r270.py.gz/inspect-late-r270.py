from pathlib import Path
from hashlib import sha256
import json,sys
from PySide6.QtGui import QImage
work=Path(__file__).resolve().parent;run=work/sys.argv[1];rows=[]
for p in sorted((run/'app-snapshots').glob('*.png')):
    im=QImage(str(p)).convertToFormat(QImage.Format_RGBA8888);assert not im.isNull()
    raw=bytes(im.bits())
    rows.append(dict(path=p.name,sha256=sha256(p.read_bytes()).hexdigest(),
        marker=sum(1<<b for b in range(11) if im.pixelColor(32+64*b,20).red()>128),
        captionPixels=sum(raw[i]>160 and raw[i+1]>160 and raw[i+2]>160 for i in range(0,len(raw),4))))
(run/'frame-measurements.json').write_text(json.dumps(dict(scope='Generated native exports; partial observations, no acceptance assertion.',frames=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(rows),flush=True)
