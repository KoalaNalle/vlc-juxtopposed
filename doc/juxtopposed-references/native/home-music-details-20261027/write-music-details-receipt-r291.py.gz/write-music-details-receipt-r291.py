from pathlib import Path
from hashlib import sha256
import gzip, json, re

work = Path(__file__).resolve().parent
repo = work.parents[1]
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda p: sha256(p.read_bytes()).hexdigest()
out = repo / 'doc/juxtopposed-references/native/home-music-details-20261027'
assert not out.exists()
manifest = read(work / 'inputs-r290.json')
assert all(digest(repo / p) == h for p, h in manifest['files'].items())
accepted = ['ui-music-details-fixed-r290', 'ui-music-details-classic-r290']
earlier = ['ui-music-details-r288', 'ui-music-details-fixed-r289']
records = {name: read(work / name / 'verification.json') for name in accepted + earlier}
guards = ['sourceInputsUnchanged', 'runtimeUnchanged', 'baseRuntimeUnchanged',
          'fixturesUnchanged', 'musicFixturesUnchanged', 'lateFixturesUnchanged',
          'decodeFixturesUnchanged', 'extraFixturesUnchanged', 'producerUnchanged', 'pluginCacheUnchanged']
for name, v in records.items():
    assert v['normalExit'] and v['exitCode'] == 0 and v['moduleCounts'] == ['602'] and not v['diagnostics']
    assert all(v[k] for k in guards)
    assert not v['privateCore'] and not v['privateGui'] and not v['forcedCleanupUsed']
assert records[accepted[0]]['runtimeSha256'] == records[accepted[1]]['runtimeSha256']
native = {name: read(work / name / 'verification.json') for name in ['music-details-fixed-r288', 'music-details-legacy-r288']}
for name, v in native.items():
    assert v['qtestCompleted'] and v['cases'] == 8 and not v['forcedCleanupUsed']
    assert all(v[k] for k in ['sourceInputsUnchanged', 'runtimeUnchanged', 'baseRuntimeUnchanged',
                             'fixturesUnchanged', 'producerUnchanged', 'pluginCacheUnchanged'])
    if 'legacy' in name:
        assert v['exitCode'] == 1 and [f['name'] for f in v['failures']] == ['mediaTrackOrderDistinctFromCollectionCount']
    else:
        assert v['normalExit'] and not v['failures']

def tree(run, name):
    return read(work / run / 'observations' / (name + '.json'))['accessibility']['tree']
warm, classic = accepted
assert 'text Show.S01E01.mp4' in tree(warm, '02-table-enter-keeps-paused-video-zero')
assert 'Progress Value: 0 ID:' in tree(warm, '02-table-enter-keeps-paused-video-zero')
queue = tree(warm, '06-space-enqueue-appends-two-tracks-paused')
queue_names = re.findall(r'list item \(selectable, settable, string\) (.*?) ID:', queue)
assert queue_names[-4:] == ['Show.S01E01.mp4', 'Show.S01E02.mp4',
    'A long title for checking truncation and focus in the redesigned music library', 'Nested song'], queue_names
held = 'Progress Value: 0.27840675000000004'
for name in ['08-paused-artist-song-before-header-journey', '09-switch-fixture-artist-correct-tracks-held-clock',
             '10-track-filter-preserves-held-song-queue', '11-back-native-artists-held-song-and-queue',
             '12-forward-fixture-artist-held-song-and-queue', '13-artist-grid-one-album-held-song',
             '14-genre-breadcrumb-grid-held-song-six-items', '15-genre-album-clean-caption-held-song']:
    assert held in tree(warm, name), name
assert 'text Second light' in tree(warm, '10-track-filter-preserves-held-song-queue')
assert 'text First light' not in tree(warm, '10-track-filter-preserves-held-song-queue')
assert 'text Another Artist - 1 track - 01:00' in tree(warm, '15-genre-album-clean-caption-held-song')
assert 'Library header' not in tree(classic, '02-classic-table-enter-custom-header-paused')
assert 'text Albums' in tree(classic, '02-classic-table-enter-custom-header-paused')
assert 'text Second light' in tree(classic, '03-classic-custom-search-one-track-paused')
assert 'text First light' not in tree(classic, '03-classic-custom-search-one-track-paused')
assert 'text First light' in tree(classic, '05-classic-explicit-play-first-light-advances')
assert 'Progress Value: 0.15998018333333333' in tree(classic, '05-classic-explicit-play-first-light-advances')
identity = read(work / 'music-album-identity-r288/report.json')
assert identity['databaseUnchanged']
reproduction = read(work / 'music-details-r289-reproduction.json')
assert not reproduction['journeyAccepted']

out.mkdir()
artifacts, local = [], []
def retain(p, relative=None):
    relative = (relative or p.relative_to(work).as_posix()) + '.gz'
    target = out / relative
    assert not target.exists()
    raw = p.read_bytes()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(raw, mtime=0))
    artifacts.append(dict(path=relative, sha256=digest(target), rawSha256=sha256(raw).hexdigest()))

for name in accepted + earlier + list(native):
    root = work / name
    for filename in ['verification.json', 'launch.json', 'producer.py', 'results.xml', 'ml-copy.json']:
        p = root / filename
        if p.is_file(): retain(p)
    for p in sorted((root / 'observations').glob('*')):
        if p.suffix in ['.png', '.json']: retain(p)
    for filename in ['vlc.log', 'stdout.txt', 'stderr.txt', 'config-before.txt', 'config-after.txt', 'settings-before.ini', 'settings-after.ini']:
        p = root / filename
        if p.is_file(): local.append(dict(path=p.relative_to(work).as_posix(), sha256=digest(p), packaged=False))
for p in sorted((work / 'music-album-identity-r288').iterdir()):
    if p.suffix in ['.json', '.txt']: retain(p)
for name in ['inputs-r288.json', 'inputs-r289.json', 'inputs-r290.json',
             'music-details-r289-reproduction.json', 'prepare-music-details-r288.py',
             'prepare-music-details-r289.py', 'prepare-music-details-r290.py',
             'run-music-details-r288.py', 'run-ui-music-details-r288.py',
             'run-ui-music-details-r289.py', 'run-ui-music-details-r290.py',
             'build-music-details-r288.sh', 'build-music-details-r289.sh', 'build-music-details-r290.sh',
             'write-music-details-receipt-r291.py']:
    retain(work / name)
sources = ['modules/gui/qt/medialibrary/qml/' + name + '.qml' for name in [
    'MusicAllArtists', 'MusicArtistsAlbums', 'MusicArtist', 'MusicGenresDisplay', 'MusicAlbumsGridExpandDelegate']]
sources += ['modules/gui/qt/widgets/qml/PageExt.qml', 'modules/gui/qt/tests/test_music_library_queries.cpp']
for source in sources:
    p = Path(manifest['sourceCopies'][source])
    assert digest(p) == manifest['files'][source]
    retain(p, 'sources/' + source)
builds = {}
for rev in ['r288', 'r289', 'r290']:
    p = work / f'build-music-details-{rev}.log'
    builds[rev] = dict(exitCode=int((work / f'build-music-details-{rev}-exit.txt').read_text()), logSha256=digest(p))
    assert builds[rev]['exitCode'] == 0
record = dict(status='passed-scoped-music-detail-nightly', fullBetaAccepted=False,
    runtimeSha256=records[warm]['runtimeSha256'], sourceManifestSha256=digest(work / 'inputs-r290.json'),
    sourceInputCount=len(manifest['files']), nativeResults=native, builds=builds,
    acceptedAppRuns={name: dict(exitCode=0, allGuards=True) for name in accepted},
    earlierRunRoles={'ui-music-details-r288': 'GUI286 missing artist shared header, combined genre label and duplicate missing-year separator baseline',
                     'ui-music-details-fixed-r289': 'Header/text improvements; failed artist-table Enter playback independence. Normal exit and guards alone do not accept this journey.'},
    reproducedFailure=reproduction, albumIdentity=identity, artifacts=artifacts, localStreams=local,
    accepted=[
        'Shared artist header exposes native album/track model counts, navigation, search, sort and view. Traditional artist details retain their original custom header; its search binding is only instantiated in that layout.',
        'Single artist table Enter now navigates without requesting playback, matching grid behavior. Explicit Play and multi-selection playback retain native routes. Ordinary fixed Enter preserves initial paused video0; banner Tab navigation reaches Play/Enqueue/tracks without a hidden control stop.',
        'Keyboard Space on Enqueue appends the two actual artist tracks after two videos without playing. Explicit Space Play appends/starts the correct artist tracks, reaches9s and pauses at16.704405s. Artist switch, track search, clear, Back/Forward, grid count, genre navigation and album expansion retain that exact held clock and six-entry queue.',
        'Genre details expose Music/Genres/Electronic breadcrumbs. Missing-year album caption shows artist, track count and duration without doubled separators. Traditional table Enter preserves paused video0; custom search filters/clears, grid shows one native album, and explicit Play advances First light before normal Pause/Quit.',
        'Eight native query functions pass on the unchanged Core265/library282. Album identities, track types/order/search, artist/genre parents and paging are verified. Legacy criterion fails only the intended media-track negative control. Native source matching and a hash-unchanged read-only generated database explain the two separate Evening Album IDs.'
    ], limits=[
        'Only the two GUI290 runs are accepted for this detail checkpoint. The GUI289 table Enter failure is retained and repaired; no claim is made that its first unmeasured journey preserved paused playback.',
        'Return on the focused ordinary banner button did not enqueue; Space is the observed standard activation. Warm observation04 records that attempt; observation05 is misleadingly named four-queue-items but actually shows the original two. The later observation06 supplies the actual four-entry enqueue result.',
        'Some immediate UIA trees lag rendered transitions. One indexed Search click after queue reflow missed the field; a screenshot-backed click with a visible caret and real typing supplied the accepted filter observation. No claim of complete assistive-technology geometry or focus feedback is made.',
        'Equal album titles are distinct native identities when cross-folder matching lacks year/multi-disc evidence. No UI deduplication or library grouping policy was changed. Year-present caption formatting keeps its original branch; this fixture tests missing year.',
        'The multi-selection artist branch is preserved by code review, but not exercised in these ordinary runs. Full rapid in-flight A-B-A, all category sort permutations, search-history retention, initial empty sort feedback, final visual scores, Windows DPI, media matrix and package gates remain open.',
        'Native query binaries do not load the GUI; their recorded staged GUI286 identity is distinct from ordinary GUI290 evidence. Raw logs/profiles/databases and executables remain local. No Windows10, physical-endpoint or full beta acceptance claim.'
    ])
(out / 'checkpoint.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
(out / 'README.md').write_text('''# Music detail nightly - 27 October 2026

Core `fdfcfcd5`, ordinary GUI `1a0c6c19` and library `13ccdc36` now keep
artist details within the shared redesigned navigation/search/sort/view header.
The traditional layout retains its custom controls. Genres have a full
breadcrumb path, and albums without a year no longer show doubled separators.

A controlled regression found that Enter on one artist table row both played
and navigated. The repaired route now only navigates, matching the grid; explicit
Play and Enqueue remain separate. Ordinary keyboard/pointer, paused clock,
queue, search, view and history observations cover both layouts. Two final apps
exit0/602modules/zero errors with all source/runtime/fixture/cache guards true.

Eight native query functions qualify actual album/artist/genre identities,
typed tracks, counts, paging and search; the old Track mapping fails its intended
control. The two Evening Album entries are deliberate native containing-folder
identities, supported by source and a read-only generated database observation.

The [checkpoint](checkpoint.json) preserves binaries, frozen source, build/test
reports, captures, the table-Enter before failure and evidence qualifications.
No full surface, visual score, OS-DPI, media-matrix or final-package gate closes
from this scoped receipt. Raw profiles/logs/databases and binaries remain local.
Continue from [STATUS](../../../juxtopposed/STATUS.md).
''', encoding='utf-8', newline='\n')
for artifact in artifacts:
    p = out / artifact['path']
    assert digest(p) == artifact['sha256']
    assert sha256(gzip.decompress(p.read_bytes())).hexdigest() == artifact['rawSha256']
print(out, len(artifacts), 'verified artifacts', flush=True)
