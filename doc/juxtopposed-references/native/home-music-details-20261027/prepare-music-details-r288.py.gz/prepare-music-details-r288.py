from pathlib import Path
from hashlib import sha256
import json,sqlite3
work=Path(__file__).resolve().parent;repo=work.parents[1]
def write(name,text):
    p=work/name;assert not p.exists();p.write_text(text,encoding='utf-8',newline='\n')
root=work/'music-album-identity-r288';assert not root.exists();root.mkdir()
db=work/'ui-music-play-r286/userdata/ml/ml.db'
digest=lambda p:sha256(p.read_bytes()).hexdigest()
before=digest(db)
connection=sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True)
connection.row_factory=sqlite3.Row
queries=dict(albums='select a.id_album,a.title,a.artist_id,r.name,a.nb_tracks,a.release_year,a.nb_discs from Album a left join Artist r on a.artist_id=r.id_artist order by a.id_album',
 tracks='select m.id_media,m.type,m.title,m.artist_id,m.album_id,m.track_number,m.disc_number,f.name as folder from Media m join Folder f on m.folder_id=f.id_folder where m.album_id is not null order by m.id_media',
 genres='select id_genre,name,nb_tracks from Genre order by name')
rows={k:[dict(r) for r in connection.execute(q)] for k,q in queries.items()}
connection.close();assert digest(db)==before
evenings=[a for a in rows['albums'] if a['title']=='Evening Album']
assert len(evenings)==2 and len({a['id_album'] for a in evenings})==2
assert len({a['artist_id'] for a in evenings})==1
source=Path(r'\\wsl.localhost\VLC-Juxtopposed-Home-20261018\root\vlc-juxtopposed-build\contrib\contrib-win64\medialibrary\src\metadata_services\MetadataParser.cpp')
lines=source.read_text().splitlines()
snippet='\n'.join(lines[1220:1380])+'\n'
assert 'Assume album files will be in the same folder.' in snippet
assert 'discTotal > 1 || discNumber > 1' in snippet
(root/'native-album-matching.cpp.txt').write_text(snippet,encoding='utf-8',newline='\n')
report=dict(scope='Read-only generated database observation and matching implementation of the installed native library; no UI deduplication or new grouping policy is implemented.',
 databaseSha256=before,databaseUnchanged=True,queries=queries,rows=rows,
 nativeMatchingSource=str(source),nativeMatchingSourceSha256=digest(source),sourceLines=[1221,1380],
 conclusion='Two separate native album IDs, each with one track in a different folder and the same album artist. No year/disc tags were supplied. Native matching deliberately rejects this cross-folder match; the UI is displaying both identities.')
(root/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
runner=(work/'run-music-queries-r283.py').read_text()
runner=runner.replace("base=work/'ui-music-r279/runtime'", "base=work/'ui-music-play-r286/runtime'")
runner=runner.replace("work/'ordinary-r282-bin'/target.name", "(work/'ordinary-r286-bin' if target.name=='libqt_plugin.dll' else work/'ordinary-r282-bin')/target.name")
runner=runner.replace("work/'native-music-real-r283-bin'/program.name", "work/'native-music-details-r288-bin'/program.name")
runner=runner.replace('assert len(cases)==6','assert len(cases)==8')
runner=runner.replace("scope='Real native library queries and generated SQL-backed folder/media/artist records. The legacy criterion selects the preceding audio-model mapping, not a previous executable or Core. No ordinary desktop, Qt model or hardware playback claim.'", "scope='Real native folder, album, artist and genre queries, distinct native album identities, audio parent filtering, paging and search. Same ordinary GUI286/Core265 tuple; UI interactions and final design acceptance remain separate.'")
write('run-music-details-r288.py',runner)
ui=(work/'run-ui-music-r286.py').read_text().replace("scope='Ordinary music category/folder/detail journey with generated silent tagged files; one60.011s encoded video holds primary playback. Actual Computer Use observations and native library indexing are required.'", "scope='Ordinary album, artist and genre detail workflows on the accepted GUI286/Core265/library282 tuple, using the unchanged generated tagged audio/video fixture. Actual observations, playback independence and normal exit are required; complete design/DPI/package gates remain separate.'")
write('run-ui-music-details-r288.py',ui)
write('build-music-details-r288.sh','''#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
native="$base/owned-music-details-20261027-r288"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-music-details-r288.log" 2>&1
trap 'code=$?; printf "%s\\n" "$code" > "$work/build-music-details-r288-exit.txt"; exit "$code"' EXIT
test ! -e "$native"
test ! -e "$work/native-music-details-r288-bin"
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = fdfcfcd599588512bb7f3a51e46305b7b0d947b47387dd205851feb45f032b46
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/modules/gui/qt/tests/native_library/music-queries.mk" -j2 MUSIC_QUERIES_OUT="$native" music-queries-native
mkdir "$work/native-music-details-r288-bin"
cp "$native/.libs/test_qt_music_library_queries.exe" "$work/native-music-details-r288-bin/"
sha256sum "$work/native-music-details-r288-bin/"*
''')
print(json.dumps(dict(prepared=True,databaseUnchanged=True,albums=len(rows['albums']))))
