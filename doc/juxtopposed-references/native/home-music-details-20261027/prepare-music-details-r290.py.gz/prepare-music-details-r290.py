from pathlib import Path
import json

work = Path(__file__).resolve().parent
def write(name, text):
    target = work / name
    assert not target.exists()
    target.write_text(text, encoding='utf-8', newline='\n')

runner = (work / 'run-ui-music-details-r289.py').read_text(encoding='utf-8')
runner = runner.replace("ordinary-r289-bin", "ordinary-r290-bin").replace('GUI289', 'GUI290')
write('run-ui-music-details-r290.py', runner)
builder = (work / 'build-music-details-r289.sh').read_text(encoding='utf-8').replace('r289', 'r290')
write('build-music-details-r290.sh', builder)
write('music-details-r289-reproduction.json', json.dumps({
    'fullBetaAccepted': False,
    'appRun': 'ui-music-details-fixed-r289',
    'runtimeExitAndGuardsPassed': True,
    'journeyAccepted': False,
    'failure': 'Enter on one selected artist in table mode both requests playback and navigates to artist details.',
    'controlledBefore': {'media': 'Nested song', 'pausedProgress': 0.12941123333333332},
    'controlledAfter': {'media': 'A long title for checking truncation and focus in the redesigned music library', 'progress': 0, 'playbackStarted': True},
    'evidence': ['observations/17-controlled-song-pause-before-navigation.json', 'observations/19-artist-track-search-one-result-paused.json', 'observations/20-failure-table-enter-starts-artist-playback.json'],
    'cause': 'MusicAllArtists table onActionForSelection unconditionally called addAndPlay before navigating on a single selection. Grid navigation did not call it. The retained asynchronous Play request now survives removal of the source view, exposing this conflicting action.',
    'repair': 'Use the same single-selection navigation and multi-selection playback contract as the grid. Keep explicit Play controls unchanged.',
    'otherObservations': 'Shared artist header, native search and sort, album-sections toggle, artist history, genre breadcrumbs and missing-year caption are visible. No complete visual/DPI/package acceptance is implied.',
    'qualification': 'The first navigation sequence did not measure the held primary clock. A later controlled pause reproduced the single-artist table failure. Initial captures must not be labeled paused-playback preservation.',
}, indent=2) + '\n')
print(json.dumps({'prepared': True}))
