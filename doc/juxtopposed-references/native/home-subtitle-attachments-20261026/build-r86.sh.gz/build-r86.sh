#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
native="$base/owned-single-frame-native-20261026-r86"
ordinary="$base/owned-single-frame-ordinary-20261026-r86"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-r86.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-r86-exit.txt"; exit "$code"' EXIT
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = 883f7e51c57be0de40e8c6a47db6ca3f60ac4cdb98920a9846b9a5e8ce8adb22
test ! -e "$ordinary"
test ! -e "$work/ordinary-r86-bin"
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/build-windows/beta-subtitle-sync-20261025/ordinary.mk" -j2 QA_OUT="$ordinary" owned-ordinary-subtitle-sync
mkdir "$work/ordinary-r86-bin"
cp "$ordinary/.libs/libqt_plugin.dll" "$work/ordinary-r86-bin/"
sha256sum "$work/ordinary-r86-bin/libqt_plugin.dll"
