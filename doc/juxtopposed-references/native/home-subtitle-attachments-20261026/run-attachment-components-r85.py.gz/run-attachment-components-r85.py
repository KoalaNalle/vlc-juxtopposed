from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
work=Path(__file__).resolve().parent;repo=work.parents[1]
revision,label=sys.argv[1:]
digest=lambda p:sha256(p.read_bytes()).hexdigest()
inputs=json.loads((work/f'inputs-{revision}.json').read_text(encoding='utf-8'))
assert all(digest(repo/p)==h for p,h in inputs['files'].items())
out=work/label;assert not out.exists();out.mkdir()
children=[]
for short,name in [('attachments','test_juxtopposed_subtitle_attachments.py'),('host','test_juxtopposed_dialogs_host.py')]:
    stdout=(out/(short+'-stdout.txt')).open('wb');stderr=(out/(short+'-stderr.txt')).open('wb')
    child=subprocess.Popen([sys.executable,str(repo/'modules/gui/qt/tests'/name),'--output-dir',str(out/short)],stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    children.append((short,child,stdout,stderr))
    print(short,'PID',child.pid,flush=True)
codes={}
for short,child,stdout,stderr in children:
    try:codes[short]=child.wait(timeout=120)
    except subprocess.TimeoutExpired:raise SystemExit('Inspect owned component PID; no automatic restart or cleanup')
    stdout.close();stderr.close()
unchanged=all(digest(repo/p)==h for p,h in inputs['files'].items())
record={'exitCodes':codes,'sourceInputsUnchanged':unchanged,'suppliedStateComponent':True,'ordinaryGuiAccepted':False,'fullBetaAccepted':False}
(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record),flush=True)
assert unchanged and all(c==0 for c in codes.values())
