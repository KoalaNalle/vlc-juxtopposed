import QtQuick
import QtQuick.Controls.Basic as C
import VLC.MainInterface
import VLC.Dialogs
import VLC.Style
import "file:///C:/Modding/vlc-juxtopposed/modules/gui/qt/dialogs/dialogs/qml" as Dialogs
import "file:///C:/Modding/vlc-juxtopposed/modules/gui/qt/menus/qml" as Menus
C.ApplicationWindow {
    id: window
    visible:true; width:1300; height:1000; color:"#181818"
    property int transports:0
    property int savedNotifications:0
    property var savedSelection:null
    property Item ephemeral:null
    Component { id: ephemeralButton; C.Button { objectName:"ephemeralOpener"; text:"Temporary"; x:700; y:10 } }
    Rectangle { id: backdropUnderlay; objectName:"settingsTestUnderlay"; anchors.fill:parent; color:window.color }
    C.Button { id: opener; objectName:"opener"; x:10; y:10; text:"Settings"; onClicked:DialogsProvider.showGlobalSettingsDialog() }
    C.Button { id: fallback; objectName:"fallback"; x:160; y:10; text:"View" }
    C.TextField { objectName:"outsideText"; x:300; y:10; width:160 }
    C.TextField { objectName:"readonlyText"; x:480; y:10; width:160; readOnly:true; text:"readonly" }
    Menus.ShortcutExt { objectName:"transportShortcut"; sequence:"Space"; onActivated:window.transports++ }
    Binding { target:JuxtopposedPalette; property:"preferences"; value:MainCtx.generalPreferences }
    Dialogs.JuxtopposedDialogsHost {
        id:host; anchors.fill:parent; mainCtx:MainCtx; dialogsProvider:DialogsProvider
        backdropSource:backdropUnderlay
        appearance:JuxtopposedPalette; assetBase:"file:///C:/Modding/vlc-juxtopposed/build-windows/beta-single-frame-20261025-night/components-r86/host/assets/"; fallbackFocusItem:fallback
        onPlaylistSaved:window.savedNotifications++
        onPlaylistRequested:playlist => window.savedSelection=playlist
    }
}