from pathlib import Path
from hashlib import sha256
import gzip,json
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
out=repo/'doc/juxtopposed-references/native/home-subtitle-attachments-20261026'
assert not out.exists()
ui_names=['ui-attachments-r85','ui-attachments-cold-r85','ui-attachments-r86','ui-attachments-cold-r87']
for name in ui_names:
    record=read(work/name/'verification.json')
    assert record['normalExit'] and not record['forcedCleanupUsed']
    assert all(record[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','producerUnchanged','pluginCacheUnchanged'])
    assert record['moduleCounts']==['602'] and record['diagnostics']==[]
native=read(work/'native-all-r87/verification.json')
assert native['normalExit'] and len(native['functions'])==22
assert all(i['type']=='pass' for f in native['functions'] for i in f['incidents'])
components=read(work/'components-r86/verification.json')
assert components['sourceInputsUnchanged'] and set(components['exitCodes'].values())=={0}
out.mkdir();artifacts=[]
def retain(path,name=None):
    raw=path.read_bytes();target=out/((name or path.relative_to(work).as_posix())+'.gz')
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(raw,mtime=0))
    artifacts.append(dict(path=target.relative_to(out).as_posix(),sha256=digest(target),rawSha256=sha256(raw).hexdigest()))
for folder in ui_names:
    for name in ['verification.json','launch.json']:retain(work/folder/name)
    for pattern in ['*.jpg','*tree.txt']:
        for p in sorted((work/folder).glob(pattern)):retain(p)
for folder in ['native-all-r85','native-all-r87']:
    for name in ['verification.json','results.xml']:retain(work/folder/name)
for p in sorted((work/'components-r86').rglob('*')):
    if p.is_file():retain(p)
for name in ['inputs-r85.json','inputs-r86.json','inputs-r87.json','build-r85.sh','build-r86.sh','build-r87.sh',
             'build-r85-exit.txt','build-r86-exit.txt','build-r87-exit.txt','run-native-attachments-r87.py',
             'run-ui-attachments-r85.py','run-ui-attachments-r86.py','run-ui-attachments-r87.py',
             'run-attachment-components-r85.py','write-attachment-receipt-r89.py']:
    retain(work/name)
manifest=read(work/'inputs-r87.json')
for key in ['modules/gui/qt/maininterface/subtitle_attachment_model.hpp','modules/gui/qt/maininterface/subtitle_attachment_model.cpp',
            'modules/gui/qt/dialogs/dialogs/qml/JuxtopposedSubtitleAttachments.qml','modules/gui/qt/tests/test_player_subtitle_delay.cpp',
            'modules/gui/qt/tests/test_juxtopposed_subtitle_attachments.py','modules/gui/qt/dialogs/dialogs_provider.cpp',
            'modules/gui/qt/dialogs/dialogs/qml/JuxtopposedDialogsHost.qml','modules/gui/qt/maininterface/mainctx.cpp',
            'modules/gui/qt/playlist/playlist_controller.cpp']:
    p=Path(manifest['sourceCopies'][key]);assert digest(p)==manifest['files'][key];retain(p,'sources/'+key)
records={name:read(work/name/'verification.json')['runtimeSha256'] for name in ui_names}
checkpoint=dict(status='scoped-checkpoint-session-continues',fullBetaAccepted=False,runtimes=records,artifacts=artifacts,
    nativeFunctions=22,componentScope='Production attachment QML with supplied state, real pointer drag, actual accessibility names and 130 host checks. Separate from native/ordinary evidence.',
    localImplemented=['Checked file/folder/saved-playlist associations; file > playlist > folder precedence.',
        'Existing stable playlist origins and loaded members, preserving unseen saved mappings on partial-queue edits.',
        'Explicit one-to-one unambiguous filename/episode proposals; manual pair selection and drag; ordered default subtitle.',
        'Standard native picker formats, checked save/retry, corrupt storage readonly, stale-media guards, bounded local storage.',
        'Normal-player attachment restore, default selection, no duplicate submission and missing-file no-fallback controls.'],
    ordinary=['r85: Select two SRTs; Save adds two native tracks, selects first external, renders English while paused; normal Quit.',
        'cold-r85: Both selections restore; playlist disabled for ad hoc queue. Folder Match names leaves ambiguous episode 1 unassigned; explicit Finnish pair and unique episode 2 pair save. File English wins for episode 1; Next renders episode 2. Modal header moves +100,+80.',
        'r86: Scope menu accessibility names corrected, mapping connectors visible. File picker Cancel returns with pairs intact; unsaved folder changes canceled. Create real saved playlist with two generated episodes. A partial one-member playlist edit saves, then Add and play restores both rows. Save second pair without losing first. Playlist English override wins over episode 2 folder mapping; episode 1 file English wins over playlist Finnish.',
        'cold-r87: Copy the normally closed isolated ML database and settings; the saved two-video playlist persists. Actual Add and play restores episode 2 playlist-specific English caption; normal Quit.'],
    limits=['No full S25, W2, visual/DPI/theme, final-package or beta acceptance.',
        'Only generated local media. The Online source currently routes to existing VLSub; the designed in-dialog search/download/error flow is unfinished.',
        'Save persists file choices and queues native loading; readable but undecodable subtitle failure/retry feedback remains unqualified.',
        'Preset/attachment track-selection overlap is being tested separately; no precedence acceptance here.',
        'One initial cold-r87 screenshot was plain red before opening tracks; the subsequent paused tracks capture rendered the attachment. Immediate first presentation needs a controlled recheck; it is not accepted from this run.',
        'Clearing a mapping affects future attachment/default choices and does not unload tracks already present in the current input.',
        'Partial playlist scope edits expose members currently loaded with that saved origin; unqueued members are preserved but not listed.'])
(out/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Local subtitle attachments - 26 October 2026

The ordinary Add Subtitles dialog now has file, folder and saved-playlist scope,
local file/folder pickers, manual pairs, pointer drag, unambiguous Match names,
checked persistence and ordered default selection. It uses the original four
[Figma references](../../figma/20261026/subtitle-attachments/README.md) and artwork.
The online search/download design remains unfinished.

Twenty-two native functions pass, including five attachment functions covering
scope/restart, ambiguity, standard picker format discovery, blocked-write retry,
corrupt storage and actual paused native attachment/default/fresh-input restore.
The component checks separately exercise production QML with supplied state,
actual pointer drag, accessible choice names, short-window errors and 130 host
checks. They do not establish ordinary desktop or native behavior.

Ordinary runs save two local SRTs and render the chosen external caption without
advancing the paused clock. Restart restores choices. Folder matching leaves
ambiguous language variants unselected; manual pairs and the next episode work.
Actual native playlist creation and Add and play establish saved playlist origin,
both loaded media rows, partial-edit preservation and file > playlist > folder
precedence. Cold reopening retains the playlist-specific choice. All four runs
exit normally with unchanged guards, 602 modules and no reported diagnostics.
The dialog moves by its header; connector visibility and choice names were fixed.

[checkpoint.json](checkpoint.json) binds original compressed artifacts and exact
source/runtime identities. It records limits, including pending asynchronous
decode-error feedback, preset interaction, the initial cold presentation recheck,
and loaded-member scope. No full surface, visual, final-package or beta gate is
closed. Continue using [STATUS](../../../juxtopposed/STATUS.md).
''',encoding='utf-8',newline='\n')
print(str(out),len(artifacts),flush=True)
