from pathlib import Path
from hashlib import sha256
import json, subprocess, sys

work = Path(__file__).resolve().parent
repo = work.parents[1]
revision, label, mode = sys.argv[1:]
digest = lambda p: sha256(p.read_bytes()).hexdigest()
inputs = json.loads((work / f'inputs-{revision}.json').read_text(encoding='utf-8'))
assert all(digest(repo / p) == h for p, h in inputs['files'].items())
out = work / label
assert not out.exists()
out.mkdir()
names = ['test_juxtopposed_settings.py']
if mode == 'all': names.append('test_juxtopposed_subtitle_presets.py')
codes = {}
for name in names:
    with (out / (name + '.stdout.txt')).open('wb') as stdout, (out / (name + '.stderr.txt')).open('wb') as stderr:
        command = [sys.executable, str(repo / 'modules/gui/qt/tests' / name), '--output-dir', str(out / name.removesuffix('.py'))]
        child = subprocess.Popen(command, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
        print(name, 'PID', child.pid, flush=True)
        codes[name] = child.wait(timeout=120)
record = dict(exitCodes=codes, sourceInputsUnchanged=all(digest(repo / p) == h for p, h in inputs['files'].items()),
              sourceManifestSha256=digest(work / f'inputs-{revision}.json'), suppliedStateComponent=True, fullBetaAccepted=False)
(out / 'verification.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(record), flush=True)
assert record['sourceInputsUnchanged']
if any(codes.values()): raise SystemExit(1)
