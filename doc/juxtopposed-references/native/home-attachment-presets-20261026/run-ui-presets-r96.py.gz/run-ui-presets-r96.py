from pathlib import Path
from hashlib import sha256
import ctypes,json,re,shutil,subprocess,sys
work=Path(__file__).resolve().parent
repo=work.parents[1]
revision,label,previous,rate,association=sys.argv[1:]; assert float(rate) in [0.5,1.0,1.5,2.0] and association in ["baseline","no-associated","software","software-no-associated","dummy-display","direct3d9","dummy-audio","ignore-config","normal-fps","attachments"]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
manifest=work/f'inputs-{revision}.json';inputs=read(manifest)
assert all(digest(repo/p)==h and digest(Path(inputs['sourceCopies'][p]))==h for p,h in inputs['files'].items())
prior=repo/'build-windows/beta-subtitle-sync-20261025'
base=prior/'ui-r1/runtime'
expected=read(prior/'ui-r1/verification.json')['runtimeSha256']
assert all(digest(base/p)==h for p,h in expected.items())
out=work/label;assert not out.exists();out.mkdir()
shutil.copyfile(Path(__file__),out/'producer.py')
(out/'app-snapshots').mkdir()
sys.path.insert(0,str(repo/'test/libvlc'))
from native_http_runtime import stage_runtime,environment
runtime=out/'runtime';stage_runtime(base,runtime)
for relative,source in [('libvlccore.dll',work/'core-r72-bin/libvlccore.dll'),
                        ('plugins/audio_output/libwasapi_plugin.dll',prior/'wasapi-r15-bin/libwasapi_plugin.dll'),
                        ('plugins/gui/libqt_plugin.dll',work/'ordinary-r96-bin/libqt_plugin.dll')]:
    target=runtime/relative;target.unlink();shutil.copyfile(source,target)
identities={p:digest(runtime/p) for p in expected}
media=work/'attachment-media-r85'
fixtures={p.name:digest(p) for p in media.iterdir() if p.is_file()}
extra=repo/'build-windows/beta-external-subtitle-acceptance-20261023/media-r1'
extra_fixtures={p.name:digest(p) for p in extra.iterdir() if p.is_file()}
config=out/'vlcrc'
if previous!='fresh':
    assert read(work/previous/'verification.json')['normalExit']
    shutil.copyfile(work/previous/'config-after.txt',config)
else:
    config.write_text('metadata-network-access=0\nml-network-discovery=0\none-instance=0\nqt-updates-notif=0\nqt-auto-raise=0\nqt-remember-window-geometry=0\nqt-controls-auto-hide=0\nqt-timeline-thumbnails=0\nsub-autodetect-file=0\nsub-language=eng\nsub-track=-1\nsub-track-id=\nsub-delay=0\nsub-fps=23.976\n',encoding='utf-8',newline='\n')
shutil.copyfile(config,out/'config-before.txt')
ini=runtime/'portable/vlc/vlc-qt-interface.ini';ini.parent.mkdir(parents=True,exist_ok=True)
ini.write_text('[General]\ngraphics-api=4\nfiledialog-path='+media.as_uri()+'\n[MainWindow]\ncolor-scheme-index=2\ninterface-scale=1\nplayqueue-panel-docked=true\n',encoding='utf-8',newline='\n')
if previous!='fresh':
    old=work/previous/'runtime/portable/vlc/vlc-qt-interface.ini'
    assert old.is_file()
    ini.unlink();shutil.copyfile(old,ini)
if previous!='fresh':
    oldml=work/previous/'userdata/ml'
    if oldml.is_dir():
        shutil.copytree(oldml,out/'userdata/ml')
        write(out/'ml-copy.json',{p.name:digest(p) for p in oldml.iterdir() if p.is_file()})
shutil.copyfile(ini,out/'settings-before.ini')
cacheout=out/'cache';cacheout.mkdir()
cacheenv=environment(runtime,cacheout);cacheenv.pop('VLC_PLUGIN_PATH',None)
with (cacheout/'stdout.txt').open('wb') as stdout,(cacheout/'stderr.txt').open('wb') as stderr:
    cache=subprocess.Popen([str(runtime/'vlc-cache-gen.exe'),str(runtime/'plugins')],
      cwd=runtime,env=cacheenv,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    write(cacheout/'process.json',dict(status='running',pid=cache.pid))
    try:cachecode=cache.wait(timeout=60)
    except subprocess.TimeoutExpired:raise SystemExit('Inspect cache PID; no automatic cleanup/restart')
write(cacheout/'process.json',dict(status='terminal',exitCode=cachecode,normalExit=cachecode==0))
assert cachecode==0 and (runtime/'plugins/plugins.dat').exists()
cachehash=digest(runtime/'plugins/plugins.dat')
command=[str(runtime/'vlc.exe'),'--intf=qt','--no-one-instance','--no-media-library',
 '--no-crashdump','--no-qt-privacy-ask','--no-qt-updates-notif','--no-metadata-network-access',
 '--no-ml-network-discovery','--config='+str(config),'--file-logging','--log-verbose=2',
 '--verbose=2','--logfile='+str(out/'vlc.log'),'--restore-playback-pos=0',
 '--snapshot-path='+str(out/'app-snapshots'),'--snapshot-format=png','--start-paused',
 '--fullscreen','--rate='+rate,'--sub-file='+str(media/'external-fps.srt'),str(media/'Show.S01E01.mp4'),str(media/'Show.S01E02.mp4')]
if association in ['no-associated','software-no-associated']: command=[p for p in command if not p.startswith('--sub-file=')]
if association in ['software','software-no-associated']: command.append('--no-hw-dec')
if association=='dummy-display': command+=['--vout=vdummy','--no-hw-dec']
if association=='direct3d9': command+=['--vout=direct3d9','--no-hw-dec']
if association=='dummy-audio': command+=['--aout=adummy']
if association=='ignore-config': command+=['--ignore-config']
if association in ['normal-fps','attachments']: command+=['--sub-fps=0']
if association=='attachments':
    command=[p for p in command if not p.startswith('--sub-file=') and p!='--no-media-library']
    command+=['--media-library']
write(out/'launch.json',command)
record=dict(status='starting',privateCore=False,privateGui=False,fullBetaAccepted=False,
 forcedCleanupUsed=False,sourceManifestSha256=digest(manifest),sourceInputCount=len(inputs['files']),
 producerSha256=digest(Path(__file__)),runtimeSha256=identities,fixtureSha256=fixtures,extraFixtureSha256=extra_fixtures,
 pluginCacheSha256=cachehash,scope='Ordinary attachment file/folder/playlist, default selection and cold persistence. Generated fixtures only; actual Computer Use observations required.')
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.SetErrorMode.argtypes=[ctypes.c_uint];kernel.SetErrorMode.restype=ctypes.c_uint
previousMode=kernel.SetErrorMode(0x8003)
env=environment(runtime,out);env.pop('VLC_PLUGIN_PATH',None)
try:
    with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=runtime,env=env,stdout=stdout,stderr=stderr,
                               creationflags=subprocess.CREATE_NO_WINDOW)
        record.update(status='running',pid=child.pid);write(out/'verification.json',record)
        print('Owned ordinary GUI',label,'PID',child.pid,flush=True)
        try:record['exitCode']=child.wait(timeout=1800)
        except subprocess.TimeoutExpired:
            record.update(status='observation-timeout-process-left-running');write(out/'verification.json',record)
            raise SystemExit('Inspect owned PID; no automatic cleanup/restart')
finally:kernel.SetErrorMode(previousMode)
shutil.copyfile(config,out/'config-after.txt')
shutil.copyfile(ini,out/'settings-after.ini')
logs='\n'.join((out/p).read_text(encoding='utf-8',errors='replace') for p in ['vlc.log','stderr.txt'])
record.update(status='terminal',normalExit=record['exitCode']==0,
 sourceInputsUnchanged=all(digest(repo/p)==h for p,h in inputs['files'].items()),
 runtimeUnchanged=all(digest(base/p)==h and digest(runtime/p)==identities[p] for p,h in expected.items()),
 fixturesUnchanged=all(digest(media/p)==h for p,h in fixtures.items()),
 extraFixturesUnchanged=all(digest(extra/p)==h for p,h in extra_fixtures.items()),
 producerUnchanged=digest(Path(__file__))==record['producerSha256'],
 pluginCacheUnchanged=digest(runtime/'plugins/plugins.dat')==cachehash,
 moduleCounts=re.findall(r'plug-ins loaded: (\d+) modules',logs),
 diagnostics=[line for line in logs.splitlines() if re.search(r'\berror:|Assertion failed|Binding loop|ReferenceError|TypeError',line)])
write(out/'verification.json',record)
print(json.dumps({k:record[k] for k in ['status','pid','exitCode','normalExit','sourceInputsUnchanged','runtimeUnchanged','fixturesUnchanged','pluginCacheUnchanged','moduleCounts','diagnostics']}),flush=True)
