from pathlib import Path
from hashlib import sha256
import gzip, json

work = Path(__file__).resolve().parent
repo = work.parents[1]
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda p: sha256(p.read_bytes()).hexdigest()
out = repo / 'doc/juxtopposed-references/native/home-attachment-presets-20261026'
assert not out.exists()
native = read(work / 'native-all-r94/verification.json')
assert native['normalExit'] and native['sourceInputsUnchanged'] and len(native['functions']) == 23
assert all(i['type'] == 'pass' for f in native['functions'] for i in f['incidents'])
uis = {name: read(work / name / 'verification.json') for name in ['ui-presets-r94', 'ui-presets-cold-r94', 'ui-presets-r96']}
for ui in uis.values():
    assert ui['normalExit'] and not ui['diagnostics']
    assert all(ui[key] for key in ['sourceInputsUnchanged', 'runtimeUnchanged', 'fixturesUnchanged', 'pluginCacheUnchanged'])
components = read(work / 'preset-components-r96/verification.json')
assert components['sourceInputsUnchanged'] and not any(components['exitCodes'].values())
assert read(work / 'preset-viewport-before-r95-frozen/verification.json')['exitCodes']['test_juxtopposed_settings.py'] == 1
out.mkdir()
artifacts = []
def retain(path, name=None):
    raw = path.read_bytes()
    target = out / ((name or path.relative_to(work).as_posix()) + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(raw, mtime=0))
    artifacts.append(dict(path=target.relative_to(out).as_posix(), sha256=digest(target), rawSha256=sha256(raw).hexdigest()))

for folder in ['integration-before-r89', 'integration-after-r90', 'integration-next-media-r91',
               'integration-stale-context-r92', 'integration-isolated-r93', 'native-all-r93', 'native-all-r94']:
    for name in ['verification.json', 'results.xml']: retain(work / folder / name)
for folder in uis:
    for name in ['verification.json', 'launch.json']: retain(work / folder / name)
    for pattern in ['*.jpg', '*tree.txt']:
        for path in sorted((work / folder).glob(pattern)): retain(path)
for folder in ['preset-viewport-before-r95-frozen', 'preset-components-r96']:
    retain(work / folder / 'verification.json')
    for pattern in ['*.stdout.txt', '*.stderr.txt']:
        for path in sorted((work / folder).glob(pattern)): retain(path)
for path in sorted((work / 'preset-components-r96/test_juxtopposed_settings').glob('preset-naming-visible-*.png')): retain(path)
for name in ['inputs-r89.json', 'inputs-r92.json', 'inputs-r94.json', 'inputs-r95.json', 'inputs-r96.json',
             'build-r93.sh', 'build-r93-exit.txt', 'build-r94.sh', 'build-r94-exit.txt', 'build-r96.sh', 'build-r96-exit.txt',
             'run-native-attachments-r88.py', 'run-ui-attachments-r93.py', 'run-ui-presets-r96.py',
             'run-preset-components-r95.py', 'write-preset-receipt-r97.py']:
    retain(work / name)
keys = ['maininterface/subtitle_attachment_model.hpp', 'maininterface/subtitle_attachment_model.cpp',
        'maininterface/subtitle_preset_model.hpp', 'maininterface/subtitle_preset_model.cpp',
        'maininterface/mainctx.cpp', 'player/qml/JuxtopposedSubtitlePresets.qml',
        'tests/test_player_subtitle_delay.cpp', 'tests/test_juxtopposed_settings.py']
for revision in ['r89', 'r92', 'r94', 'r95', 'r96']:
    manifest = read(work / f'inputs-{revision}.json')
    for suffix in keys:
        key = 'modules/gui/qt/' + suffix
        source = Path(manifest['sourceCopies'][key])
        assert digest(source) == manifest['files'][key]
        retain(source, f'sources/{revision}/{key}')
record = dict(status='scoped-checkpoint-session-continues', fullBetaAccepted=False,
    runtimeSha256=uis['ui-presets-r96']['runtimeSha256'], nativeFunctions=23, artifacts=artifacts,
    before='Both service-construction orders fail initial saved-track restore in r89. Both fail the forced stale-Qt-cache next-input control in r92.',
    after='Saved exact native external-track IDs wait for the associated tracks. Automatic attachment restore defers selection to the current media preset; explicit attachment Save still selects its default. Target-media lookup avoids using the preceding cached input.',
    testSetup='The initial r93 full run retains one failed production-order row, although isolated rows pass. r94 waits for Default restore to finish before manual capture and asserts actual native category delay/FPS before save; production code is unchanged from r93. The full r94 run passes all 23 functions.',
    ordinary='Save Finnish external track with -0.375s category delay and 30fps. Duplicate name retains draft/error; renamed retry succeeds. Default resets delay/FPS; named reapply and cold restart restore values and track. Next media uses its own episode-two attachment. Three ordinary runs exit normally with 602 modules, unchanged guards and no diagnostics.',
    naming='Before control fails the production popup viewport bound. After reflow correction, editor plus Cancel/Save fit normal, short, 150% and 200% component layouts with focus retained. Actual ordinary popup shows all three without further scrolling; typed draft Cancel preserves selected preset and paused clock.',
    startupObservation='Earlier occluded first captures are retained. In r96, explicit target-window activation followed by the initial capture shows the Finnish caption at unchanged paused 0.08s without Play/seek; this qualifies that ordinary run, not every startup configuration.',
    limits=['Supplied-state layouts do not establish Windows OS DPI acceptance.',
            'Readable-but-undecodable attachment feedback/retry and the designed online flow remain open.',
            'Native fixture and ordinary GUI have separate identities; no complete W1/W2/visual/final-package/beta acceptance.'])
(out / 'checkpoint.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
(out / 'README.md').write_text('''# Attachment and preset integration - 26 October 2026

Core `883f7e51` / ordinary GUI `b2a96829` is the selected scoped runtime.
Twenty-three native functions pass, including both construction orders and a
next-input control that deliberately keeps the preceding Qt preset cache alive.
Earlier failures are preserved. Attachments load the saved files; automatic
selection follows this media's saved preset, while explicit attachment Save
chooses its current default. Saved native track identities wait for their tracks.

The initial r93 full run had one failed row while isolated rows passed. The r94
fixture waits for Default restore to settle before editing/capture, then asserts
actual native delay/FPS before saving. Production code is unchanged between those
two native runs. Both results and source snapshots are retained; this fixture
correction is distinct from the production integration repairs.

Ordinary save, duplicate-name retry, Default, named reapply, cold restart and
next-source attachment selection pass on the recorded tuples. Finnish track,
-0.375-second category delay and 30 fps return after restart. The next episode
uses its own attachment and zero delay. Normal exits preserve all guards, load
602 modules and report no diagnostics. Only generated media was used.

The production preset naming form now reveals its name and Cancel/Save actions
after expansion. A failing before viewport check and passing normal/short/150%/
200% supplied-state layouts are retained. Actual ordinary entry and Cancel keep
the saved preset and paused clock. These component scales are not OS DPI tests.

Earlier occluded first captures remain evidence. Explicit activation before the
r96 initial capture shows the Finnish caption at the unchanged paused 0.08-second
position without Play or seeking. This qualifies that run, not all startup cases.

[checkpoint.json](checkpoint.json) binds exact identities and original gzip
artifacts. The [preceding local attachment receipt](../home-subtitle-attachments-20261026/README.md)
retains its separate scope. Readable-but-undecodable subtitle feedback, online
search, remaining timing combinations and the beta gates are unfinished.
Continue from [STATUS](../../../juxtopposed/STATUS.md).
''', encoding='utf-8', newline='\n')
print(str(out), len(artifacts), flush=True)
