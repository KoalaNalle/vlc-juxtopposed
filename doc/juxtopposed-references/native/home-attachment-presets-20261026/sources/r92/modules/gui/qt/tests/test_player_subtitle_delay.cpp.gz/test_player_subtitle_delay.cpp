// SPDX-License-Identifier: GPL-2.0-or-later
// Copyright (C) 2026 VLC authors and VideoLAN
// Exercise the actual PlayerController and its queued production callbacks.
// VLCTestingEnv supplies the native main-playlist NORMAL-lock player; only
// unrelated interface/discovery modules use the existing test infrastructure.
#ifdef HAVE_CONFIG_H
# include "config.h"
#endif
#include "vlc_stub_modules.hpp"
#include "player/player_controller.hpp"
#include "player/delay_estimator.hpp"
#include "player/subtitle_appearance.hpp"
#include "maininterface/subtitle_preset_model.hpp"
#include "maininterface/subtitle_attachment_model.hpp"
#include <vlc_input_item.h>
#include <vlc_vout.h>
#include <QDir>
#include <QCryptographicHash>
#include <QElapsedTimer>
#include <QFileInfo>
#include <QFile>
#include <QImage>
#include <QQmlComponent>
#include <QQmlContext>
#include <QQmlEngine>
#include <QQmlExtensionPlugin>
#include <QSettings>
#include <QSignalSpy>
#include <QTemporaryDir>
#include <QTest>
#include <QThread>
#include <limits>

#ifdef QT_STATIC
Q_IMPORT_QML_PLUGIN(QtQmlPlugin)
Q_IMPORT_QML_PLUGIN(QtQmlModelsPlugin)
Q_IMPORT_QML_PLUGIN(QtQmlWorkerScriptPlugin)
#endif

using HeldEs = vlc::vlc_shared_data_ptr<vlc_es_id_t, &vlc_es_id_Hold, &vlc_es_id_Release>;

class TestPlayerSubtitleDelay : public QObject
{
    Q_OBJECT
    std::unique_ptr<VLCTestingEnv> m_environment;
    std::unique_ptr<PlayerController> m_controller;
    std::unique_ptr<SubtitlePresetModel> m_presets;
    std::unique_ptr<QSettings> m_settings;
    QTemporaryDir m_directory;
    vlc_player_t *m_player = nullptr;
    HeldEs m_first, m_second;
    QString m_fixture;
    int m_observations = 0;
    int m_fpsObservations = 0;

    static unsigned frameMarker(const QImage &image)
    {
        unsigned value = 0;
        for (unsigned bit = 0; bit < 11; ++bit)
            if (image.pixelColor(32 + 64 * bit, 20).red() > 128)
                value |= 1u << bit;
        return value;
    }

    QPair<vlc_es_id_t *, vlc_es_id_t *> roles() const
    {
        QPair<vlc_es_id_t *, vlc_es_id_t *> result;
        vlc_player_locker lock{m_player};
        for (size_t i = 0; i < vlc_player_GetTrackCount(m_player, SPU_ES); ++i)
        {
            const auto *track = vlc_player_GetTrackAt(m_player, SPU_ES, i);
            if (!track->selected) continue;
            vlc_vout_order order = VLC_VOUT_ORDER_NONE;
            vlc_player_GetEsIdVout(m_player, track->es_id, &order);
            if (order == VLC_VOUT_ORDER_PRIMARY) result.first = track->es_id;
            if (order == VLC_VOUT_ORDER_SECONDARY) result.second = track->es_id;
        }
        return result;
    }
    unsigned select(vlc_es_id_t *primary, vlc_es_id_t *secondary = nullptr)
    {
        // Native EsOutSelectList skips already selected IDs; merely reversing
        // them cannot change their output roles. Clear real selection first.
        {
            vlc_player_locker lock{m_player};
            vlc_player_UnselectTrackCategory(m_player, SPU_ES);
        }
        if (!waitNativeRoles(nullptr, nullptr)) return unsigned(-1);
        // Renderer channels are allocated when the first cue is decoded, not
        // in request-list order. Establish the first real output before adding
        // the other one so this fixture has deliberate primary/secondary roles.
        vlc_es_id_t *ids[] = {primary, nullptr, nullptr};
        {
            vlc_player_locker lock{m_player};
            if (vlc_player_SelectEsIdList(m_player, SPU_ES, ids) != 1)
                return unsigned(-1);
            vlc_player_SetTime(m_player, VLC_TICK_FROM_MS(1500));
        }
        QElapsedTimer deadline; deadline.start();
        bool outputReady = false;
        while (deadline.elapsed() < 5000)
        {
            {
                vlc_player_locker lock{m_player};
                outputReady = vlc_player_GetEsIdVout(m_player, primary, nullptr);
            }
            if (outputReady) break;
            QThread::msleep(10);
        }
        if (!outputReady) return unsigned(-1);
        if (!secondary) return 1;
        ids[1] = secondary;
        vlc_player_locker lock{m_player};
        const auto selected = vlc_player_SelectEsIdList(m_player, SPU_ES, ids);
        // The short second SRT must have a real cue while the video is paused.
        // These native waits/seeks do not dispatch queued QObject callbacks.
        vlc_player_SetTime(m_player, VLC_TICK_FROM_MS(1500));
        return selected;
    }
    // Deliberately do not dispatch GUI events: the setter must read the current
    // native role while the controller's queued role cache is still old.
    bool waitNativeRoles(vlc_es_id_t *primary, vlc_es_id_t *secondary)
    {
        QElapsedTimer deadline; deadline.start();
        while (deadline.elapsed() < 5000)
        {
            if (roles() == qMakePair(primary, secondary)) return true;
            QThread::msleep(10);
        }
        return false;
    }
    vlc_tick_t own(vlc_es_id_t *id) const
    {
        vlc_player_locker lock{m_player};
        return vlc_player_GetEsIdDelay(m_player, id);
    }
    vlc_tick_t category() const
    {
        vlc_player_locker lock{m_player};
        return vlc_player_GetSubtitleDelay(m_player);
    }
    int setOwn(vlc_es_id_t *id, vlc_tick_t delay)
    {
        vlc_player_locker lock{m_player};
        return vlc_player_SetEsIdDelay(m_player, id, delay, VLC_PLAYER_WHENCE_ABSOLUTE);
    }
    void setCategory(vlc_tick_t delay)
    {
        vlc_player_locker lock{m_player};
        vlc_player_SetSubtitleDelay(m_player, delay, VLC_PLAYER_WHENCE_ABSOLUTE);
    }
    void observeAfterUnlock(VLCDuration)
    {
        QCOMPARE(QThread::currentThread(), m_controller->thread());
        // This direct QObject observer re-locks the actual NORMAL player.
        // Notification under the native lock deadlocks and the external test
        // runner's finite deadline reports failure, rather than a false pass.
        (void)m_controller->getInput();
        ++m_observations;
    }
private slots:
    void initTestCase()
    {
        m_fixture = qEnvironmentVariable("VLC_SUBTITLE_FIXTURE");
        if (m_fixture.isEmpty())
            QSKIP("Set VLC_SUBTITLE_FIXTURE to run the actual native controller diagnostic");
        QVERIFY2(QFileInfo::exists(m_fixture), "Use the real generated subtitle-style.mp4");
        const QDir fixtures(QFileInfo(m_fixture).absolutePath());
        QVERIFY(fixtures.exists("subtitle-style.srt"));
        QVERIFY(fixtures.exists("duration-cues.srt"));
        QVERIFY(m_directory.isValid());
        qputenv("VLC_TEST_TIMEOUT", "30");
        qRegisterMetaType<VLCDuration>();
        m_environment = std::make_unique<VLCTestingEnv>();
        QVERIFY(m_environment->init(true));
        m_player = m_environment->intf->p_player;
        QVERIFY(m_player);
        m_settings = std::make_unique<QSettings>(m_directory.filePath("settings.ini"), QSettings::IniFormat);
        m_environment->intf->mainSettings = m_settings.get();
        m_environment->intf->p_mi = nullptr;
        m_environment->intf->p_mainPlaylistController = nullptr;
        // The existing stub defaults to a dummy text renderer. Use production
        // Freetype so Default applies through the actual SubtitlePresetModel.
        {
            vlc_player_locker lock{m_player};
            // PlayerController's production variable proxies use this native
            // object view too; the public player type is opaque in C++.
            auto *playerObject = reinterpret_cast<vlc_object_t *>(m_player);
            var_Create(playerObject, "text-renderer", VLC_VAR_STRING);
            QCOMPARE(var_SetString(playerObject, "text-renderer", "freetype"), VLC_SUCCESS);
            var_Create(playerObject, "sub-autodetect-file", VLC_VAR_BOOL);
            QCOMPARE(var_SetBool(playerObject, "sub-autodetect-file", false), VLC_SUCCESS);
        }
        var_Create(m_environment->intf, "sub-delay", VLC_VAR_INTEGER);
        var_SetInteger(m_environment->intf, "sub-delay", 0);
        var_Create(m_environment->intf, "sub-fps", VLC_VAR_FLOAT);
        var_SetFloat(m_environment->intf, "sub-fps", 0.f);
        m_controller = std::make_unique<PlayerController>(m_environment->intf);
        m_environment->intf->p_mainPlayerController = m_controller.get();
        connect(m_controller.get(), &PlayerController::subtitleDelayChanged, this,
                &TestPlayerSubtitleDelay::observeAfterUnlock, Qt::DirectConnection);
        connect(m_controller.get(), &PlayerController::secondarySubtitleDelayChanged, this,
                &TestPlayerSubtitleDelay::observeAfterUnlock, Qt::DirectConnection);
        m_presets = std::make_unique<SubtitlePresetModel>(m_player, m_controller->getSubtitleAppearance(),
                m_settings.get(), VLC_OBJECT(m_environment->intf));
        const auto uri = QUrl::fromLocalFile(m_fixture).toEncoded();
        auto *item = input_item_New(uri.constData(), "Native controller subtitle fixture");
        QVERIFY(item);
        int configured, started;
        {
            vlc_player_locker lock{m_player};
            configured = vlc_player_SetCurrentMedia(m_player, item);
            started = configured == VLC_SUCCESS ? vlc_player_Start(m_player) : VLC_EGENERIC;
        }
        input_item_Release(item);
        QCOMPARE(configured, VLC_SUCCESS);
        QCOMPARE(started, VLC_SUCCESS);
        QTRY_VERIFY_WITH_TIMEOUT(m_controller->hasVideoOutput(), 10000);
        for (const auto &name : {"subtitle-style.srt", "duration-cues.srt"})
        {
            const auto subtitle = QUrl::fromLocalFile(fixtures.filePath(name)).toEncoded();
            vlc_player_locker lock{m_player};
            QCOMPARE(vlc_player_AddAssociatedMedia(m_player, SPU_ES, subtitle.constData(), true, false, true), VLC_SUCCESS);
        }
        // A media may already contain two embedded tracks. Wait for the actual
        // associated sources instead of mistaking those initial rows for SRTs.
        auto findAssociated = [this, &fixtures](const QString &name, HeldEs &id) {
            if (id) return true;
            const auto uri = QUrl::fromLocalFile(fixtures.filePath(name)).toEncoded();
            const QByteArray prefix = QCryptographicHash::hash(uri, QCryptographicHash::Md5).toHex() + '/';
            vlc_player_locker lock{m_player};
            for (size_t i = 0; i < vlc_player_GetTrackCount(m_player, SPU_ES); ++i) {
                auto *es = vlc_player_GetTrackAt(m_player, SPU_ES, i)->es_id;
                if (QByteArray(vlc_es_id_GetStrId(es)).startsWith(prefix)) {
                    id.reset(es);
                    return true;
                }
            }
            return false;
        };
        QTRY_VERIFY_WITH_TIMEOUT(findAssociated("subtitle-style.srt", m_first), 10000);
        QTRY_VERIFY_WITH_TIMEOUT(findAssociated("duration-cues.srt", m_second), 10000);
        QVERIFY(m_first != m_second);
        QCOMPARE(select(m_first.get(), m_second.get()), 2u);
        QTRY_VERIFY_WITH_TIMEOUT(roles() == qMakePair(m_first.get(), m_second.get()), 5000);
        QTRY_VERIFY_WITH_TIMEOUT(m_controller->getSubtitleAppearance()->available(), 10000);
        QTRY_VERIFY_WITH_TIMEOUT(m_presets->canApply(), 5000);
        {
            vlc_player_locker lock{m_player};
            vlc_player_Pause(m_player);
        }
        QTRY_COMPARE_WITH_TIMEOUT(m_controller->getPlayingState(), PlayerController::PLAYING_STATE_PAUSED, 5000);
    }
    void initialAssociatedFpsMatchesNative()
    {
        vlc_player_locker lock{m_player};
        const auto fps = vlc_player_GetAssociatedSubsFPS(m_player);
        QCOMPARE(fps, 0.f); // the generated fixture inherits the native default
        QCOMPARE(m_controller->getSubtitleFPS(), fps);
    }
    void associatedFpsRetimesHeldCaption()
    {
        const auto directory = qEnvironmentVariable("VLC_FPS_SNAPSHOTS");
        if (directory.isEmpty())
            QSKIP("Set VLC_FPS_SNAPSHOTS and use the 60-second frame-marker fixture");
        QVERIFY(QDir(directory).exists());
        QCOMPARE(select(m_first.get()), 1u);
        QTRY_VERIFY(roles() == qMakePair(m_first.get(), static_cast<vlc_es_id_t *>(nullptr)));
        m_controller->setSubtitleFPS(0.f);
        QTRY_COMPARE(m_controller->getSubtitleFPS(), 0.f);

        auto seek = [this](vlc_tick_t time) {
            vlc_player_locker lock{m_player};
            vlc_player_SetTime(m_player, time);
        };
        auto time = [this] {
            vlc_player_locker lock{m_player};
            return vlc_player_GetTime(m_player);
        };
        auto snapshot = [this, &directory](const QString &name) {
            const auto path = QDir(directory).filePath(name + ".png");
            vout_thread_t *output;
            {
                vlc_player_locker lock{m_player};
                output = vlc_player_vout_Hold(m_player);
            }
            if (!output) return QImage();
            var_Create(output, "snapshot-width", VLC_VAR_INTEGER);
            var_SetInteger(output, "snapshot-width", 960);
            var_Create(output, "snapshot-height", VLC_VAR_INTEGER);
            var_SetInteger(output, "snapshot-height", 540);
            var_Create(output, "snapshot-path", VLC_VAR_STRING);
            var_SetString(output, "snapshot-path", qtu(path));
            var_Create(output, "snapshot-format", VLC_VAR_STRING);
            var_SetString(output, "snapshot-format", "png");
            var_TriggerCallback(output, "video-snapshot");
            vout_Release(output);
            QImage image;
            for (int i = 0; i < 100 && image.isNull(); ++i) {
                QTest::qWait(20);
                image.load(path);
            }
            return image.convertToFormat(QImage::Format_RGBA8888);
        };
        auto captionMask = [](const QImage &image) {
            QByteArray mask;
            for (int y = image.height() * 3 / 4; y < image.height(); ++y)
                for (int x = 0; x < image.width(); ++x) {
                    const auto c = image.pixelColor(x, y);
                    mask.append(char(c.red() > 160 && c.green() > 160 && c.blue() > 160));
                }
            return mask;
        };
        auto captionMatches = [](const QByteArray &actual, const QByteArray &reference) {
            if (actual.size() != reference.size()) return false;
            qsizetype intersection = 0, united = 0;
            for (qsizetype i = 0; i < actual.size(); ++i) {
                intersection += actual[i] && reference[i];
                united += actual[i] || reference[i];
            }
            // Reference cues sit over different marker colors. Their five
            // threshold-edge antialias pixels differ; the wrong cue differs
            // by thousands. Keep 99.5% overlap and exact held-video matching.
            return united > 100 && intersection * 1000 >= united * 995;
        };
        seek(VLC_TICK_FROM_SEC(24));
        QTest::qWait(700);
        const auto middle = snapshot("normal-middle-reference");
        QVERIFY(!middle.isNull());
        seek(VLC_TICK_FROM_SEC(12));
        QTest::qWait(700);
        const auto first = snapshot("normal-first-reference");
        QVERIFY(!first.isNull());
        const auto firstMask = captionMask(first), middleMask = captionMask(middle);
        QVERIFY(firstMask.count(char(1)) > 100);
        QVERIFY(middleMask.count(char(1)) > 100);
        QVERIFY(firstMask != middleMask);
        QCOMPARE(frameMarker(first), 300u);
        QCOMPARE(frameMarker(middle), 600u);
        const auto heldTime = time();
        // A paused timer may retain its previous playing point after a seek.
        // The decoded marker proves the landed frame; edits must preserve both
        // that exact picture and the timer's held value independently.
        const auto picture = first.copy(0, 0, first.width(), first.height() * 3 / 4);
        bool captionsMatch = true, picturesMatch = true, positionsMatch = true;
        for (const auto fps : {50.f, 29.97f, 23.976f, 0.f}) {
            m_controller->setSubtitleFPS(fps);
            QTRY_COMPARE(m_controller->getSubtitleFPS(), fps);
            QTest::qWait(700);
            const auto image = snapshot(QString("live-%1").arg(fps, 0, 'f', 3));
            QVERIFY(!image.isNull());
            const bool caption = captionMatches(captionMask(image), fps == 50.f ? middleMask : firstMask);
            const bool frame = image.copy(0, 0, image.width(), image.height() * 3 / 4) == picture;
            const bool position = qAbs(time() - heldTime) < VLC_TICK_FROM_MS(50);
            qInfo("FPS %.3f caption=%d heldFrame=%d heldTime=%d time=%lld", double(fps),
                  caption, frame, position, static_cast<long long>(time()));
            captionsMatch &= caption; picturesMatch &= frame; positionsMatch &= position;
        }
        m_controller->setSubtitleFPS(50.f);
        QTRY_COMPARE(m_controller->getSubtitleFPS(), 50.f);
        QTest::qWait(300);
        seek(VLC_TICK_FROM_SEC(12));
        QTest::qWait(700);
        const auto reseek = snapshot("seek-with-fps-50");
        QVERIFY(!reseek.isNull());
        captionsMatch &= captionMatches(captionMask(reseek), middleMask);
        picturesMatch &= reseek.copy(0, 0, reseek.width(), reseek.height() * 3 / 4) == picture;
        positionsMatch &= qAbs(time() - heldTime) < VLC_TICK_FROM_MS(50);
        m_controller->setSubtitleFPS(0.f);
        QTRY_COMPARE(m_controller->getSubtitleFPS(), 0.f);
        QTest::qWait(700);
        const auto reset = snapshot("reset-after-fps-seek");
        QVERIFY(!reset.isNull());
        captionsMatch &= captionMatches(captionMask(reset), firstMask);
        picturesMatch &= reset.copy(0, 0, reset.width(), reset.height() * 3 / 4) == picture;
        positionsMatch &= qAbs(time() - heldTime) < VLC_TICK_FROM_MS(50);
        QCOMPARE(select(m_first.get(), m_second.get()), 2u);
        QTRY_VERIFY(roles() == qMakePair(m_first.get(), m_second.get()));
        QVERIFY2(captionsMatch, "Live FPS/reset must update the held external cue without a user seek");
        QVERIFY2(picturesMatch, "FPS must preserve the held video picture");
        QVERIFY2(positionsMatch, "FPS must preserve the held video time");
    }
    void associatedFpsRetimesPlayingCaption()
    {
        const auto directory = qEnvironmentVariable("VLC_FPS_SNAPSHOTS");
        if (directory.isEmpty())
            QSKIP("Set VLC_FPS_SNAPSHOTS and use the 60-second frame-marker fixture");
        QVERIFY(QDir(directory).exists());
        QCOMPARE(select(m_first.get()), 1u);
        QTRY_VERIFY(roles() == qMakePair(m_first.get(), static_cast<vlc_es_id_t *>(nullptr)));
        auto snapshot = [this, &directory](const QString &name) {
            const auto path = QDir(directory).filePath(name + ".png");
            vout_thread_t *output;
            {
                vlc_player_locker lock{m_player};
                output = vlc_player_vout_Hold(m_player);
            }
            if (!output) return QImage();
            var_Create(output, "snapshot-width", VLC_VAR_INTEGER);
            var_SetInteger(output, "snapshot-width", 960);
            var_Create(output, "snapshot-height", VLC_VAR_INTEGER);
            var_SetInteger(output, "snapshot-height", 540);
            var_Create(output, "snapshot-path", VLC_VAR_STRING);
            var_SetString(output, "snapshot-path", qtu(path));
            var_Create(output, "snapshot-format", VLC_VAR_STRING);
            var_SetString(output, "snapshot-format", "png");
            var_TriggerCallback(output, "video-snapshot");
            vout_Release(output);
            QImage image;
            for (int i = 0; i < 100 && image.isNull(); ++i) {
                QTest::qWait(20);
                image.load(path);
            }
            return image.convertToFormat(QImage::Format_RGBA8888);
        };
        auto captionMask = [](const QImage &image) {
            QByteArray result;
            for (int y = image.height() * 3 / 4; y < image.height(); ++y)
                for (int x = 0; x < image.width(); ++x) {
                    const auto color = image.pixelColor(x, y);
                    result.append(char(color.red() > 160 && color.green() > 160 && color.blue() > 160));
                }
            return result;
        };
        auto matches = [](const QByteArray &actual, const QByteArray &expected) {
            if (actual.size() != expected.size()) return false;
            qsizetype intersection = 0, united = 0;
            for (qsizetype i = 0; i < actual.size(); ++i) {
                intersection += actual[i] && expected[i];
                united += actual[i] || expected[i];
            }
            return united > 100 && intersection * 1000 >= united * 995;
        };
        auto time = [this] {
            vlc_player_locker lock{m_player};
            return vlc_player_GetTime(m_player);
        };
        m_controller->setSubtitleFPS(50.f);
        {
            vlc_player_locker lock{m_player};
            vlc_player_SetTime(m_player, VLC_TICK_FROM_SEC(12));
        }
        QTest::qWait(700);
        const auto middle = snapshot("playing-middle-reference");
        QVERIFY(!middle.isNull());
        m_controller->setSubtitleFPS(0.f);
        QTest::qWait(700);
        const auto first = snapshot("playing-first-reference");
        QVERIFY(!first.isNull());
        const auto firstMask = captionMask(first), middleMask = captionMask(middle);
        QVERIFY(firstMask != middleMask);
        QCOMPARE(frameMarker(first), 300u);
        QCOMPARE(frameMarker(middle), 300u);
        {
            vlc_player_locker lock{m_player};
            vlc_player_Resume(m_player);
        }
        QTRY_COMPARE(m_controller->getPlayingState(), PlayerController::PLAYING_STATE_PLAYING);
        qInfo("Resume from frame 300: first raw clock=%lld", static_cast<long long>(time()));
        QTRY_VERIFY(time() > VLC_TICK_FROM_SEC(12) + VLC_TICK_FROM_MS(100));
        qInfo("Resume from frame 300: updated raw clock=%lld", static_cast<long long>(time()));
        const auto resumedDiagnostic = snapshot("resume-frame-300-diagnostic");
        QVERIFY(!resumedDiagnostic.isNull());
        qInfo("Resume diagnostic decoded frame=%u", frameMarker(resumedDiagnostic));
        // The timer can keep its paused point until the first output update.
        // Qualify the actual decoded progress too, within two media seconds.
        QVERIFY(time() < VLC_TICK_FROM_SEC(14));
        QVERIFY(frameMarker(resumedDiagnostic) >= 300u);
        QVERIFY(frameMarker(resumedDiagnostic) < 350u);
        bool captionsMatch = true, clocksAdvance = true;
        for (const auto fps : {50.f, 0.f, 29.97f, 23.976f, 0.f}) {
            const auto before = time();
            m_controller->setSubtitleFPS(fps);
            QTRY_COMPARE(m_controller->getSubtitleFPS(), fps);
            QTest::qWait(350);
            const auto image = snapshot(QString("playing-%1-%2").arg(fps, 0, 'f', 3).arg(before));
            QVERIFY(!image.isNull());
            const auto after = time();
            const bool caption = matches(captionMask(image), fps == 50.f ? middleMask : firstMask);
            const bool clock = after > before && after - before < VLC_TICK_FROM_SEC(2)
                            && after < VLC_TICK_FROM_SEC(16);
            qInfo("Playing FPS %.3f caption=%d advancingClock=%d before=%lld after=%lld", double(fps),
                  caption, clock, static_cast<long long>(before), static_cast<long long>(after));
            captionsMatch &= caption;
            clocksAdvance &= clock;
        }
        {
            vlc_player_locker lock{m_player};
            vlc_player_Pause(m_player);
        }
        QTRY_COMPARE(m_controller->getPlayingState(), PlayerController::PLAYING_STATE_PAUSED);
        // At 50 FPS all three external cues have ended by 30 seconds. Reset
        // while playing must revive that EOF source, without a primary seek.
        m_controller->setSubtitleFPS(50.f);
        {
            vlc_player_locker lock{m_player};
            vlc_player_SetTime(m_player, VLC_TICK_FROM_SEC(32));
        }
        QTest::qWait(700);
        const auto ended = snapshot("playing-eof-reference");
        QVERIFY(!ended.isNull());
        QCOMPARE(captionMask(ended).count(char(1)), qsizetype(0));
        QCOMPARE(frameMarker(ended), 800u); // actual 25 FPS frame at 32 seconds
        m_controller->setSubtitleFPS(0.f);
        QTest::qWait(700);
        const auto revived = snapshot("playing-revived-reference");
        QVERIFY(!revived.isNull());
        QCOMPARE(frameMarker(revived), 800u);
        const auto revivedMask = captionMask(revived);
        QVERIFY(revivedMask.count(char(1)) > 100);
        m_controller->setSubtitleFPS(50.f);
        QTest::qWait(700);
        qInfo("EOF paused raw clock=%lld state=%d", static_cast<long long>(time()),
              int(m_controller->getPlayingState()));
        {
            vlc_player_locker lock{m_player};
            vlc_player_Resume(m_player);
        }
        QTRY_COMPARE(m_controller->getPlayingState(), PlayerController::PLAYING_STATE_PLAYING);
        // The raw main timer can retain its last playing point during a paused
        // seek. The snapshots above prove the landed frame independently.
        // Establish the real resumed clock before testing a playing FPS edit.
        QTRY_VERIFY(time() > VLC_TICK_FROM_SEC(32) + VLC_TICK_FROM_MS(100));
        QVERIFY(time() < VLC_TICK_FROM_SEC(34));
        for (const auto fps : {0.f, 50.f, 0.f}) {
            const auto before = time();
            m_controller->setSubtitleFPS(fps);
            QTRY_COMPARE(m_controller->getSubtitleFPS(), fps);
            QTest::qWait(350);
            const auto image = snapshot(QString("playing-eof-%1-%2").arg(fps).arg(before));
            QVERIFY(!image.isNull());
            const auto mask = captionMask(image);
            const bool caption = fps == 0.f ? matches(mask, revivedMask) : mask.count(char(1)) == 0;
            const auto after = time();
            const bool clock = after > before && after - before < VLC_TICK_FROM_SEC(2)
                            && after < VLC_TICK_FROM_SEC(36);
            qInfo("Playing EOF FPS %.3f caption=%d advancingClock=%d before=%lld after=%lld", double(fps),
                  caption, clock, static_cast<long long>(before), static_cast<long long>(after));
            captionsMatch &= caption;
            clocksAdvance &= clock;
        }
        {
            vlc_player_locker lock{m_player};
            vlc_player_Pause(m_player);
        }
        QTRY_COMPARE(m_controller->getPlayingState(), PlayerController::PLAYING_STATE_PAUSED);
        QCOMPARE(select(m_first.get(), m_second.get()), 2u);
        QTRY_VERIFY(roles() == qMakePair(m_first.get(), m_second.get()));
        QVERIFY2(captionsMatch, "Playing FPS changes must replace queued cues and revive subtitle EOF");
        QVERIFY2(clocksAdvance, "The primary clock must continue without an FPS-induced seek");
    }
    void associatedFpsNotificationsAndValidation()
    {
        QSignalSpy changes(m_controller.get(), &PlayerController::subtitleFPSChanged);
        const int observationsBefore = m_fpsObservations;
        const auto connection = connect(m_controller.get(), &PlayerController::subtitleFPSChanged,
            this, [this](float) {
                QCOMPARE(QThread::currentThread(), m_controller->thread());
                // A direct observer must be able to re-lock the NORMAL player.
                (void)m_controller->getInput();
                ++m_fpsObservations;
            }, Qt::DirectConnection);
        {
            vlc_player_locker lock{m_player};
            vlc_player_SetAssociatedSubsFPS(m_player, 23.976f);
        }
        QCOMPARE(m_fpsObservations, observationsBefore);
        QTRY_COMPARE(m_controller->getSubtitleFPS(), 23.976f);
        QVERIFY(!changes.isEmpty());
        QCOMPARE(changes.last().front().toFloat(), 23.976f);

        const auto *input = m_controller->getInput();
        const auto selected = roles();
        const auto categoryBefore = category();
        m_controller->setSubtitleFPS(29.97f);
        {
            vlc_player_locker lock{m_player};
            QCOMPARE(vlc_player_GetAssociatedSubsFPS(m_player), 29.97f);
        }
        QTRY_COMPARE(m_controller->getSubtitleFPS(), 29.97f);
        const int before = changes.size();
        for (const auto invalid : {-1.f, std::numeric_limits<float>::infinity(),
                                  std::numeric_limits<float>::quiet_NaN()})
            m_controller->setSubtitleFPS(invalid);
        QTest::qWait(30);
        QCOMPARE(changes.size(), before);
        {
            vlc_player_locker lock{m_player};
            QCOMPARE(vlc_player_GetAssociatedSubsFPS(m_player), 29.97f);
        }
        m_controller->setSubtitleFPS(0.f);
        QTRY_COMPARE(m_controller->getSubtitleFPS(), 0.f);
        QCOMPARE(m_controller->getInput(), input);
        QCOMPARE(roles(), selected);
        QCOMPARE(category(), categoryBefore);
        QVERIFY(m_fpsObservations >= observationsBefore + 3);
        disconnect(connection);
    }
    void estimatorDirectionsAndCancellation()
    {
        DelayEstimator estimator;
        QSignalSpy changes(&estimator, &DelayEstimator::delayChanged);
        QVERIFY(!estimator.isHeardTimeMarked());
        QVERIFY(!estimator.isSpottedTimeMarked());
        estimator.markHeardTime();
        QVERIFY(estimator.isHeardTimeMarked());
        QTest::qWait(30);
        estimator.markSpottedTime();
        QCOMPARE(changes.size(), 1);
        QVERIFY(estimator.getDelay().valid());
        QVERIFY(estimator.getDelay().toVLCTick() <= -VLC_TICK_FROM_MS(20));
        QVERIFY(estimator.getDelay().toVLCTick() > -VLC_TICK_FROM_SEC(3));
        QVERIFY(!estimator.isHeardTimeMarked());
        QVERIFY(!estimator.isSpottedTimeMarked());
        estimator.reset();
        QVERIFY(!estimator.getDelay().valid());
        estimator.markSpottedTime();
        QTest::qWait(30);
        estimator.markHeardTime();
        QCOMPARE(changes.size(), 3);
        QVERIFY(estimator.getDelay().valid());
        QVERIFY(estimator.getDelay().toVLCTick() >= VLC_TICK_FROM_MS(20));
        QVERIFY(estimator.getDelay().toVLCTick() < VLC_TICK_FROM_SEC(3));
        estimator.reset();
        const auto beforeCancel = changes.size();
        estimator.markHeardTime();
        estimator.markHeardTime();
        QVERIFY(!estimator.isHeardTimeMarked());
        estimator.markSpottedTime();
        QCOMPARE(changes.size(), beforeCancel);
        QVERIFY(estimator.isSpottedTimeMarked());
        estimator.reset();
        QVERIFY(!estimator.isHeardTimeMarked());
        QVERIFY(!estimator.isSpottedTimeMarked());
        QVERIFY(!estimator.getDelay().valid());
    }
    void estimatorCancellationDoesNotPublishAnAdjustment()
    {
        DelayEstimator estimator;
        QSignalSpy changes(&estimator, &DelayEstimator::delayChanged);
        estimator.markHeardTime();
        estimator.cancel();
        QVERIFY(!estimator.isHeardTimeMarked());
        QVERIFY(!estimator.isSpottedTimeMarked());
        QVERIFY(changes.isEmpty());
        estimator.markSpottedTime();
        QVERIFY(estimator.isSpottedTimeMarked());
        QVERIFY(changes.isEmpty()); // cannot complete a pair from the old input
        QTest::qWait(30);
        estimator.markHeardTime();
        QCOMPARE(changes.size(), 1);
        const auto applied = estimator.getDelay().toVLCTick();
        QVERIFY(applied >= VLC_TICK_FROM_MS(20));
        estimator.markSpottedTime();
        estimator.cancel();
        estimator.cancel(); // repeated input-detach/rate notifications are safe
        QVERIFY(!estimator.isHeardTimeMarked());
        QVERIFY(!estimator.isSpottedTimeMarked());
        QCOMPARE(changes.size(), 1);
        QCOMPARE(estimator.getDelay().toVLCTick(), applied);
    }
    void categoryRelativeAdjustmentsAndResetNotifications()
    {
        QCOMPARE(select(m_first.get(), m_second.get()), 2u);
        QTRY_VERIFY(roles() == qMakePair(m_first.get(), m_second.get()));
        setCategory(350000);
        QCOMPARE(setOwn(m_first.get(), INT64_MAX), VLC_SUCCESS);
        QCOMPARE(setOwn(m_second.get(), 650000), VLC_SUCCESS);
        m_controller->setAudioDelayMS(350);
        QTRY_COMPARE(m_controller->getAudioDelayMS(), 350);
        QTRY_COMPARE(m_controller->getSubtitleDelayMS(), 350);
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelayMS(), 650);
        QSignalSpy audioChanges(m_controller.get(), &PlayerController::audioDelayChanged);
        QSignalSpy subtitleChanges(m_controller.get(), &PlayerController::subtitleDelayChanged);
        const auto audioObserver = connect(m_controller.get(), &PlayerController::audioDelayChanged,
            this, &TestPlayerSubtitleDelay::observeAfterUnlock, Qt::DirectConnection);
        auto expected = vlc_tick_t(350000);
        for (const auto delta : {vlc_tick_t(50000), vlc_tick_t(-75750)})
        {
            const int observations = m_observations;
            m_controller->addAudioDelay(VLCDuration(delta));
            m_controller->addSubtitleDelay(VLCDuration(delta));
            QCOMPARE(m_observations, observations); // no direct signal under the lock
            expected += delta;
            QCOMPARE(category(), expected);
            QTRY_COMPARE(m_controller->getAudioDelay().toVLCTick(), expected);
            QTRY_COMPARE(m_controller->getSubtitleDelay().toVLCTick(), expected);
            QVERIFY(!audioChanges.isEmpty());
            QVERIFY(!subtitleChanges.isEmpty());
            QCOMPARE(audioChanges.last().front().value<VLCDuration>().toVLCTick(), expected);
            QCOMPARE(subtitleChanges.last().front().value<VLCDuration>().toVLCTick(), expected);
            QCOMPARE(own(m_second.get()), vlc_tick_t(650000));
            QCOMPARE(m_controller->getSecondarySubtitleDelayMS(), 650);
        }
        // Follow the ordinary Reset binding while a direct re-locking observer
        // remains connected, as when the legacy synchronization editor exists.
        DelayEstimator estimator;
        connect(&estimator, &DelayEstimator::delayChanged, this, [this, &estimator] {
            m_controller->addAudioDelay(estimator.getDelay());
            m_controller->addSubtitleDelay(estimator.getDelay());
            m_controller->addSecondarySubtitleDelay(estimator.getDelay());
        });
        const auto audioCount = audioChanges.size();
        const auto subtitleCount = subtitleChanges.size();
        estimator.markHeardTime();
        estimator.reset(); // an invalid estimate must not publish a delta
        QTest::qWait(30);
        QCOMPARE(audioChanges.size(), audioCount);
        QCOMPARE(subtitleChanges.size(), subtitleCount);
        QCOMPARE(category(), expected);
        QCOMPARE(own(m_second.get()), vlc_tick_t(650000));
        m_controller->setSubtitleDelayMS(0);
        estimator.reset();
        QTRY_COMPARE(m_controller->getSubtitleDelayMS(), 0);
        QCOMPARE(m_controller->getSecondarySubtitleDelayMS(), 650);
        m_controller->setSecondarySubtitleDelayMS(0);
        estimator.reset();
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelayMS(), 0);
        QCOMPARE(own(m_second.get()), vlc_tick_t(0));
        m_controller->setAudioDelayMS(0);
        estimator.reset();
        QTRY_COMPARE(m_controller->getAudioDelayMS(), 0);
        QVERIFY(m_observations > 0);
        disconnect(audioObserver);
    }
    void timingContextCancellation_data()
    {
        QTest::addColumn<bool>("subtitle");
        QTest::addColumn<QString>("change");
        for (const auto *page : {"audio", "subtitle"})
            for (const auto *change : {"qt-seek", "native-seek", "qt-rate", "native-rate"})
                QTest::newRow(qPrintable(QString::fromLatin1(page)+QLatin1Char('-')+QString::fromLatin1(change)))
                    << (QByteArray(page)=="subtitle") << QString::fromLatin1(change);
    }
    void timingContextCancellation()
    {
        QFETCH(bool, subtitle); QFETCH(QString, change);
        const QDir pages(qEnvironmentVariable("VLC_TRACKS_SOURCE_DIR"));
        QVERIFY2(!qEnvironmentVariable("VLC_TRACKS_SOURCE_DIR").isEmpty(),
                 "Supply frozen production synchronization QML pages");
        QFile source(pages.filePath(subtitle ? QStringLiteral("TracksPageSubtitle.qml")
                                            : QStringLiteral("TracksPageAudio.qml")));
        QVERIFY(source.open(QIODevice::ReadOnly));
        const auto text=source.readAll();
        const auto start=text.indexOf("    Connections {");
        const auto close=text.indexOf("\n    }", start);
        const auto end=text.indexOf("    // Functions", close);
        QVERIFY(start>=0 && close>start && end>close);
        const auto connections=text.mid(start, close+6-start);
        const auto helpers=text.mid(close+6, end-close-6);
        m_controller->setRate(1.f);
        QTRY_COMPARE(m_controller->getRate(), 1.f);
        m_controller->setTime(VLCTime(VLC_TICK_FROM_SEC(3)));
        QTRY_VERIFY(qAbs(m_controller->getTime().toVLCTick()-VLC_TICK_FROM_SEC(3)) <= VLC_TICK_FROM_MS(100));
        QTest::qWait(100); // drain the setup seek before marking a new pair
        DelayEstimator audio, primary, secondary;
        QSignalSpy audioChanges(&audio, &DelayEstimator::delayChanged);
        QSignalSpy primaryChanges(&primary, &DelayEstimator::delayChanged);
        QSignalSpy secondaryChanges(&secondary, &DelayEstimator::delayChanged);
        QQmlEngine engine;
        engine.rootContext()->setContextProperty(QStringLiteral("Player"), m_controller.get());
        engine.rootContext()->setContextProperty(QStringLiteral("delayEstimator"), &audio);
        engine.rootContext()->setContextProperty(QStringLiteral("delayEstimatorPrimary"), &primary);
        engine.rootContext()->setContextProperty(QStringLiteral("delayEstimatorSecondary"), &secondary);
        QQmlComponent component(&engine);
        component.setData(QByteArrayLiteral("import QtQml\nQtObject { id: root; property QtObject hook: ")
            +connections+'\n'+helpers+'\n'+'}', QUrl(QStringLiteral("file:///timing-context-native.qml")));
        QScopedPointer<QObject> root(component.create());
        QVERIFY2(root, qPrintable(component.errorString()));
        connect(m_controller.get(), &PlayerController::rateChanged, root.data(), [this](float) {
            QCOMPARE(QThread::currentThread(), m_controller->thread());
            (void)m_controller->getInput(); // rate observers may re-lock too
        }, Qt::DirectConnection);
        auto marked=[&] { return subtitle ? primary.isHeardTimeMarked() || secondary.isSpottedTimeMarked()
                                          : audio.isHeardTimeMarked(); };
        if (subtitle) { primary.markHeardTime(); secondary.markSpottedTime(); }
        else audio.markHeardTime();
        QVERIFY(marked());
        QTest::qWait(50);
        QVERIFY(marked()); // no delayed setup event may cancel this pair
        const auto input=m_controller->getInput();
        const auto selected=roles(); const auto savedCategory=category();
        const auto savedOwn=own(m_second.get());
        if (change==QStringLiteral("qt-seek")) m_controller->jumpToPos(.25);
        else if (change==QStringLiteral("qt-rate")) m_controller->setRate(1.5f);
        else {
            vlc_player_locker lock{m_player};
            if (change==QStringLiteral("native-seek")) vlc_player_SetTime(m_player, VLC_TICK_FROM_SEC(9));
            else vlc_player_ChangeRate(m_player, 1.5f);
        }
        QTRY_VERIFY_WITH_TIMEOUT(!marked(), 2500);
        if (change.endsWith(QStringLiteral("rate"))) QTRY_COMPARE(m_controller->getRate(), 1.5f);
        else {
            const auto requested=VLC_TICK_FROM_SEC(change==QStringLiteral("qt-seek") ? 15 : 9);
            QTRY_VERIFY(qAbs(m_controller->getTime().toVLCTick()-requested) <= VLC_TICK_FROM_MS(100));
        }
        QVERIFY(audioChanges.isEmpty() && primaryChanges.isEmpty() && secondaryChanges.isEmpty());
        QCOMPARE(m_controller->getInput(), input);
        QCOMPARE(roles(), selected); QCOMPARE(category(), savedCategory);
        QCOMPARE(own(m_second.get()), savedOwn);
        // The same hook/estimator objects survive the native event. Teardown
        // cannot account for cancellation and must not apply a zero override.
        QVERIFY(root);
    }
    void incrementalSelectionKeepsSecondaryTimingReachable()
    {
        // Follow the ordinary track list: keep one subtitle selected and add
        // another with SIMULTANEOUS, without clearing the existing selection.
        setCategory(0);
        QCOMPARE(setOwn(m_first.get(), INT64_MAX), VLC_SUCCESS);
        QCOMPARE(setOwn(m_second.get(), INT64_MAX), VLC_SUCCESS);
        QCOMPARE(select(m_first.get()), 1u);
        QTRY_VERIFY(roles() == qMakePair(m_first.get(), static_cast<vlc_es_id_t *>(nullptr)));
        {
            vlc_player_locker lock{m_player};
            QCOMPARE(vlc_player_SelectEsId(m_player, m_second.get(),
                     VLC_PLAYER_SELECT_SIMULTANEOUS), 2u);
            vlc_player_SetTime(m_player, VLC_TICK_FROM_MS(1500));
        }
        auto bothOutputs = [this] {
            vlc_player_locker lock{m_player};
            return vlc_player_GetEsIdVout(m_player, m_first.get(), nullptr)
                && vlc_player_GetEsIdVout(m_player, m_second.get(), nullptr);
        };
        QTRY_VERIFY_WITH_TIMEOUT(bothOutputs(), 5000);
        QTRY_VERIFY_WITH_TIMEOUT(roles() == qMakePair(m_first.get(), m_second.get()), 5000);
        m_controller->setSecondarySubtitleDelay(VLCDuration(1200000));
        QCOMPARE(own(m_second.get()), vlc_tick_t(1200000));
        QCOMPARE(own(m_first.get()), vlc_tick_t(INT64_MAX));
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelayMS(), 1200);
        setCategory(350000);
        QTRY_COMPARE(m_controller->getSubtitleDelayMS(), 350);
        QCOMPARE(own(m_second.get()), vlc_tick_t(1200000));
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelayMS(), 1200);
        m_controller->setSecondarySubtitleDelay(VLCDuration(0));
        QCOMPARE(own(m_second.get()), vlc_tick_t(0));
        setCategory(450000);
        QTRY_COMPARE(m_controller->getSubtitleDelayMS(), 450);
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelayMS(), 0);
        // Leave the same real pair ready for the remaining timing regressions.
        setCategory(0);
        QCOMPARE(setOwn(m_second.get(), INT64_MAX), VLC_SUCCESS);
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelayMS(), 0);
    }
    void sentinelCategoryAndEffectivePayload()
    {
        QSignalSpy changes(m_controller.get(), &PlayerController::secondarySubtitleDelayChanged);
        setCategory(350000);
        QCOMPARE(setOwn(m_second.get(), 650000), VLC_SUCCESS);
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelayMS(), 650);
        changes.clear();
        const int observations = m_observations;
        QCOMPARE(setOwn(m_second.get(), INT64_MAX), VLC_SUCCESS);
        QCOMPARE(m_observations, observations); // native callback stays queued
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelayMS(), 350);
        QCOMPARE(own(m_second.get()), vlc_tick_t(INT64_MAX));
        QVERIFY(!changes.isEmpty());
        QCOMPARE(changes.last().front().value<VLCDuration>().toVLCTick(), vlc_tick_t(350000));
        setCategory(450000);
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelayMS(), 450);
        QCOMPARE(changes.last().front().value<VLCDuration>().toVLCTick(), vlc_tick_t(450000));
        // Override/inherit transitions still notify when their effective number
        // is equal; zero is an explicit override, never the inheritance marker.
        const int before = changes.size();
        QCOMPARE(setOwn(m_second.get(), 450000), VLC_SUCCESS);
        QTRY_VERIFY(changes.size() > before);
        QCOMPARE(setOwn(m_second.get(), INT64_MAX), VLC_SUCCESS);
        QTRY_VERIFY(changes.size() > before + 1);
    }
    void relativeAdjustmentAndExactNativeUnits()
    {
        setCategory(350000);
        QCOMPARE(setOwn(m_second.get(), INT64_MAX), VLC_SUCCESS);
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelayMS(), 350);
        const int observations = m_observations;
        m_controller->addSecondarySubtitleDelay(VLCDuration(50000));
        QCOMPARE(m_observations, observations);
        QCOMPARE(own(m_second.get()), vlc_tick_t(400000));
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelayMS(), 400);
        m_controller->setSecondarySubtitleDelay(VLCDuration(-25555));
        QCOMPARE(own(m_second.get()), vlc_tick_t(-25555));
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelay().toVLCTick(), vlc_tick_t(-25555));
    }
    void currentRoleWinsBeforeQueuedCacheRefresh()
    {
        QCOMPARE(setOwn(m_first.get(), 125000), VLC_SUCCESS);
        QCOMPARE(setOwn(m_second.get(), 650000), VLC_SUCCESS);
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelayMS(), 650);
        QCOMPARE(select(m_second.get(), m_first.get()), 2u);
        QVERIFY(waitNativeRoles(m_second.get(), m_first.get()));
        // GUI callbacks have not been dispatched, so this proves the setter
        // avoids the former secondary role rather than just a fresh cache.
        QCOMPARE(m_controller->getSecondarySubtitleDelayMS(), 650);
        m_controller->setSecondarySubtitleDelay(VLCDuration(333333));
        QCOMPARE(own(m_first.get()), vlc_tick_t(333333));
        QCOMPARE(own(m_second.get()), vlc_tick_t(650000));
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelay().toVLCTick(), vlc_tick_t(333333));
        QCOMPARE(own(m_second.get()), vlc_tick_t(650000)); // refresh must not reapply
    }
    void actualDefaultClearsAllPerTrackOverrides()
    {
        // Native role metadata precedes asynchronous subtitle output creation.
        // Default requires those real outputs, as in the initial fixture setup.
        QTRY_VERIFY_WITH_TIMEOUT(m_presets->canApply(), 5000);
        QVERIFY(m_presets->apply("default"));
        QTRY_VERIFY(!m_presets->restoring());
        QCOMPARE(m_presets->error(), QString());
        QCOMPARE(own(m_first.get()), vlc_tick_t(INT64_MAX));
        QCOMPARE(own(m_second.get()), vlc_tick_t(INT64_MAX));
        QCOMPARE(category(), vlc_tick_t(0));
        QTRY_COMPARE(m_controller->getSubtitleDelayMS(), 0);
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelayMS(), 0);
        QCOMPARE(roles(), qMakePair(m_second.get(), m_first.get()));
    }
    void unselectAndNewRoleDoNotCarryAnOverride()
    {
        QCOMPARE(setOwn(m_first.get(), 725000), VLC_SUCCESS);
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelayMS(), 725);
        QCOMPARE(select(m_second.get()), 1u);
        QTRY_VERIFY(roles() == qMakePair(m_second.get(), static_cast<vlc_es_id_t *>(nullptr)));
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelayMS(), 0);
        // The track retains its genuine native override while unselected.
        // Selecting the other track as secondary must inherit its own sentinel.
        QCOMPARE(select(m_first.get(), m_second.get()), 2u);
        QTRY_VERIFY(roles() == qMakePair(m_first.get(), m_second.get()));
        QCOMPARE(own(m_first.get()), vlc_tick_t(725000));
        QCOMPARE(own(m_second.get()), vlc_tick_t(INT64_MAX));
        setCategory(275000);
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelayMS(), 275);
    }
    void queuedOldMediaEventsAndDetachedInputClearCache()
    {
        QCOMPARE(setOwn(m_second.get(), 975000), VLC_SUCCESS);
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelayMS(), 975);
        const auto uri = QUrl::fromLocalFile(m_fixture).toEncoded();
        auto *replacement = input_item_New(uri.constData(), "Unstarted replacement input");
        QVERIFY(replacement);
        int changed;
        {
            vlc_player_locker lock{m_player};
            // Both callbacks remain queued; the old delay must not survive the
            // native input detachment or be applied to the new input item.
            vlc_player_SetEsIdDelay(m_player, m_second.get(), 1110000, VLC_PLAYER_WHENCE_ABSOLUTE);
            vlc_player_Stop(m_player);
            changed = vlc_player_SetCurrentMedia(m_player, replacement);
        }
        input_item_Release(replacement);
        QCOMPARE(changed, VLC_SUCCESS);
        QTRY_COMPARE_WITH_TIMEOUT(m_controller->getPlayingState(), PlayerController::PLAYING_STATE_STOPPED, 10000);
        QTRY_COMPARE(m_controller->getSecondarySubtitleDelayMS(), 0);
        QTRY_COMPARE(m_controller->getSubtitleDelayMS(), 0);
        QCOMPARE(roles(), qMakePair(static_cast<vlc_es_id_t *>(nullptr), static_cast<vlc_es_id_t *>(nullptr)));
        m_controller->setSecondarySubtitleDelay(VLCDuration(75000));
        m_controller->addSecondarySubtitleDelay(VLCDuration(75000));
        QCOMPARE(category(), vlc_tick_t(0));
        {
            vlc_player_locker lock{m_player};
            QCOMPARE(vlc_player_SetCurrentMedia(m_player, nullptr), VLC_SUCCESS);
        }
        QTRY_VERIFY(!m_controller->hasInput());
        QCOMPARE(m_controller->getSecondarySubtitleDelayMS(), 0);
        QVERIFY(m_observations > 0);
    }
    void attachmentScopeMappingsAndRestart()
    {
        QTemporaryDir temporary; QVERIFY(temporary.isValid());
        auto create = [&](const QString &name) {
            QFile file(temporary.filePath(name));
            if (!file.open(QIODevice::WriteOnly)) return QUrl{};
            file.write("1\n00:00:00,000 --> 00:01:00,000\nAttachment test\n"); file.close();
            return QUrl::fromLocalFile(file.fileName());
        };
        const auto a = create("Show.S01E01.mp4"), b = create("Show.S01E02.mp4");
        const auto sa = create("Show.S01E01.srt"), sb = create("Show.S01E02.srt");
        const auto playlistSub = create("Playlist choice.srt"), fileSub = create("File choice %.srt");
        QVERIFY(!a.isEmpty() && !fileSub.isEmpty());
        SubtitleAttachmentModel::Context context;
        auto *item = input_item_New(a.toEncoded().constData(), "Attachment mapping fixture"); QVERIFY(item);
        context.item.reset(item); input_item_Release(item); context.playlistId = 42;
        context.playlistItems = {QVariantMap{{"url",a},{"title","Episode one"}}, QVariantMap{{"url",b},{"title","Episode two"}}};
        QSettings settings(temporary.filePath("attachments.ini"), QSettings::IniFormat);
        const auto key = QStringLiteral("Juxtopposed/SubtitleAttachments/v1");
        auto provider = [&](bool) { return context; };
        auto model = std::make_unique<SubtitleAttachmentModel>(nullptr, &settings, provider);
        auto selectFile = [&](int row, const QUrl &url) {
            const auto files = model->subtitleRows();
            for (qsizetype i = 0; i < files.size(); ++i) if (files[i].toMap().value("url").toUrl() == url) {
                model->toggle(row, int(i)); return true;
            }
            return false;
        };
        auto encoded = [](const QUrl &url) { return url.toString(QUrl::FullyEncoded); };
        QVERIFY(model->begin()); model->setScope(SubtitleAttachmentModel::ThisFolder);
        QCOMPARE(model->mediaRows().size(), 2); model->matchNames();
        QCOMPARE(model->mediaRows()[0].toMap().value("count").toInt(), 1);
        QCOMPARE(model->mediaRows()[1].toMap().value("count").toInt(), 1);
        QVERIFY(model->save());
        QCOMPARE(model->effectiveFiles(a, 0), QStringList{encoded(sa)});
        QCOMPARE(model->effectiveFiles(b, 0), QStringList{encoded(sb)});
        QVERIFY(model->begin()); model->setScope(SubtitleAttachmentModel::ThisPlaylist);
        QVERIFY(selectFile(0, playlistSub)); QVERIFY(selectFile(1, playlistSub)); QVERIFY(model->save());
        QCOMPARE(model->effectiveFiles(a, 42), QStringList{encoded(playlistSub)});
        QCOMPARE(model->effectiveFiles(b, 42), QStringList{encoded(playlistSub)});
        QCOMPARE(model->effectiveFiles(b, 43), QStringList{encoded(sb)});
        const auto completePlaylist = context.playlistItems;
        context.playlistItems = {completePlaylist.first()};
        QVERIFY(model->begin()); model->setScope(SubtitleAttachmentModel::ThisPlaylist);
        QCOMPARE(model->mediaRows().size(), 1); model->clearRow(0); QVERIFY(selectFile(0, sa)); QVERIFY(model->save());
        QCOMPARE(model->effectiveFiles(a, 42), QStringList{encoded(sa)});
        QCOMPARE(model->effectiveFiles(b, 42), QStringList{encoded(playlistSub)}); // Unseen member retained.
        context.playlistItems = completePlaylist;
        QVERIFY(model->begin()); model->setScope(SubtitleAttachmentModel::ThisPlaylist);
        model->clearRow(0); QVERIFY(selectFile(0, playlistSub)); QVERIFY(model->save());
        QVERIFY(model->begin()); QVERIFY(selectFile(0, fileSub)); QVERIFY(selectFile(0, sa)); QVERIFY(model->save());
        QCOMPARE(model->effectiveFiles(a, 42), (QStringList{encoded(fileSub), encoded(sa)}));
        const auto saved = settings.value(key).toByteArray();
        QVERIFY(model->begin()); model->clearRow(0); model->cancel();
        QCOMPARE(settings.value(key).toByteArray(), saved);
        model.reset(); model = std::make_unique<SubtitleAttachmentModel>(nullptr, &settings, provider);
        QCOMPARE(model->effectiveFiles(a, 42), (QStringList{encoded(fileSub), encoded(sa)}));
        QCOMPARE(model->effectiveFiles(b, 42), QStringList{encoded(playlistSub)});
        QCOMPARE(model->effectiveFiles(b, 0), QStringList{encoded(sb)});
        QVERIFY(model->effectiveFiles(QUrl::fromLocalFile(temporary.filePath("Moved.S01E01.mp4")), 42).isEmpty());

        // Missing sources do not overwrite persisted matches or fall back to a
        // less-specific association. The deliberate replacement is reviewable.
        QVERIFY(QFile::rename(fileSub.toLocalFile(), temporary.filePath("Moved choice.srt")));
        QVERIFY(model->begin()); QVERIFY(!model->save()); QVERIFY(!model->error().isEmpty());
        QCOMPARE(settings.value(key).toByteArray(), saved);
        QCOMPARE(model->effectiveFiles(a, 42).first(), encoded(fileSub));
        model->clearRow(0); QVERIFY(selectFile(0, sa)); QVERIFY(model->save());
        QCOMPARE(model->effectiveFiles(a, 42), QStringList{encoded(sa)});
        QVERIFY(model->begin()); model->clearRow(0); QVERIFY(model->save());
        QCOMPARE(model->effectiveFiles(a, 42), QStringList{encoded(playlistSub)});

        // A queue-source change cannot save an old draft against the next item.
        QVERIFY(model->begin()); QVERIFY(selectFile(0, sa));
        auto *other = input_item_New(b.toEncoded().constData(), "Replacement mapping fixture"); QVERIFY(other);
        context.item.reset(other); input_item_Release(other);
        const auto beforeStale = settings.value(key).toByteArray();
        QVERIFY(!model->save()); QVERIFY(!model->canSave());
        QCOMPARE(settings.value(key).toByteArray(), beforeStale);
    }
    void attachmentAmbiguousMatchesStayUnselected()
    {
        QTemporaryDir temporary; QVERIFY(temporary.isValid());
        for (const auto &name : {"Show.S01E01.mp4","Show.S01E02.mp4","Show.S01E01.en.srt","Show.S01E01.fi.srt","Other.S01E02.srt"}) {
            QFile file(temporary.filePath(name)); QVERIFY(file.open(QIODevice::WriteOnly)); file.write("fixture");
        }
        const auto url = QUrl::fromLocalFile(temporary.filePath("Show.S01E01.mp4"));
        SubtitleAttachmentModel::Context context;
        auto *item = input_item_New(url.toEncoded().constData(), "Ambiguous matching fixture"); QVERIFY(item);
        context.item.reset(item); input_item_Release(item);
        QSettings settings(temporary.filePath("attachments.ini"), QSettings::IniFormat);
        SubtitleAttachmentModel model(nullptr, &settings, [&](bool) { return context; });
        QVERIFY(model.begin()); model.setScope(SubtitleAttachmentModel::ThisFolder); model.matchNames();
        QCOMPARE(model.mediaRows().size(), 2);
        QCOMPARE(model.mediaRows()[0].toMap().value("count").toInt(), 0);
        QCOMPARE(model.mediaRows()[1].toMap().value("count").toInt(), 1);
        QVERIFY(model.save()); QVERIFY(model.effectiveFiles(url, 0).isEmpty());
    }
    void attachmentStandardPickerFormats()
    {
        QTemporaryDir temporary; QVERIFY(temporary.isValid());
        for (const auto &name : {"Movie.3gp", "Movie.webm", "Song.flac", "Captions.MKS", "Captions.usf", "Captions.scc"}) {
            QFile file(temporary.filePath(name)); QVERIFY(file.open(QIODevice::WriteOnly)); file.write("format-discovery fixture");
        }
        const auto url = QUrl::fromLocalFile(temporary.filePath("Movie.3gp"));
        SubtitleAttachmentModel::Context context;
        auto *item = input_item_New(url.toEncoded().constData(), "Picker format fixture"); QVERIFY(item);
        context.item.reset(item); input_item_Release(item);
        QSettings settings(temporary.filePath("formats.ini"), QSettings::IniFormat);
        SubtitleAttachmentModel model(nullptr, &settings, [&](bool) { return context; });
        QVERIFY(model.begin()); QCOMPARE(model.subtitleRows().size(), 3);
        model.setScope(SubtitleAttachmentModel::ThisFolder); QCOMPARE(model.mediaRows().size(), 3);
        QTemporaryDir elsewhere; QVERIFY(elsewhere.isValid());
        const auto extra = QUrl::fromLocalFile(elsewhere.filePath("Imported.dfxp"));
        QFile file(extra.toLocalFile()); QVERIFY(file.open(QIODevice::WriteOnly)); file.write("picker fixture"); file.close();
        model.addFiles({extra}); QCOMPARE(model.subtitleRows().size(), 4);
        model.toggle(0, 3); QVERIFY(model.save());
        QCOMPARE(model.effectiveFiles(url, 0), QStringList{extra.toString(QUrl::FullyEncoded)});
        // Discovery and checked persistence only; these bytes are not a decode fixture.
    }
    void attachmentCheckedSaveFailureAndCorruptStorage()
    {
        QTemporaryDir temporary; QVERIFY(temporary.isValid());
        const auto mediaPath = temporary.filePath("media.mp4"), subtitlePath = temporary.filePath("caption.srt");
        for (const auto &path : {mediaPath, subtitlePath}) { QFile file(path); QVERIFY(file.open(QIODevice::WriteOnly)); file.write("fixture"); }
        SubtitleAttachmentModel::Context context;
        auto *item = input_item_New(QUrl::fromLocalFile(mediaPath).toEncoded().constData(), "Checked save fixture"); QVERIFY(item);
        context.item.reset(item); input_item_Release(item);
        const auto blockedPath = temporary.filePath("blocked.ini"); QVERIFY(QDir().mkpath(blockedPath));
        QSettings settings(blockedPath, QSettings::IniFormat);
        SubtitleAttachmentModel model(nullptr, &settings, [&](bool) { return context; });
        QVERIFY(model.begin()); QCOMPARE(model.subtitleRows().size(), 1); model.toggle(0, 0);
        QVERIFY(model.canSave()); QVERIFY(!model.save()); QVERIFY(model.active()); QVERIFY(!model.error().isEmpty());
        QVERIFY(model.effectiveFiles(QUrl::fromLocalFile(mediaPath), 0).isEmpty());
        QVERIFY(QDir().rmdir(blockedPath));
        QVERIFY(model.save()); // Fresh checked settings session recovers the old access error.
        QVERIFY(!model.effectiveFiles(QUrl::fromLocalFile(mediaPath), 0).isEmpty());
        const auto key = QStringLiteral("Juxtopposed/SubtitleAttachments/v1");
        QSettings corrupt(temporary.filePath("corrupt.ini"), QSettings::IniFormat);
        const QByteArray bytes("{\"schema\":1,\"records\":[{\"scope\":2,\"owner\":\"wrong\",\"files\":{}}]}");
        corrupt.setValue(key, bytes); corrupt.sync();
        SubtitleAttachmentModel invalid(nullptr, &corrupt, [&](bool) { return context; });
        QVERIFY(invalid.begin()); invalid.toggle(0, 0);
        QVERIFY(!invalid.editable()); QVERIFY(!invalid.error().isEmpty());
        QVERIFY(!invalid.canSave()); QVERIFY(!invalid.save());
        QCOMPARE(corrupt.value(key).toByteArray(), bytes);
    }
    void attachmentNativePausedAndFreshInputRestore()
    {
        QTemporaryDir temporary; QVERIFY(temporary.isValid());
        const auto mediaPath = temporary.filePath("Attachment media %.mp4");
        QVERIFY(QFile::copy(m_fixture, mediaPath));
        const auto firstPath = temporary.filePath("First ä %.srt"), secondPath = temporary.filePath("Second.srt");
        for (const auto &path : {firstPath, secondPath}) {
            QFile file(path); QVERIFY(file.open(QIODevice::WriteOnly));
            file.write("1\n00:00:00,000 --> 00:01:00,000\nEXTERNAL ATTACHMENT\n");
        }
        QSettings settings(temporary.filePath("native.ini"), QSettings::IniFormat);
        auto model = std::make_unique<SubtitleAttachmentModel>(m_player, &settings);
        auto openFresh = [&] {
            auto *item = input_item_New(QUrl::fromLocalFile(mediaPath).toEncoded().constData(), "Native attachment fixture");
            if (!item) return false;
            vlc_player_locker lock{m_player};
            const auto changed = vlc_player_SetCurrentMedia(m_player, item); input_item_Release(item);
            return changed == VLC_SUCCESS && vlc_player_Start(m_player) == VLC_SUCCESS;
        };
        auto stop = [&] {
            { vlc_player_locker lock{m_player}; vlc_player_Stop(m_player); }
            QElapsedTimer deadline; deadline.start();
            while (deadline.elapsed() < 10000) {
                bool stopped; { vlc_player_locker lock{m_player}; stopped = vlc_player_GetState(m_player) == VLC_PLAYER_STATE_STOPPED; }
                if (stopped) return true;
                QTest::qWait(20);
            }
            return false;
        };
        auto count = [&] { vlc_player_locker lock{m_player}; return vlc_player_GetTrackCount(m_player, SPU_ES); };
        auto defaultSelected = [&] {
            const auto uri = QUrl::fromLocalFile(firstPath).toEncoded();
            const QByteArray prefix = QCryptographicHash::hash(uri, QCryptographicHash::Md5).toHex() + '/';
            vlc_player_locker lock{m_player};
            for (size_t i = 0; i < vlc_player_GetTrackCount(m_player, SPU_ES); ++i) {
                const auto *track = vlc_player_GetTrackAt(m_player, SPU_ES, i);
                if (track->selected && QByteArray(vlc_es_id_GetStrId(track->es_id)).startsWith(prefix)) return true;
            }
            return false;
        };
        QVERIFY(stop()); QVERIFY(openFresh());
        QTRY_COMPARE_WITH_TIMEOUT(m_controller->getPlayingState(), PlayerController::PLAYING_STATE_PLAYING, 10000);
        QTRY_COMPARE_WITH_TIMEOUT(count(), size_t(2), 10000);
        { vlc_player_locker lock{m_player}; vlc_player_Pause(m_player); vlc_player_SetTime(m_player, VLC_TICK_FROM_SEC(3)); }
        QTRY_COMPARE(m_controller->getPlayingState(), PlayerController::PLAYING_STATE_PAUSED);
        QTest::qWait(200);
        qint64 before; size_t audioCount;
        { vlc_player_locker lock{m_player}; before = vlc_player_GetTime(m_player); audioCount = vlc_player_GetTrackCount(m_player, AUDIO_ES); }
        QVERIFY(model->begin());
        auto files = model->subtitleRows(); QCOMPARE(files.size(), 2);
        for (int i = 0; i < files.size(); ++i) model->toggle(0, i);
        QVERIFY(model->save());
        QTRY_COMPARE_WITH_TIMEOUT(count(), size_t(4), 10000);
        QTRY_VERIFY_WITH_TIMEOUT(defaultSelected(), 5000);
        { vlc_player_locker lock{m_player};
          QCOMPARE(vlc_player_GetState(m_player), VLC_PLAYER_STATE_PAUSED);
          QVERIFY(qAbs(vlc_player_GetTime(m_player) - before) < VLC_TICK_FROM_MS(100));
          QCOMPARE(vlc_player_GetTrackCount(m_player, AUDIO_ES), audioCount); }
        model->refresh(); model->refresh(); QTest::qWait(150); QCOMPARE(count(), size_t(4));
        const auto saved = settings.value("Juxtopposed/SubtitleAttachments/v1").toByteArray();
        QVERIFY(stop()); model.reset();
        model = std::make_unique<SubtitleAttachmentModel>(m_player, &settings);
        QVERIFY(openFresh());
        QTRY_COMPARE_WITH_TIMEOUT(count(), size_t(4), 10000);
        QTRY_VERIFY_WITH_TIMEOUT(defaultSelected(), 5000);
        QCOMPARE(settings.value("Juxtopposed/SubtitleAttachments/v1").toByteArray(), saved);
        QVERIFY(stop()); QVERIFY(QFile::rename(firstPath, firstPath + ".moved.srt"));
        QVERIFY(openFresh());
        QTRY_COMPARE_WITH_TIMEOUT(m_controller->getPlayingState(), PlayerController::PLAYING_STATE_PLAYING, 10000);
        QTRY_VERIFY_WITH_TIMEOUT(!model->error().isEmpty(), 5000);
        QCOMPARE(count(), size_t(2)); // No partial attach or lower-priority fallback.
        QCOMPARE(settings.value("Juxtopposed/SubtitleAttachments/v1").toByteArray(), saved);
        QVERIFY(stop()); model.reset();
        { vlc_player_locker lock{m_player}; QCOMPARE(vlc_player_SetCurrentMedia(m_player, nullptr), VLC_SUCCESS); }
    }
    void attachmentAndPresetRestore_data()
    {
        QTest::addColumn<bool>("attachmentsFirst");
        QTest::newRow("production-preset-first") << false;
        QTest::newRow("attachment-first") << true;
    }
    void attachmentAndPresetRestore()
    {
        QFETCH(bool, attachmentsFirst);
        QTemporaryDir temporary; QVERIFY(temporary.isValid());
        const auto mediaPath = temporary.filePath("Preset attachment.mp4");
        const auto nextPath = temporary.filePath("Next attachment.mp4");
        QVERIFY(QFile::copy(m_fixture, mediaPath));
        QVERIFY(QFile::copy(m_fixture, nextPath));
        const auto first = temporary.filePath("First.en.srt"), second = temporary.filePath("Second.fi.srt");
        for (const auto &path : {first, second}) {
            QFile file(path); QVERIFY(file.open(QIODevice::WriteOnly));
            file.write("1\n00:00:00,000 --> 00:01:00,000\nPRESET ATTACHMENT\n");
        }
        auto stop = [&] {
            { vlc_player_locker lock{m_player}; vlc_player_Stop(m_player); }
            QElapsedTimer timer; timer.start();
            while (timer.elapsed() < 10000) {
                bool stopped;
                { vlc_player_locker lock{m_player}; stopped = vlc_player_GetState(m_player) == VLC_PLAYER_STATE_STOPPED; }
                if (stopped) return true;
                QTest::qWait(20);
            }
            return false;
        };
        auto openFresh = [&](const QString &path) {
            auto *item = input_item_New(QUrl::fromLocalFile(path).toEncoded().constData(), "Preset attachment fixture");
            if (!item) return false;
            vlc_player_locker lock{m_player};
            const auto result = vlc_player_SetCurrentMedia(m_player, item); input_item_Release(item);
            return result == VLC_SUCCESS && vlc_player_Start(m_player) == VLC_SUCCESS;
        };
        auto prefixFor = [](const QString &path) -> QByteArray {
            return QCryptographicHash::hash(QUrl::fromLocalFile(path).toEncoded(), QCryptographicHash::Md5).toHex() + '/';
        };
        auto selected = [&](const QString &path) {
            const auto prefix = prefixFor(path);
            vlc_player_locker lock{m_player};
            for (size_t i = 0; i < vlc_player_GetTrackCount(m_player, SPU_ES); ++i) {
                const auto *track = vlc_player_GetTrackAt(m_player, SPU_ES, i);
                if (track->selected && QByteArray(vlc_es_id_GetStrId(track->es_id)).startsWith(prefix)) return true;
            }
            return false;
        };
        auto count = [&] { vlc_player_locker lock{m_player}; return vlc_player_GetTrackCount(m_player, SPU_ES); };
        QVERIFY(stop());
        {
            SubtitleAttachmentModel::Context future;
            auto *item = input_item_New(QUrl::fromLocalFile(nextPath).toEncoded().constData(), "Next attachment fixture");
            QVERIFY(item); future.item.reset(item); input_item_Release(item);
            SubtitleAttachmentModel seed(nullptr, m_settings.get(), [&](bool) { return future; });
            QVERIFY(seed.begin()); QCOMPARE(seed.subtitleRows().size(), 2); seed.toggle(0, 0); QVERIFY(seed.save());
        }
        auto makeAttachments = [&] {
            return std::make_unique<SubtitleAttachmentModel>(m_player, m_settings.get(),
                SubtitleAttachmentModel::ContextProvider{}, [this] {
                    return !m_presets || !m_presets->hasTrackSelectionPolicy();
                });
        };
        auto attachments = makeAttachments();
        QVERIFY(openFresh(mediaPath));
        QTRY_COMPARE_WITH_TIMEOUT(count(), size_t(2), 10000);
        { vlc_player_locker lock{m_player}; vlc_player_SetTime(m_player, VLC_TICK_FROM_SEC(3)); vlc_player_Pause(m_player); }
        QTRY_COMPARE(m_controller->getPlayingState(), PlayerController::PLAYING_STATE_PAUSED);
        QVERIFY(attachments->begin()); QCOMPARE(attachments->subtitleRows().size(), 2);
        attachments->toggle(0, 0); attachments->toggle(0, 1); QVERIFY(attachments->save());
        QTRY_COMPARE_WITH_TIMEOUT(count(), size_t(4), 10000);
        QTRY_VERIFY_WITH_TIMEOUT(selected(first), 5000);
        {
            const auto prefix = prefixFor(second);
            vlc_player_locker lock{m_player};
            bool found = false;
            for (size_t i = 0; i < vlc_player_GetTrackCount(m_player, SPU_ES); ++i) {
                const auto *track = vlc_player_GetTrackAt(m_player, SPU_ES, i);
                if (!QByteArray(vlc_es_id_GetStrId(track->es_id)).startsWith(prefix)) continue;
                vlc_player_SelectTrack(m_player, track, VLC_PLAYER_SELECT_EXCLUSIVE);
                QCOMPARE(vlc_player_SetEsIdDelay(m_player, track->es_id, 175000, VLC_PLAYER_WHENCE_ABSOLUTE), VLC_SUCCESS);
                found = true;
            }
            QVERIFY(found);
            QCOMPARE(vlc_player_SetCategoryDelay(m_player, SPU_ES, 250000, VLC_PLAYER_WHENCE_ABSOLUTE), VLC_SUCCESS);
            vlc_player_SetAssociatedSubsFPS(m_player, 30.f);
        }
        QTRY_VERIFY_WITH_TIMEOUT(selected(second), 5000);
        QTRY_VERIFY_WITH_TIMEOUT(m_presets->canSave(), 5000);
        QVERIFY(m_presets->save(QStringLiteral("Attachment restore %1").arg(attachmentsFirst)));
        const auto savedId = m_presets->selectedId();
        QVERIFY(stop()); attachments.reset(); m_presets.reset();
        { vlc_player_locker lock{m_player}; QCOMPARE(vlc_player_SetCurrentMedia(m_player, nullptr), VLC_SUCCESS); }
        auto makePresets = [&] {
            m_presets = std::make_unique<SubtitlePresetModel>(m_player, m_controller->getSubtitleAppearance(),
                m_settings.get(), VLC_OBJECT(m_environment->intf));
        };
        if (attachmentsFirst) {
            attachments = makeAttachments(); makePresets();
        } else {
            makePresets(); attachments = makeAttachments();
        }
        QVERIFY(openFresh(mediaPath));
        QTRY_COMPARE_WITH_TIMEOUT(count(), size_t(4), 10000);
        QTRY_COMPARE_WITH_TIMEOUT(m_presets->selectedId(), savedId, 6000);
        QTRY_VERIFY_WITH_TIMEOUT(!m_presets->restoring() && selected(second), 6000);
        QTest::qWait(500);
        QVERIFY(selected(second)); QVERIFY(!selected(first));
        QVERIFY(!m_presets->edited()); QCOMPARE(m_presets->error(), QString());
        {
            vlc_player_locker lock{m_player};
            QCOMPARE(vlc_player_GetSubtitleDelay(m_player), vlc_tick_t(250000));
            QCOMPARE(vlc_player_GetAssociatedSubsFPS(m_player), 30.f);
            const auto prefix = prefixFor(second);
            for (size_t i = 0; i < vlc_player_GetTrackCount(m_player, SPU_ES); ++i) {
                const auto *track = vlc_player_GetTrackAt(m_player, SPU_ES, i);
                if (QByteArray(vlc_es_id_GetStrId(track->es_id)).startsWith(prefix))
                    QCOMPARE(vlc_player_GetEsIdDelay(m_player, track->es_id), vlc_tick_t(175000));
            }
        }
        // A-B transition: A's named preset must not suppress B's attachment
        // default, even when attachment callbacks are registered first.
        QVERIFY(openFresh(nextPath));
        // Keep Qt callbacks queued while B's native input becomes ready, then
        // exercise the attachment refresh against A's still-cached preset.
        bool nextReady = false;
        QElapsedTimer nextDeadline; nextDeadline.start();
        while (nextDeadline.elapsed() < 10000) {
            {
                vlc_player_locker lock{m_player};
                auto *current = vlc_player_GetCurrentMedia(m_player);
                char *uri = current ? input_item_GetURI(current) : nullptr;
                nextReady = uri && QByteArray(uri) == QUrl::fromLocalFile(nextPath).toEncoded()
                    && vlc_player_GetState(m_player) == VLC_PLAYER_STATE_PLAYING
                    && vlc_player_GetTrackCount(m_player, SPU_ES) == 2;
                free(uri);
            }
            if (nextReady) break;
            QThread::msleep(10);
        }
        QVERIFY(nextReady); QCOMPARE(m_presets->selectedId(), savedId);
        attachments->refresh();
        QTRY_COMPARE_WITH_TIMEOUT(count(), size_t(3), 10000);
        QTRY_VERIFY_WITH_TIMEOUT(selected(first), 5000);
        QTRY_VERIFY_WITH_TIMEOUT(!m_presets->restoring(), 5000);
        QCOMPARE(m_presets->selectedId(), QStringLiteral("default"));
        QVERIFY(stop()); attachments.reset();
        { vlc_player_locker lock{m_player}; QCOMPARE(vlc_player_SetCurrentMedia(m_player, nullptr), VLC_SUCCESS); }
    }
    void cleanupTestCase()
    {
        // Listener owners and held IDs die before their real native interface,
        // playlist/player and LibVLC instance; no controller survives the env.
        m_presets.reset();
        m_controller.reset();
        m_first.reset(); m_second.reset();
        if (m_environment && m_environment->intf)
            m_environment->intf->p_mainPlayerController = nullptr;
        m_player = nullptr;
        m_environment.reset();
        m_settings.reset();
    }
};
QTEST_GUILESS_MAIN(TestPlayerSubtitleDelay)
#include "test_player_subtitle_delay.moc"
