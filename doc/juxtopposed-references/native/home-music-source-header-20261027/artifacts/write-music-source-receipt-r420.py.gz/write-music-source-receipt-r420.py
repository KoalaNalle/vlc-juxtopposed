from pathlib import Path
from hashlib import sha256
import gzip,json,subprocess

work=Path(__file__).resolve().parent
repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
receipt=repo/'doc/juxtopposed-references/native/home-music-source-header-20261027'
assert not receipt.exists()
gui=read(work/'ui-music-source-r419/verification.json')
native=read(work/'native-music-source-r402/verification.json')
assert gui['normalExit'] and gui['exitCode']==0 and gui['moduleCounts']==['602'] and not gui['diagnostics']
assert all(gui[k] for k in ['sourceInputsUnchanged','runtimeUnchanged','baseRuntimeUnchanged','producerUnchanged','pluginCacheUnchanged','musicFixturesUnchanged','fixturesUnchanged','extraFixturesUnchanged','chapterFixturesUnchanged','lateFixturesUnchanged','decodeFixturesUnchanged'])
assert native['normalExit'] and not any(i['type']=='fail' for f in native['functions'] for i in f['incidents'])
manifest=read(work/'inputs-r418.json')
assert all(digest(repo/name)==value for name,value in manifest['files'].items())
native_manifest=read(work/'inputs-r401.json')
native_names=['modules/gui/qt/player/local_music_folder.cpp','modules/gui/qt/player/local_music_folder.hpp','modules/gui/qt/tests/test_local_music_folder.cpp']
assert all(native_manifest['files'][name]==manifest['files'][name] for name in native_names)
assert read(work/'component-music-source-r417/music-player-verification.json')['resourceAliasesVerified']
assert all(native[k] for k in ['sourceInputsUnchanged','baseRuntimeUnchanged','runtimeUnchanged','producerUnchanged','testExecutableUnchanged'])
assert read(work/'component-titlebar-source-r409/verification.json')['passed']
source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert source_commit.startswith('d80fb40b3a')
receipt.mkdir()
artifacts=receipt/'artifacts';artifacts.mkdir()
files=[]
for name in ['inputs-r401.json','inputs-r408.json','inputs-r414.json','inputs-r418.json',
 'build-music-source-r401.sh','build-music-source-r401.log','build-music-source-r401-exit.txt',
 'build-music-header-r408.sh','build-music-header-r408.log','build-music-header-r408-exit.txt',
 'build-music-header-r414.sh','build-music-header-r414.log','build-music-header-r414-exit.txt',
 'build-music-header-r418.sh','build-music-header-r418.log','build-music-header-r418-exit.txt',
 'freeze-music-header-r408.py','run-native-music-source-r402.py','run-ui-music-header-r418.py',
 'inspect-music-header-assets-r403.py','inspect-music-header-assets-r404.py',
 'music-header-assets-r404/assets.json',
 'native-music-source-r402/verification.json','native-music-source-r402/results.xml','native-music-source-r402/producer.py',
 'component-music-source-before-r405/test-source.py','component-music-source-before-r405/music-player-before.qml','component-music-source-before-r405/outcome.json',
 'component-music-menu-before-r416/test-source.py','component-music-menu-before-r416/music-player-before.qml','component-music-menu-before-r416/outcome.json',
 'component-titlebar-source-r409/verification.json',
 'ui-music-source-r411/verification.json','ui-music-source-r411/scope-observations.json','ui-music-source-r411/vlc.log',
 'ui-music-source-r415/verification.json','ui-music-source-r415/scope-observations.json',
 'ui-music-source-r419/verification.json','ui-music-source-r419/vlc.log','ui-music-source-r419/stderr.txt',
 'ui-music-source-r419/producer.py','ui-music-source-r419/launch.json','ui-music-source-r419/layout-fixture.json',
 'ui-music-source-r419/settings-before.ini','ui-music-source-r419/settings-after.ini',
 'ui-music-source-r419/config-before.txt','ui-music-source-r419/config-after.txt',
 'write-music-source-receipt-r420.py']:
    files.append(work/name)
files.extend(p for p in (work/'component-music-source-r417').iterdir() if p.is_file())
files.extend(p for p in (work/'ui-music-source-r419/observations').iterdir()
             if p.is_file() and 'external-folder-window' not in p.name)
for directory,prefixes in [('ui-music-source-r411',['01-cold-small','02-wide']),
                           ('ui-music-source-r415',['03-compact-ancestor-submenu','05-ancestor-menu-retained'])]:
    files.extend(p for p in (work/directory/'observations').iterdir()
                 if p.is_file() and any(p.name.startswith(prefix) for prefix in prefixes))
inventory=[]
for path in sorted(set(files)):
    data=path.read_bytes()
    name=path.relative_to(work).as_posix().replace('/','__')+'.gz'
    payload=gzip.compress(data,mtime=0)
    target=artifacts/name;assert not target.exists();target.write_bytes(payload)
    assert gzip.decompress(target.read_bytes())==data
    inventory.append(dict(file='artifacts/'+name,source=path.relative_to(repo).as_posix(),
                          sha256=sha256(data).hexdigest(),gzipSha256=digest(target),bytes=len(data),compressedBytes=len(payload)))
observations=work/'ui-music-source-r419/observations'
def progress(name):
    import re
    data=read(observations/(name+'.json'))
    return float(re.search(r'Progress Value: ([0-9.]+)',data['accessibility']['tree'])[1])
held=[progress(name) for name in ['13-paused-after-history','14-source-hidden','15-source-badge-reopened',
 '16-play-queue-mode','17-queue-list-mode','18-current-track-folder','19-search-empty-paused','20-search-cleared-paused','21-home-paused','22-home-return']]
assert len(set(held))==1
checkpoint=dict(sourceCommit=source_commit,fullBetaAccepted=False,finalPackageAccepted=False,
 runtime='build-windows/beta-single-frame-20261025-night/ui-music-source-r419/runtime',
 runtimeSha256=gui['runtimeSha256'],ordinaryExitCode=gui['exitCode'],plugins=gui['moduleCounts'],checkedDiagnostics=gui['diagnostics'],
 nativeTestFunctions=len(native['functions']),nativeSourceMatchesFinalGuiInputs=True,
 componentResourceAliasesVerified=True,pausedPosition=held[0],pausedPositionRetainedAcrossTenObservations=True,
 externalFileManagerWindowObserved=True,externalFileManagerRawObservationExcluded=True,
 firewallRulesAdded=[],firewallRulesChanged=[],firewallSettingsChanged=False,
 limits=['Scoped music-header journeys only','Full visual scores and actual Windows DPI remain open',
 'UIA focused_element remained stale; actual Enter activation was observed but screen-reader behavior remains open',
 'Source-search placeholder contrast needs a follow-up',
 'Cover layout is a functional adaptation using the shared library card'],artifacts=inventory)
write(receipt/'checkpoint.json',checkpoint)
(receipt/'README.md').write_text(f'''# Music source header and folder history

27 October 2026. Source `{source_commit[:10]}`. This is a scoped nightly checkpoint;
the beta and final-package gates remain open.

## Result

The music source panel has native per-player Back/Forward history and real local
ancestor URLs. Browsing changes the displayed folder without changing the playing
input or queue. History is bounded to64 locations and is not saved to settings.
Current track folder returns to the input's origin. A separate external-folder
button opens the browsed directory. The title-strip badge follows the actual
folder or Play Queue and reopens/focuses the inline panel rather than returning
to unrelated library History.

The header retains the original two-row geometry,20px padding and exported SVGs.
Source options and ancestors remain reachable through the compact folder caption.
Cover view reuses the existing library card; this layout is a functional adaptation
for the referenced view action, not a newly claimed original music-player frame.

## Evidence and limits

- Native LocalMusicFolder test:9 QtTest functions including init/cleanup, no failed
  incidents, normal exit and all guards. Covers actual folder data/history,
  rejected locations without losing Forward, rapid folder/source changes,
  unchanged queue/audio callbacks while browsing, real playback/reuse and worker
  teardown. Its three native sources match the final GUI input manifest.
- Maintained music component: the preceding header fails on missing Forward.
  A second negative control reproduces a menu remaining visible when native-style
  synchronous navigation replaces its selected delegate. The final test passes
  actual qrc aliases, disabled/history/ancestor/external actions, menu dismissal
  and palette, list/cover selection and keyboard activation, search, queue fallback,
  loading/error/empty states and five component-scaled layouts. Title-strip12
  geometry cases and source-description/controller seams pass separately.
- Ordinary GUI418 `{gui['runtimeSha256']['plugins/gui/libqt_plugin.dll'][:8]}`,
  Core265 `fdfcfcd5`, library282 `13ccdc36`, recording322 `930205b1`:
  cold602x421 and wide window, compact ancestor navigation/dismissal, Back/Forward,
  empty parent, original icons, actual File Pilot folder window, cover click without
  playback and Enter starting Second light, playing parent/Back, paused source badge,
  real three-item queue/list/folder modes, no-match search/Escape and Home/return.
  Ten paused observations retain position `{held[0]}`. Final normal exit0,
  602plugins, zero checked errors including missing SVG resources, and all source,
  runtime, producer, cache and fixture ending guards pass.
- Raw File Pilot observation stays ignored. All retained media/UI journeys use
  generated project fixtures; no personal media is packaged here. No firewall,
  Defender, security/privacy choices or rules were changed by these checks.

The preliminary GUI408 run preserves the squeezed compact label and missing qrc
menu alias. GUI414 preserves the white/retained ancestor menu. Both close normally;
their checked-error count alone did not establish header acceptance. The first
asset inspector stopped on a zero-alpha unrelated existing SVG; the revised
inspector tolerates such existing assets while requiring visible new exports.
No unrelated SVG was changed. Component run412 completed its assertions but failed
Windows temporary-font cleanup; later outputs keep the resource mirror ignored
with verification artifacts and terminate normally.

Actual Windows100/150/200% DPI, complete Dark/Light/System/accent states,
screen-reader behavior, risky media/instance combinations, final-package testing
and the full visual scoring gates remain open. Native UIA focused-element reports
were stale across several actions, despite the observed correct Enter activation;
this is not screen-reader acceptance. The existing source-search placeholder was
hard to read in Dark mode and needs a follow-up.

## Provenance

Figma file `zdNUYRVOH9lEtIxMYvh8DV`, open music frame `4778:25123`, header
`I4778:25149;4778:25000` and its two rows. Use the complete cached subtree retained
by the [navigation receipt](../home-music-navigation-20261027/README.md); sparse
follow-up wrappers did not replace it. Original art is unchanged. Sort/Search
reuse exact existing renders; More reuses the equivalent existing18px asset through
its qrc alias. Four other original exports are copied byte-for-byte with authored
horizontal mirroring. The asset hashes and input manifests are retained below.

`checkpoint.json` records exact binaries and each compressed artifact's original
and compressed SHA-256. Decompression was verified. Large binaries and isolated
profiles remain ignored on the development SSD. This receipt does not contain a
release package or claim that the complete music surface is accepted.
''',encoding='utf-8',newline='\n')
print(json.dumps(dict(receipt=str(receipt),artifacts=len(inventory),compressedBytes=sum(i['compressedBytes'] for i in inventory),sourceCommit=source_commit)),flush=True)
