#!/usr/bin/env bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-music-source-r401.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-music-source-r401-exit.txt"; exit "$code"' EXIT
out="$work/native-music-source-r401-bin"
test ! -e "$out"
mkdir "$out"
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = fdfcfcd599588512bb7f3a51e46305b7b0d947b47387dd205851feb45f032b46
sha256sum "$repo/modules/gui/qt/player/local_music_folder.cpp" "$repo/modules/gui/qt/player/local_music_folder.hpp" "$repo/modules/gui/qt/tests/test_local_music_folder.cpp" > "$out/inputs.sha256"
if test -f "$base/win64/modules/gui/qt/test_qt_local_music_folder.exe"; then
    cp "$base/win64/modules/gui/qt/test_qt_local_music_folder.exe" "$out/previous-test_qt_local_music_folder.exe"
fi
make -C "$base/win64/modules/gui/qt" -j2 test_qt_local_music_folder.exe
cp "$base/win64/modules/gui/qt/test_qt_local_music_folder.exe" "$out/"
sha256sum -c "$out/inputs.sha256"
sha256sum "$out/test_qt_local_music_folder.exe"
test "$(sha256sum "$base/win64/src/.libs/libvlccore.dll" | cut -d' ' -f1)" = fdfcfcd599588512bb7f3a51e46305b7b0d947b47387dd205851feb45f032b46
