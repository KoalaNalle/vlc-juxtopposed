from pathlib import Path
from hashlib import sha256
import json, os
os.environ['QT_QPA_PLATFORM']='offscreen'
from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QGuiApplication,QImage,QPainter,QColor,QFont
from PySide6.QtSvg import QSvgRenderer
app=QGuiApplication([])
work=Path(__file__).resolve().parent;repo=work.parents[1]
out=work/'music-header-assets-r404';out.mkdir(exist_ok=False)
specs=[('back','785d7.svg',True),('forward','a7541.svg',True),('more','54fdc.svg',True),
       ('external','6dd1e.svg',True),('sort','c1afe.svg',False),('view','fcd8d.svg',False),('search','80d5a.svg',False)]
def render(path, require_visible=True):
    svg=QSvgRenderer(str(path));assert svg.isValid(),path
    image=QImage(240,240,QImage.Format_RGBA8888);image.fill(0)
    painter=QPainter(image);svg.render(painter,QRectF(0,0,240,240));painter.end()
    raw=bytes(image.constBits());alpha=raw[3::4]
    assert not require_visible or any(alpha),path
    return image,[svg.defaultSize().width(),svg.defaultSize().height()],sha256(raw).hexdigest(),sha256(alpha).hexdigest()
existing=[]
for path in (repo/'modules/gui/qt/pixmaps/juxtopposed').glob('*.svg'):
    image,size,raw,alpha=render(path, False);existing.append((path.name,size,raw,alpha))
sheet=QImage(1120,210,QImage.Format_RGBA8888);sheet.fill(QColor('#191919'))
painter=QPainter(sheet);painter.setPen(QColor('#dddddd'));painter.setFont(QFont('Segoe UI',10))
rows=[]
for i,(slot,filename,mirror) in enumerate(specs):
    path=work/'figma-music-header-r400'/filename
    image,size,raw,alpha=render(path)
    picture=image.mirrored(True,False) if mirror else image
    picture.save(str(out/(slot+'.png')))
    painter.drawImage(QRectF(i*160+20,20,120,120),picture)
    painter.drawText(i*160+14,166,slot)
    painter.drawText(i*160+14,187,filename+' '+str(size[0]))
    rows.append(dict(slot=slot,filename=filename,rootDimensions=size,mirror=mirror,
        sourceSha256=sha256(path.read_bytes()).hexdigest(),renderSha256=raw,alphaSha256=alpha,
        exactRenderMatches=[name for name,s,r,a in existing if s==size and r==raw],
        exactAlphaMatches=[name for name,s,r,a in existing if s==size and a==alpha]))
painter.end();assert sheet.save(str(out/'contact-sheet.png'))
(out/'assets.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
print(json.dumps(rows))
