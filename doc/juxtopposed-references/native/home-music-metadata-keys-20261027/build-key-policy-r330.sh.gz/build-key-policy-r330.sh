#!/bin/bash
set -euo pipefail
base=/root/vlc-juxtopposed-build
repo=/mnt/c/Modding/vlc-juxtopposed
work="$repo/build-windows/beta-single-frame-20261025-night"
exec 9> "$base/.vlc-build.lock"
flock -n 9
export PATH="$base/extras/tools/build/bin:$base/contrib/bin:$PATH"
unset CC CXX
exec > "$work/build-key-policy-r330.log" 2>&1
trap 'code=$?; printf "%s\n" "$code" > "$work/build-key-policy-r330-exit.txt"; exit "$code"' EXIT
out="$base/owned-key-policy-20261027-r330"
test ! -e "$out"
test ! -e "$work/key-policy-r330-bin"
make -C "$base/win64/modules/gui/qt" -f Makefile -f "$repo/modules/gui/qt/tests/native_library/key-routing.mk" -j2 ROUTING_OUT="$out" key-routing-native
mkdir "$work/key-policy-r330-bin"
cp "$out/.libs/test_qt_shared_modal_hotkeys.exe" "$out/shared_modal_hotkey_production.inc" "$out/shared_modal_hotkey_production.inc.json" "$work/key-policy-r330-bin/"
sha256sum "$work/key-policy-r330-bin/"*
