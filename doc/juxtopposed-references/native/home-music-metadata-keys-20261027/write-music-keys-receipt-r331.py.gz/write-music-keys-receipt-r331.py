from pathlib import Path
from hashlib import sha256
import gzip,json
work=Path(__file__).resolve().parent;repo=work.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:sha256(p.read_bytes()).hexdigest()
before=read(work/'ui-customizer-metadata-r327/verification.json')
fixed=read(work/'ui-music-keys-fixed-r330/verification.json')
native=read(work/'native-key-policy-r330/verification.json')
assert before['normalExit'] and not before['diagnostics'] and not before['sourceInputsUnchanged']
assert all(v for k,v in before.items() if k.endswith('Unchanged') and k!='sourceInputsUnchanged')
old=read(work/'inputs-r327.json')
changes=[p for p,h in old['files'].items() if digest(repo/p)!=h]
assert changes==['modules/gui/qt/player/qml/JuxtopposedMusicPlayer.qml']
for record in [fixed,native]:
    assert record['normalExit'] and all(v for k,v in record.items() if k.endswith('Unchanged'))
assert fixed['moduleCounts']==['602'] and not fixed['diagnostics']
assert not native['failures'] and '28 passed, 0 failed, 0 skipped' in native['totals'][0]

def tree(name):
    return read(work/'ui-music-keys-fixed-r330/observations'/(name+'.json'))['accessibility']['tree']

assert 'File Name: 2-Second light.flac' in tree('05-fixed-enter-activation')
assert 'File Name: 1-First light.flac' in tree('07-fixed-space-activates-selected-first-song')
assert 'Artist Name: Another Artist' in tree('09-fixed-arrow-enter-another-artist')
assert 'Playlist Name: Renamed Nightly' in tree('12-fixed-unicode-playlist-metadata')
assert 'Playlist Name: Accepted <b>Nightly' in tree('17-fixed-renamed-literal-metadata-held')
assert 'Progress Value: 0.3537280333333333' in tree('16-fixed-rename-saved-paused-clock')
assert 'Progress Value: 0.3537280333333333' in tree('17-fixed-renamed-literal-metadata-held')
out=repo/'doc/juxtopposed-references/native/home-music-metadata-keys-20261027'
assert not out.exists();out.mkdir()
artifacts=[]
def retain(p):
    name=p.relative_to(work).as_posix()+'.gz';target=out/name;target.parent.mkdir(parents=True,exist_ok=True)
    raw=p.read_bytes();target.write_bytes(gzip.compress(raw,mtime=0))
    artifacts.append(dict(path=name,sha256=digest(target),rawSha256=sha256(raw).hexdigest()))
for name in ['ui-customizer-metadata-r327','ui-music-keys-fixed-r330','native-key-policy-r330']:
    root=work/name
    for filename in ['verification.json','producer.py','launch.json','staging.json','layout-fixture.json','qtest.txt','qtest.xml']:
        if (root/filename).is_file():retain(root/filename)
    for p in sorted((root/'observations').glob('*')):
        if p.suffix in ['.json','.png']:
            # Misleading early names about origin clearing are not acceptance
            # evidence. The folder action reuses an existing native queue entry.
            if name=='ui-customizer-metadata-r327' and p.name.startswith(('25-','26-','27-')):continue
            retain(p)
for p in sorted((work/'component-music-keys-r329').glob('*')):
    if p.suffix in ['.json','.png']:retain(p)
for filename in ['inputs-r327.json','inputs-r329.json','inputs-r330.json','freeze-music-keys-r330.py',
    'build-music-keys-r329.sh','build-customizer-r329-exit.txt','build-key-policy-r330.sh','build-key-policy-r330-exit.txt',
    'run-key-policy-r330.py','run-ui-music-keys-r330.py','write-music-keys-receipt-r331.py']:
    retain(work/filename)
for p in sorted((work/'key-policy-r330-bin').glob('*.inc*')):retain(p)
result=dict(status='passed-scoped-music-metadata-and-mouse-focused-activation',fullBetaAccepted=False,
    runtimeSha256=fixed['runtimeSha256'],nativeExecutableSha256=native['runtimeSha256']['test_qt_shared_modal_hotkeys.exe'],
    sourceSha256=digest(repo/'modules/gui/qt/player/qml/JuxtopposedMusicPlayer.qml'),
    invalidatedBeforeRun=dict(sourceInputsUnchanged=False,changedFiles=changes,normalExit=True,ordinaryAcceptance=False),
    observations=[
        'Before: mouse-selecting Second light highlights it while First light stays paused; Return does not activate it. Pointer double-click does activate it. The music pane lacked the navigationKeyScope consumed by the actual window filter for mouse focus without visualFocus.',
        'The music pane now declares the existing navigation ownership contract. In ordinary GUI329 mouse-select Second then Return starts Second; mouse-select First then Space starts First rather than resuming Second. Up selects another row without changing the playing source; Return starts that different artist.',
        'Existing music component suite passes selection/keyboard, Add/back/search/sort, model fallback, loading/error/empty and five simulated-scale/layout variants. The exact-production native key-routing suite passes28/0/0, including native callbacks, mouse-focused navigation, timeline/volume/queue scope, modal routing and preserved unclaimed/modified hotkeys. Neither test alone instantiates the ordinary application focus scene.',
        'Current-tuple ordinary metadata covers video with absent artist/playlist, tagged songs with blue/orange real generated covers, a different artist and filename, Unicode filename/artist/folder, explicit native named-playlist origin and live rename. Literal Accepted <b>Nightly äö</b> is retained in the text label. The21.223682-second paused position stays exactly held during rename and return.',
        'The real native rename popup moves135pixels right and45down by its title bar. First attempted drag exceeded the observed208pixel window width and was rejected before a successful bounded retry. Native popup keyboard entry and pointer save use its returned separate window.',
        'Accepted GUI329 app exits0/602modules/zero errors with every source/runtime/base/media/cache/producer guard intact. The before app also exits0/zero errors, but its producer exits1 because the music QML was edited after requesting Quit and before its final source check. Only that one source changed. Its original failed verification is retained and is not promoted to a fully guarded pass; relevant metadata and keyboard journeys were repeated on GUI329.'
    ],limits=[
        'Toolbar data was preseeded in isolated generated-media profile fixtures; this does not prove gesture installation of each metadata tile. Actual Snapshot Add/Save has separate evidence.',
        'Folder addAndPlay intentionally reuses the first existing native queue entry with the same URL. Its genuine playlist origin therefore remains; early before-run capture names suggesting origin clearing were incorrect expectations, not observed behavior. No queue-origin policy changed.',
        'Simulated uiScale/component geometry does not qualify Windows OS-DPI, screen readers, every theme/monitor or final-package fidelity. Global shortcut registration/full action coverage and other beta gates remain open.',
        'Only generated owned media, profiles and playlists were used. Raw configs/databases/personal logs/media and binaries remain ignored locally. No security/privacy choices changed and no process was forcibly cleaned up.'
    ],artifacts=artifacts)
(out/'checkpoint.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Music source keys and metadata - 27 October 2026

Mouse-selected music source rows lost Enter/Space to the window's player-key
policy. Declaring their existing navigation-key ownership fixes ordinary Enter,
Space and arrow/Enter activation on GUI329. The music component suite passes;
the exact-production native routing suite passes28/0/0.

Ordinary metadata checks cover video, tagged songs, different artists/covers,
Unicode filename/artist/folder and native named-playlist origin. A live literal
playlist rename updates the toolbar while the paused clock stays held. The real
rename popup moves by its title bar. The accepted app exits0/602modules/zero
errors with all guards intact.

The before run's source guard was invalidated by editing after requesting Quit;
its original failure is retained, and relevant journeys were repeated on the
fixed build. See the [checkpoint](checkpoint.json) for exact scope/identities and
limitations. OS-DPI, broad accessibility and final-package acceptance remain
open. Continue from [STATUS](../../../juxtopposed/STATUS.md).
''',encoding='utf-8',newline='\n')
for artifact in artifacts:
    p=out/artifact['path'];assert digest(p)==artifact['sha256']
    assert sha256(gzip.decompress(p.read_bytes())).hexdigest()==artifact['rawSha256']
print(out,len(artifacts),'verified artifacts',flush=True)
